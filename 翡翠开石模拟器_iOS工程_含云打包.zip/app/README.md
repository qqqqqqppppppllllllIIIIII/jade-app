# 璞玉 · 开石模拟器

3D 翡翠开石小游戏。购买原石，控制切割温度以减少裂纹，抛光后鉴定估价并售出，逐步收集翡翠图鉴。

## 操作

- 鼠标或触控：选石、点击按钮。
- 切割与抛光：按住操作按钮，或按住空格；切割时松开可降温。
- Esc：暂停或继续。
- 金币、最高估价和图鉴仅保存在当前浏览器，不跨设备同步。

## 网页运行

```bash
npm install
npm run build
npm run preview
```

## iOS 工程

`ios/App/App.xcworkspace` 是 Capacitor 原生工程。需使用 macOS、Xcode 和 CocoaPods：

```bash
npm install
npm run build
npx cap sync ios
cd ios/App
pod install
open App.xcworkspace
```

在 Xcode 选择 Apple 开发团队并连接 iPhone 后运行。要生成未签名 IPA，可在 Xcode 中以 Any iOS Device 构建，再导出或整理 `.app` 为 `Payload` 目录并压缩为 IPA；未签名 IPA 仍不能直接在普通 iPhone 上安装，需要有效签名。
