(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))r(l);new MutationObserver(l=>{for(const c of l)if(c.type==="childList")for(const h of c.addedNodes)h.tagName==="LINK"&&h.rel==="modulepreload"&&r(h)}).observe(document,{childList:!0,subtree:!0});function i(l){const c={};return l.integrity&&(c.integrity=l.integrity),l.referrerPolicy&&(c.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?c.credentials="include":l.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function r(l){if(l.ep)return;l.ep=!0;const c=i(l);fetch(l.href,c)}})();var xd={exports:{}},cl={};var U0;function HE(){if(U0)return cl;U0=1;var o=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function i(r,l,c){var h=null;if(c!==void 0&&(h=""+c),l.key!==void 0&&(h=""+l.key),"key"in l){c={};for(var d in l)d!=="key"&&(c[d]=l[d])}else c=l;return l=c.ref,{$$typeof:o,type:r,key:h,ref:l!==void 0?l:null,props:c}}return cl.Fragment=e,cl.jsx=i,cl.jsxs=i,cl}var N0;function GE(){return N0||(N0=1,xd.exports=HE()),xd.exports}var _t=GE(),yd={exports:{}},ce={};var L0;function VE(){if(L0)return ce;L0=1;var o=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),i=Symbol.for("react.fragment"),r=Symbol.for("react.strict_mode"),l=Symbol.for("react.profiler"),c=Symbol.for("react.consumer"),h=Symbol.for("react.context"),d=Symbol.for("react.forward_ref"),m=Symbol.for("react.suspense"),g=Symbol.for("react.memo"),_=Symbol.for("react.lazy"),p=Symbol.for("react.activity"),x=Symbol.for("react.view_transition"),M=Symbol.iterator;function E(H){return H===null||typeof H!="object"?null:(H=M&&H[M]||H["@@iterator"],typeof H=="function"?H:null)}var b={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},y=Object.assign,S={};function U(H,ft,$){this.props=H,this.context=ft,this.refs=S,this.updater=$||b}U.prototype.isReactComponent={},U.prototype.setState=function(H,ft){if(typeof H!="object"&&typeof H!="function"&&H!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,H,ft,"setState")},U.prototype.forceUpdate=function(H){this.updater.enqueueForceUpdate(this,H,"forceUpdate")};function N(){}N.prototype=U.prototype;function D(H,ft,$){this.props=H,this.context=ft,this.refs=S,this.updater=$||b}var I=D.prototype=new N;I.constructor=D,y(I,U.prototype),I.isPureReactComponent=!0;var z=Array.isArray;function L(){}var B={H:null,A:null,T:null,S:null},C=Object.prototype.hasOwnProperty;function R(H,ft,$){var at=$.ref;return{$$typeof:o,type:H,key:ft,ref:at!==void 0?at:null,props:$}}function G(H,ft){return R(H.type,ft,H.props)}function Z(H){return typeof H=="object"&&H!==null&&H.$$typeof===o}function et(H){var ft={"=":"=0",":":"=2"};return"$"+H.replace(/[=:]/g,function($){return ft[$]})}var ct=/\/+/g;function st(H,ft){return typeof H=="object"&&H!==null&&H.key!=null?et(""+H.key):ft.toString(36)}function k(H){switch(H.status){case"fulfilled":return H.value;case"rejected":throw H.reason;default:switch(typeof H.status=="string"?H.then(L,L):(H.status="pending",H.then(function(ft){H.status==="pending"&&(H.status="fulfilled",H.value=ft)},function(ft){H.status==="pending"&&(H.status="rejected",H.reason=ft)})),H.status){case"fulfilled":return H.value;case"rejected":throw H.reason}}throw H}function it(H,ft,$,at,Et){var Ut=typeof H;(Ut==="undefined"||Ut==="boolean")&&(H=null);var Rt=!1;if(H===null)Rt=!0;else switch(Ut){case"bigint":case"string":case"number":Rt=!0;break;case"object":switch(H.$$typeof){case o:case e:Rt=!0;break;case _:return Rt=H._init,it(Rt(H._payload),ft,$,at,Et)}}if(Rt)return Et=Et(H),Rt=at===""?"."+st(H,0):at,z(Et)?($="",Rt!=null&&($=Rt.replace(ct,"$&/")+"/"),it(Et,ft,$,"",function(F){return F})):Et!=null&&(Z(Et)&&(Et=G(Et,$+(Et.key==null||H&&H.key===Et.key?"":(""+Et.key).replace(ct,"$&/")+"/")+Rt)),ft.push(Et)),1;Rt=0;var St=at===""?".":at+":";if(z(H))for(var kt=0;kt<H.length;kt++)at=H[kt],Ut=St+st(at,kt),Rt+=it(at,ft,$,Ut,Et);else if(kt=E(H),typeof kt=="function")for(H=kt.call(H),kt=0;!(at=H.next()).done;)at=at.value,Ut=St+st(at,kt++),Rt+=it(at,ft,$,Ut,Et);else if(Ut==="object"){if(typeof H.then=="function")return it(k(H),ft,$,at,Et);throw ft=String(H),Error("Objects are not valid as a React child (found: "+(ft==="[object Object]"?"object with keys {"+Object.keys(H).join(", ")+"}":ft)+"). If you meant to render a collection of children, use an array instead.")}return Rt}function j(H,ft,$){if(H==null)return H;var at=[],Et=0;return it(H,at,"","",function(Ut){return ft.call($,Ut,Et++)}),at}function xt(H){if(H._status===-1){var ft=H._result,$=ft();$.then(function(at){(H._status===0||H._status===-1)&&(H._status=1,H._result=at,$.status===void 0&&($.status="fulfilled",$.value=at))},function(at){(H._status===0||H._status===-1)&&(H._status=2,H._result=at,$.status===void 0&&($.status="rejected",$.reason=at))}),H._status===-1&&(H._status=0,H._result=$)}if(H._status===1)return H._result.default;throw H._result}var Mt=typeof reportError=="function"?reportError:function(H){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var ft=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof H=="object"&&H!==null&&typeof H.message=="string"?String(H.message):String(H),error:H});if(!window.dispatchEvent(ft))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",H);return}console.error(H)};function Ht(H){var ft=B.T,$={};$.types=ft!==null?ft.types:null,B.T=$;try{var at=H(),Et=B.S;Et!==null&&Et($,at),typeof at=="object"&&at!==null&&typeof at.then=="function"&&at.then(L,Mt)}catch(Ut){Mt(Ut)}finally{ft!==null&&$.types!==null&&(ft.types=$.types),B.T=ft}}function oe(H){var ft=B.T;if(ft!==null){var $=ft.types;$===null?ft.types=[H]:$.indexOf(H)===-1&&$.push(H)}else Ht(oe.bind(null,H))}var xe={map:j,forEach:function(H,ft,$){j(H,function(){ft.apply(this,arguments)},$)},count:function(H){var ft=0;return j(H,function(){ft++}),ft},toArray:function(H){return j(H,function(ft){return ft})||[]},only:function(H){if(!Z(H))throw Error("React.Children.only expected to receive a single React element child.");return H}};return ce.Activity=p,ce.Children=xe,ce.Component=U,ce.Fragment=i,ce.Profiler=l,ce.PureComponent=D,ce.StrictMode=r,ce.Suspense=m,ce.ViewTransition=x,ce.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=B,ce.__COMPILER_RUNTIME={__proto__:null,c:function(H){return B.H.useMemoCache(H)}},ce.addTransitionType=oe,ce.cache=function(H){return function(){return H.apply(null,arguments)}},ce.cacheSignal=function(){return null},ce.cloneElement=function(H,ft,$){if(H==null)throw Error("The argument must be a React element, but you passed "+H+".");var at=y({},H.props),Et=H.key;if(ft!=null)for(Ut in ft.key!==void 0&&(Et=""+ft.key),ft)!C.call(ft,Ut)||Ut==="key"||Ut==="__self"||Ut==="__source"||Ut==="ref"&&ft.ref===void 0||(at[Ut]=ft[Ut]);var Ut=arguments.length-2;if(Ut===1)at.children=$;else if(1<Ut){for(var Rt=Array(Ut),St=0;St<Ut;St++)Rt[St]=arguments[St+2];at.children=Rt}return R(H.type,Et,at)},ce.createContext=function(H){return H={$$typeof:h,_currentValue:H,_currentValue2:H,_threadCount:0,Provider:null,Consumer:null},H.Provider=H,H.Consumer={$$typeof:c,_context:H},H},ce.createElement=function(H,ft,$){var at,Et={},Ut=null;if(ft!=null)for(at in ft.key!==void 0&&(Ut=""+ft.key),ft)C.call(ft,at)&&at!=="key"&&at!=="__self"&&at!=="__source"&&(Et[at]=ft[at]);var Rt=arguments.length-2;if(Rt===1)Et.children=$;else if(1<Rt){for(var St=Array(Rt),kt=0;kt<Rt;kt++)St[kt]=arguments[kt+2];Et.children=St}if(H&&H.defaultProps)for(at in Rt=H.defaultProps,Rt)Et[at]===void 0&&(Et[at]=Rt[at]);return R(H,Ut,Et)},ce.createRef=function(){return{current:null}},ce.forwardRef=function(H){return{$$typeof:d,render:H}},ce.isValidElement=Z,ce.lazy=function(H){return{$$typeof:_,_payload:{_status:-1,_result:H},_init:xt}},ce.memo=function(H,ft){return{$$typeof:g,type:H,compare:ft===void 0?null:ft}},ce.startTransition=Ht,ce.unstable_useCacheRefresh=function(){return B.H.useCacheRefresh()},ce.use=function(H){return B.H.use(H)},ce.useActionState=function(H,ft,$){return B.H.useActionState(H,ft,$)},ce.useCallback=function(H,ft){return B.H.useCallback(H,ft)},ce.useContext=function(H){return B.H.useContext(H)},ce.useDebugValue=function(){},ce.useDeferredValue=function(H,ft){return B.H.useDeferredValue(H,ft)},ce.useEffect=function(H,ft){return B.H.useEffect(H,ft)},ce.useEffectEvent=function(H){return B.H.useEffectEvent(H)},ce.useId=function(){return B.H.useId()},ce.useImperativeHandle=function(H,ft,$){return B.H.useImperativeHandle(H,ft,$)},ce.useInsertionEffect=function(H,ft){return B.H.useInsertionEffect(H,ft)},ce.useLayoutEffect=function(H,ft){return B.H.useLayoutEffect(H,ft)},ce.useMemo=function(H,ft){return B.H.useMemo(H,ft)},ce.useOptimistic=function(H,ft){return B.H.useOptimistic(H,ft)},ce.useReducer=function(H,ft,$){return B.H.useReducer(H,ft,$)},ce.useRef=function(H){return B.H.useRef(H)},ce.useState=function(H){return B.H.useState(H)},ce.useSyncExternalStore=function(H,ft,$){return B.H.useSyncExternalStore(H,ft,$)},ce.useTransition=function(){return B.H.useTransition()},ce.version="19.3.1",ce}var O0;function nm(){return O0||(O0=1,yd.exports=VE()),yd.exports}var dt=nm(),Sd={exports:{}},fl={},Md={exports:{}},Ed={};var P0;function XE(){return P0||(P0=1,(function(o){function e(k,it){var j=k.length;k.push(it);t:for(;0<j;){var xt=j-1>>>1,Mt=k[xt];if(0<l(Mt,it))k[xt]=it,k[j]=Mt,j=xt;else break t}}function i(k){return k.length===0?null:k[0]}function r(k){if(k.length===0)return null;var it=k[0],j=k.pop();if(j!==it){k[0]=j;t:for(var xt=0,Mt=k.length,Ht=Mt>>>1;xt<Ht;){var oe=2*(xt+1)-1,xe=k[oe],H=oe+1,ft=k[H];if(0>l(xe,j))H<Mt&&0>l(ft,xe)?(k[xt]=ft,k[H]=j,xt=H):(k[xt]=xe,k[oe]=j,xt=oe);else if(H<Mt&&0>l(ft,j))k[xt]=ft,k[H]=j,xt=H;else break t}}return it}function l(k,it){var j=k.sortIndex-it.sortIndex;return j!==0?j:k.id-it.id}if(o.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var c=performance;o.unstable_now=function(){return c.now()}}else{var h=Date,d=h.now();o.unstable_now=function(){return h.now()-d}}var m=[],g=[],_=1,p=null,x=3,M=!1,E=!1,b=!1,y=!1,S=typeof setTimeout=="function"?setTimeout:null,U=typeof clearTimeout=="function"?clearTimeout:null,N=typeof setImmediate<"u"?setImmediate:null;function D(k){for(var it=i(g);it!==null;){if(it.callback===null)r(g);else if(it.startTime<=k)r(g),it.sortIndex=it.expirationTime,e(m,it);else break;it=i(g)}}function I(k){if(b=!1,D(k),!E)if(i(m)!==null)E=!0,z||(z=!0,Z());else{var it=i(g);it!==null&&st(I,it.startTime-k)}}var z=!1,L=-1,B=5,C=-1;function R(){return y?!0:!(o.unstable_now()-C<B)}function G(){if(y=!1,z){var k=o.unstable_now();C=k;var it=!0;try{t:{E=!1,b&&(b=!1,U(L),L=-1),M=!0;var j=x;try{e:{for(D(k),p=i(m);p!==null&&!(p.expirationTime>k&&R());){var xt=p.callback;if(typeof xt=="function"){p.callback=null,x=p.priorityLevel;var Mt=xt(p.expirationTime<=k);if(k=o.unstable_now(),typeof Mt=="function"){p.callback=Mt,D(k),it=!0;break e}p===i(m)&&r(m),D(k)}else r(m);p=i(m)}if(p!==null)it=!0;else{var Ht=i(g);Ht!==null&&st(I,Ht.startTime-k),it=!1}}break t}finally{p=null,x=j,M=!1}it=void 0}}finally{it?Z():z=!1}}}var Z;if(typeof N=="function")Z=function(){N(G)};else if(typeof MessageChannel<"u"){var et=new MessageChannel,ct=et.port2;et.port1.onmessage=G,Z=function(){ct.postMessage(null)}}else Z=function(){S(G,0)};function st(k,it){L=S(function(){k(o.unstable_now())},it)}o.unstable_IdlePriority=5,o.unstable_ImmediatePriority=1,o.unstable_LowPriority=4,o.unstable_NormalPriority=3,o.unstable_Profiling=null,o.unstable_UserBlockingPriority=2,o.unstable_cancelCallback=function(k){k.callback=null},o.unstable_forceFrameRate=function(k){0>k||125<k?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):B=0<k?Math.floor(1e3/k):5},o.unstable_getCurrentPriorityLevel=function(){return x},o.unstable_next=function(k){switch(x){case 1:case 2:case 3:var it=3;break;default:it=x}var j=x;x=it;try{return k()}finally{x=j}},o.unstable_requestPaint=function(){y=!0},o.unstable_runWithPriority=function(k,it){switch(k){case 1:case 2:case 3:case 4:case 5:break;default:k=3}var j=x;x=k;try{return it()}finally{x=j}},o.unstable_scheduleCallback=function(k,it,j){var xt=o.unstable_now();switch(typeof j=="object"&&j!==null?(j=j.delay,j=typeof j=="number"&&0<j?xt+j:xt):j=xt,k){case 1:var Mt=-1;break;case 2:Mt=250;break;case 5:Mt=1073741823;break;case 4:Mt=1e4;break;default:Mt=5e3}return Mt=j+Mt,k={id:_++,callback:it,priorityLevel:k,startTime:j,expirationTime:Mt,sortIndex:-1},j>xt?(k.sortIndex=j,e(g,k),i(m)===null&&k===i(g)&&(b?(U(L),L=-1):b=!0,st(I,j-xt))):(k.sortIndex=Mt,e(m,k),E||M||(E=!0,z||(z=!0,Z()))),k},o.unstable_shouldYield=R,o.unstable_wrapCallback=function(k){var it=x;return function(){var j=x;x=it;try{return k.apply(this,arguments)}finally{x=j}}}})(Ed)),Ed}var z0;function kE(){return z0||(z0=1,Md.exports=XE()),Md.exports}var Td={exports:{}},Un={};var I0;function qE(){if(I0)return Un;I0=1;var o=nm();function e(_){var p="https://react.dev/errors/"+_;if(1<arguments.length){p+="?args[]="+encodeURIComponent(arguments[1]);for(var x=2;x<arguments.length;x++)p+="&args[]="+encodeURIComponent(arguments[x])}return"Minified React error #"+_+"; visit "+p+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function i(){}var r={d:{f:i,r:function(){throw Error(e(522))},D:i,C:i,L:i,m:i,X:i,S:i,M:i},p:0,findDOMNode:null},l=Symbol.for("react.portal"),c=Symbol.for("react.recoverable"),h=Symbol.for("react.optimistic_key");function d(_,p,x){var M=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:l,key:M==null?null:M===h?h:""+M,children:_,containerInfo:p,implementation:x}}var m=o.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function g(_,p){if(_==="font")return"";if(typeof p=="string")return p==="use-credentials"?p:""}return Un.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=r,Un.browser=function(_){return{$$typeof:c,_reason:_}},Un.createPortal=function(_,p){var x=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!p||p.nodeType!==1&&p.nodeType!==9&&p.nodeType!==11)throw Error(e(299));return d(_,p,null,x)},Un.flushSync=function(_){var p=m.T,x=r.p;try{if(m.T=null,r.p=2,_)return _()}finally{m.T=p,r.p=x,r.d.f()}},Un.preconnect=function(_,p){typeof _=="string"&&(p?(p=p.crossOrigin,p=typeof p=="string"?p==="use-credentials"?p:"":void 0):p=null,r.d.C(_,p))},Un.prefetchDNS=function(_){typeof _=="string"&&r.d.D(_)},Un.preinit=function(_,p){if(typeof _=="string"&&p&&typeof p.as=="string"){var x=p.as,M=g(x,p.crossOrigin),E=typeof p.integrity=="string"?p.integrity:void 0,b=typeof p.fetchPriority=="string"?p.fetchPriority:void 0;x==="style"?r.d.S(_,typeof p.precedence=="string"?p.precedence:void 0,{crossOrigin:M,integrity:E,fetchPriority:b}):x==="script"&&r.d.X(_,{crossOrigin:M,integrity:E,fetchPriority:b,nonce:typeof p.nonce=="string"?p.nonce:void 0})}},Un.preinitModule=function(_,p){if(typeof _=="string")if(typeof p=="object"&&p!==null){if(p.as==null||p.as==="script"){var x=g(p.as,p.crossOrigin);r.d.M(_,{crossOrigin:x,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0})}}else p==null&&r.d.M(_)},Un.preload=function(_,p){if(typeof _=="string"&&typeof p=="object"&&p!==null&&typeof p.as=="string"){var x=p.as,M=g(x,p.crossOrigin);r.d.L(_,x,{crossOrigin:M,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,type:typeof p.type=="string"?p.type:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0,referrerPolicy:typeof p.referrerPolicy=="string"?p.referrerPolicy:void 0,imageSrcSet:typeof p.imageSrcSet=="string"?p.imageSrcSet:void 0,imageSizes:typeof p.imageSizes=="string"?p.imageSizes:void 0,media:typeof p.media=="string"?p.media:void 0})}},Un.preloadModule=function(_,p){if(typeof _=="string")if(p){var x=g(p.as,p.crossOrigin);r.d.m(_,{as:typeof p.as=="string"&&p.as!=="script"?p.as:void 0,crossOrigin:x,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0})}else r.d.m(_)},Un.requestFormReset=function(_){r.d.r(_)},Un.unstable_batchedUpdates=function(_,p){return _(p)},Un.useFormState=function(_,p,x){return m.H.useFormState(_,p,x)},Un.useFormStatus=function(){return m.H.useHostTransitionStatus()},Un.version="19.3.1",Un}var B0;function YE(){if(B0)return Td.exports;B0=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(e){console.error(e)}}return o(),Td.exports=qE(),Td.exports}var F0;function WE(){if(F0)return fl;F0=1;var o=kE(),e=nm(),i=YE();function r(t){var n="https://react.dev/errors/"+t;if(1<arguments.length){n+="?args[]="+encodeURIComponent(arguments[1]);for(var a=2;a<arguments.length;a++)n+="&args[]="+encodeURIComponent(arguments[a])}return"Minified React error #"+t+"; visit "+n+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function l(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function c(t){for(var n=t,a=n;a&&!a.alternate;)n=a,(n.flags&4098)!==0&&(t=n.return),a=n.return;for(;n.return;)n=n.return;return n.tag===3?t:null}function h(t){if(t.tag===13){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function d(t){if(t.tag===31){var n=t.memoizedState;if(n===null&&(t=t.alternate,t!==null&&(n=t.memoizedState)),n!==null)return n.dehydrated}return null}function m(t){if(c(t)!==t)throw Error(r(188))}function g(t){var n=t.alternate;if(!n){if(n=c(t),n===null)throw Error(r(188));return n!==t?null:t}for(var a=t,s=n;;){var u=a.return;if(u===null)break;var f=u.alternate;if(f===null){if(s=u.return,s!==null){a=s;continue}break}if(u.child===f.child){for(f=u.child;f;){if(f===a)return m(u),t;if(f===s)return m(u),n;f=f.sibling}throw Error(r(188))}if(a.return!==s.return)a=u,s=f;else{for(var v=!1,T=u.child;T;){if(T===a){v=!0,a=u,s=f;break}if(T===s){v=!0,s=u,a=f;break}T=T.sibling}if(!v){for(T=f.child;T;){if(T===a){v=!0,a=f,s=u;break}if(T===s){v=!0,s=f,a=u;break}T=T.sibling}if(!v)throw Error(r(189))}}if(a.alternate!==s)throw Error(r(190))}if(a.tag!==3)throw Error(r(188));return a.stateNode.current===a?t:n}function _(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t;for(t=t.child;t!==null;){if(n=_(t),n!==null)return n;t=t.sibling}return null}function p(t,n,a,s,u,f){for(;t!==null;){if((t.tag===5||t.tag===27||t.tag===6)&&a(t,s,u,f)||(t.tag!==22||t.memoizedState===null)&&(n||t.tag!==5&&t.tag!==27)&&p(t.child,n,a,s,u,f))return!0;t=t.sibling}return!1}function x(t){for(t=t.return;t!==null;){if(t.tag===3||t.tag===5||t.tag===27)return t;t=t.return}return null}function M(t){var n=!1;for(t=t.return;t!==null&&(t.tag===4&&(n=!0),!(t.tag===3||t.tag===5||t.tag===27));)t=t.return;return n}function E(t){var n=[null,null],a=x(t);return a===null||b(n,t,a.child,{foundSelf:!1}),n}function b(t,n,a,s){for(;a!==null;){if(a===n)s.foundSelf=!0;else if(a.tag===5||a.tag===27||a.tag===6){if(s.foundSelf)return t[1]=a,!0;t[0]=a}else if((a.tag!==22||a.memoizedState===null)&&b(t,n,a.child,s))return!0;a=a.sibling}return!1}function y(t){switch(t.tag){case 5:case 27:case 6:return t.stateNode;case 3:return t.stateNode.containerInfo;default:throw Error(r(559))}}var S=null,U=null;function N(t,n,a){return t===a?!0:t===n?(S=t,!0):!1}function D(t,n,a){return t===a?(U=t,!1):t===n?(U!==null&&(S=t),!0):!1}function I(t){if(t===null)return null;do t=t===null?null:t.return;while(t&&t.tag!==5&&t.tag!==27&&t.tag!==3);return t||null}function z(t,n,a){for(var s=0,u=t;u;u=a(u))s++;u=0;for(var f=n;f;f=a(f))u++;for(;0<s-u;)t=a(t),s--;for(;0<u-s;)n=a(n),u--;for(;s--;){if(t===n||n!==null&&t===n.alternate)return t;t=a(t),n=a(n)}return null}var L=Object.assign,B=Symbol.for("react.element"),C=Symbol.for("react.transitional.element"),R=Symbol.for("react.portal"),G=Symbol.for("react.fragment"),Z=Symbol.for("react.strict_mode"),et=Symbol.for("react.profiler"),ct=Symbol.for("react.consumer"),st=Symbol.for("react.context"),k=Symbol.for("react.forward_ref"),it=Symbol.for("react.suspense"),j=Symbol.for("react.suspense_list"),xt=Symbol.for("react.memo"),Mt=Symbol.for("react.lazy"),Ht=Symbol.for("react.activity"),oe=Symbol.for("react.legacy_hidden"),xe=Symbol.for("react.memo_cache_sentinel"),H=Symbol.for("react.view_transition"),ft=Symbol.for("react.recoverable"),$=Symbol.iterator;function at(t){return t===null||typeof t!="object"?null:(t=$&&t[$]||t["@@iterator"],typeof t=="function"?t:null)}var Et=Symbol.for("react.client.reference");function Ut(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===Et?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case G:return"Fragment";case et:return"Profiler";case Z:return"StrictMode";case it:return"Suspense";case j:return"SuspenseList";case Ht:return"Activity";case H:return"ViewTransition"}if(typeof t=="object")switch(t.$$typeof){case R:return"Portal";case st:return t.displayName||"Context";case ct:return(t._context.displayName||"Context")+".Consumer";case k:var n=t.render;return t=t.displayName,t||(t=n.displayName||n.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case xt:return n=t.displayName||null,n!==null?n:Ut(t.type)||"Memo";case Mt:n=t._payload,t=t._init;try{return Ut(t(n))}catch{}}return null}var Rt=Array.isArray,St=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,kt=i.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,F={pending:!1,data:null,method:null,action:null},Pe=[],re=-1;function Qt(t){return{current:t}}function Ot(t){0>re||(t.current=Pe[re],Pe[re]=null,re--)}function ie(t,n){re++,Pe[re]=t.current,t.current=n}var vt=Qt(null),Gt=Qt(null),le=Qt(null),Me=Qt(null);function O(t,n){switch(ie(le,n),ie(Gt,t),ie(vt,null),n.nodeType){case 9:case 11:t=(t=n.documentElement)&&(t=t.namespaceURI)?Hv(t):0;break;default:if(t=n.tagName,n=n.namespaceURI)n=Hv(n),t=Gv(n,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}Ot(vt),ie(vt,t)}function A(){Ot(vt),Ot(Gt),Ot(le)}function rt(t){var n=t.memoizedState;n!==null&&(Bs._currentValue=n.memoizedState,ie(Me,t)),n=vt.current;var a=Gv(n,t.type);n!==a&&(ie(Gt,t),ie(vt,a))}function mt(t){Gt.current===t&&(Ot(vt),Ot(Gt)),Me.current===t&&(Ot(Me),Bs._currentValue=F)}var Tt,ht;function Yt(t){if(Tt===void 0)try{throw Error()}catch(a){var n=a.stack.trim().match(/\n( *(at )?)/);Tt=n&&n[1]||"",ht=-1<a.stack.indexOf(`
    at`)?" (<anonymous>)":-1<a.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Tt+t+ht}var Dt=!1;function Kt(t,n){if(!t||Dt)return"";Dt=!0;var a=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var s={DetermineComponentFrameRoot:function(){try{if(n){var gt=function(){throw Error()};if(Object.defineProperty(gt.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(gt,[])}catch(Pt){var q=Pt}Reflect.construct(t,[],gt)}else{try{gt.call()}catch(Pt){q=Pt}gt=!1;try{var nt=Object.getOwnPropertyDescriptor(t.prototype,"props");Object.defineProperty(t.prototype,"props",{configurable:!0,set:function(){throw Error()}}),gt=!0,new t}finally{gt&&(nt!==void 0?Object.defineProperty(t.prototype,"props",nt):delete t.prototype.props)}}}else{try{throw Error()}catch(Pt){q=Pt}(gt=t())&&typeof gt.catch=="function"&&gt.catch(function(){})}}catch(Pt){if(Pt&&q&&typeof Pt.stack=="string")return[Pt.stack,q.stack]}return[null,null]}};s.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var u=Object.getOwnPropertyDescriptor(s.DetermineComponentFrameRoot,"name");u&&u.configurable&&Object.defineProperty(s.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var f=s.DetermineComponentFrameRoot(),v=f[0],T=f[1];if(v&&T){var P=v.split(`
`),W=T.split(`
`);for(u=s=0;s<P.length&&!P[s].includes("DetermineComponentFrameRoot");)s++;for(;u<W.length&&!W[u].includes("DetermineComponentFrameRoot");)u++;if(s===P.length||u===W.length)for(s=P.length-1,u=W.length-1;1<=s&&0<=u&&P[s]!==W[u];)u--;for(;1<=s&&0<=u;s--,u--)if(P[s]!==W[u]){if(s!==1||u!==1)do if(s--,u--,0>u||P[s]!==W[u]){var ot=`
`+P[s].replace(" at new "," at ");return t.displayName&&ot.includes("<anonymous>")&&(ot=ot.replace("<anonymous>",t.displayName)),ot}while(1<=s&&0<=u);break}}}finally{Dt=!1,Error.prepareStackTrace=a}return(a=t?t.displayName||t.name:"")?Yt(a):""}function $t(t,n){switch(t.tag){case 26:case 27:case 5:return Yt(t.type);case 16:return Yt("Lazy");case 13:return t.child!==n&&n!==null?Yt("Suspense Fallback"):Yt("Suspense");case 19:return Yt("SuspenseList");case 0:case 15:return Kt(t.type,!1);case 11:return Kt(t.type.render,!1);case 1:return Kt(t.type,!0);case 31:return Yt("Activity");case 30:return Yt("ViewTransition");default:return""}}function Ct(t){try{var n="",a=null;do n+=$t(t,a),a=t,t=t.return;while(t);return n}catch(s){return`
Error generating stack: `+s.message+`
`+s.stack}}var zt=Object.prototype.hasOwnProperty,se=o.unstable_scheduleCallback,Jt=o.unstable_cancelCallback,It=o.unstable_shouldYield,he=o.unstable_requestPaint,X=o.unstable_now,wt=o.unstable_getCurrentPriorityLevel,Lt=o.unstable_ImmediatePriority,qt=o.unstable_UserBlockingPriority,bt=o.unstable_NormalPriority,yt=o.unstable_LowPriority,Zt=o.unstable_IdlePriority,fe=o.log,ke=o.unstable_setDisableYieldValue,Ae=null,tn=null;function gn(t){if(typeof fe=="function"&&ke(t),tn&&typeof tn.setStrictMode=="function")try{tn.setStrictMode(Ae,t)}catch{}}var Ln=Math.clz32?Math.clz32:Ol,ia=Math.log,yo=Math.LN2;function Ol(t){return t>>>=0,t===0?32:31-(ia(t)/yo|0)|0}var _r=256,aa=262144,vr=4194304;function fi(t){var n=t&42;if(n!==0)return n;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return t&-t;case 262144:case 524288:case 1048576:case 2097152:return t&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function xr(t,n,a){var s=t.pendingLanes;if(s===0)return 0;var u=0,f=t.suspendedLanes,v=t.pingedLanes;t=t.warmLanes;var T=s&134217727;return T!==0?(s=T&~f,s!==0?u=fi(s):(v&=T,v!==0?u=fi(v):a||(a=T&~t,a!==0&&(u=fi(a))))):(T=s&~f,T!==0?u=fi(T):v!==0?u=fi(v):a||(a=s&~t,a!==0&&(u=fi(a)))),u===0?0:n!==0&&n!==u&&(n&f)===0&&(f=u&-u,a=n&-n,f>=a||f===32&&(a&4194048)!==0)?n:u}function Ua(t,n){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&n)===0}function Pl(t,n){(n&8)!==0&&(n|=n&32);var a=t.entangledLanes;if(a!==0)for(t=t.entanglements,a&=n;0<a;){var s=31-Ln(a),u=1<<s;n|=t[s],a&=~u}return n}function Yc(t,n){switch(t){case 1:case 2:case 4:case 8:case 64:return n+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function zl(){var t=vr;return vr<<=1,(vr&62914560)===0&&(vr=4194304),t}function So(t){for(var n=[],a=0;31>a;a++)n.push(t);return n}function yr(t,n){t.pendingLanes|=n,n!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function Wc(t,n,a,s,u,f){var v=t.pendingLanes;t.pendingLanes=a,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=a,t.entangledLanes&=a,t.errorRecoveryDisabledLanes&=a,t.shellSuspendCounter=0;var T=t.entanglements,P=t.expirationTimes,W=t.hiddenUpdates;for(a=v&~a;0<a;){var ot=31-Ln(a),gt=1<<ot;T[ot]=0,P[ot]=-1;var q=W[ot];if(q!==null)for(W[ot]=null,ot=0;ot<q.length;ot++){var nt=q[ot];nt!==null&&(nt.lane&=-536870913)}a&=~gt}s!==0&&w(t,s,0),f!==0&&u===0&&t.tag!==0&&(t.suspendedLanes|=f&~(v&~n))}function w(t,n,a){t.pendingLanes|=n,t.suspendedLanes&=~n;var s=31-Ln(n);t.entangledLanes|=n,t.entanglements[s]=t.entanglements[s]|1073741824|a&261930}function K(t,n){var a=t.entangledLanes|=n;for(t=t.entanglements;a;){var s=31-Ln(a),u=1<<s;u&n|t[s]&n&&(t[s]|=n),a&=~u}}function lt(t,n){var a=n&-n;return a=(a&42)!==0?1:ut(a),(a&(t.suspendedLanes|n))!==0?0:a}function ut(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function Q(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function At(){var t=kt.p;return t!==0?t:(t=window.event,t===void 0?32:T0(t.type))}function Bt(t,n){var a=kt.p;try{return kt.p=t,n()}finally{kt.p=a}}var Vt=Math.random().toString(36).slice(2),Nt="__reactFiber$"+Vt,Wt="__reactProps$"+Vt,ae="__reactContainer$"+Vt,ee="__reactEvents$"+Vt,ye="__reactListeners$"+Vt,Fe="__reactHandles$"+Vt,Je="__reactResources$"+Vt,ze="__reactMarker$"+Vt,Ue="__reactLoad$"+Vt;function ne(t){delete t[Nt],delete t[Wt],delete t[ye],delete t[Fe]}function Ie(t){var n;if(n=t[Nt])return n;for(var a=t.parentNode;a;){if(n=a[ae]||a[Nt]){if(a=n.alternate,n.child!==null||a!==null&&a.child!==null)for(t=a0(t);t!==null;){if(a=t[Nt])return a;t=a0(t)}return n}t=a,a=t.parentNode}return null}function _e(t){if(t=t[Nt]||t[ae]){var n=t.tag;if(n===5||n===6||n===13||n===31||n===26||n===27||n===3)return t}return null}function _n(t){var n=t.tag;if(n===5||n===26||n===27||n===6)return t.stateNode;throw Error(r(33))}function $n(t){var n=t[Je];return n||(n=t[Je]={hoistableStyles:new Map,hoistableScripts:new Map}),n}function Ne(t){t[ze]=!0}function Na(t){t[Ue]=void 0}var Ze=new Set,Fn={};function un(t,n){rn(t,n),rn(t+"Capture",n)}function rn(t,n){for(Fn[t]=n,t=0;t<n.length;t++)Ze.add(n[t])}var On=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),es={},Fi={};function rS(t){return zt.call(Fi,t)?!0:zt.call(es,t)?!1:On.test(t)?Fi[t]=!0:(es[t]=!0,!1)}var Le=!1;function Am(){var t=Le;return Le=!1,t}function Il(t,n,a){if(rS(n))if(a===null)t.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":t.removeAttribute(n);return;case"boolean":var s=n.toLowerCase().slice(0,5);if(s!=="data-"&&s!=="aria-"){t.removeAttribute(n);return}}t.setAttribute(n,a)}}function Bl(t,n,a){if(a===null)t.removeAttribute(n);else{switch(typeof a){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(n);return}t.setAttribute(n,a)}}function ra(t,n,a,s){if(s===null)t.removeAttribute(a);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(a);return}t.setAttributeNS(n,a,s)}}function ti(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function Rm(t){var n=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(n==="checkbox"||n==="radio")}function sS(t,n,a){var s=Object.getOwnPropertyDescriptor(t.constructor.prototype,n);if(!t.hasOwnProperty(n)&&typeof s<"u"&&typeof s.get=="function"&&typeof s.set=="function"){var u=s.get,f=s.set;return Object.defineProperty(t,n,{configurable:!0,get:function(){return u.call(this)},set:function(v){a=""+v,f.call(this,v)}}),Object.defineProperty(t,n,{enumerable:s.enumerable}),{getValue:function(){return a},setValue:function(v){a=""+v},stopTracking:function(){t._valueTracker=null,delete t[n]}}}}function jc(t){if(!t._valueTracker){var n=Rm(t)?"checked":"value";t._valueTracker=sS(t,n,""+t[n])}}function Cm(t){if(!t)return!1;var n=t._valueTracker;if(!n)return!0;var a=n.getValue(),s="";return t&&(s=Rm(t)?t.checked?"true":"false":t.value),t=s,t!==a?(n.setValue(t),!0):!1}var oS=/[\n"\\]/g;function hi(t){return t.replace(oS,function(n){return"\\"+n.charCodeAt(0).toString(16)+" "})}function Zc(t,n,a,s,u,f,v,T){t.name="",v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"?t.type=v:t.removeAttribute("type"),n!=null?v==="number"?(n===0&&t.value===""||t.value!=n)&&(t.value=""+ti(n)):t.value!==""+ti(n)&&(t.value=""+ti(n)):v!=="submit"&&v!=="reset"||t.removeAttribute("value"),n!=null?v==="number"&&t.value==n?Kc(t,ti(t.value)):Kc(t,ti(n)):a!=null?Kc(t,ti(a)):s!=null&&t.removeAttribute("value"),u==null&&f!=null&&(t.defaultChecked=!!f),u!=null&&(t.checked=u&&typeof u!="function"&&typeof u!="symbol"),T!=null&&typeof T!="function"&&typeof T!="symbol"&&typeof T!="boolean"?t.name=""+ti(T):t.removeAttribute("name")}function wm(t,n,a,s,u,f,v,T){if(f!=null&&typeof f!="function"&&typeof f!="symbol"&&typeof f!="boolean"&&(t.type=f),n!=null||a!=null){if(!(f!=="submit"&&f!=="reset"||n!=null)){jc(t);return}a=a!=null?""+ti(a):"",n=n!=null?""+ti(n):a,T||n===t.value||(t.value=n),t.defaultValue=n}s=s??u,s=typeof s!="function"&&typeof s!="symbol"&&!!s,t.checked=T?t.checked:!!s,t.defaultChecked=!!s,v!=null&&typeof v!="function"&&typeof v!="symbol"&&typeof v!="boolean"&&(t.name=v),jc(t)}function Kc(t,n){t.defaultValue!==""+n&&(t.defaultValue=""+n)}function ns(t,n,a,s){if(t=t.options,n){n={};for(var u=0;u<a.length;u++)n["$"+a[u]]=!0;for(a=0;a<t.length;a++)u=n.hasOwnProperty("$"+t[a].value),t[a].selected!==u&&(t[a].selected=u),u&&s&&(t[a].defaultSelected=!0)}else{for(a=""+ti(a),n=null,u=0;u<t.length;u++){if(t[u].value===a){t[u].selected=!0,s&&(t[u].defaultSelected=!0);return}n!==null||t[u].disabled||(n=t[u])}n!==null&&(n.selected=!0)}}function Dm(t,n,a){if(n!=null&&(n=""+ti(n),n!==t.value&&(t.value=n),a==null)){t.defaultValue!==n&&(t.defaultValue=n);return}t.defaultValue=a!=null?""+ti(a):""}function Um(t,n,a,s){if(n==null){if(s!=null){if(a!=null)throw Error(r(92));if(Rt(s)){if(1<s.length)throw Error(r(93));s=s[0]}a=s}a==null&&(a=""),n=a}a=ti(n),t.defaultValue=a,s=t.textContent,s===a&&s!==""&&s!==null&&(t.value=s),jc(t)}function is(t,n){if(n){var a=t.firstChild;if(a&&a===t.lastChild&&a.nodeType===3){a.nodeValue=n;return}}t.textContent=n}var lS=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function Nm(t,n,a){var s=n.indexOf("--")===0;a==null||typeof a=="boolean"||a===""?s?t.setProperty(n,""):n==="float"?t.cssFloat="":t[n]="":s?t.setProperty(n,a):typeof a!="number"||a===0||lS.has(n)?n==="float"?t.cssFloat=a:t[n]=(""+a).trim():t[n]=a+"px"}function Lm(t,n,a){if(n!=null&&typeof n!="object")throw Error(r(62));if(t=t.style,a!=null){for(var s in a)!a.hasOwnProperty(s)||n!=null&&n.hasOwnProperty(s)||(s.indexOf("--")===0?t.setProperty(s,""):s==="float"?t.cssFloat="":t[s]="",Le=!0);for(var u in n)s=n[u],n.hasOwnProperty(u)&&a[u]!==s&&(Nm(t,u,s),Le=!0)}else for(var f in n)n.hasOwnProperty(f)&&Nm(t,f,n[f])}function Qc(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var uS=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["maskType","mask-type"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),cS=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function Fl(t){return cS.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}function Hi(){}var Jc=null;function $c(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var as=null,rs=null;function Om(t){var n=_e(t);if(n&&(t=n.stateNode)){var a=t[Wt]||null;t:switch(t=n.stateNode,n.type){case"input":if(Zc(t,a.value,a.defaultValue,a.defaultValue,a.checked,a.defaultChecked,a.type,a.name),n=a.name,a.type==="radio"&&n!=null){for(a=t;a.parentNode;)a=a.parentNode;for(a=a.querySelectorAll('input[name="'+hi(""+n)+'"][type="radio"]'),n=0;n<a.length;n++){var s=a[n];if(s!==t&&s.form===t.form){var u=s[Wt]||null;if(!u)throw Error(r(90));Zc(s,u.value,u.defaultValue,u.defaultValue,u.checked,u.defaultChecked,u.type,u.name)}}for(n=0;n<a.length;n++)s=a[n],s.form===t.form&&Cm(s)}break t;case"textarea":Dm(t,a.value,a.defaultValue);break t;case"select":n=a.value,n!=null&&ns(t,!!a.multiple,n,!1)}}}var tf=!1;function Pm(t,n,a){if(tf)return t(n,a);tf=!0;try{var s=t(n);return s}finally{if(tf=!1,(as!==null||rs!==null)&&(Fu(),as&&(n=as,t=rs,rs=as=null,Om(n),t)))for(n=0;n<t.length;n++)Om(t[n])}}function Mo(t,n){var a=t.stateNode;if(a===null)return null;var s=a[Wt]||null;if(s===null)return null;a=s[n];t:switch(n){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(s=!s.disabled)||(t=t.type,s=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!s;break t;default:t=!1}if(t)return null;if(a&&typeof a!="function")throw Error(r(231,n,typeof a));return a}var sa=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),ef=!1;if(sa)try{var Eo={};Object.defineProperty(Eo,"passive",{get:function(){ef=!0}}),window.addEventListener("test",Eo,Eo),window.removeEventListener("test",Eo,Eo)}catch{ef=!1}var La=null,nf=null,Hl=null;function zm(){if(Hl)return Hl;var t,n=nf,a=n.length,s,u="value"in La?La.value:La.textContent,f=u.length;for(t=0;t<a&&n[t]===u[t];t++);var v=a-t;for(s=1;s<=v&&n[a-s]===u[f-s];s++);return Hl=u.slice(t,1<s?1-s:void 0)}function Gl(t){var n=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&n===13&&(t=13)):t=n,t===10&&(t=13),32<=t||t===13?t:0}function Vl(){return!0}function Im(){return!1}function Hn(t){function n(a,s,u,f,v){this._reactName=a,this._targetInst=u,this.type=s,this.nativeEvent=f,this.target=v,this.currentTarget=null;for(var T in t)t.hasOwnProperty(T)&&(a=t[T],this[T]=a?a(f):f[T]);return this.isDefaultPrevented=(f.defaultPrevented!=null?f.defaultPrevented:f.returnValue===!1)?Vl:Im,this.isPropagationStopped=Im,this}return L(n.prototype,{preventDefault:function(){this.defaultPrevented=!0;var a=this.nativeEvent;a&&(a.preventDefault?a.preventDefault():typeof a.returnValue!="unknown"&&(a.returnValue=!1),this.isDefaultPrevented=Vl)},stopPropagation:function(){var a=this.nativeEvent;a&&(a.stopPropagation?a.stopPropagation():typeof a.cancelBubble!="unknown"&&(a.cancelBubble=!0),this.isPropagationStopped=Vl)},persist:function(){},isPersistent:Vl}),n}var Oa={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Xl=Hn(Oa),To=L({},Oa,{view:0,detail:0}),fS=Hn(To),af,rf,bo,kl=L({},To,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:of,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==bo&&(bo&&t.type==="mousemove"?(af=t.screenX-bo.screenX,rf=t.screenY-bo.screenY):rf=af=0,bo=t),af)},movementY:function(t){return"movementY"in t?t.movementY:rf}}),Bm=Hn(kl),hS=L({},kl,{dataTransfer:0}),dS=Hn(hS),pS=L({},To,{relatedTarget:0}),sf=Hn(pS),mS=L({},Oa,{animationName:0,elapsedTime:0,pseudoElement:0}),gS=Hn(mS),_S=L({},Oa,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),vS=Hn(_S),xS=L({},Oa,{data:0}),Fm=Hn(xS),yS={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},SS={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},MS={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function ES(t){var n=this.nativeEvent;return n.getModifierState?n.getModifierState(t):(t=MS[t])?!!n[t]:!1}function of(){return ES}var TS=L({},To,{key:function(t){if(t.key){var n=yS[t.key]||t.key;if(n!=="Unidentified")return n}return t.type==="keypress"?(t=Gl(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?SS[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:of,charCode:function(t){return t.type==="keypress"?Gl(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?Gl(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),bS=Hn(TS),AS=L({},kl,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Hm=Hn(AS),RS=L({},Oa,{submitter:0}),CS=Hn(RS),wS=L({},To,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:of}),DS=Hn(wS),US=L({},Oa,{propertyName:0,elapsedTime:0,pseudoElement:0}),NS=Hn(US),LS=L({},kl,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),OS=Hn(LS),PS=L({},Oa,{newState:0,oldState:0,source:0}),zS=Hn(PS),IS=[9,13,27,32],lf=sa&&"CompositionEvent"in window,Ao=null;sa&&"documentMode"in document&&(Ao=document.documentMode);var BS=sa&&"TextEvent"in window&&!Ao,Gm=sa&&(!lf||Ao&&8<Ao&&11>=Ao),Vm=" ",Xm=!1;function km(t,n){switch(t){case"keyup":return IS.indexOf(n.keyCode)!==-1;case"keydown":return n.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function qm(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var ss=!1;function FS(t,n){switch(t){case"compositionend":return qm(n);case"keypress":return n.which!==32?null:(Xm=!0,Vm);case"textInput":return t=n.data,t===Vm&&Xm?null:t;default:return null}}function HS(t,n){if(ss)return t==="compositionend"||!lf&&km(t,n)?(t=zm(),Hl=nf=La=null,ss=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(n.ctrlKey||n.altKey||n.metaKey)||n.ctrlKey&&n.altKey){if(n.char&&1<n.char.length)return n.char;if(n.which)return String.fromCharCode(n.which)}return null;case"compositionend":return Gm&&n.locale!=="ko"?null:n.data;default:return null}}var GS={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Ym(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n==="input"?!!GS[t.type]:n==="textarea"}function Wm(t,n,a,s){as?rs?rs.push(s):rs=[s]:as=s,n=qu(n,"onChange"),0<n.length&&(a=new Xl("onChange","change",null,a,s),t.push({event:a,listeners:n}))}var Ro=null,Co=null;function VS(t){Ov(t,0)}function ql(t){var n=_n(t);if(Cm(n))return t}function jm(t,n){if(t==="change")return n}var Zm=!1;if(sa){var uf;if(sa){var cf="oninput"in document;if(!cf){var Km=document.createElement("div");Km.setAttribute("oninput","return;"),cf=typeof Km.oninput=="function"}uf=cf}else uf=!1;Zm=uf&&(!document.documentMode||9<document.documentMode)}function Qm(){Ro&&(Ro.detachEvent("onpropertychange",Jm),Co=Ro=null)}function Jm(t){if(t.propertyName==="value"&&ql(Co)){var n=[];Wm(n,Co,t,$c(t)),Pm(VS,n)}}function XS(t,n,a){t==="focusin"?(Qm(),Ro=n,Co=a,Ro.attachEvent("onpropertychange",Jm)):t==="focusout"&&Qm()}function kS(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return ql(Co)}function qS(t,n){if(t==="click")return ql(n)}function YS(t,n){if(t==="input"||t==="change")return ql(n)}function WS(t,n){return t===n&&(t!==0||1/t===1/n)||t!==t&&n!==n}var ei=typeof Object.is=="function"?Object.is:WS;function wo(t,n){if(ei(t,n))return!0;if(typeof t!="object"||t===null||typeof n!="object"||n===null)return!1;var a=Object.keys(t),s=Object.keys(n);if(a.length!==s.length)return!1;for(s=0;s<a.length;s++){var u=a[s];if(!zt.call(n,u)||!ei(t[u],n[u]))return!1}return!0}function ff(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}function $m(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function tg(t,n){var a=$m(t);t=0;for(var s;a;){if(a.nodeType===3){if(s=t+a.textContent.length,t<=n&&s>=n)return{node:a,offset:n-t};t=s}t:{for(;a;){if(a.nextSibling){a=a.nextSibling;break t}a=a.parentNode}a=void 0}a=$m(a)}}function eg(t,n){return t&&n?t===n?!0:t&&t.nodeType===3?!1:n&&n.nodeType===3?eg(t,n.parentNode):"contains"in t?t.contains(n):t.compareDocumentPosition?!!(t.compareDocumentPosition(n)&16):!1:!1}function ng(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var n=ff(t.document);n instanceof t.HTMLIFrameElement;){try{var a=typeof n.contentWindow.location.href=="string"}catch{a=!1}if(a)t=n.contentWindow;else break;n=ff(t.document)}return n}function hf(t){var n=t&&t.nodeName&&t.nodeName.toLowerCase();return n&&(n==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||n==="textarea"||t.contentEditable==="true")}var jS=sa&&"documentMode"in document&&11>=document.documentMode,os=null,df=null,Do=null,pf=!1;function ig(t,n,a){var s=a.window===a?a.document:a.nodeType===9?a:a.ownerDocument;pf||os==null||os!==ff(s)||(s=os,"selectionStart"in s&&hf(s)?s={start:s.selectionStart,end:s.selectionEnd}:(s=(s.ownerDocument&&s.ownerDocument.defaultView||window).getSelection(),s={anchorNode:s.anchorNode,anchorOffset:s.anchorOffset,focusNode:s.focusNode,focusOffset:s.focusOffset}),Do&&wo(Do,s)||(Do=s,s=qu(df,"onSelect"),0<s.length&&(n=new Xl("onSelect","select",null,n,a),t.push({event:n,listeners:s}),n.target=os)))}function Sr(t,n){var a={};return a[t.toLowerCase()]=n.toLowerCase(),a["Webkit"+t]="webkit"+n,a["Moz"+t]="moz"+n,a}var ls={animationend:Sr("Animation","AnimationEnd"),animationiteration:Sr("Animation","AnimationIteration"),animationstart:Sr("Animation","AnimationStart"),transitionrun:Sr("Transition","TransitionRun"),transitionstart:Sr("Transition","TransitionStart"),transitioncancel:Sr("Transition","TransitionCancel"),transitionend:Sr("Transition","TransitionEnd")},mf={},ag={};sa&&(ag=document.createElement("div").style,"AnimationEvent"in window||(delete ls.animationend.animation,delete ls.animationiteration.animation,delete ls.animationstart.animation),"TransitionEvent"in window||delete ls.transitionend.transition);function Mr(t){if(mf[t])return mf[t];if(!ls[t])return t;var n=ls[t],a;for(a in n)if(n.hasOwnProperty(a)&&a in ag)return mf[t]=n[a];return t}var rg=Mr("animationend"),sg=Mr("animationiteration"),og=Mr("animationstart"),ZS=Mr("transitionrun"),KS=Mr("transitionstart"),QS=Mr("transitioncancel"),lg=Mr("transitionend"),ug=new Map,gf="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error fullscreenChange fullscreenError gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");gf.push("scrollEnd");function bi(t,n){ug.set(t,n),un(n,[t])}var JS=0;function oa(t,n){if(t.name!=null&&t.name!=="auto")return t.name;if(n.autoName!==null)return n.autoName;t=wi.identifierPrefix;var a=JS++;return t="_"+t+"t_"+a.toString(32)+"_",n.autoName=t}function cg(t){if(t==null||typeof t=="string")return t;var n=null,a=Cs;if(a!==null)for(var s=0;s<a.length;s++){var u=t[a[s]];if(u!=null){if(u==="none")return"none";n=n==null?u:n+(" "+u)}}return n??t.default}function la(t,n){return t=cg(t),n=cg(n),n==null?t==="auto"?null:t:n==="auto"?null:n}var Yl=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var n=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(n))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)},di=[],us=0,_f=0;function Wl(){for(var t=us,n=_f=us=0;n<t;){var a=di[n];di[n++]=null;var s=di[n];di[n++]=null;var u=di[n];di[n++]=null;var f=di[n];if(di[n++]=null,s!==null&&u!==null){var v=s.pending;v===null?u.next=u:(u.next=v.next,v.next=u),s.pending=u}f!==0&&fg(a,u,f)}}function jl(t,n,a,s){di[us++]=t,di[us++]=n,di[us++]=a,di[us++]=s,_f|=s,t.lanes|=s,t=t.alternate,t!==null&&(t.lanes|=s)}function vf(t,n,a,s){return jl(t,n,a,s),Zl(t)}function Er(t,n){return jl(t,null,null,n),Zl(t)}function fg(t,n,a){t.lanes|=a;var s=t.alternate;s!==null&&(s.lanes|=a);for(var u=!1,f=t.return;f!==null;)f.childLanes|=a,s=f.alternate,s!==null&&(s.childLanes|=a),f.tag===22&&(t=f.stateNode,t===null||t._visibility&1||(u=!0)),t=f,f=f.return;return t.tag===3?(f=t.stateNode,u&&n!==null&&(u=31-Ln(a),t=f.hiddenUpdates,s=t[u],s===null?t[u]=[n]:s.push(n),n.lane=a|536870912),f):null}function Zl(t){if(50<Jo)throw Jo=0,Bu=null,Error(r(185));for(var n=t.return;n!==null;)t=n,n=t.return;return t.tag===3?t.stateNode:null}var cs={};function $S(t,n,a,s){this.tag=t,this.key=a,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=n,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=s,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function qn(t,n,a,s){return new $S(t,n,a,s)}function xf(t){return t=t.prototype,!(!t||!t.isReactComponent)}function ua(t,n){var a=t.alternate;return a===null?(a=qn(t.tag,n,t.key,t.mode),a.elementType=t.elementType,a.type=t.type,a.stateNode=t.stateNode,a.alternate=t,t.alternate=a):(a.pendingProps=n,a.type=t.type,a.flags=0,a.subtreeFlags=0,a.deletions=null),a.flags=t.flags&1206910976,a.childLanes=t.childLanes,a.lanes=t.lanes,a.child=t.child,a.memoizedProps=t.memoizedProps,a.memoizedState=t.memoizedState,a.updateQueue=t.updateQueue,n=t.dependencies,a.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext},a.sibling=t.sibling,a.index=t.index,a.ref=t.ref,a.refCleanup=t.refCleanup,a}function hg(t,n){t.flags&=1206910978;var a=t.alternate;return a===null?(t.childLanes=0,t.lanes=n,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=a.childLanes,t.lanes=a.lanes,t.child=a.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=a.memoizedProps,t.memoizedState=a.memoizedState,t.updateQueue=a.updateQueue,t.type=a.type,n=a.dependencies,t.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),t}function Kl(t,n,a,s,u,f){var v=0;if(s=t,typeof s=="function")xf(s)&&(v=1);else if(typeof s=="string")v=RE(t,a,vt.current)?26:t==="html"||t==="head"||t==="body"?27:5;else t:switch(s){case Ht:return t=qn(31,a,n,u),t.elementType=Ht,t.lanes=f,t;case G:return Tr(a.children,u,f,n);case Z:v=8,u|=24;break;case et:return t=qn(12,a,n,u|2),t.elementType=et,t.lanes=f,t;case it:return t=qn(13,a,n,u),t.elementType=it,t.lanes=f,t;case j:return t=qn(19,a,n,u),t.elementType=j,t.lanes=f,t;case oe:case H:return t=u|32,t=qn(30,a,n,t),t.elementType=H,t.lanes=f,t.stateNode={autoName:null,paired:null,clones:null,ref:null},t;default:if(typeof s=="object"&&s!==null)switch(s.$$typeof){case st:v=10;break t;case ct:v=9;break t;case k:v=11;break t;case xt:v=14;break t;case Mt:v=16,s=null;break t}v=29,a=Error(r(130,t===null?"null":typeof t,"")),s=null}return n=qn(v,a,n,u),n.elementType=t,n.type=s,n.lanes=f,n}function Tr(t,n,a,s){return t=qn(7,t,s,n),t.lanes=a,t}function yf(t,n,a){return t=qn(6,t,null,n),t.lanes=a,t}function dg(t){var n=qn(18,null,null,0);return n.stateNode=t,n}function Sf(t,n,a){return n=qn(4,t.children!==null?t.children:[],t.key,n),n.lanes=a,n.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},n}var pg=new WeakMap;function pi(t,n){if(typeof t=="object"&&t!==null){var a=pg.get(t);return a!==void 0?a:(n={value:t,source:n,stack:Ct(n)},pg.set(t,n),n)}return{value:t,source:n,stack:Ct(n)}}var fs=[],hs=0,Ql=null,Uo=0,mi=[],gi=0,Pa=null,Gi=1,Vi="";function ca(t,n){fs[hs++]=Uo,fs[hs++]=Ql,Ql=t,Uo=n}function mg(t,n,a){mi[gi++]=Gi,mi[gi++]=Vi,mi[gi++]=Pa,Pa=t;var s=Gi;t=Vi;var u=32-Ln(s)-1;s&=~(1<<u),a+=1;var f=32-Ln(n)+u;if(30<f){var v=u-u%5;f=(s&(1<<v)-1).toString(32),s>>=v,u-=v,Gi=1<<32-Ln(n)+u|a<<u|s,Vi=f+t}else Gi=1<<f|a<<u|s,Vi=t}function Jl(t){t.return!==null&&(ca(t,1),mg(t,1,0))}function Mf(t){for(;t===Ql;)Ql=fs[--hs],fs[hs]=null,Uo=fs[--hs],fs[hs]=null;for(;t===Pa;)Pa=mi[--gi],mi[gi]=null,Vi=mi[--gi],mi[gi]=null,Gi=mi[--gi],mi[gi]=null}function gg(t,n){mi[gi++]=Gi,mi[gi++]=Vi,mi[gi++]=Pa,Gi=n.id,Vi=n.overflow,Pa=t}var Sn=null,Ke=null,ve=!1,za=null,_i=!1,Ef=Error(r(519));function Ia(t){var n=Error(r(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw No(pi(n,t)),Ef}function _g(t){var n=t.stateNode,a=t.type,s=t.memoizedProps;switch(n[Nt]=t,n[Wt]=s,a){case"dialog":Te("cancel",n),Te("close",n);break;case"iframe":case"object":case"embed":Te("load",n);break;case"video":case"audio":for(a=0;a<tl.length;a++)Te(tl[a],n);break;case"source":Te("error",n);break;case"img":case"image":case"link":Te("error",n),Te("load",n);break;case"details":Te("toggle",n);break;case"input":Te("invalid",n),wm(n,s.value,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name,!0);break;case"select":Te("invalid",n);break;case"textarea":Te("invalid",n),Um(n,s.value,s.defaultValue,s.children)}a=s.children,typeof a!="string"&&typeof a!="number"&&typeof a!="bigint"||n.textContent===""+a||s.suppressHydrationWarning===!0||Bv(n.textContent,a)?(s.popover!=null&&(Te("beforetoggle",n),Te("toggle",n)),s.onScroll!=null&&Te("scroll",n),s.onScrollEnd!=null&&Te("scrollend",n),s.onClick!=null&&(n.onclick=Hi),n=!0):n=!1,n||Ia(t,!0)}function $l(t){for(Sn=t.return;Sn;)switch(Sn.tag){case 5:case 31:case 13:_i=!1;return;case 27:case 3:_i=!0;return;default:Sn=Sn.return}}function ds(t){if(t!==Sn)return!1;if(!ve)return $l(t),ve=!0,!1;var n=t.tag,a;if((a=n!==3&&n!==27)&&((a=n===5)&&(a=t.type,a=!(a!=="form"&&a!=="button")||$h(t.type,t.memoizedProps)),a=!a),a&&Ke&&Ia(t),$l(t),n===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(r(317));Ke=i0(t)}else if(n===31){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(r(317));Ke=i0(t)}else n===27?(n=Ke,$a(t.type)?(t=ld,ld=null,Ke=t):Ke=n):Ke=Sn?xi(t.stateNode.nextSibling):null;return!0}function br(){Ke=Sn=null,ve=!1}function Tf(){var t=za;return t!==null&&(jn===null?jn=t:jn.push.apply(jn,t),za=null),t}function No(t){za===null?za=[t]:za.push(t)}var bf=Qt(null),Ar=null,fa=null;function Ba(t,n,a){ie(bf,n._currentValue),n._currentValue=a}function ha(t){t._currentValue=bf.current,Ot(bf)}function tu(t,n,a){for(;t!==null;){var s=t.alternate;if((t.childLanes&n)!==n?(t.childLanes|=n,s!==null&&(s.childLanes|=n)):s!==null&&(s.childLanes&n)!==n&&(s.childLanes|=n),t===a)break;t=t.return}}function Af(t,n,a,s){var u=t.child;for(u!==null&&(u.return=t);u!==null;){var f=u.dependencies;if(f!==null){var v=u.child;f=f.firstContext;t:for(;f!==null;){var T=f;f=u;for(var P=0;P<n.length;P++)if(T.context===n[P]){f.lanes|=a,T=f.alternate,T!==null&&(T.lanes|=a),tu(f.return,a,t),s||(v=null);break t}f=T.next}}else if(u.tag===18){if(v=u.return,v===null)throw Error(r(341));v.lanes|=a,f=v.alternate,f!==null&&(f.lanes|=a),tu(v,a,t),v=null}else u.tag===13&&u.memoizedState!==null&&u.memoizedState.dehydrated===null?(u.lanes|=a,v=u.alternate,v!==null&&(v.lanes|=a),tu(u.return,a,t),v=u.child,v=v!==null?v.sibling:null):v=u.child;if(v!==null)v.return=u;else for(v=u;v!==null;){if(v===t){v=null;break}if(u=v.sibling,u!==null){u.return=v.return,v=u;break}v=v.return}u=v}}function Rr(t,n,a,s){t=null;for(var u=n,f=!1;u!==null;){if(!f){if((u.flags&524288)!==0)f=!0;else if((u.flags&262144)!==0)break}if(u.tag===10){var v=u.alternate;if(v===null)throw Error(r(387));if(v=v.memoizedProps,v!==null){var T=u.type;ei(u.pendingProps.value,v.value)||(t!==null?t.push(T):t=[T])}}else if(u===Me.current){if(v=u.alternate,v===null)throw Error(r(387));v.memoizedState.memoizedState!==u.memoizedState.memoizedState&&(t!==null?t.push(Bs):t=[Bs])}u=u.return}return t!==null&&Af(n,t,a,s),n.flags|=262144,t!==null}function eu(t){for(t=t.firstContext;t!==null;){if(!ei(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function Cr(t){Ar=t,fa=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function An(t){return vg(Ar,t)}function nu(t,n){return Ar===null&&Cr(t),vg(t,n)}function vg(t,n){var a=n._currentValue;if(n={context:n,memoizedValue:a,next:null},fa===null){if(t===null)throw Error(r(308));fa=n,t.dependencies={lanes:0,firstContext:n},t.flags|=524288}else fa=fa.next=n;return a}var tM=typeof AbortController<"u"?AbortController:function(){var t=[],n=this.signal={aborted:!1,addEventListener:function(a,s){t.push(s)}};this.abort=function(){n.aborted=!0,t.forEach(function(a){return a()})}},eM=o.unstable_scheduleCallback,nM=o.unstable_NormalPriority,cn={$$typeof:st,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function Rf(){return{controller:new tM,data:new Map,refCount:0}}function Lo(t){t.refCount--,t.refCount===0&&eM(nM,function(){t.controller.abort()})}function xg(t,n){if((t.pendingLanes&4194048)!==0){var a=t.transitionTypes;for(a===null&&(a=t.transitionTypes=[]),t=0;t<n.length;t++){var s=n[t];a.indexOf(s)===-1&&a.push(s)}}}var Oo=null;function iM(t){var n=t.transitionTypes;return t.transitionTypes=null,n}var Po=null,Cf=0,wr=0,ps=null;function aM(t,n){if(Po===null){var a=Po=[];Cf=0,wr=kh(),ps={status:"pending",value:void 0,then:function(s){a.push(s)}}}return Cf++,n.then(yg,yg),n}function yg(){if(--Cf===0&&(Oo=null,Po!==null)){ps!==null&&(ps.status="fulfilled");var t=Po;Po=null,wr=0,ps=null;for(var n=0;n<t.length;n++)(0,t[n])()}}function rM(t,n){var a=[],s={status:"pending",value:null,reason:null,then:function(u){a.push(u)}};return t.then(function(){s.status="fulfilled",s.value=n;for(var u=0;u<a.length;u++)(0,a[u])(n)},function(u){for(s.status="rejected",s.reason=u,u=0;u<a.length;u++)(0,a[u])(void 0)}),s}var Sg=St.S;St.S=function(t,n){if(dv=X(),typeof n=="object"&&n!==null&&typeof n.then=="function"&&aM(t,n),Oo!==null)for(var a=Ns;a!==null;)xg(a,Oo),a=a.next;if(a=t.types,a!==null){for(var s=Ns;s!==null;)xg(s,a),s=s.next;if(wr!==0){s=Oo,s===null&&(s=Oo=[]);for(var u=0;u<a.length;u++){var f=a[u];s.indexOf(f)===-1&&s.push(f)}}}Sg!==null&&Sg(t,n)};var Dr=Qt(null);function wf(){var t=Dr.current;return t!==null?t:je.pooledCache}function iu(t,n){n===null?ie(Dr,Dr.current):ie(Dr,n.pool)}function Mg(){var t=wf();return t===null?null:{parent:cn._currentValue,pool:t}}var ms=Error(r(460)),Df=Error(r(474)),au=Error(r(542)),ru={then:function(){}};function Eg(t){return t=t.status,t==="fulfilled"||t==="rejected"}function Tg(t,n,a){switch(a=t[a],a===void 0?t.push(n):a!==n&&(n.then(Hi,Hi),n=a),n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,Ag(t),t===void 0&&!("reason"in n)?Error(r(600)):t;default:if(typeof n.status=="string")n.then(Hi,Hi);else{if(t=je,t!==null&&100<t.shellSuspendCounter)throw Error(r(482));t=n,t.status="pending",t.then(function(s){if(n.status==="pending"){var u=n;u.status="fulfilled",u.value=s}},function(s){if(n.status==="pending"){var u=n;u.status="rejected",u.reason=s}})}switch(n.status){case"fulfilled":return n.value;case"rejected":throw t=n.reason,Ag(t),t}throw Nr=n,ms}}function Ur(t){try{var n=t._init;return n(t._payload)}catch(a){throw a!==null&&typeof a=="object"&&typeof a.then=="function"?(Nr=a,ms):a}}var Nr=null;function bg(){if(Nr===null)throw Error(r(459));var t=Nr;return Nr=null,t}function Ag(t){if(t===ms||t===au)throw Error(r(483))}var gs=null,zo=0;function su(t){var n=zo;return zo+=1,gs===null&&(gs=[]),Tg(gs,t,n)}function Fa(t,n){n=n.props.ref,t.ref=n!==void 0?n:null}function ou(t,n){throw n.$$typeof===B?Error(r(525)):(t=Object.prototype.toString.call(n),Error(r(31,t==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":t)))}function Rg(t){function n(Y,V){if(t){var tt=Y.deletions;tt===null?(Y.deletions=[V],Y.flags|=16):tt.push(V)}}function a(Y,V){if(!t)return null;for(;V!==null;)n(Y,V),V=V.sibling;return null}function s(Y){for(var V=new Map;Y!==null;)Y.key===null?V.set(Y.index,Y):V.set(Y.key,Y),Y=Y.sibling;return V}function u(Y,V){return Y=ua(Y,V),Y.index=0,Y.sibling=null,Y}function f(Y,V,tt){return Y.index=tt,t?(tt=Y.alternate,tt!==null?(tt=tt.index,tt<V?(Y.flags|=2,V):tt):(Y.flags|=134217730,V)):(Y.flags|=1048576,V)}function v(Y){return t&&Y.alternate===null&&(Y.flags|=134217730),Y}function T(Y,V,tt,pt){return V===null||V.tag!==6?(V=yf(tt,Y.mode,pt),V.return=Y,V):(V=u(V,tt),V.return=Y,V)}function P(Y,V,tt,pt){var Xt=tt.type;return Xt===G?(Y=ot(Y,V,tt.props.children,pt,tt.key),Fa(Y,tt),Y):V!==null&&(V.elementType===Xt||typeof Xt=="object"&&Xt!==null&&Xt.$$typeof===Mt&&Ur(Xt)===V.type)?(V=u(V,tt.props),Fa(V,tt),V.return=Y,V):(V=Kl(tt.type,tt.key,tt.props,null,Y.mode,pt),Fa(V,tt),V.return=Y,V)}function W(Y,V,tt,pt){return V===null||V.tag!==4||V.stateNode.containerInfo!==tt.containerInfo||V.stateNode.implementation!==tt.implementation?(V=Sf(tt,Y.mode,pt),V.return=Y,V):(V=u(V,tt.children||[]),V.return=Y,V)}function ot(Y,V,tt,pt,Xt){return V===null||V.tag!==7?(V=Tr(tt,Y.mode,pt,Xt),V.return=Y,V):(V=u(V,tt),V.return=Y,V)}function gt(Y,V,tt){if(typeof V=="string"&&V!==""||typeof V=="number"||typeof V=="bigint")return V=yf(""+V,Y.mode,tt),V.return=Y,V;if(typeof V=="object"&&V!==null){switch(V.$$typeof){case C:return tt=Kl(V.type,V.key,V.props,null,Y.mode,tt),Fa(tt,V),tt.return=Y,tt;case R:return V=Sf(V,Y.mode,tt),V.return=Y,V;case Mt:return V=Ur(V),gt(Y,V,tt)}if(Rt(V)||at(V))return V=Tr(V,Y.mode,tt,null),V.return=Y,V;if(typeof V.then=="function")return gt(Y,su(V),tt);if(V.$$typeof===st)return gt(Y,nu(Y,V),tt);ou(Y,V)}return null}function q(Y,V,tt,pt){var Xt=V!==null?V.key:null;if(typeof tt=="string"&&tt!==""||typeof tt=="number"||typeof tt=="bigint")return Xt!==null?null:T(Y,V,""+tt,pt);if(typeof tt=="object"&&tt!==null){switch(tt.$$typeof){case C:return tt.key===Xt?P(Y,V,tt,pt):null;case R:return tt.key===Xt?W(Y,V,tt,pt):null;case Mt:return tt=Ur(tt),q(Y,V,tt,pt)}if(Rt(tt)||at(tt))return Xt!==null?null:ot(Y,V,tt,pt,null);if(typeof tt.then=="function")return q(Y,V,su(tt),pt);if(tt.$$typeof===st)return q(Y,V,nu(Y,tt),pt);ou(Y,tt)}return null}function nt(Y,V,tt,pt,Xt){if(typeof pt=="string"&&pt!==""||typeof pt=="number"||typeof pt=="bigint")return Y=Y.get(tt)||null,T(V,Y,""+pt,Xt);if(typeof pt=="object"&&pt!==null){switch(pt.$$typeof){case C:return Y=Y.get(pt.key===null?tt:pt.key)||null,P(V,Y,pt,Xt);case R:return Y=Y.get(pt.key===null?tt:pt.key)||null,W(V,Y,pt,Xt);case Mt:return pt=Ur(pt),nt(Y,V,tt,pt,Xt)}if(Rt(pt)||at(pt))return Y=Y.get(tt)||null,ot(V,Y,pt,Xt,null);if(typeof pt.then=="function")return nt(Y,V,tt,su(pt),Xt);if(pt.$$typeof===st)return nt(Y,V,tt,nu(V,pt),Xt);ou(V,pt)}return null}function Pt(Y,V,tt,pt){for(var Xt=null,Ce=null,te=V,ue=V=0,dn=null;te!==null&&ue<tt.length;ue++){te.index>ue?(dn=te,te=null):dn=te.sibling;var De=q(Y,te,tt[ue],pt);if(De===null){te===null&&(te=dn);break}t&&te&&De.alternate===null&&n(Y,te),V=f(De,V,ue),Ce===null?Xt=De:Ce.sibling=De,Ce=De,te=dn}if(ue===tt.length)return a(Y,te),ve&&ca(Y,ue),Xt;if(te===null){for(;ue<tt.length;ue++)te=gt(Y,tt[ue],pt),te!==null&&(V=f(te,V,ue),Ce===null?Xt=te:Ce.sibling=te,Ce=te);return ve&&ca(Y,ue),Xt}for(te=s(te);ue<tt.length;ue++)dn=nt(te,Y,ue,tt[ue],pt),dn!==null&&(t&&(De=dn.alternate,De!==null&&te.delete(De.key===null?ue:De.key)),V=f(dn,V,ue),Ce===null?Xt=dn:Ce.sibling=dn,Ce=dn);return t&&te.forEach(function(ar){return n(Y,ar)}),ve&&ca(Y,ue),Xt}function jt(Y,V,tt,pt){if(tt==null)throw Error(r(151));for(var Xt=null,Ce=null,te=V,ue=V=0,dn=null,De=tt.next();te!==null&&!De.done;ue++,De=tt.next()){te.index>ue?(dn=te,te=null):dn=te.sibling;var ar=q(Y,te,De.value,pt);if(ar===null){te===null&&(te=dn);break}t&&te&&ar.alternate===null&&n(Y,te),V=f(ar,V,ue),Ce===null?Xt=ar:Ce.sibling=ar,Ce=ar,te=dn}if(De.done)return a(Y,te),ve&&ca(Y,ue),Xt;if(te===null){for(;!De.done;ue++,De=tt.next())De=gt(Y,De.value,pt),De!==null&&(V=f(De,V,ue),Ce===null?Xt=De:Ce.sibling=De,Ce=De);return ve&&ca(Y,ue),Xt}for(te=s(te);!De.done;ue++,De=tt.next())De=nt(te,Y,ue,De.value,pt),De!==null&&(t&&(dn=De.alternate,dn!==null&&te.delete(dn.key===null?ue:dn.key)),V=f(De,V,ue),Ce===null?Xt=De:Ce.sibling=De,Ce=De);return t&&te.forEach(function(FE){return n(Y,FE)}),ve&&ca(Y,ue),Xt}function pe(Y,V,tt,pt){if(typeof tt=="object"&&tt!==null&&tt.type===G&&tt.key===null&&tt.props.ref===void 0&&(tt=tt.props.children),typeof tt=="object"&&tt!==null){switch(tt.$$typeof){case C:t:{for(var Xt=tt.key;V!==null;){if(V.key===Xt){if(Xt=tt.type,Xt===G){if(V.tag===7){a(Y,V.sibling),pt=u(V,tt.props.children),Fa(pt,tt),pt.return=Y,Y=pt;break t}}else if(V.elementType===Xt||typeof Xt=="object"&&Xt!==null&&Xt.$$typeof===Mt&&Ur(Xt)===V.type){a(Y,V.sibling),pt=u(V,tt.props),Fa(pt,tt),pt.return=Y,Y=pt;break t}a(Y,V);break}else n(Y,V);V=V.sibling}tt.type===G?(pt=Tr(tt.props.children,Y.mode,pt,tt.key),Fa(pt,tt),pt.return=Y,Y=pt):(pt=Kl(tt.type,tt.key,tt.props,null,Y.mode,pt),Fa(pt,tt),pt.return=Y,Y=pt)}return v(Y);case R:t:{for(Xt=tt.key;V!==null;){if(V.key===Xt)if(V.tag===4&&V.stateNode.containerInfo===tt.containerInfo&&V.stateNode.implementation===tt.implementation){a(Y,V.sibling),pt=u(V,tt.children||[]),pt.return=Y,Y=pt;break t}else{a(Y,V);break}else n(Y,V);V=V.sibling}pt=Sf(tt,Y.mode,pt),pt.return=Y,Y=pt}return v(Y);case Mt:return tt=Ur(tt),pe(Y,V,tt,pt)}if(Rt(tt))return Pt(Y,V,tt,pt);if(at(tt)){if(Xt=at(tt),typeof Xt!="function")throw Error(r(150));return tt=Xt.call(tt),jt(Y,V,tt,pt)}if(typeof tt.then=="function")return pe(Y,V,su(tt),pt);if(tt.$$typeof===st)return pe(Y,V,nu(Y,tt),pt);ou(Y,tt)}return typeof tt=="string"&&tt!==""||typeof tt=="number"||typeof tt=="bigint"?(tt=""+tt,V!==null&&V.tag===6?(a(Y,V.sibling),pt=u(V,tt),pt.return=Y,Y=pt):(a(Y,V),pt=yf(tt,Y.mode,pt),pt.return=Y,Y=pt),v(Y)):a(Y,V)}return function(Y,V,tt,pt){try{zo=0;var Xt=pe(Y,V,tt,pt);return gs=null,Xt}catch(te){if(te===ms||te===au)throw te;var Ce=qn(29,te,null,Y.mode);return Ce.lanes=pt,Ce.return=Y,Ce}}}var Lr=Rg(!0),Cg=Rg(!1),Ha=!1;function Uf(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function Nf(t,n){t=t.updateQueue,n.updateQueue===t&&(n.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function Ga(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function Va(t,n,a){var s=t.updateQueue;if(s===null)return null;if(s=s.shared,(Be&2)!==0){var u=s.pending;return u===null?n.next=n:(n.next=u.next,u.next=n),s.pending=n,n=Zl(t),fg(t,null,a),n}return jl(t,s,n,a),Zl(t)}function Io(t,n,a){if(n=n.updateQueue,n!==null&&(n=n.shared,(a&4194048)!==0)){var s=n.lanes;s&=t.pendingLanes,a|=s,n.lanes=a,K(t,a)}}function Lf(t,n){var a=t.updateQueue,s=t.alternate;if(s!==null&&(s=s.updateQueue,a===s)){var u=null,f=null;if(a=a.firstBaseUpdate,a!==null){do{var v={lane:a.lane,tag:a.tag,payload:a.payload,callback:null,next:null};f===null?u=f=v:f=f.next=v,a=a.next}while(a!==null);f===null?u=f=n:f=f.next=n}else u=f=n;a={baseState:s.baseState,firstBaseUpdate:u,lastBaseUpdate:f,shared:s.shared,callbacks:s.callbacks},t.updateQueue=a;return}t=a.lastBaseUpdate,t===null?a.firstBaseUpdate=n:t.next=n,a.lastBaseUpdate=n}var Of=!1;function Bo(){if(Of){var t=ps;if(t!==null)throw t}}function Fo(t,n,a,s){Of=!1;var u=t.updateQueue;Ha=!1;var f=u.firstBaseUpdate,v=u.lastBaseUpdate,T=u.shared.pending;if(T!==null){u.shared.pending=null;var P=T,W=P.next;P.next=null,v===null?f=W:v.next=W,v=P;var ot=t.alternate;ot!==null&&(ot=ot.updateQueue,T=ot.lastBaseUpdate,T!==v&&(T===null?ot.firstBaseUpdate=W:T.next=W,ot.lastBaseUpdate=P))}if(f!==null){var gt=u.baseState;v=0,ot=W=P=null,T=f;do{var q=T.lane&-536870913,nt=q!==T.lane;if(nt?(Re&q)===q:(s&q)===q){q!==0&&q===wr&&(Of=!0),ot!==null&&(ot=ot.next={lane:0,tag:T.tag,payload:T.payload,callback:null,next:null});t:{var Pt=t,jt=T;q=n;var pe=a;switch(jt.tag){case 1:if(Pt=jt.payload,typeof Pt=="function"){gt=Pt.call(pe,gt,q);break t}gt=Pt;break t;case 3:Pt.flags=Pt.flags&-65537|128;case 0:if(Pt=jt.payload,q=typeof Pt=="function"?Pt.call(pe,gt,q):Pt,q==null)break t;gt=L({},gt,q);break t;case 2:Ha=!0}}q=T.callback,q!==null&&(t.flags|=64,nt&&(t.flags|=8192),nt=u.callbacks,nt===null?u.callbacks=[q]:nt.push(q))}else nt={lane:q,tag:T.tag,payload:T.payload,callback:T.callback,next:null},ot===null?(W=ot=nt,P=gt):ot=ot.next=nt,v|=q;if(T=T.next,T===null){if(T=u.shared.pending,T===null)break;nt=T,T=nt.next,nt.next=null,u.lastBaseUpdate=nt,u.shared.pending=null}}while(!0);ot===null&&(P=gt),u.baseState=P,u.firstBaseUpdate=W,u.lastBaseUpdate=ot,f===null&&(u.shared.lanes=0),Za|=v,t.lanes=v,t.memoizedState=gt}}function wg(t,n){if(typeof t!="function")throw Error(r(191,t));t.call(n)}function Dg(t,n){var a=t.callbacks;if(a!==null)for(t.callbacks=null,t=0;t<a.length;t++)wg(a[t],n)}var Xa=Qt(null),lu=Qt(0);function Ug(t,n){t=_a,ie(lu,t),ie(Xa,n),_a=t|n.baseLanes}function Pf(){ie(lu,_a),ie(Xa,Xa.current)}function zf(){_a=lu.current,Ot(Xa),Ot(lu)}var Rn=Qt(null),Pn=null;function ka(t){var n=t.alternate;ie(Cn,Cn.current&1),ie(Rn,t),Pn===null&&(n===null||Xa.current!==null||n.memoizedState!==null)&&(Pn=t)}function If(t){ie(Cn,Cn.current),ie(Rn,t),Pn===null&&(Pn=t)}function Ng(t){t.tag===22?(ie(Cn,Cn.current),ie(Rn,t),Pn===null&&(Pn=t)):qa()}function qa(){ie(Cn,Cn.current),ie(Rn,Rn.current)}function ni(t){Ot(Rn),Pn===t&&(Pn=null),Ot(Cn)}var Cn=Qt(0);function Ho(t,n){ie(Rn,Rn.current),ie(Cn,n)}function Bf(t){Ot(Cn),Ot(Rn),Pn===t&&(Pn=null)}function uu(t){for(var n=t;n!==null;){if(n.tag===13){var a=n.memoizedState;if(a!==null&&(a=a.dehydrated,a===null||sd(a)||od(a)))return n}else if(n.tag===19&&n.memoizedProps.revealOrder!=="independent"){if((n.flags&128)!==0)return n}else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return null;n=n.return}n.sibling.return=n.return,n=n.sibling}return null}var da=0,de=null,qe=null,fn=null,cu=!1,_s=!1,Or=!1,fu=0,Go=0,vs=null,sM=0;function sn(){throw Error(r(321))}function Ff(t,n){if(n===null)return!1;for(var a=0;a<n.length&&a<t.length;a++)if(!ei(t[a],n[a]))return!1;return!0}function Hf(t,n,a,s,u,f){return da=f,de=n,n.memoizedState=null,n.updateQueue=null,n.lanes=0,St.H=t===null||t.memoizedState===null?m_:g_,Or=!1,f=a(s,u),Or=!1,_s&&(f=Og(n,a,s,u)),Lg(t),f}function Lg(t){St.H=vu;var n=qe!==null&&qe.next!==null;if(da=0,fn=qe=de=null,cu=!1,Go=0,vs=null,n)throw Error(r(300));t===null||hn||(t=t.dependencies,t!==null&&eu(t)&&(hn=!0))}function Og(t,n,a,s){de=t;var u=0;do{if(_s&&(vs=null),Go=0,_s=!1,25<=u)throw Error(r(301));if(u+=1,fn=qe=null,t.updateQueue!=null){var f=t.updateQueue;f.lastEffect=null,f.events=null,f.stores=null,f.memoCache!=null&&(f.memoCache.index=0)}St.H=pM,f=n(a,s)}while(_s);return f}function oM(){var t=St.H,n=t.useState()[0];return n=typeof n.then=="function"?Vo(n):n,t=t.useState()[0],(qe!==null?qe.memoizedState:null)!==t&&(de.flags|=1024),n}function Gf(){var t=fu!==0;return fu=0,t}function Vf(t,n,a){n.updateQueue=t.updateQueue,n.flags&=-2053,t.lanes&=~a}function Xf(t){if(cu){for(t=t.memoizedState;t!==null;){var n=t.queue;n!==null&&(n.pending=null),t=t.next}cu=!1}da=0,fn=qe=de=null,_s=!1,Go=fu=0,vs=null}function Gn(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return fn===null?de.memoizedState=fn=t:fn=fn.next=t,fn}function ln(){if(qe===null){var t=de.alternate;t=t!==null?t.memoizedState:null}else t=qe.next;var n=fn===null?de.memoizedState:fn.next;if(n!==null)fn=n,qe=t;else{if(t===null)throw de.alternate===null?Error(r(467)):Error(r(310));qe=t,t={memoizedState:qe.memoizedState,baseState:qe.baseState,baseQueue:qe.baseQueue,queue:qe.queue,next:null},fn===null?de.memoizedState=fn=t:fn=fn.next=t}return fn}function hu(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Vo(t){var n=Go;return Go+=1,vs===null&&(vs=[]),t=Tg(vs,t,n),n=de,(fn===null?n.memoizedState:fn.next)===null&&(n=n.alternate,St.H=n===null||n.memoizedState===null?m_:g_),t}function du(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return Vo(t);if(t.$$typeof===ft)return;if(t.$$typeof===st)return An(t)}throw Error(r(438,String(t)))}function kf(t){var n=null,a=de.updateQueue;if(a!==null&&(n=a.memoCache),n==null){var s=de.alternate;s!==null&&(s=s.updateQueue,s!==null&&(s=s.memoCache,s!=null&&(n={data:s.data.map(function(u){return u.slice()}),index:0})))}if(n==null&&(n={data:[],index:0}),a===null&&(a=hu(),de.updateQueue=a),a.memoCache=n,a=n.data[n.index],a===void 0)for(a=n.data[n.index]=Array(t),s=0;s<t;s++)a[s]=xe;return n.index++,a}function pa(t,n){return typeof n=="function"?n(t):n}function pu(t){var n=ln();return qf(n,qe,t)}function qf(t,n,a){var s=t.queue;if(s===null)throw Error(r(311));s.lastRenderedReducer=a;var u=t.baseQueue,f=s.pending;if(f!==null){if(u!==null){var v=u.next;u.next=f.next,f.next=v}n.baseQueue=u=f,s.pending=null}if(f=t.baseState,u===null)t.memoizedState=f;else{n=u.next;var T=v=null,P=null,W=n,ot=!1;do{var gt=W.lane&-536870913;if(gt!==W.lane?(Re&gt)===gt:(da&gt)===gt){var q=W.revertLane;if(q===0)P!==null&&(P=P.next={lane:0,revertLane:0,gesture:null,action:W.action,hasEagerState:W.hasEagerState,eagerState:W.eagerState,next:null}),gt===wr&&(ot=!0);else if((da&q)===q){W=W.next,q===wr&&(ot=!0);continue}else gt={lane:0,revertLane:W.revertLane,gesture:null,action:W.action,hasEagerState:W.hasEagerState,eagerState:W.eagerState,next:null},P===null?(T=P=gt,v=f):P=P.next=gt,de.lanes|=q,Za|=q;gt=W.action,Or&&a(f,gt),f=W.hasEagerState?W.eagerState:a(f,gt)}else q={lane:gt,revertLane:W.revertLane,gesture:W.gesture,action:W.action,hasEagerState:W.hasEagerState,eagerState:W.eagerState,next:null},P===null?(T=P=q,v=f):P=P.next=q,de.lanes|=gt,Za|=gt;W=W.next}while(W!==null&&W!==n);if(P===null?v=f:P.next=T,!ei(f,t.memoizedState)&&(hn=!0,ot&&(a=ps,a!==null)))throw a;t.memoizedState=f,t.baseState=v,t.baseQueue=P,s.lastRenderedState=f}return u===null&&(s.lanes=0),[t.memoizedState,s.dispatch]}function Yf(t){var n=ln(),a=n.queue;if(a===null)throw Error(r(311));a.lastRenderedReducer=t;var s=a.dispatch,u=a.pending,f=n.memoizedState;if(u!==null){a.pending=null;var v=u=u.next;do f=t(f,v.action),v=v.next;while(v!==u);ei(f,n.memoizedState)||(hn=!0),n.memoizedState=f,n.baseQueue===null&&(n.baseState=f),a.lastRenderedState=f}return[f,s]}function Pg(t,n,a){var s=de,u=ln(),f=ve;if(f){if(a===void 0)throw Error(r(407));a=a()}else a=n();var v=!ei((qe||u).memoizedState,a);if(v&&(u.memoizedState=a,hn=!0),u=u.queue,Zf(Bg.bind(null,s,u,t),[t]),t=u.getSnapshot!==n||v||fn!==null&&(fn.memoizedState.tag&1)!==0,xs(t?9:8,{destroy:void 0},Ig.bind(null,s,u,a,n),null),t){if(s.flags|=2048,je===null)throw Error(r(349));f||(da&127)!==0||zg(s,n,a)}return a}function zg(t,n,a){t.flags|=16384,t={getSnapshot:n,value:a},n=de.updateQueue,n===null?(n=hu(),de.updateQueue=n,n.stores=[t]):(a=n.stores,a===null?n.stores=[t]:a.push(t))}function Ig(t,n,a,s){n.value=a,n.getSnapshot=s,Fg(n)&&Hg(t)}function Bg(t,n,a){return a(function(){Fg(n)&&Hg(t)})}function Fg(t){var n=t.getSnapshot;t=t.value;try{var a=n();return!ei(t,a)}catch{return!0}}function Hg(t){var n=Er(t,2);n!==null&&Zn(n,t,2)}function Wf(t){var n=Gn();if(typeof t=="function"){var a=t;if(t=a(),Or){gn(!0);try{a()}finally{gn(!1)}}}return n.memoizedState=n.baseState=t,n.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:pa,lastRenderedState:t},n}function Gg(t,n,a,s){return t.baseState=a,qf(t,qe,typeof s=="function"?s:pa)}function lM(t,n,a,s,u){if(_u(t))throw Error(r(485));if(t=n.action,t!==null){var f={payload:u,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(v){f.listeners.push(v)}};St.T!==null?a(!0):f.isTransition=!1,s(f),a=n.pending,a===null?(f.next=n.pending=f,Vg(n,f)):(f.next=a.next,n.pending=a.next=f)}}function Vg(t,n){var a=n.action,s=n.payload,u=t.state;if(n.isTransition){var f=St.T,v={};v.types=f!==null?f.types:null,St.T=v;try{var T=a(u,s),P=St.S;P!==null&&P(v,T),Xg(t,n,T)}catch(W){jf(t,n,W)}finally{f!==null&&v.types!==null&&(f.types=v.types),St.T=f}}else try{f=a(u,s),Xg(t,n,f)}catch(W){jf(t,n,W)}}function Xg(t,n,a){a!==null&&typeof a=="object"&&typeof a.then=="function"?a.then(function(s){kg(t,n,s)},function(s){return jf(t,n,s)}):kg(t,n,a)}function kg(t,n,a){n.status="fulfilled",n.value=a,qg(n),t.state=a,n=t.pending,n!==null&&(a=n.next,a===n?t.pending=null:(a=a.next,n.next=a,Vg(t,a)))}function jf(t,n,a){var s=t.pending;if(t.pending=null,s!==null){s=s.next;do n.status="rejected",n.reason=a,qg(n),n=n.next;while(n!==s)}t.action=null}function qg(t){t=t.listeners;for(var n=0;n<t.length;n++)(0,t[n])()}function Yg(t,n){return n}function Wg(t,n){if(ve){var a=je.formState;if(a!==null){t:{var s=de;if(ve){if(Ke){e:{for(var u=Ke,f=_i;u.nodeType!==8;){if(!f){u=null;break e}if(u=xi(u.nextSibling),u===null){u=null;break e}}f=u.data,u=f==="F!"||f==="F"?u:null}if(u){Ke=xi(u.nextSibling),s=u.data==="F!";break t}}Ia(s)}s=!1}s&&(n=a[0])}}return a=Gn(),a.memoizedState=a.baseState=n,s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Yg,lastRenderedState:n},a.queue=s,a=h_.bind(null,de,s),s.dispatch=a,s=Wf(!1),f=th.bind(null,de,!1,s.queue),s=Gn(),u={state:n,dispatch:null,action:t,pending:null},s.queue=u,a=lM.bind(null,de,u,f,a),u.dispatch=a,s.memoizedState=t,[n,a,!1]}function jg(t){var n=ln();return Zg(n,qe,t)}function Zg(t,n,a){if(n=qf(t,n,Yg)[0],t=pu(pa)[0],typeof n=="object"&&n!==null&&typeof n.then=="function")try{var s=Vo(n)}catch(v){throw v===ms?au:v}else s=n;n=ln();var u=n.queue,f=u.dispatch;return a!==n.memoizedState&&(de.flags|=2048,xs(9,{destroy:void 0},uM.bind(null,u,a),null)),[s,f,t]}function uM(t,n){t.action=n}function Kg(t){var n=ln(),a=qe;if(a!==null)return Zg(n,a,t);ln(),n=n.memoizedState,a=ln();var s=a.queue.dispatch;return a.memoizedState=t,[n,s,!1]}function xs(t,n,a,s){return t={tag:t,create:a,deps:s,inst:n,next:null},n=de.updateQueue,n===null&&(n=hu(),de.updateQueue=n),a=n.lastEffect,a===null?n.lastEffect=t.next=t:(s=a.next,a.next=t,t.next=s,n.lastEffect=t),t}function Qg(){return ln().memoizedState}function mu(t,n,a,s){var u=Gn();de.flags|=t,u.memoizedState=xs(1|n,{destroy:void 0},a,s===void 0?null:s)}function gu(t,n,a,s){var u=ln();s=s===void 0?null:s;var f=u.memoizedState.inst;qe!==null&&s!==null&&Ff(s,qe.memoizedState.deps)?u.memoizedState=xs(n,f,a,s):(de.flags|=t,u.memoizedState=xs(1|n,f,a,s))}function Jg(t,n){mu(8390656,8,t,n)}function Zf(t,n){gu(2048,8,t,n)}function cM(t){de.flags|=4;var n=de.updateQueue;if(n===null)n=hu(),de.updateQueue=n,n.events=[t];else{var a=n.events;a===null?n.events=[t]:a.push(t)}}function $g(t){var n=ln().memoizedState;return cM({ref:n,nextImpl:t}),function(){if((Be&2)!==0)throw Error(r(440));return n.impl.apply(void 0,arguments)}}function t_(t,n){return gu(4,2,t,n)}function e_(t,n){return gu(4,4,t,n)}function n_(t,n){if(typeof n=="function"){t=t();var a=n(t);return function(){typeof a=="function"?a():n(null)}}if(n!=null)return t=t(),n.current=t,function(){n.current=null}}function i_(t,n,a){a=a!=null?a.concat([t]):null,gu(4,4,n_.bind(null,n,t),a)}function Kf(){}function a_(t,n){var a=ln();n=n===void 0?null:n;var s=a.memoizedState;return n!==null&&Ff(n,s[1])?s[0]:(a.memoizedState=[t,n],t)}function r_(t,n){var a=ln();n=n===void 0?null:n;var s=a.memoizedState;if(n!==null&&Ff(n,s[1]))return s[0];if(s=t(),Or){gn(!0);try{t()}finally{gn(!1)}}return a.memoizedState=[s,n],s}function Qf(t,n,a){return a===void 0||(da&1073741824)!==0&&(Re&261930)===0?t.memoizedState=n:(t.memoizedState=a,t=mv(),de.lanes|=t,Za|=t,a)}function s_(t,n,a,s){return ei(a,n)?a:Xa.current!==null?(t=Qf(t,a,s),ei(t,n)||(hn=!0),t):(da&106)===0||(da&1073741824)!==0&&(Re&261930)===0?(hn=!0,t.memoizedState=a):(t=mv(),de.lanes|=t,Za|=t,n)}function o_(t,n,a,s,u){var f=kt.p;kt.p=f!==0&&8>f?f:8;var v=St.T,T={};T.types=v!==null?v.types:null,St.T=T,th(t,!1,n,a);try{var P=u(),W=St.S;if(W!==null&&W(T,P),P!==null&&typeof P=="object"&&typeof P.then=="function"){var ot=rM(P,s);Xo(t,n,ot,si(t))}else Xo(t,n,s,si(t))}catch(gt){Xo(t,n,{then:function(){},status:"rejected",reason:gt},si())}finally{kt.p=f,v!==null&&T.types!==null&&(v.types=T.types),St.T=v}}function fM(){}function Jf(t,n,a,s){if(t.tag!==5)throw Error(r(476));var u=l_(t).queue;o_(t,u,n,F,a===null?fM:function(){return u_(t),a(s)})}function l_(t){var n=t.memoizedState;if(n!==null)return n;n={memoizedState:F,baseState:F,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:pa,lastRenderedState:F},next:null};var a={};return n.next={memoizedState:a,baseState:a,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:pa,lastRenderedState:a},next:null},t.memoizedState=n,t=t.alternate,t!==null&&(t.memoizedState=n),n}function u_(t){var n=l_(t);n.next===null&&(n=t.alternate.memoizedState),Xo(t,n.next.queue,{},si())}function $f(){return An(Bs)}function c_(){return ln().memoizedState}function f_(){return ln().memoizedState}function hM(t){for(var n=t.return;n!==null;){switch(n.tag){case 24:case 3:var a=si();t=Ga(a);var s=Va(n,t,a);s!==null&&(Zn(s,n,a),Io(s,n,a)),n={cache:Rf()},t.payload=n;return}n=n.return}}function dM(t,n,a){var s=si();a={lane:s,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null},_u(t)?d_(n,a):(a=vf(t,n,a,s),a!==null&&(Zn(a,t,s),p_(a,n,s)))}function h_(t,n,a){var s=si();Xo(t,n,a,s)}function Xo(t,n,a,s){var u={lane:s,revertLane:0,gesture:null,action:a,hasEagerState:!1,eagerState:null,next:null};if(_u(t))d_(n,u);else{var f=t.alternate;if(t.lanes===0&&(f===null||f.lanes===0)&&(f=n.lastRenderedReducer,f!==null))try{var v=n.lastRenderedState,T=f(v,a);if(u.hasEagerState=!0,u.eagerState=T,ei(T,v))return jl(t,n,u,0),je===null&&Wl(),!1}catch{}if(a=vf(t,n,u,s),a!==null)return Zn(a,t,s),p_(a,n,s),!0}return!1}function th(t,n,a,s){if(s={lane:2,revertLane:kh(),gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null},_u(t)){if(n)throw Error(r(479))}else n=vf(t,a,s,2),n!==null&&Zn(n,t,2)}function _u(t){var n=t.alternate;return t===de||n!==null&&n===de}function d_(t,n){_s=cu=!0;var a=t.pending;a===null?n.next=n:(n.next=a.next,a.next=n),t.pending=n}function p_(t,n,a){if((a&4194048)!==0){var s=n.lanes;s&=t.pendingLanes,a|=s,n.lanes=a,K(t,a)}}var vu={readContext:An,use:du,useCallback:sn,useContext:sn,useEffect:sn,useImperativeHandle:sn,useLayoutEffect:sn,useInsertionEffect:sn,useMemo:sn,useReducer:sn,useRef:sn,useState:sn,useDebugValue:sn,useDeferredValue:sn,useTransition:sn,useSyncExternalStore:sn,useId:sn,useHostTransitionStatus:sn,useFormState:sn,useActionState:sn,useOptimistic:sn,useMemoCache:sn,useCacheRefresh:sn,useEffectEvent:sn},m_={readContext:An,use:du,useCallback:function(t,n){return Gn().memoizedState=[t,n===void 0?null:n],t},useContext:An,useEffect:Jg,useImperativeHandle:function(t,n,a){a=a!=null?a.concat([t]):null,mu(4194308,4,n_.bind(null,n,t),a)},useLayoutEffect:function(t,n){return mu(4194308,4,t,n)},useInsertionEffect:function(t,n){mu(4,2,t,n)},useMemo:function(t,n){var a=Gn();n=n===void 0?null:n;var s=t();if(Or){gn(!0);try{t()}finally{gn(!1)}}return a.memoizedState=[s,n],s},useReducer:function(t,n,a){var s=Gn();if(a!==void 0){var u=a(n);if(Or){gn(!0);try{a(n)}finally{gn(!1)}}}else u=n;return s.memoizedState=s.baseState=u,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:u},s.queue=t,t=t.dispatch=dM.bind(null,de,t),[s.memoizedState,t]},useRef:function(t){var n=Gn();return t={current:t},n.memoizedState=t},useState:function(t){t=Wf(t);var n=t.queue,a=h_.bind(null,de,n);return n.dispatch=a,[t.memoizedState,a]},useDebugValue:Kf,useDeferredValue:function(t,n){var a=Gn();return Qf(a,t,n)},useTransition:function(){var t=Wf(!1);return t=o_.bind(null,de,t.queue,!0,!1),Gn().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,n,a){var s=de,u=Gn();if(ve){if(a===void 0)throw Error(r(407));a=a()}else{if(a=n(),je===null)throw Error(r(349));(Re&127)!==0||zg(s,n,a)}u.memoizedState=a;var f={value:a,getSnapshot:n};return u.queue=f,Jg(Bg.bind(null,s,f,t),[t]),s.flags|=2048,xs(9,{destroy:void 0},Ig.bind(null,s,f,a,n),null),a},useId:function(){var t=Gn(),n=je.identifierPrefix;if(ve){var a=Vi,s=Gi;a=(s&~(1<<32-Ln(s)-1)).toString(32)+a,n="_"+n+"R_"+a,a=fu++,0<a&&(n+="H"+a.toString(32)),n+="_"}else a=sM++,n="_"+n+"r_"+a.toString(32)+"_";return t.memoizedState=n},useHostTransitionStatus:$f,useFormState:Wg,useActionState:Wg,useOptimistic:function(t){var n=Gn();n.memoizedState=n.baseState=t;var a={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return n.queue=a,n=th.bind(null,de,!0,a),a.dispatch=n,[t,n]},useMemoCache:kf,useCacheRefresh:function(){return Gn().memoizedState=hM.bind(null,de)},useEffectEvent:function(t){var n=Gn(),a={impl:t};return n.memoizedState=a,function(){if((Be&2)!==0)throw Error(r(440));return a.impl.apply(void 0,arguments)}}},g_={readContext:An,use:du,useCallback:a_,useContext:An,useEffect:Zf,useImperativeHandle:i_,useInsertionEffect:t_,useLayoutEffect:e_,useMemo:r_,useReducer:pu,useRef:Qg,useState:function(){return pu(pa)},useDebugValue:Kf,useDeferredValue:function(t,n){var a=ln();return s_(a,qe.memoizedState,t,n)},useTransition:function(){var t=pu(pa)[0],n=ln().memoizedState;return[typeof t=="boolean"?t:Vo(t),n]},useSyncExternalStore:Pg,useId:c_,useHostTransitionStatus:$f,useFormState:jg,useActionState:jg,useOptimistic:function(t,n){var a=ln();return Gg(a,qe,t,n)},useMemoCache:kf,useCacheRefresh:f_,useEffectEvent:$g},pM={readContext:An,use:du,useCallback:a_,useContext:An,useEffect:Zf,useImperativeHandle:i_,useInsertionEffect:t_,useLayoutEffect:e_,useMemo:r_,useReducer:Yf,useRef:Qg,useState:function(){return Yf(pa)},useDebugValue:Kf,useDeferredValue:function(t,n){var a=ln();return qe===null?Qf(a,t,n):s_(a,qe.memoizedState,t,n)},useTransition:function(){var t=Yf(pa)[0],n=ln().memoizedState;return[typeof t=="boolean"?t:Vo(t),n]},useSyncExternalStore:Pg,useId:c_,useHostTransitionStatus:$f,useFormState:Kg,useActionState:Kg,useOptimistic:function(t,n){var a=ln();return qe!==null?Gg(a,qe,t,n):(a.baseState=t,[t,a.queue.dispatch])},useMemoCache:kf,useCacheRefresh:f_,useEffectEvent:$g};function eh(t,n,a,s){n=t.memoizedState,a=a(s,n),a=a==null?n:L({},n,a),t.memoizedState=a,t.lanes===0&&(t.updateQueue.baseState=a)}var nh={enqueueSetState:function(t,n,a){t=t._reactInternals;var s=si(),u=Ga(s);u.payload=n,a!=null&&(u.callback=a),n=Va(t,u,s),n!==null&&(Zn(n,t,s),Io(n,t,s))},enqueueReplaceState:function(t,n,a){t=t._reactInternals;var s=si(),u=Ga(s);u.tag=1,u.payload=n,a!=null&&(u.callback=a),n=Va(t,u,s),n!==null&&(Zn(n,t,s),Io(n,t,s))},enqueueForceUpdate:function(t,n){t=t._reactInternals;var a=si(),s=Ga(a);s.tag=2,n!=null&&(s.callback=n),n=Va(t,s,a),n!==null&&(Zn(n,t,a),Io(n,t,a))}};function __(t,n,a,s,u,f,v){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(s,f,v):n.prototype&&n.prototype.isPureReactComponent?!wo(a,s)||!wo(u,f):!0}function v_(t,n,a,s){t=n.state,typeof n.componentWillReceiveProps=="function"&&n.componentWillReceiveProps(a,s),typeof n.UNSAFE_componentWillReceiveProps=="function"&&n.UNSAFE_componentWillReceiveProps(a,s),n.state!==t&&nh.enqueueReplaceState(n,n.state,null)}function Pr(t,n){var a=n;if("ref"in n){a={};for(var s in n)s!=="ref"&&(a[s]=n[s])}if(t=t.defaultProps){a===n&&(a=L({},a));for(var u in t)a[u]===void 0&&(a[u]=t[u])}return a}function x_(t){Yl(t)}function y_(t){console.error(t)}function S_(t){Yl(t)}function xu(t,n){try{var a=t.onUncaughtError;a(n.value,{componentStack:n.stack})}catch(s){setTimeout(function(){throw s})}}function M_(t,n,a){try{var s=t.onCaughtError;s(a.value,{componentStack:a.stack,errorBoundary:n.tag===1?n.stateNode:null})}catch(u){setTimeout(function(){throw u})}}function ih(t,n,a){return a=Ga(a),a.tag=3,a.payload={element:null},a.callback=function(){xu(t,n)},a}function E_(t){return t=Ga(t),t.tag=3,t}function T_(t,n,a,s){var u=a.type.getDerivedStateFromError;if(typeof u=="function"){var f=s.value;t.payload=function(){return u(f)},t.callback=function(){M_(n,a,s)}}var v=a.stateNode;v!==null&&typeof v.componentDidCatch=="function"&&(t.callback=function(){M_(n,a,s),typeof u!="function"&&(Ka===null?Ka=new Set([this]):Ka.add(this));var T=s.stack;this.componentDidCatch(s.value,{componentStack:T!==null?T:""})})}function mM(t,n,a,s,u){if(a.flags|=32768,s!==null&&typeof s=="object"&&typeof s.then=="function"){if(n=a.alternate,n!==null&&Rr(n,a,u,!0),a=Rn.current,a!==null){switch(a.tag){case 31:case 13:case 19:return Pn===null?Hu():a.alternate===null&&on===0&&(on=3),a.flags&=-257,a.flags|=65536,a.lanes=u,s===ru?a.flags|=16384:(n=a.updateQueue,n===null?a.updateQueue=new Set([s]):n.add(s),Gh(t,s,u)),!1;case 22:return a.flags|=65536,s===ru?a.flags|=16384:(n=a.updateQueue,n===null?(n={transitions:null,markerInstances:null,retryQueue:new Set([s])},a.updateQueue=n):(a=n.retryQueue,a===null?n.retryQueue=new Set([s]):a.add(s)),Gh(t,s,u)),!1}throw Error(r(435,a.tag))}return Gh(t,s,u),Hu(),!1}if(ve)return n=Rn.current,n!==null?((n.flags&65536)===0&&(n.flags|=256),n.flags|=65536,n.lanes=u,s!==Ef&&(t=Error(r(422),{cause:s}),No(pi(t,a)))):(s!==Ef&&(n=Error(r(423),{cause:s}),No(pi(n,a))),t=t.current.alternate,t.flags|=65536,u&=-u,t.lanes|=u,s=pi(s,a),u=ih(t.stateNode,s,u),Lf(t,u),on!==4&&(on=2)),!1;var f=Error(r(520),{cause:s});if(f=pi(f,a),Qo===null?Qo=[f]:Qo.push(f),on!==4&&(on=2),n===null)return!0;s=pi(s,a),a=n;do{switch(a.tag){case 3:return a.flags|=65536,t=u&-u,a.lanes|=t,t=ih(a.stateNode,s,t),Lf(a,t),!1;case 1:if(n=a.type,f=a.stateNode,(a.flags&128)===0&&(typeof n.getDerivedStateFromError=="function"||f!==null&&typeof f.componentDidCatch=="function"&&(Ka===null||!Ka.has(f))))return a.flags|=65536,u&=-u,a.lanes|=u,u=E_(u),T_(u,t,a,s),Lf(a,u),!1;break;case 22:if(a.memoizedState!==null)return a.flags|=65536,!1}a=a.return}while(a!==null);return!1}var ah=Error(r(461)),hn=!1;function vn(t,n,a,s){n.child=t===null?Cg(n,null,a,s):Lr(n,t.child,a,s)}function b_(t,n,a,s,u){a=a.render;var f=n.ref;if("ref"in s){var v={};for(var T in s)T!=="ref"&&(v[T]=s[T])}else v=s;return Cr(n),s=Hf(t,n,a,v,f,u),T=Gf(),t!==null&&!hn?(Vf(t,n,u),ma(t,n,u)):(ve&&T&&Jl(n),n.flags|=1,vn(t,n,s,u),n.child)}function A_(t,n,a,s,u){if(t===null){var f=a.type;return typeof f=="function"&&!xf(f)&&f.defaultProps===void 0&&a.compare===null?(n.tag=15,n.type=f,R_(t,n,f,s,u)):(t=Kl(a.type,null,s,n,n.mode,u),t.ref=n.ref,t.return=n,n.child=t)}if(f=t.child,!hh(t,u)){var v=f.memoizedProps;if(a=a.compare,a=a!==null?a:wo,a(v,s)&&t.ref===n.ref)return ma(t,n,u)}return n.flags|=1,t=ua(f,s),t.ref=n.ref,t.return=n,n.child=t}function R_(t,n,a,s,u){if(t!==null){var f=t.memoizedProps;if(wo(f,s)&&t.ref===n.ref)if(hn=!1,n.pendingProps=s=f,hh(t,u))(t.flags&131072)!==0&&(hn=!0);else return n.lanes=t.lanes,ma(t,n,u)}return rh(t,n,a,s,u)}function C_(t,n,a,s){var u=s.children,f=t!==null?t.memoizedState:null;if(t===null&&n.stateNode===null&&(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),s.mode==="hidden"){if((n.flags&128)!==0){if(f=f!==null?f.baseLanes|a:a,t!==null){for(s=n.child=t.child,u=0;s!==null;)u=u|s.lanes|s.childLanes,s=s.sibling;s=u&~f}else s=0,n.child=null;return w_(t,n,f,a,s)}if((a&536870912)!==0)n.memoizedState={baseLanes:0,cachePool:null},t!==null&&iu(n,f!==null?f.cachePool:null),f!==null?Ug(n,f):Pf(),Ng(n);else return s=n.lanes=536870912,w_(t,n,f!==null?f.baseLanes|a:a,a,s)}else f!==null?(iu(n,f.cachePool),Ug(n,f),qa(),n.memoizedState=null):(t!==null&&iu(n,null),Pf(),qa());return vn(t,n,u,a),n.child}function ko(t,n){return t!==null&&t.tag===22||n.stateNode!==null||(n.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),n.sibling}function w_(t,n,a,s,u){var f=wf();return f=f===null?null:{parent:cn._currentValue,pool:f},n.memoizedState={baseLanes:a,cachePool:f},t!==null&&iu(n,null),Pf(),Ng(n),t!==null&&Rr(t,n,s,!0),n.childLanes=u,null}function yu(t,n){return n=Su({mode:n.mode,children:n.children},t.mode),n.ref=t.ref,t.child=n,n.return=t,n}function D_(t,n,a){return Lr(n,t.child,null,a),t=yu(n,n.pendingProps),t.flags|=2,ni(n),n.memoizedState=null,t}function gM(t,n,a){var s=n.pendingProps,u=(n.flags&128)!==0;if(n.flags&=-129,t===null){if(ve){if(s.mode==="hidden")return t=yu(n,s),n.lanes=536870912,t.memoizedState={baseLanes:0,cachePool:null},ko(null,t);if(If(n),(t=Ke)?(t=n0(t,_i),t=t!==null&&t.data==="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:Pa!==null?{id:Gi,overflow:Vi}:null,retryLane:536870912,hydrationErrors:null},a=dg(t),a.return=n,n.child=a,Sn=n,Ke=null)):t=null,t===null)throw Ia(n);return n.lanes=536870912,null}return yu(n,s)}var f=t.memoizedState;if(f!==null){var v=f.dehydrated;if(If(n),u)if(n.flags&256)n.flags&=-257,n=D_(t,n,a);else if(n.memoizedState!==null)n.child=t.child,n.flags|=128,n=null;else throw Error(r(558));else if(hn||Rr(t,n,a,!1),u=(a&t.childLanes)!==0,hn||u){if(Xa.current===null){if(s=je,s!==null&&(v=lt(s,a),v!==0&&v!==f.retryLane))throw f.retryLane=v,Er(t,v),Zn(s,t,v),ah;Hu()}n=D_(t,n,a)}else t=f.treeContext,Ke=xi(v.nextSibling),Sn=n,ve=!0,za=null,_i=!1,t!==null&&gg(n,t),n=yu(n,s),n.flags|=134221824;return n}return t=ua(t.child,{mode:s.mode,children:s.children}),t.ref=n.ref,n.child=t,t.return=n,t}function ys(t,n){var a=n.ref;if(a===null)t!==null&&t.ref!==null&&(n.flags|=4194816);else{if(typeof a!="function"&&typeof a!="object")throw Error(r(284));(t===null||t.ref!==a)&&(n.flags|=4194816)}}function rh(t,n,a,s,u){return Cr(n),a=Hf(t,n,a,s,void 0,u),s=Gf(),t!==null&&!hn?(Vf(t,n,u),ma(t,n,u)):(ve&&s&&Jl(n),n.flags|=1,vn(t,n,a,u),n.child)}function U_(t,n,a,s,u,f){return Cr(n),n.updateQueue=null,a=Og(n,s,a,u),Lg(t),s=Gf(),t!==null&&!hn?(Vf(t,n,f),ma(t,n,f)):(ve&&s&&Jl(n),n.flags|=1,vn(t,n,a,f),n.child)}function N_(t,n,a,s,u){if(Cr(n),n.stateNode===null){var f=cs,v=a.contextType;typeof v=="object"&&v!==null&&(f=An(v)),f=new a(s,f),n.memoizedState=f.state!==null&&f.state!==void 0?f.state:null,f.updater=nh,n.stateNode=f,f._reactInternals=n,f=n.stateNode,f.props=s,f.state=n.memoizedState,f.refs={},Uf(n),v=a.contextType,f.context=typeof v=="object"&&v!==null?An(v):cs,f.state=n.memoizedState,v=a.getDerivedStateFromProps,typeof v=="function"&&(eh(n,a,v,s),f.state=n.memoizedState),typeof a.getDerivedStateFromProps=="function"||typeof f.getSnapshotBeforeUpdate=="function"||typeof f.UNSAFE_componentWillMount!="function"&&typeof f.componentWillMount!="function"||(v=f.state,typeof f.componentWillMount=="function"&&f.componentWillMount(),typeof f.UNSAFE_componentWillMount=="function"&&f.UNSAFE_componentWillMount(),v!==f.state&&nh.enqueueReplaceState(f,f.state,null),Fo(n,s,f,u),Bo(),f.state=n.memoizedState),typeof f.componentDidMount=="function"&&(n.flags|=4194308),s=!0}else if(t===null){f=n.stateNode;var T=n.memoizedProps,P=Pr(a,T);f.props=P;var W=f.context,ot=a.contextType;v=cs,typeof ot=="object"&&ot!==null&&(v=An(ot));var gt=a.getDerivedStateFromProps;ot=typeof gt=="function"||typeof f.getSnapshotBeforeUpdate=="function",T=n.pendingProps!==T,ot||typeof f.UNSAFE_componentWillReceiveProps!="function"&&typeof f.componentWillReceiveProps!="function"||(T||W!==v)&&v_(n,f,s,v),Ha=!1;var q=n.memoizedState;f.state=q,Fo(n,s,f,u),Bo(),W=n.memoizedState,T||q!==W||Ha?(typeof gt=="function"&&(eh(n,a,gt,s),W=n.memoizedState),(P=Ha||__(n,a,P,s,q,W,v))?(ot||typeof f.UNSAFE_componentWillMount!="function"&&typeof f.componentWillMount!="function"||(typeof f.componentWillMount=="function"&&f.componentWillMount(),typeof f.UNSAFE_componentWillMount=="function"&&f.UNSAFE_componentWillMount()),typeof f.componentDidMount=="function"&&(n.flags|=4194308)):(typeof f.componentDidMount=="function"&&(n.flags|=4194308),n.memoizedProps=s,n.memoizedState=W),f.props=s,f.state=W,f.context=v,s=P):(typeof f.componentDidMount=="function"&&(n.flags|=4194308),s=!1)}else{f=n.stateNode,Nf(t,n),v=n.memoizedProps,ot=Pr(a,v),f.props=ot,gt=n.pendingProps,q=f.context,W=a.contextType,P=cs,typeof W=="object"&&W!==null&&(P=An(W)),T=a.getDerivedStateFromProps,(W=typeof T=="function"||typeof f.getSnapshotBeforeUpdate=="function")||typeof f.UNSAFE_componentWillReceiveProps!="function"&&typeof f.componentWillReceiveProps!="function"||(v!==gt||q!==P)&&v_(n,f,s,P),Ha=!1,q=n.memoizedState,f.state=q,Fo(n,s,f,u),Bo();var nt=n.memoizedState;v!==gt||q!==nt||Ha||t!==null&&t.dependencies!==null&&eu(t.dependencies)?(typeof T=="function"&&(eh(n,a,T,s),nt=n.memoizedState),(ot=Ha||__(n,a,ot,s,q,nt,P)||t!==null&&t.dependencies!==null&&eu(t.dependencies))?(W||typeof f.UNSAFE_componentWillUpdate!="function"&&typeof f.componentWillUpdate!="function"||(typeof f.componentWillUpdate=="function"&&f.componentWillUpdate(s,nt,P),typeof f.UNSAFE_componentWillUpdate=="function"&&f.UNSAFE_componentWillUpdate(s,nt,P)),typeof f.componentDidUpdate=="function"&&(n.flags|=4),typeof f.getSnapshotBeforeUpdate=="function"&&(n.flags|=1024)):(typeof f.componentDidUpdate!="function"||v===t.memoizedProps&&q===t.memoizedState||(n.flags|=4),typeof f.getSnapshotBeforeUpdate!="function"||v===t.memoizedProps&&q===t.memoizedState||(n.flags|=1024),n.memoizedProps=s,n.memoizedState=nt),f.props=s,f.state=nt,f.context=P,s=ot):(typeof f.componentDidUpdate!="function"||v===t.memoizedProps&&q===t.memoizedState||(n.flags|=4),typeof f.getSnapshotBeforeUpdate!="function"||v===t.memoizedProps&&q===t.memoizedState||(n.flags|=1024),s=!1)}return f=s,ys(t,n),s=(n.flags&128)!==0,f||s?(f=n.stateNode,a=s&&typeof a.getDerivedStateFromError!="function"?null:f.render(),n.flags|=1,t!==null&&s?(n.child=Lr(n,t.child,null,u),n.child=Lr(n,null,a,u)):vn(t,n,a,u),n.memoizedState=f.state,t=n.child):t=ma(t,n,u),t}function L_(t,n,a,s){return br(),n.flags|=256,vn(t,n,a,s),n.child}var sh={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function oh(t){return{baseLanes:t,cachePool:Mg()}}function lh(t,n,a){return t=t!==null?t.childLanes&~a:0,n&&(t|=ri),t}function O_(t,n,a){var s=n.pendingProps,u=!1,f=(n.flags&128)!==0,v;if((v=f)||(v=t!==null&&t.memoizedState===null?!1:(Cn.current&2)!==0),v&&(u=!0,n.flags&=-129),v=(n.flags&32)!==0,n.flags&=-33,t===null){if(ve){if(u?ka(n):qa(),(t=Ke)?(t=n0(t,_i),t=t!==null&&t.data!=="&"?t:null,t!==null&&(n.memoizedState={dehydrated:t,treeContext:Pa!==null?{id:Gi,overflow:Vi}:null,retryLane:536870912,hydrationErrors:null},a=dg(t),a.return=n,n.child=a,Sn=n,Ke=null)):t=null,t===null)throw Ia(n);return od(t)?n.lanes=32:n.lanes=536870912,null}return f=s.children,s=s.fallback,u?(qa(),u=n.mode,f=Su({mode:"hidden",children:f},u),s=Tr(s,u,a,null),f.return=n,s.return=n,f.sibling=s,n.child=f,s=n.child,s.memoizedState=oh(a),s.childLanes=lh(t,v,a),n.memoizedState=sh,ko(null,s)):(ka(n),uh(n,f))}var T=t.memoizedState;if(T!==null){var P=T.dehydrated;if(P!==null)return _M(t,n,f,v,s,P,T,a)}return u?(qa(),u=s.fallback,f=n.mode,T=t.child,P=T.sibling,s=ua(T,{mode:"hidden",children:s.children}),s.subtreeFlags=T.subtreeFlags&1206910976,P!==null?u=ua(P,u):(u=Tr(u,f,a,null),u.flags|=2),u.return=n,s.return=n,s.sibling=u,n.child=s,ko(null,s),s=n.child,u=t.child.memoizedState,u===null?u=oh(a):(f=u.cachePool,f!==null?(T=cn._currentValue,f=f.parent!==T?{parent:T,pool:T}:f):f=Mg(),u={baseLanes:u.baseLanes|a,cachePool:f}),s.memoizedState=u,s.childLanes=lh(t,v,a),n.memoizedState=sh,ko(t.child,s)):(ka(n),a=t.child,t=a.sibling,a=ua(a,{mode:"visible",children:s.children}),a.return=n,a.sibling=null,t!==null&&(v=n.deletions,v===null?(n.deletions=[t],n.flags|=16):v.push(t)),n.child=a,n.memoizedState=null,a)}function uh(t,n){return n=Su({mode:"visible",children:n},t.mode),n.return=t,t.child=n}function Su(t,n){return t=qn(22,t,null,n),t.lanes=0,t}function Mu(t,n,a){return Lr(n,t.child,null,a),t=uh(n,n.pendingProps.children),t.flags|=2,n.memoizedState=null,t}function _M(t,n,a,s,u,f,v,T){if(a)return n.flags&256?(ka(n),n.flags&=-257,Mu(t,n,T)):n.memoizedState!==null?(qa(),n.child=t.child,n.flags|=128,null):(qa(),f=u.fallback,v=n.mode,u=Su({mode:"visible",children:u.children},v),f=Tr(f,v,T,null),f.flags|=2,u.return=n,f.return=n,u.sibling=f,n.child=u,Lr(n,t.child,null,T),u=n.child,u.memoizedState=oh(T),u.childLanes=lh(t,s,T),n.memoizedState=sh,ko(null,u));if(ka(n),od(f)){if(s=f.nextSibling&&f.nextSibling.dataset,s)var P=s.dgst;return s=P,s!==""&&(u=Error(r(419)),u.stack="",u.digest=s,No({value:u,source:null,stack:null})),Mu(t,n,T)}if(hn||Rr(t,n,T,!1),s=(T&t.childLanes)!==0,hn||s){if(Xa.current!==null)return Mu(t,n,T);if(s=je,s!==null&&(u=lt(s,T),u!==0&&u!==v.retryLane))throw v.retryLane=u,Er(t,u),Zn(s,t,u),ah;return sd(f)||Hu(),Mu(t,n,T)}return sd(f)?(n.flags|=192,n.child=t.child,null):(t=v.treeContext,Ke=xi(f.nextSibling),Sn=n,ve=!0,za=null,_i=!1,t!==null&&gg(n,t),n=uh(n,u.children),n.flags|=134221824,n)}function P_(t,n,a){t.lanes|=n;var s=t.alternate;s!==null&&(s.lanes|=n),tu(t.return,n,a)}function z_(t){for(var n=null;t!==null;){var a=t.alternate;a!==null&&uu(a)===null&&(n=t),t=t.sibling}return n}function Eu(t,n,a,s,u,f){var v=t.memoizedState;v===null?t.memoizedState={isBackwards:n,rendering:null,renderingStartTime:0,last:s,tail:a,tailMode:u,treeForkCount:f}:(v.isBackwards=n,v.rendering=null,v.renderingStartTime=0,v.last=s,v.tail=a,v.tailMode=u,v.treeForkCount=f)}function ch(t){var n=t.child;for(t.child=null;n!==null;){var a=n.sibling;n.sibling=t.child,t.child=n,n=a}}function fh(t,n,a){var s=n.pendingProps,u=s.revealOrder,f=s.tail;s=s.children;var v=Cn.current;if(n.flags&128)return Ho(n,v),null;var T=(v&2)!==0;if(T?(v=v&1|2,n.flags|=128):v&=1,Ho(n,v),u==="backwards"&&t!==null?(ch(t),vn(t,n,s,a),ch(t)):vn(t,n,s,a),s=ve?Uo:0,!T&&t!==null&&(t.flags&128)!==0)t:for(t=n.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&P_(t,a,n);else if(t.tag===19)P_(t,a,n);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===n)break t;for(;t.sibling===null;){if(t.return===null||t.return===n)break t;t=t.return}t.sibling.return=t.return,t=t.sibling}switch(u){case"backwards":a=z_(n.child),a===null?(u=n.child,n.child=null):(u=a.sibling,a.sibling=null,ch(n)),Eu(n,!0,u,null,f,s);break;case"unstable_legacy-backwards":for(a=null,u=n.child,n.child=null;u!==null;){if(t=u.alternate,t!==null&&uu(t)===null){n.child=u;break}t=u.sibling,u.sibling=a,a=u,u=t}Eu(n,!0,a,null,f,s);break;case"together":Eu(n,!1,null,null,void 0,s);break;case"independent":n.memoizedState=null;break;default:a=z_(n.child),a===null?(u=n.child,n.child=null):(u=a.sibling,a.sibling=null),Eu(n,!1,u,a,f,s)}return n.child}function I_(t,n,a){var s=n.pendingProps;return Ba(n,n.type,s.value),vn(t,n,s.children,a),n.child}function ma(t,n,a){if(t!==null&&(n.dependencies=t.dependencies),Za|=n.lanes,(a&n.childLanes)===0)if(t!==null){if(Rr(t,n,a,!1),(a&n.childLanes)===0)return null}else return null;if(t!==null&&n.child!==t.child)throw Error(r(153));if(n.child!==null){for(t=n.child,a=ua(t,t.pendingProps),n.child=a,a.return=n;t.sibling!==null;)t=t.sibling,a=a.sibling=ua(t,t.pendingProps),a.return=n;a.sibling=null}return n.child}function hh(t,n){return(t.lanes&n)!==0?!0:(t=t.dependencies,!!(t!==null&&eu(t)))}function vM(t,n,a){switch(n.tag){case 3:O(n,n.stateNode.containerInfo),Ba(n,cn,t.memoizedState.cache),br();break;case 27:case 5:rt(n);break;case 4:O(n,n.stateNode.containerInfo);break;case 10:Ba(n,n.type,n.memoizedProps.value);break;case 31:if(n.memoizedState!==null)return n.flags|=128,If(n),null;break;case 13:var s=n.memoizedState;if(s!==null){if(s.dehydrated!==null)return ka(n),n.flags|=128,null;s=Rr(t,n,a,!1);var u=n.child.childLanes;return s||(a&u)!==0?O_(t,n,a):(ka(n),t=ma(t,n,a),t!==null?t.sibling:null)}ka(n);break;case 19:if(n.flags&128)return fh(t,n,a);if(u=(t.flags&128)!==0,s=(a&n.childLanes)!==0,s||(Rr(t,n,a,!1),s=(a&n.childLanes)!==0),u){if(s)return fh(t,n,a);n.flags|=128}if(u=n.memoizedState,u!==null&&(u.rendering=null,u.tail=null,u.lastEffect=null),Ho(n,Cn.current),s)break;return null;case 22:return n.lanes=0,C_(t,n,a,n.pendingProps);case 24:Ba(n,cn,t.memoizedState.cache)}return ma(t,n,a)}function B_(t,n,a){if(t!==null)if(t.memoizedProps!==n.pendingProps)hn=!0;else{if(!hh(t,a)&&(n.flags&128)===0)return hn=!1,vM(t,n,a);hn=(t.flags&131072)!==0}else hn=!1,ve&&(n.flags&1048576)!==0&&mg(n,Uo,n.index);switch(n.lanes=0,n.tag){case 16:t:{var s=n.pendingProps;if(t=Ur(n.elementType),n.type=t,typeof t=="function")xf(t)?(s=Pr(t,s),n.tag=1,n=N_(null,n,t,s,a)):(n.tag=0,n=rh(null,n,t,s,a));else{if(t!=null){var u=t.$$typeof;if(u===k){n.tag=11,n=b_(null,n,t,s,a);break t}else if(u===xt){n.tag=14,n=A_(null,n,t,s,a);break t}else if(u===st){n.tag=10,n.type=t,n=I_(null,n,a);break t}}throw n=Ut(t)||t,Error(r(306,n,""))}}return n;case 0:return rh(t,n,n.type,n.pendingProps,a);case 1:return s=n.type,u=Pr(s,n.pendingProps),N_(t,n,s,u,a);case 3:t:{if(O(n,n.stateNode.containerInfo),t===null)throw Error(r(387));s=n.pendingProps;var f=n.memoizedState;u=f.element,Nf(t,n),Fo(n,s,null,a);var v=n.memoizedState;if(s=v.cache,Ba(n,cn,s),s!==f.cache&&Af(n,[cn],a,!0),Bo(),s=v.element,f.isDehydrated)if(f={element:s,isDehydrated:!1,cache:v.cache},n.updateQueue.baseState=f,n.memoizedState=f,n.flags&256){n=L_(t,n,s,a);break t}else if(s!==u){u=pi(Error(r(424)),n),No(u),n=L_(t,n,s,a);break t}else for(t=n.stateNode.containerInfo,t.nodeType===9?t=t.body:t=t.nodeName==="HTML"?t.ownerDocument.body:t,Ke=xi(t.firstChild),Sn=n,ve=!0,za=null,_i=!0,a=Cg(n,null,s,a),n.child=a;a;)a.flags=a.flags&-3|134221824,a=a.sibling;else{if(br(),s===u){n=ma(t,n,a);break t}vn(t,n,s,a)}n=n.child}return n;case 26:return ys(t,n),t===null?(a=u0(n.type,null,n.pendingProps,null))?n.memoizedState=a:ve||(n.stateNode=Vv(n.type,n.pendingProps,le.current,n)):n.memoizedState=u0(n.type,t.memoizedProps,n.pendingProps,t.memoizedState),null;case 27:return rt(n),t===null&&ve&&(s=n.stateNode=r0(n.type,n.pendingProps,le.current),Sn=n,_i=!0,u=Ke,$a(n.type)?(ld=u,Ke=xi(s.firstChild)):Ke=u),vn(t,n,n.pendingProps.children,a),ys(t,n),t===null&&(n.flags|=4194304),n.child;case 5:return t===null&&ve&&((u=s=Ke)&&(s=hE(s,n.type,n.pendingProps,_i),s!==null?(n.stateNode=s,Sn=n,Ke=xi(s.firstChild),_i=!1,u=!0):u=!1),u||Ia(n)),rt(n),u=n.type,f=n.pendingProps,v=t!==null?t.memoizedProps:null,s=f.children,$h(u,f)?s=null:v!==null&&$h(u,v)&&(n.flags|=32),n.memoizedState!==null&&(u=Hf(t,n,oM,null,null,a),Bs._currentValue=u),ys(t,n),vn(t,n,s,a),n.child;case 6:return t===null&&ve&&((t=a=Ke)&&(a=dE(a,n.pendingProps,_i),a!==null?(n.stateNode=a,Sn=n,Ke=null,t=!0):t=!1),t||Ia(n)),null;case 13:return O_(t,n,a);case 4:return O(n,n.stateNode.containerInfo),s=n.pendingProps,t===null?n.child=Lr(n,null,s,a):vn(t,n,s,a),n.child;case 11:return b_(t,n,n.type,n.pendingProps,a);case 7:return s=n.pendingProps,ys(t,n),vn(t,n,s,a),n.child;case 8:return vn(t,n,n.pendingProps.children,a),n.child;case 12:return vn(t,n,n.pendingProps.children,a),n.child;case 10:return I_(t,n,a);case 9:return u=n.type._context,s=n.pendingProps.children,Cr(n),u=An(u),s=s(u),n.flags|=1,vn(t,n,s,a),n.child;case 14:return A_(t,n,n.type,n.pendingProps,a);case 15:return R_(t,n,n.type,n.pendingProps,a);case 19:return fh(t,n,a);case 31:return gM(t,n,a);case 22:return C_(t,n,a,n.pendingProps);case 24:return Cr(n),s=An(cn),t===null?(u=wf(),u===null&&(u=je,f=Rf(),u.pooledCache=f,f.refCount++,f!==null&&(u.pooledCacheLanes|=a),u=f),n.memoizedState={parent:s,cache:u},Uf(n),Ba(n,cn,u)):((t.lanes&a)!==0&&(Nf(t,n),Fo(n,null,null,a),Bo()),u=t.memoizedState,f=n.memoizedState,u.parent!==s?(u={parent:s,cache:s},n.memoizedState=u,n.lanes===0&&(n.memoizedState=n.updateQueue.baseState=u),Ba(n,cn,s)):(s=f.cache,Ba(n,cn,s),s!==u.cache&&Af(n,[cn],a,!0))),vn(t,n,n.pendingProps.children,a),n.child;case 30:return n.stateNode===null&&(n.stateNode={autoName:null,paired:null,clones:null,ref:null}),s=n.pendingProps,s.name!=null&&s.name!=="auto"?n.flags|=t===null?18882560:18874368:ve&&Jl(n),t!==null&&t.memoizedProps.name!==s.name?n.flags|=4194816:ys(t,n),vn(t,n,s.children,a),n.child;case 29:throw n.pendingProps}throw Error(r(156,n.tag))}function ga(t){t.flags|=4}function dh(t,n,a,s,u){var f;if((f=(t.mode&32)!==0)&&(f=a===null?d0(n,s):d0(n,s)&&(s.src!==a.src||s.srcSet!==a.srcSet)),f){if(t.flags|=16777216,(u&335544128)===u)if(t.stateNode.complete)t.flags|=8192;else if(xv())t.flags|=8192;else throw Nr=ru,Df}else t.flags&=-16777217}function F_(t,n){if(n.type!=="stylesheet"||(n.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!p0(n))if(xv())t.flags|=8192;else throw Nr=ru,Df}function Tu(t,n){n!==null&&(t.flags|=4),t.flags&16384&&(n=t.tag!==22?zl():536870912,t.lanes|=n,bs|=n)}function qo(t,n){if(!ve)switch(t.tailMode){case"visible":break;case"collapsed":for(var a=t.tail,s=null;a!==null;)a.alternate!==null&&(s=a),a=a.sibling;s===null?n||t.tail===null?t.tail=null:t.tail.sibling=null:s.sibling=null;break;default:for(n=t.tail,a=null;n!==null;)n.alternate!==null&&(a=n),n=n.sibling;a===null?t.tail=null:a.sibling=null}}function Qe(t){var n=t.alternate!==null&&t.alternate.child===t.child,a=0,s=0;if(n)for(var u=t.child;u!==null;)a|=u.lanes|u.childLanes,s|=u.subtreeFlags&1206910976,s|=u.flags&1206910976,u.return=t,u=u.sibling;else for(u=t.child;u!==null;)a|=u.lanes|u.childLanes,s|=u.subtreeFlags,s|=u.flags,u.return=t,u=u.sibling;return t.subtreeFlags|=s,t.childLanes=a,n}function xM(t,n,a){var s=n.pendingProps;switch(Mf(n),n.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Qe(n),null;case 1:return Qe(n),null;case 3:return a=n.stateNode,s=null,t!==null&&(s=t.memoizedState.cache),n.memoizedState.cache!==s&&(n.flags|=2048),ha(cn),A(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(t===null||t.child===null)&&(ds(n)?ga(n):t===null||t.memoizedState.isDehydrated&&(n.flags&256)===0||(n.flags|=1024,Tf())),Qe(n),null;case 26:var u=n.type,f=n.memoizedState;return t===null?(ga(n),f!==null?(Qe(n),F_(n,f)):(Qe(n),dh(n,u,null,s,a))):f?f!==t.memoizedState?(ga(n),Qe(n),F_(n,f)):(Qe(n),n.flags&=-16777217):(t=t.memoizedProps,t!==s&&ga(n),Qe(n),dh(n,u,t,s,a)),null;case 27:if(mt(n),a=le.current,u=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==s&&ga(n);else{if(!s){if(n.stateNode===null)throw Error(r(166));return Qe(n),n.subtreeFlags&=-33554433,null}t=vt.current,ds(n)?_g(n):(t=r0(u,s,a),n.stateNode=t,ga(n))}return Qe(n),n.subtreeFlags&=-33554433,null;case 5:if(mt(n),u=n.type,t!==null&&n.stateNode!=null)t.memoizedProps!==s&&ga(n);else{if(!s){if(n.stateNode===null)throw Error(r(166));return Qe(n),n.subtreeFlags&=-33554433,null}if(f=vt.current,ds(n))_g(n);else{var v=nl(le.current);switch(f){case 1:f=v.createElementNS("http://www.w3.org/2000/svg",u);break;case 2:f=v.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;default:switch(u){case"svg":f=v.createElementNS("http://www.w3.org/2000/svg",u);break;case"math":f=v.createElementNS("http://www.w3.org/1998/Math/MathML",u);break;case"script":f=v.createElement("div"),f.innerHTML="<script><\/script>",f=f.removeChild(f.firstChild);break;case"select":f=typeof s.is=="string"?v.createElement("select",{is:s.is}):v.createElement("select"),s.multiple?f.multiple=!0:s.size&&(f.size=s.size);break;default:f=typeof s.is=="string"?v.createElement(u,{is:s.is}):v.createElement(u)}}f[Nt]=n,f[Wt]=s;t:for(v=n.child;v!==null;){if(v.tag===5||v.tag===6)f.appendChild(v.stateNode);else if(v.tag!==4&&v.tag!==27&&v.child!==null){v.child.return=v,v=v.child;continue}if(v===n)break t;for(;v.sibling===null;){if(v.return===null||v.return===n)break t;v=v.return}v.sibling.return=v.return,v=v.sibling}n.stateNode=f;t:switch(Dn(f,u,s),u){case"button":case"input":case"select":case"textarea":s=!!s.autoFocus;break t;case"img":s=!0;break t;default:s=!1}s&&ga(n)}}return Qe(n),n.subtreeFlags&=-33554433,dh(n,n.type,t===null?null:t.memoizedProps,n.pendingProps,a),null;case 6:if(t&&n.stateNode!=null)t.memoizedProps!==s&&ga(n);else{if(typeof s!="string"&&n.stateNode===null)throw Error(r(166));if(t=le.current,ds(n)){if(t=n.stateNode,a=n.memoizedProps,s=null,u=Sn,u!==null)switch(u.tag){case 27:case 5:s=u.memoizedProps}t[Nt]=n,t=!!(t.nodeValue===a||s!==null&&s.suppressHydrationWarning===!0||Bv(t.nodeValue,a)),t||Ia(n,!0)}else t=nl(t).createTextNode(s),t[Nt]=n,n.stateNode=t}return Qe(n),null;case 31:if(a=n.memoizedState,t===null||t.memoizedState!==null){if(s=ds(n),a!==null){if(t===null){if(!s)throw Error(r(318));if(t=n.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(r(557));t[Nt]=n}else br(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;Qe(n),t=!1}else a=Tf(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=a),t=!0;if(!t)return n.flags&256?(ni(n),n):(ni(n),null);if((n.flags&128)!==0)throw Error(r(558))}return Qe(n),null;case 13:if(s=n.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(u=ds(n),s!==null&&s.dehydrated!==null){if(t===null){if(!u)throw Error(r(318));if(u=n.memoizedState,u=u!==null?u.dehydrated:null,!u)throw Error(r(317));u[Nt]=n}else br(),(n.flags&128)===0&&(n.memoizedState=null),n.flags|=4;Qe(n),u=!1}else u=Tf(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=u),u=!0;if(!u)return n.flags&256?(ni(n),n):(ni(n),null)}return ni(n),(n.flags&128)!==0?(n.lanes=a,n):(a=s!==null,t=t!==null&&t.memoizedState!==null,a&&(s=n.child,u=null,s.alternate!==null&&s.alternate.memoizedState!==null&&s.alternate.memoizedState.cachePool!==null&&(u=s.alternate.memoizedState.cachePool.pool),f=null,s.memoizedState!==null&&s.memoizedState.cachePool!==null&&(f=s.memoizedState.cachePool.pool),f!==u&&(s.flags|=2048)),a!==t&&a&&(n.child.flags|=8192),Tu(n,n.updateQueue),Qe(n),null);case 4:return A(),t===null&&jh(n.stateNode.containerInfo),n.flags|=67108864,Qe(n),null;case 10:return ha(n.type),Qe(n),null;case 19:if(Bf(n),s=n.memoizedState,s===null)return Qe(n),null;if(u=(n.flags&128)!==0,f=s.rendering,f===null)if(u)qo(s,!1);else{if(on!==0||t!==null&&(t.flags&128)!==0)for(t=n.child;t!==null;){if(f=uu(t),f!==null){for(n.flags|=128,qo(s,!1),t=f.updateQueue,n.updateQueue=t,Tu(n,t),n.subtreeFlags=0,t=a,a=n.child;a!==null;)hg(a,t),a=a.sibling;return Ho(n,Cn.current&1|2),ve&&ca(n,s.treeForkCount),n.child}t=t.sibling}s.tail!==null&&X()>zu&&(n.flags|=128,u=!0,qo(s,!1),n.lanes=4194304)}else{if(!u)if(t=uu(f),t!==null){if(n.flags|=128,u=!0,t=t.updateQueue,n.updateQueue=t,Tu(n,t),qo(s,!0),s.tail===null&&s.tailMode!=="collapsed"&&s.tailMode!=="visible"&&!f.alternate&&!ve)return Qe(n),null}else 2*X()-s.renderingStartTime>zu&&a!==536870912&&(n.flags|=128,u=!0,qo(s,!1),n.lanes=4194304);s.isBackwards?(f.sibling=n.child,n.child=f):(t=s.last,t!==null?t.sibling=f:n.child=f,s.last=f)}if(s.tail!==null){t=s.tail;t:{for(a=t;a!==null;){if(a.alternate!==null){a=!1;break t}a=a.sibling}a=!0}return s.rendering=t,s.tail=t.sibling,s.renderingStartTime=X(),t.sibling=null,f=Cn.current,f=u?f&1|2:f&1,s.tailMode==="visible"||s.tailMode==="collapsed"||!a||ve?Ho(n,f):(a=f,ie(Rn,n),ie(Cn,a),Pn===null&&(Pn=n)),ve&&ca(n,s.treeForkCount),t}return Qe(n),null;case 22:case 23:return ni(n),zf(),s=n.memoizedState!==null,t!==null?t.memoizedState!==null!==s&&(n.flags|=8192):s&&(n.flags|=8192),s?(a&536870912)!==0&&(n.flags&128)===0&&(Qe(n),n.subtreeFlags&6&&(n.flags|=8192)):Qe(n),a=n.updateQueue,a!==null&&Tu(n,a.retryQueue),a=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(a=t.memoizedState.cachePool.pool),s=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(s=n.memoizedState.cachePool.pool),s!==a&&(n.flags|=2048),t!==null&&Ot(Dr),null;case 24:return a=null,t!==null&&(a=t.memoizedState.cache),n.memoizedState.cache!==a&&(n.flags|=2048),ha(cn),Qe(n),null;case 25:return null;case 30:return n.flags|=33554432,Qe(n),null}throw Error(r(156,n.tag))}function yM(t,n){switch(Mf(n),n.tag){case 1:return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 3:return ha(cn),A(),t=n.flags,(t&65536)!==0&&(t&128)===0?(n.flags=t&-65537|128,n):null;case 26:case 27:case 5:return mt(n),null;case 31:if(n.memoizedState!==null){if(ni(n),n.alternate===null)throw Error(r(340));br()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 13:if(ni(n),t=n.memoizedState,t!==null&&t.dehydrated!==null){if(n.alternate===null)throw Error(r(340));br()}return t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 19:return Bf(n),t=n.flags,t&65536?(n.flags=t&-65537|128,t=n.memoizedState,t!==null&&(t.rendering=null,t.tail=null),n.flags|=4,n):null;case 4:return A(),null;case 10:return ha(n.type),null;case 22:case 23:return ni(n),zf(),t!==null&&Ot(Dr),t=n.flags,t&65536?(n.flags=t&-65537|128,n):null;case 24:return ha(cn),null;case 25:return null;default:return null}}function H_(t,n){switch(Mf(n),n.tag){case 3:ha(cn),A();break;case 26:case 27:case 5:mt(n);break;case 4:A();break;case 31:n.memoizedState!==null&&ni(n);break;case 13:ni(n);break;case 19:Bf(n);break;case 10:ha(n.type);break;case 22:case 23:ni(n),zf(),t!==null&&Ot(Dr);break;case 24:ha(cn)}}function Yo(t,n){try{var a=n.updateQueue,s=a!==null?a.lastEffect:null;if(s!==null){var u=s.next;a=u;do{if((a.tag&t)===t){s=void 0;var f=a.create,v=a.inst;s=f(),v.destroy=s}a=a.next}while(a!==u)}}catch(T){Ve(n,n.return,T)}}function Ya(t,n,a){try{var s=n.updateQueue,u=s!==null?s.lastEffect:null;if(u!==null){var f=u.next;s=f;do{if((s.tag&t)===t){var v=s.inst,T=v.destroy;if(T!==void 0){v.destroy=void 0,u=n;var P=a,W=T;try{W()}catch(ot){Ve(u,P,ot)}}}s=s.next}while(s!==f)}}catch(ot){Ve(n,n.return,ot)}}function G_(t){var n=t.updateQueue;if(n!==null){var a=t.stateNode;try{Dg(n,a)}catch(s){Ve(t,t.return,s)}}}function V_(t,n,a){a.props=Pr(t.type,t.memoizedProps),a.state=t.memoizedState;try{a.componentWillUnmount()}catch(s){Ve(t,n,s)}}function Xi(t,n){try{var a=t.ref;if(a!==null){switch(t.tag){case 26:case 27:case 5:var s=t.stateNode;break;case 30:var u=t.stateNode,f=oa(t.memoizedProps,u);(u.ref===null||u.ref.name!==f)&&(u.ref=Zv(f)),s=u.ref;break;case 7:if(t.stateNode===null){var v=new oi(t);p(t.child,!1,cE,v,void 0,void 0),t.stateNode=v}s=t.stateNode;break;default:s=t.stateNode}typeof a=="function"?t.refCleanup=a(s):a.current=s}}catch(T){Ve(t,n,T)}}function wn(t,n){var a=t.ref,s=t.refCleanup;if(a!==null)if(typeof s=="function")try{s()}catch(u){Ve(t,n,u)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof a=="function")try{a(null)}catch(u){Ve(t,n,u)}else a.current=null}function bu(t,n){if((t.tag===5||t.tag===27||t.tag===6)&&t.alternate===null&&n!==null)for(var a=0;a<n.length;a++)e0(t.stateNode,n[a])}function X_(t){for(var n=t.return;n!==null&&(mh(n)&&e0(t.stateNode,n.stateNode),!ph(n));)n=n.return}function Wo(t){for(var n=t.return;n!==null&&(mh(n)&&fE(t.stateNode,n.stateNode),!ph(n));)n=n.return}function ph(t){return t.tag===5||t.tag===3||t.tag===27}function mh(t){return t&&t.tag===7&&t.stateNode!==null}function gh(t){var n=t.type,a=t.memoizedProps,s=t.stateNode;try{t:switch(n){case"button":case"input":case"select":case"textarea":a.autoFocus&&s.focus();break t;case"img":a.src?s.src=a.src:a.srcSet&&(s.srcset=a.srcSet)}}catch(u){Ve(t,t.return,u)}}function _h(t,n,a){try{var s=t.stateNode;YM(s,t.type,a,n),s[Wt]=n}catch(u){Ve(t,t.return,u)}}function k_(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&$a(t.type)||t.tag===4}function vh(t){t:for(;;){for(;t.sibling===null;){if(t.return===null||k_(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&$a(t.type)||t.flags&2||t.child===null||t.tag===4)continue t;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function xh(t,n,a,s){var u=t.tag;if(u===5||u===6)u=t.stateNode,n?(a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a).insertBefore(u,n):(n=a.nodeType===9?a.body:a.nodeName==="HTML"?a.ownerDocument.body:a,n.appendChild(u),a=a._reactRootContainer,a!=null||n.onclick!==null||(n.onclick=Hi)),bu(t,s),Le=!0;else if(u!==4&&(u===27&&(bu(t,s),s=null,$a(t.type)&&(a=t.stateNode,n=null)),t=t.child,t!==null))for(xh(t,n,a,s),t=t.sibling;t!==null;)xh(t,n,a,s),t=t.sibling}function Au(t,n,a,s){var u=t.tag;if(u===5||u===6)u=t.stateNode,n?a.insertBefore(u,n):a.appendChild(u),bu(t,s),Le=!0;else if(u!==4&&(u===27&&(bu(t,s),s=null,$a(t.type)&&(a=t.stateNode)),t=t.child,t!==null))for(Au(t,n,a,s),t=t.sibling;t!==null;)Au(t,n,a,s),t=t.sibling}function q_(t){var n=t.stateNode,a=t.memoizedProps;try{for(var s=t.type,u=n.attributes;u.length;)n.removeAttributeNode(u[0]);Dn(n,s,a),n[Nt]=t,n[Wt]=a}catch(f){Ve(t,t.return,f)}}var Ru=!1,ii=null;function Y_(t){(t.tag===30||(t.subtreeFlags&33554432)!==0)&&(Ru=!0)}var ki=null;function W_(){var t=ki;return ki=null,t}var Yn=0;function Ss(t,n,a,s,u){return Yn=0,j_(t.child,n,a,s,u)}function j_(t,n,a,s,u){for(var f=!1;t!==null;){if(t.tag===5){var v=t.stateNode;if(s!==null){var T=nd(v);s.push(T),T.view&&(f=!0)}else f||nd(v).view&&(f=!0);Ru=!0,Wv(v,Yn===0?n:n+"_"+Yn,a),Yn++}else(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&u||j_(t.child,n,a,s,u)&&(f=!0));t=t.sibling}return f}function qi(t,n){for(;t!==null;)t.tag===5?jv(t.stateNode,t.memoizedProps):(t.tag!==22||t.memoizedState===null)&&(t.tag===30&&n||qi(t.child,n)),t=t.sibling}function Cu(t){if((t.subtreeFlags&18874368)!==0)for(t=t.child;t!==null;){if((t.tag!==22||t.memoizedState===null)&&(Cu(t),t.tag===30&&(t.flags&18874368)!==0&&t.stateNode.paired)){var n=t.memoizedProps;if(n.name==null||n.name==="auto")throw Error(r(544));var a=n.name;n=la(n.default,n.share),n!=="none"&&(Ss(t,a,n,null,!1)||qi(t.child,!1))}t=t.sibling}}function yh(t,n){if(t.tag===30){var a=t.stateNode,s=t.memoizedProps,u=oa(s,a),f=la(s.default,a.paired?s.share:s.enter);f!=="none"?Ss(t,u,f,null,!1)?(Cu(t),a.paired||n||ws(t,s.onEnter)):qi(t.child,!1):Cu(t)}else if((t.subtreeFlags&33554432)!==0)for(t=t.child;t!==null;)yh(t,n),t=t.sibling;else Cu(t)}function Sh(t){if(ii!==null&&ii.size!==0){var n=ii;if((t.subtreeFlags&18874368)!==0)for(t=t.child;t!==null;){if(t.tag!==22||t.memoizedState===null){if(t.tag===30&&(t.flags&18874368)!==0){var a=t.memoizedProps,s=a.name;if(s!=null&&s!=="auto"){var u=n.get(s);if(u!==void 0){var f=la(a.default,a.share);if(f!=="none"&&(Ss(t,s,f,null,!1)?(f=t.stateNode,u.paired=f,f.paired=u,ws(t,a.onShare)):qi(t.child,!1)),n.delete(s),n.size===0)break}}}Sh(t)}t=t.sibling}}}function Mh(t){if(t.tag===30){var n=t.memoizedProps,a=oa(n,t.stateNode),s=ii!==null?ii.get(a):void 0,u=la(n.default,s!==void 0?n.share:n.exit);u!=="none"&&(Ss(t,a,u,null,!1)?s!==void 0?(u=t.stateNode,s.paired=u,u.paired=s,ii.delete(a),ws(t,n.onShare)):ws(t,n.onExit):qi(t.child,!1)),ii!==null&&Sh(t)}else if((t.subtreeFlags&33554432)!==0)for(t=t.child;t!==null;)Mh(t),t=t.sibling;else ii!==null&&Sh(t)}function Z_(t){for(t=t.child;t!==null;){if(t.tag===30){var n=t.memoizedProps,a=oa(n,t.stateNode);n=la(n.default,n.update),t.flags&=-5,n!=="none"&&Ss(t,a,n,t.memoizedState=[],!1)}else(t.subtreeFlags&33554432)!==0&&Z_(t);t=t.sibling}}function Eh(t){if((t.subtreeFlags&18874368)!==0)for(t=t.child;t!==null;){if(t.tag!==22||t.memoizedState===null){if(t.tag===30&&(t.flags&18874368)!==0){var n=t.stateNode;n.paired!==null&&(n.paired=null,qi(t.child,!1))}Eh(t)}t=t.sibling}}function wu(t){if(t.tag===30)t.stateNode.paired=null,qi(t.child,!1),Eh(t);else if((t.subtreeFlags&33554432)!==0)for(t=t.child;t!==null;)wu(t),t=t.sibling;else Eh(t)}function K_(t){for(t=t.child;t!==null;)t.tag===30?qi(t.child,!1):(t.subtreeFlags&33554432)!==0&&K_(t),t=t.sibling}function Th(t,n,a,s,u,f,v){for(var T=!1;n!==null;){if(n.tag===5){var P=n.stateNode;if(f!==null&&Yn<f.length){var W=f[Yn],ot=nd(P);(W.view||ot.view)&&(T=!0);var gt;if(gt=(t.flags&4)===0)if(ot.clip)gt=!0;else{gt=W.rect;var q=ot.rect;gt=gt.y!==q.y||gt.x!==q.x||gt.height!==q.height||gt.width!==q.width}gt&&(t.flags|=4),ot.abs?ot=!W.abs:(W=W.rect,ot=ot.rect,ot=W.height!==ot.height||W.width!==ot.width),ot&&(t.flags|=32)}else t.flags|=32;(t.flags&4)!==0&&Wv(P,Yn===0?a:a+"_"+Yn,u),T&&(t.flags&4)!==0||(ki===null&&(ki=[]),ki.push(P,Yn===0?s:s+"_"+Yn,n.memoizedProps)),Yn++}else(n.tag!==22||n.memoizedState===null)&&(n.tag===30&&v?t.flags|=n.flags&32:Th(t,n.child,a,s,u,f,v)&&(T=!0));n=n.sibling}return T}function Q_(t,n){for(t=t.child;t!==null;){if(t.tag===30){var a=t.memoizedProps,s=t.stateNode,u=oa(a,s),f=la(a.default,a.update),v;v=t.memoizedState,t.memoizedState=null,s=t;var T=t.child;Yn=0,u=Th(s,T,u,u,f,v,!1),(t.flags&4)!==0&&u&&ws(t,a.onUpdate)}else(t.subtreeFlags&33554432)!==0&&Q_(t);t=t.sibling}}var Mn=!1,He=!1,Yi=!1,bh=!1,J_=typeof WeakSet=="function"?WeakSet:Set,En=null,Wi=!1,jo=!1,Du=!1,Ah=!1;function SM(t,n,a){if(t=t.containerInfo,Qh=Fs,t=ng(t),hf(t)){if("selectionStart"in t)var s={start:t.selectionStart,end:t.selectionEnd};else t:{s=(s=t.ownerDocument)&&s.defaultView||window;var u=s.getSelection&&s.getSelection();if(u&&u.rangeCount!==0){s=u.anchorNode;var f=u.anchorOffset,v=u.focusNode;u=u.focusOffset;try{s.nodeType,v.nodeType}catch{s=null;break t}var T=0,P=-1,W=-1,ot=0,gt=0,q=t,nt=null;e:for(;;){for(var Pt;q!==s||f!==0&&q.nodeType!==3||(P=T+f),q!==v||u!==0&&q.nodeType!==3||(W=T+u),q.nodeType===3&&(T+=q.nodeValue.length),(Pt=q.firstChild)!==null;)nt=q,q=Pt;for(;;){if(q===t)break e;if(nt===s&&++ot===f&&(P=T),nt===v&&++gt===u&&(W=T),(Pt=q.nextSibling)!==null)break;q=nt,nt=q.parentNode}q=Pt}s=P===-1||W===-1?null:{start:P,end:W}}else s=null}s=s||{start:0,end:0}}else s=null;for(Jh={focusedElem:t,selectionRange:s},Fs=!1,a=(a&335544064)===a,En=n,n=a?9270:1024;En!==null;){if(t=En,a&&(s=t.deletions,s!==null))for(f=0;f<s.length;f++)a&&Mh(s[f]);if(t.alternate===null&&(t.flags&2)!==0)a&&Y_(t),Uu(a);else{if(t.tag===22){if(s=t.alternate,t.memoizedState!==null){s!==null&&s.memoizedState===null&&a&&Mh(s),Uu(a);continue}else if(s!==null&&s.memoizedState!==null){a&&Y_(t),Uu(a);continue}}s=t.child,(t.subtreeFlags&n)!==0&&s!==null?(s.return=t,En=s):(a&&Z_(t),Uu(a))}}ii=null}function Uu(t){for(;En!==null;){var n=En,a=t,s=n.alternate,u=n.flags;switch(n.tag){case 0:case 11:case 15:break;case 1:if((u&1024)!==0&&s!==null){a=void 0,u=s.memoizedProps,s=s.memoizedState;var f=n.stateNode;try{var v=Pr(n.type,u);a=f.getSnapshotBeforeUpdate(v,s),f.__reactInternalSnapshotBeforeUpdate=a}catch(T){Ve(n,n.return,T)}}break;case 3:if((u&1024)!==0){if(s=n.stateNode.containerInfo,a=s.nodeType,a===9)rd(s);else if(a===1)switch(s.nodeName){case"HEAD":case"HTML":case"BODY":rd(s);break;default:s.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;case 30:a&&s!==null&&(a=oa(s.memoizedProps,s.stateNode),u=n.memoizedProps,u=la(u.default,u.update),u!=="none"&&Ss(s,a,u,s.memoizedState=[],!0));break;default:if((u&1024)!==0)throw Error(r(163))}if(s=n.sibling,s!==null){s.return=n.return,En=s;break}En=n.return}}function $_(t,n,a){var s=a.flags;switch(a.tag){case 0:case 11:case 15:ji(t,a),s&4&&Yo(5,a);break;case 1:if(ji(t,a),s&4)if(t=a.stateNode,n===null)try{t.componentDidMount()}catch(v){Ve(a,a.return,v)}else{var u=Pr(a.type,n.memoizedProps);n=n.memoizedState;try{t.componentDidUpdate(u,n,t.__reactInternalSnapshotBeforeUpdate)}catch(v){Ve(a,a.return,v)}}s&64&&G_(a),s&512&&Xi(a,a.return);break;case 3:if(ji(t,a),s&64&&(t=a.updateQueue,t!==null)){if(n=null,a.child!==null)switch(a.child.tag){case 27:case 5:n=a.child.stateNode;break;case 1:n=a.child.stateNode}try{Dg(t,n)}catch(v){Ve(a,a.return,v)}}break;case 27:n===null&&s&4&&q_(a);case 26:case 5:ji(t,a),n===null&&s&4&&gh(a),s&512&&Xi(a,a.return);break;case 12:ji(t,a);break;case 31:ji(t,a),s&4&&iv(t,a);break;case 13:ji(t,a),s&4&&av(t,a),s&64&&(t=a.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(a=LM.bind(null,a),pE(t,a))));break;case 22:if(s=a.memoizedState!==null||Mn,!s){var f=n!==null&&n.memoizedState!==null||He;n=Mn,u=He,Mn=s,(He=f)&&!u?(s=2,(a.subtreeFlags&8772)!==0&&(s|=1),Ci(t,a,s)):ji(t,a),Mn=n,He=u}break;case 30:ji(t,a),s&512&&Xi(a,a.return);break;case 7:s&512&&Xi(a,a.return);default:ji(t,a)}}function Rh(t,n){for(t=t.child;t!==null;)tv(t,n),t=t.sibling}function tv(t,n){switch(t.tag){case 5:case 26:try{var a=t.stateNode;if(n){var s=a.style;typeof s.setProperty=="function"?s.setProperty("display","none","important"):s.display="none"}else{var u=t.stateNode,f=t.memoizedProps.style,v=f!=null&&f.hasOwnProperty("display")?f.display:null;u.style.display=v==null||typeof v=="boolean"?"":(""+v).trim()}}catch(P){Ve(t,t.return,P)}Ch(t,n);break;case 6:try{t.stateNode.nodeValue=n?"":t.memoizedProps,Le=!0}catch(P){Ve(t,t.return,P)}break;case 18:try{var T=t.stateNode;n?Yv(T,!0):Yv(t.stateNode,!1)}catch(P){Ve(t,t.return,P)}break;case 22:case 23:t.memoizedState===null&&Rh(t,n);break;default:Rh(t,n)}}function Ch(t,n){if(t.subtreeFlags&67108864)for(t=t.child;t!==null;){t:{var a=t,s=n;switch(a.tag){case 4:tv(a,s);break t;case 22:a.memoizedState===null&&Ch(a,s);break t;default:Ch(a,s)}}t=t.sibling}}function ev(t){var n=t.alternate;n!==null&&(t.alternate=null,ev(n)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(n=t.stateNode,n!==null&&ne(n)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var $e=null,Wn=!1;function Ai(t,n,a){for(a=a.child;a!==null;)nv(t,n,a),a=a.sibling}function nv(t,n,a){if(tn&&typeof tn.onCommitFiberUnmount=="function")try{tn.onCommitFiberUnmount(Ae,a)}catch{}switch(a.tag){case 26:He||wn(a,n),Ai(t,n,a),a.memoizedState?a.memoizedState.count--:a.stateNode&&!He&&(a=a.stateNode,a.parentNode.removeChild(a));break;case 27:He||wn(a,n),Wo(a);var s=$e,u=Wn;$a(a.type)&&($e=a.stateNode,Wn=!1),Ai(t,n,a),s0(a.stateNode,a.type,a.memoizedProps),$e=s,Wn=u;break;case 5:He||wn(a,n),Wo(a);case 6:if(a.tag===6&&Wo(a),s=$e,u=Wn,$e=null,Ai(t,n,a),$e=s,Wn=u,$e!==null)if(Wn)try{($e.nodeType===9?$e.body:$e.nodeName==="HTML"?$e.ownerDocument.body:$e).removeChild(a.stateNode),Le=!0}catch(f){Ve(a,n,f)}else try{$e.removeChild(a.stateNode),Le=!0}catch(f){Ve(a,n,f)}break;case 18:$e!==null&&(Wn?(t=$e,qv(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,a.stateNode),Hs(t)):qv($e,a.stateNode));break;case 4:s=$e,u=Wn,$e=a.stateNode.containerInfo,Wn=!0,Ai(t,n,a),$e=s,Wn=u;break;case 0:case 11:case 14:case 15:Ya(2,a,n),He||Ya(4,a,n),Ai(t,n,a);break;case 1:He||(wn(a,n),s=a.stateNode,typeof s.componentWillUnmount=="function"&&V_(a,n,s)),Ai(t,n,a);break;case 21:Ai(t,n,a);break;case 22:He=(s=He)||a.memoizedState!==null,Ai(t,n,a),He=s;break;case 30:wn(a,n),Ai(t,n,a);break;case 7:He||wn(a,n),Ai(t,n,a);break;default:Ai(t,n,a)}}function iv(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null))){t=t.dehydrated;try{Hs(t)}catch(a){Ve(n,n.return,a)}}}function av(t,n){if(n.memoizedState===null&&(t=n.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{Hs(t)}catch(a){Ve(n,n.return,a)}}function MM(t){switch(t.tag){case 31:case 13:case 19:var n=t.stateNode;return n===null&&(n=t.stateNode=new J_),n;case 22:return t=t.stateNode,n=t._retryCache,n===null&&(n=t._retryCache=new J_),n;default:throw Error(r(435,t.tag))}}function Nu(t,n){var a=MM(t);n.forEach(function(s){if(!a.has(s)){a.add(s);var u=OM.bind(null,t,s);s.then(u,u)}})}function Vn(t,n,a){var s=n.deletions;if(s!==null)for(var u=0;u<s.length;u++){var f=s[u],v=t,T=n,P=T;t:for(;P!==null;){switch(P.tag){case 27:if($a(P.type)){$e=P.stateNode,Wn=!1;break t}break;case 5:$e=P.stateNode,Wn=!1;break t;case 3:case 4:$e=P.stateNode.containerInfo,Wn=!0;break t}P=P.return}if($e===null)throw Error(r(160));nv(v,T,f),$e=null,Wn=!1,v=f.alternate,v!==null&&(v.return=null),f.return=null}if(n.subtreeFlags&13886)for(n=n.child;n!==null;)rv(n,t,a),n=n.sibling}var Ri=null;function rv(t,n,a){var s=t.alternate,u=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:if(u&4&&(s=t.updateQueue,s=s!==null?s.events:null,s!==null))for(var f=0;f<s.length;f++){var v=s[f];v.ref.impl=v.nextImpl}Vn(n,t,a),Xn(t),u&4&&(Ya(3,t,t.return),Yo(3,t),Ya(5,t,t.return));break;case 1:Vn(n,t,a),Xn(t),u&512&&(He||s===null||wn(s,s.return)),u&64&&Mn&&(t=t.updateQueue,t!==null&&(n=t.callbacks,n!==null&&(a=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=a===null?n:a.concat(n))));break;case 26:if(f=Ri,Vn(n,t,a),Xn(t),u&512&&(He||s===null||wn(s,s.return)),u&4)if(u=s!==null?s.memoizedState:null,a=t.memoizedState,s===null)if(a===null)if(t.stateNode===null)if(Mn)t.stateNode=Vv(t.type,t.memoizedProps,n.containerInfo,t);else{t:{n=t.type,a=t.memoizedProps,u=f.ownerDocument||f;e:switch(n){case"title":s=u.getElementsByTagName("title")[0],(!s||s[ze]||s[Nt]||s.namespaceURI==="http://www.w3.org/2000/svg"||s.hasAttribute("itemprop"))&&(s=u.createElement(n),u.head.insertBefore(s,u.querySelector("head > title"))),Dn(s,n,a),s[Nt]=t,Ne(s),n=s;break t;case"link":if(f=h0("link","href",u).get(n+(a.href||""))){for(v=0;v<f.length;v++)if(s=f[v],s.getAttribute("href")===(a.href==null||a.href===""?null:a.href)&&s.getAttribute("rel")===(a.rel==null?null:a.rel)&&s.getAttribute("title")===(a.title==null?null:a.title)&&s.getAttribute("crossorigin")===(a.crossOrigin==null?null:a.crossOrigin)){f.splice(v,1);break e}}s=u.createElement(n),Dn(s,n,a),u.head.appendChild(s);break;case"meta":if(f=h0("meta","content",u).get(n+(a.content||""))){for(v=0;v<f.length;v++)if(s=f[v],s.getAttribute("content")===(a.content==null?null:""+a.content)&&s.getAttribute("name")===(a.name==null?null:a.name)&&s.getAttribute("property")===(a.property==null?null:a.property)&&s.getAttribute("http-equiv")===(a.httpEquiv==null?null:a.httpEquiv)&&s.getAttribute("charset")===(a.charSet==null?null:a.charSet)){f.splice(v,1);break e}}s=u.createElement(n),Dn(s,n,a),u.head.appendChild(s);break;default:throw Error(r(468,n))}s[Nt]=t,Ne(s),n=s}t.stateNode=n}else Mn||hd(f,t.type,t.stateNode);else t.stateNode=f0(f,a,t.memoizedProps);else u!==a?(u===null?(n=s.stateNode,n===null||He||n.parentNode.removeChild(n)):u.count--,a===null?Mn||hd(f,t.type,t.stateNode):f0(f,a,t.memoizedProps)):a===null&&t.stateNode!==null&&_h(t,t.memoizedProps,s.memoizedProps);break;case 27:Vn(n,t,a),Xn(t),u&512&&(He||s===null||wn(s,s.return)),s!==null&&u&4&&_h(t,t.memoizedProps,s.memoizedProps);break;case 5:if(f=Yi,Yi=!1,Vn(n,t,a),Yi=f,Xn(t),u&512&&(He||s===null||wn(s,s.return)),t.flags&32){n=t.stateNode;try{is(n,""),Le=!0}catch(ot){Ve(t,t.return,ot)}}u&4&&t.stateNode!=null&&(n=t.memoizedProps,_h(t,n,s!==null?s.memoizedProps:n)),u&1024&&(bh=!0);break;case 6:if(Vn(n,t,a),Xn(t),u&4){if(t.stateNode===null)throw Error(r(162));n=t.memoizedProps,a=t.stateNode;try{a.nodeValue=n,Le=!0}catch(ot){Ve(t,t.return,ot)}}break;case 3:if(Le=!1,Wu=null,f=Ri,Ri=il(n.containerInfo),Vn(n,t,a),Ri=f,Xn(t),u&4&&s!==null&&s.memoizedState.isDehydrated)try{Hs(n.containerInfo)}catch(ot){Ve(t,t.return,ot)}bh&&(bh=!1,sv(t)),Le=!1;break;case 4:u=Yi,Yi=Mn,s=Am(),f=Ri,Ri=il(t.stateNode.containerInfo),Vn(n,t,a),Xn(t),Ri=f,Le&&jo&&(Du=!0),Le=s,Yi=u;break;case 12:Vn(n,t,a),Xn(t);break;case 31:Vn(n,t,a),Xn(t),u&4&&(n=t.updateQueue,n!==null&&(t.updateQueue=null,Nu(t,n)));break;case 13:Vn(n,t,a),Xn(t),t.child.flags&8192&&t.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(Pu=X()),u&4&&(n=t.updateQueue,n!==null&&(t.updateQueue=null,Nu(t,n)));break;case 22:f=t.memoizedState!==null,v=s!==null&&s.memoizedState!==null;var T=Mn,P=He,W=Yi;Mn=T||f,Yi=W||f,He=P||v,Vn(n,t,a),He=P,Yi=W,Mn=T,Xn(t),u&8192&&(n=t.stateNode,n._visibility=f?n._visibility&-2:n._visibility|1,!f||s===null||v||Mn||He||(n=v||He,a=Mn,s=He,Mn=f||Mn,He=n,Wa(t,2),Mn=a,He=s),!f&&Yi||Rh(t,f)),u&4&&(n=t.updateQueue,n!==null&&(a=n.retryQueue,a!==null&&(n.retryQueue=null,Nu(t,a))));break;case 19:Vn(n,t,a),Xn(t),u&4&&(n=t.updateQueue,n!==null&&(t.updateQueue=null,Nu(t,n)));break;case 30:u&512&&(He||s===null||wn(s,s.return)),u=Am(),f=jo,v=(a&335544064)===a,T=t.memoizedProps,jo=v&&la(T.default,T.update)!=="none",Vn(n,t,a),Xn(t),v&&s!==null&&Le&&(t.flags|=4),jo=f,Le=u;break;case 21:break;case 7:u&512&&(He||s===null||wn(s,s.return)),s&&s.stateNode!==null&&(s.stateNode._fragmentFiber=t);default:Vn(n,t,a),Xn(t)}}function Xn(t){var n=t.flags;if(n&2){try{for(var a,s=t.return;s!==null;){if(k_(s)){a=s;break}s=s.return}s=null;for(var u=t.return;u!==null;){if(mh(u)){var f=u.stateNode;s===null?s=[f]:s.push(f)}if(ph(u))break;u=u.return}var v=s;if(a==null)throw Error(r(160));switch(a.tag){case 27:var T=a.stateNode,P=vh(t);Au(t,P,T,v);break;case 5:var W=a.stateNode;a.flags&32&&(is(W,""),a.flags&=-33);var ot=vh(t);Au(t,ot,W,v);break;case 3:case 4:var gt=a.stateNode.containerInfo,q=vh(t);xh(t,q,gt,v);break;default:throw Error(r(161))}}catch(nt){Ve(t,t.return,nt)}t.flags&=-3}n&4096&&(t.flags&=-4097)}function sv(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var n=t;sv(n),n.tag===5&&n.flags&1024&&(n=n.stateNode,Fs=!0,n.reset(),Fs=!1),t=t.sibling}}function Ms(t,n){if(n.subtreeFlags&9270)for(n=n.child;n!==null;)ov(n,t),n=n.sibling;else Q_(n)}function ov(t,n){var a=t.alternate;if(a===null)yh(t,!1);else switch(t.tag){case 3:if(Ah=Wi=!1,W_(),Ms(n,t),!Wi&&!Du){if(t=ki,t!==null)for(var s=0;s<t.length;s+=3){a=t[s];var u=t[s+1];jv(a,t[s+2]),a=a.ownerDocument.documentElement,a!==null&&a.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group("+u+")"})}t=n.containerInfo,t=t.nodeType===9?t.documentElement:t.ownerDocument.documentElement,t!==null&&t.style.viewTransitionName===""&&(t.style.viewTransitionName="none",t.animate({opacity:[0,0],pointerEvents:["none","none"]},{duration:0,fill:"forwards",pseudoElement:"::view-transition-group(root)"}),t.animate({width:[0,0],height:[0,0]},{duration:0,fill:"forwards",pseudoElement:"::view-transition"})),Ah=!0}ki=null;break;case 5:Ms(n,t);break;case 4:s=Wi,Wi=!1,Ms(n,t),Wi&&(Du=!0),Wi=s;break;case 22:t.memoizedState===null&&(a.memoizedState!==null?yh(t,!1):Ms(n,t));break;case 30:s=Wi,u=W_(),Wi=!1,Ms(n,t),Wi&&(t.flags|=4);var f=t.memoizedProps,v=t.stateNode;n=oa(f,v),v=oa(a.memoizedProps,v);var T=la(f.default,f.update);T==="none"?n=!1:(f=a.memoizedState,a.memoizedState=null,a=t.child,Yn=0,n=Th(t,a,n,v,T,f,!0),Yn!==(f===null?0:f.length)&&(t.flags|=32)),(t.flags&4)!==0&&n?(ws(t,t.memoizedProps.onUpdate),ki=u):u!==null&&(u.push.apply(u,ki),ki=u),Wi=(t.flags&32)!==0?!0:s;break;default:Ms(n,t)}}function ji(t,n){if(n.subtreeFlags&8772)for(n=n.child;n!==null;)$_(t,n.alternate,n),n=n.sibling}function Wa(t,n){for(t=t.child;t!==null;){var a=t,s=n;switch(a.tag){case 0:case 11:case 14:case 15:Ya(4,a,a.return),Wa(a,s);break;case 1:wn(a,a.return);var u=a.stateNode;typeof u.componentWillUnmount=="function"&&V_(a,a.return,u),Wa(a,s);break;case 27:(s&2)!==0&&s0(a.stateNode,a.type,a.memoizedProps);case 5:wn(a,a.return),a.tag!==5&&a.tag!==27||Wo(a),Wa(a,s);break;case 6:Wo(a);break;case 26:wn(a,a.return),u=a.stateNode,a.memoizedState!==null||u===null||He||u.parentNode.removeChild(u),Wa(a,s);break;case 22:a.memoizedState===null&&Wa(a,s);break;case 30:wn(a,a.return),Wa(a,s);break;case 7:wn(a,a.return);default:Wa(a,s)}t=t.sibling}}function Ci(t,n,a){for(a=(n.subtreeFlags&8772)!==0?a:a&-2,n=n.child;n!==null;){var s=n.alternate,u=t,f=n,v=f.flags,T=(a&1)!==0;switch(f.tag){case 0:case 11:case 15:Ci(u,f,a),Yo(4,f);break;case 1:if(Ci(u,f,a),s=f,u=s.stateNode,typeof u.componentDidMount=="function")try{u.componentDidMount()}catch(ot){Ve(s,s.return,ot)}if(s=f,u=s.updateQueue,u!==null){var P=s.stateNode;try{var W=u.shared.hiddenCallbacks;if(W!==null)for(u.shared.hiddenCallbacks=null,u=0;u<W.length;u++)wg(W[u],P)}catch(ot){Ve(s,s.return,ot)}}T&&v&64&&G_(f),Xi(f,f.return);break;case 27:(a&2)!==0&&q_(f);case 5:f.tag!==5&&f.tag!==27||X_(f),Ci(u,f,a),T&&s===null&&v&4&&gh(f),Xi(f,f.return);break;case 6:X_(f);break;case 26:P=f.stateNode,f.memoizedState!==null||P===null||Mn||hd(il(P.ownerDocument),f.type,P),Ci(u,f,a),T&&s===null&&v&4&&gh(f),Xi(f,f.return);break;case 12:Ci(u,f,a);break;case 31:Ci(u,f,a),T&&v&4&&iv(u,f);break;case 13:Ci(u,f,a),T&&v&4&&av(u,f);break;case 22:f.memoizedState===null&&Ci(u,f,a),Xi(f,f.return);break;case 30:Ci(u,f,a),Xi(f,f.return);break;case 7:Xi(f,f.return);default:Ci(u,f,a)}n=n.sibling}}function wh(t,n){var a=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(a=t.memoizedState.cachePool.pool),t=null,n.memoizedState!==null&&n.memoizedState.cachePool!==null&&(t=n.memoizedState.cachePool.pool),t!==a&&(t!=null&&t.refCount++,a!=null&&Lo(a))}function Dh(t,n){t=null,n.alternate!==null&&(t=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==t&&(n.refCount++,t!=null&&Lo(t))}function vi(t,n,a,s){var u=(a&335544064)===a;if(n.subtreeFlags&(u?10262:10256))for(n=n.child;n!==null;)lv(t,n,a,s),n=n.sibling;else u&&K_(n)}function lv(t,n,a,s){var u=(a&335544064)===a;u&&n.alternate===null&&n.return!==null&&n.return.alternate!==null&&wu(n);var f=n.flags;switch(n.tag){case 0:case 11:case 15:vi(t,n,a,s),f&2048&&Yo(9,n);break;case 1:vi(t,n,a,s);break;case 3:vi(t,n,a,s),u&&Ah&&(t=t.containerInfo,t=t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,t.style.viewTransitionName==="root"&&(t.style.viewTransitionName=""),t=t.ownerDocument.documentElement,t!==null&&t.style.viewTransitionName==="none"&&(t.style.viewTransitionName="")),f&2048&&(f=null,n.alternate!==null&&(f=n.alternate.memoizedState.cache),n=n.memoizedState.cache,n!==f&&(n.refCount++,f!=null&&Lo(f)));break;case 12:if(f&2048){vi(t,n,a,s),f=n.stateNode;try{var v=n.memoizedProps,T=v.id,P=v.onPostCommit;typeof P=="function"&&P(T,n.alternate===null?"mount":"update",f.passiveEffectDuration,-0)}catch(W){Ve(n,n.return,W)}}else vi(t,n,a,s);break;case 31:vi(t,n,a,s);break;case 13:vi(t,n,a,s);break;case 23:break;case 22:v=n.stateNode,T=n.alternate,n.memoizedState!==null?(u&&T!==null&&T.memoizedState===null&&wu(T),v._visibility&2?vi(t,n,a,s):Zo(t,n)):(u&&T!==null&&T.memoizedState!==null&&wu(n),v._visibility&2?vi(t,n,a,s):(v._visibility|=2,Es(t,n,a,s,(n.subtreeFlags&10256)!==0||!1))),f&2048&&wh(T,n);break;case 24:vi(t,n,a,s),f&2048&&Dh(n.alternate,n);break;case 30:u&&(f=n.alternate,f!==null&&(qi(f.child,!0),qi(n.child,!0))),vi(t,n,a,s);break;default:vi(t,n,a,s)}}function Es(t,n,a,s,u){for(u=u&&((n.subtreeFlags&10256)!==0||!1),n=n.child;n!==null;){var f=t,v=n,T=a,P=s,W=v.flags;switch(v.tag){case 0:case 11:case 15:Es(f,v,T,P,u),Yo(8,v);break;case 23:break;case 22:var ot=v.stateNode;v.memoizedState!==null?ot._visibility&2?Es(f,v,T,P,u):Zo(f,v):(ot._visibility|=2,Es(f,v,T,P,u)),u&&W&2048&&wh(v.alternate,v);break;case 24:Es(f,v,T,P,u),u&&W&2048&&Dh(v.alternate,v);break;default:Es(f,v,T,P,u)}n=n.sibling}}function Zo(t,n){if(n.subtreeFlags&10256)for(n=n.child;n!==null;){var a=t,s=n,u=s.flags;switch(s.tag){case 22:Zo(a,s),u&2048&&wh(s.alternate,s);break;case 24:Zo(a,s),u&2048&&Dh(s.alternate,s);break;default:Zo(a,s)}n=n.sibling}}var zr=8192;function Ir(t,n,a){if(t.subtreeFlags&zr)for(t=t.child;t!==null;)uv(t,n,a),t=t.sibling}function uv(t,n,a){switch(t.tag){case 26:Ir(t,n,a),t.flags&zr&&(t.memoizedState!==null?CE(a,Ri,t.memoizedState,t.memoizedProps):(t=t.stateNode,(n&335544128)===n&&g0(a,t)));break;case 5:Ir(t,n,a),t.flags&zr&&(t=t.stateNode,(n&335544128)===n&&g0(a,t));break;case 3:case 4:var s=Ri;Ri=il(t.stateNode.containerInfo),Ir(t,n,a),Ri=s;break;case 22:t.memoizedState===null&&(s=t.alternate,s!==null&&s.memoizedState!==null?(s=zr,zr=16777216,Ir(t,n,a),zr=s):Ir(t,n,a));break;case 30:if((t.flags&zr)!==0&&(s=t.memoizedProps.name,s!=null&&s!=="auto")){var u=t.stateNode;u.paired=null,ii===null&&(ii=new Map),ii.set(s,u)}Ir(t,n,a);break;default:Ir(t,n,a)}}function cv(t){var n=t.alternate;if(n!==null&&(t=n.child,t!==null)){n.child=null;do n=t.sibling,t.sibling=null,t=n;while(t!==null)}}function Ko(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var s=n[a];En=s,hv(s,t)}cv(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)fv(t),t=t.sibling}function fv(t){switch(t.tag){case 0:case 11:case 15:Ko(t),t.flags&2048&&Ya(9,t,t.return);break;case 3:Ko(t);break;case 12:Ko(t);break;case 22:var n=t.stateNode;t.memoizedState!==null&&n._visibility&2&&(t.return===null||t.return.tag!==13)?(n._visibility&=-3,Lu(t)):Ko(t);break;default:Ko(t)}}function Lu(t){var n=t.deletions;if((t.flags&16)!==0){if(n!==null)for(var a=0;a<n.length;a++){var s=n[a];En=s,hv(s,t)}cv(t)}for(t=t.child;t!==null;){switch(n=t,n.tag){case 0:case 11:case 15:Ya(8,n,n.return),Lu(n);break;case 22:a=n.stateNode,a._visibility&2&&(a._visibility&=-3,Lu(n));break;default:Lu(n)}t=t.sibling}}function hv(t,n){for(;En!==null;){var a=En;switch(a.tag){case 0:case 11:case 15:Ya(8,a,n);break;case 23:case 22:if(a.memoizedState!==null&&a.memoizedState.cachePool!==null){var s=a.memoizedState.cachePool.pool;s!=null&&s.refCount++}break;case 24:Lo(a.memoizedState.cache)}if(s=a.child,s!==null)s.return=a,En=s;else t:for(a=t;En!==null;){s=En;var u=s.sibling,f=s.return;if(ev(s),s===a){En=null;break t}if(u!==null){u.return=f,En=u;break t}En=f}}}var EM={getCacheForType:function(t){var n=An(cn),a=n.data.get(t);return a===void 0&&(a=t(),n.data.set(t,a)),a},cacheSignal:function(){return An(cn).controller.signal}},TM=typeof WeakMap=="function"?WeakMap:Map,Be=0,je=null,Ee=null,Re=0,Ge=0,ai=null,ja=!1,Ts=!1,Uh=!1,_a=0,on=0,Za=0,Br=0,Ou=0,ri=0,bs=0,Qo=null,jn=null,Nh=!1,Pu=0,dv=0,zu=1/0,Iu=null,Ka=null,en=0,wi=null,Fr=null,Zi=0,Lh=0,Oh=null,pv=null,As=null,Rs=null,Cs=null,Jo=0,Bu=null;function si(){return(Be&2)!==0&&Re!==0?Re&-Re:St.T!==null?kh():At()}function mv(){if(ri===0)if((Re&536870912)===0||ve){var t=aa;aa<<=1,(aa&3932160)===0&&(aa=262144),ri=t}else ri=536870912;return t=Rn.current,t!==null&&(t.flags|=32),ri}function ws(t,n){if(n!=null){var a=t.stateNode,s=a.ref;s===null&&(s=a.ref=Zv(oa(t.memoizedProps,a))),Rs===null&&(Rs=[]),Rs.push(n.bind(null,s))}}function Zn(t,n,a){(t===je&&(Ge===2||Ge===9)||t.cancelPendingCommit!==null)&&(Ds(t,0),Qa(t,Re,ri,!1)),yr(t,a),((Be&2)===0||t!==je)&&(t===je&&((Be&2)===0&&(Br|=a),on===4&&Qa(t,Re,ri,!1)),Ki(t))}function gv(t,n,a){if((Be&6)!==0)throw Error(r(327));var s=!a&&(n&127)===0&&(n&t.expiredLanes)===0||Ua(t,n),u=s?RM(t,n):zh(t,n,!0),f=s;do{if(u===0){Ts&&!s&&Qa(t,n,0,!1);break}else{if(a=t.current.alternate,f&&!bM(a)){u=zh(t,n,!1),f=!1;continue}if(u===2){if(f=n,t.errorRecoveryDisabledLanes&f)var v=0;else v=t.pendingLanes&-536870913,v=v!==0?v:v&536870912?536870912:0;if(v!==0){n=v;t:{var T=t;u=Qo;var P=T.current.memoizedState.isDehydrated;if(P&&(Ds(T,v).flags|=256),v=zh(T,v,!1),v!==2&&v!==6){if(Uh&&!P){T.errorRecoveryDisabledLanes|=f,Br|=f,u=4;break t}f=jn,jn=u,f!==null&&(jn===null?jn=f:jn.push.apply(jn,f))}u=v}if(f=!1,u!==2)continue}}if(u===1){Ds(t,0),Qa(t,n,0,!0);break}t:{switch(s=t,f=u,f){case 0:case 1:throw Error(r(345));case 4:if((n&4194048)!==n&&(n&62914560)!==n)break;case 6:Qa(s,n,ri,!ja);break t;case 2:jn=null;break;case 3:case 5:break;default:throw Error(r(329))}if((n&62914560)===n&&(u=Pu+300-X(),10<u)){if(Qa(s,n,ri,!ja),xr(s,0,!0)!==0)break t;Zi=n,s.timeoutHandle=ed(_v.bind(null,s,a,jn,Iu,Nh,n,ri,Br,bs,ja,f,"Throttled",-0,0),u);break t}_v(s,a,jn,Iu,Nh,n,ri,Br,bs,ja,f,null,-0,0)}}break}while(!0);Ki(t)}function _v(t,n,a,s,u,f,v,T,P,W,ot,gt,q,nt){t.timeoutHandle=-1;var Pt=n.subtreeFlags,jt=(f&335544064)===f;if(gt=null,(jt||Pt&8192||(Pt&16785408)===16785408)&&(gt={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Hi},ii=null,uv(n,f,gt),jt&&(Pt=gt,jt=t.containerInfo,jt=(jt.nodeType===9?jt:jt.ownerDocument).__reactViewTransition,jt!=null&&(Pt.count++,Pt.waitingForViewTransition=!0,Pt=sl.bind(Pt),jt.finished.then(Pt,Pt))),Pt=(f&62914560)===f?Pu-X():(f&4194048)===f?dv-X():0,Pt=wE(gt,Pt),Pt!==null)){Zi=f,t.cancelPendingCommit=Pt(bv.bind(null,t,n,f,a,s,u,v,T,P,W,ot,gt,null,q,nt)),Qa(t,f,v,!W);return}bv(t,n,f,a,s,u,v,T,P,W,ot,gt)}function bM(t){for(var n=t;;){var a=n.tag;if((a===0||a===11||a===15)&&n.flags&16384&&(a=n.updateQueue,a!==null&&(a=a.stores,a!==null)))for(var s=0;s<a.length;s++){var u=a[s],f=u.getSnapshot;u=u.value;try{if(!ei(f(),u))return!1}catch{return!1}}if(a=n.child,n.subtreeFlags&16384&&a!==null)a.return=n,n=a;else{if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return!0;n=n.return}n.sibling.return=n.return,n=n.sibling}}return!0}function Qa(t,n,a,s){n=Pl(t,n),n&=~Ou,n&=~Br,t.suspendedLanes|=n,t.pingedLanes&=~n,s&&(t.warmLanes|=n),s=t.expirationTimes;for(var u=n;0<u;){var f=31-Ln(u),v=1<<f;s[f]=-1,u&=~v}a!==0&&w(t,a,n)}function Fu(){return(Be&6)===0?($o(0),!1):!0}function Ph(){if(Ee!==null){if(Ge===0)var t=Ee.return;else t=Ee,fa=Ar=null,Xf(t),gs=null,zo=0,t=Ee;for(;t!==null;)H_(t.alternate,t),t=t.return;Ee=null}}function Ds(t,n){var a=t.timeoutHandle;return a!==-1&&(t.timeoutHandle=-1,ZM(a)),a=t.cancelPendingCommit,a!==null&&(t.cancelPendingCommit=null,a()),Zi=0,Ph(),je=t,Ee=a=ua(t.current,null),Re=n,Ge=0,ai=null,ja=!1,Ts=Ua(t,n),Uh=!1,bs=ri=Ou=Br=Za=on=0,jn=Qo=null,Nh=!1,_a=Pl(t,n),Wl(),a}function vv(t,n){de=null,St.H=vu,n===ms||n===au?(n=bg(),Ge=3):n===Df?(n=bg(),Ge=4):Ge=n===ah?8:n!==null&&typeof n=="object"&&typeof n.then=="function"?6:1,ai=n,Ee===null&&(on=1,xu(t,pi(n,t.current)))}function xv(){var t=Rn.current;return t===null?!0:(Re&4194048)===Re?Pn===null:(Re&62914560)===Re||(Re&536870912)!==0?t===Pn:!1}function yv(){var t=St.H;return St.H=vu,t===null?vu:t}function Sv(){var t=St.A;return St.A=EM,t}function Hu(){on=4,ja||(Re&4194048)!==Re&&Rn.current!==null||(Ts=!0),(Za&134217727)===0&&(Br&134217727)===0||je===null||Qa(je,Re,ri,!1)}function zh(t,n,a){var s=Be;Be|=2;var u=yv(),f=Sv();(je!==t||Re!==n)&&(Iu=null,Ds(t,n)),n=!1;var v=on;t:do try{if(Ge!==0&&Ee!==null){var T=Ee,P=ai;switch(Ge){case 8:Ph(),v=6;break t;case 3:case 2:case 9:case 6:Rn.current===null&&(n=!0);var W=Ge;if(Ge=0,ai=null,Us(t,T,P,W),a&&Ts){v=0;break t}break;default:W=Ge,Ge=0,ai=null,Us(t,T,P,W)}}AM(),v=on;break}catch(ot){vv(t,ot)}while(!0);return n&&t.shellSuspendCounter++,fa=Ar=null,Be=s,St.H=u,St.A=f,Ee===null&&(je=null,Re=0,Wl()),v}function AM(){for(;Ee!==null;)Mv(Ee)}function RM(t,n){var a=Be;Be|=2;var s=yv(),u=Sv();je!==t||Re!==n?(Iu=null,zu=X()+500,Ds(t,n)):Ts=Ua(t,n);t:do try{if(Ge!==0&&Ee!==null){n=Ee;var f=ai;e:switch(Ge){case 1:Ge=0,ai=null,Us(t,n,f,1);break;case 2:case 9:if(Eg(f)){Ge=0,ai=null,Ev(n);break}n=function(){Ge!==2&&Ge!==9||je!==t||(Ge=7),Ki(t)},f.then(n,n);break t;case 3:Ge=7;break t;case 4:Ge=5;break t;case 7:Eg(f)?(Ge=0,ai=null,Ev(n)):(Ge=0,ai=null,Us(t,n,f,7));break;case 5:var v=null;switch(Ee.tag){case 26:v=Ee.memoizedState;case 5:case 27:var T=Ee;if(v?p0(v):T.stateNode.complete){Ge=0,ai=null;var P=T.sibling;if(P!==null)Ee=P;else{var W=T.return;W!==null?(Ee=W,Gu(W)):Ee=null}break e}}Ge=0,ai=null,Us(t,n,f,5);break;case 6:Ge=0,ai=null,Us(t,n,f,6);break;case 8:Ph(),on=6;break t;default:throw Error(r(462))}}CM();break}catch(ot){vv(t,ot)}while(!0);return fa=Ar=null,St.H=s,St.A=u,Be=a,Ee!==null?0:(je=null,Re=0,Wl(),on)}function CM(){for(;Ee!==null&&!It();)Mv(Ee)}function Mv(t){var n=B_(t.alternate,t,_a);t.memoizedProps=t.pendingProps,n===null?Gu(t):Ee=n}function Ev(t){var n=t,a=n.alternate;switch(n.tag){case 15:case 0:n=U_(a,n,n.pendingProps,n.type,void 0,Re);break;case 11:n=U_(a,n,n.pendingProps,n.type.render,n.ref,Re);break;case 5:Xf(n);var s=n;s===Sn&&(ve?($l(s),s.tag===5&&s.stateNode!=null&&(Ke=s.stateNode)):($l(s),ve=!0));default:H_(a,n),n=Ee=hg(n,_a),n=B_(a,n,_a)}t.memoizedProps=t.pendingProps,n===null?Gu(t):Ee=n}function Us(t,n,a,s){fa=Ar=null,Xf(n),gs=null,zo=0;var u=n.return;try{if(mM(t,u,n,a,Re)){on=1,xu(t,pi(a,t.current)),Ee=null;return}}catch(f){if(u!==null)throw Ee=u,f;on=1,xu(t,pi(a,t.current)),Ee=null;return}n.flags&32768?(ve||s===1?t=!0:Ts||(Re&536870912)!==0?t=!1:(ja=t=!0,(s===2||s===9||s===3||s===6)&&(s=Rn.current,s!==null&&s.tag===13&&(s.flags|=16384))),Tv(n,t)):Gu(n)}function Gu(t){var n=t;do{if((n.flags&32768)!==0){Tv(n,ja);return}t=n.return;var a=xM(n.alternate,n,_a);if(a!==null){Ee=a;return}if(n=n.sibling,n!==null){Ee=n;return}Ee=n=t}while(n!==null);on===0&&(on=5)}function Tv(t,n){do{var a=yM(t.alternate,t);if(a!==null){a.flags&=32767,Ee=a;return}if(a=t.return,a!==null&&(a.flags|=32768,a.subtreeFlags=0,a.deletions=null),!n&&(t=t.sibling,t!==null)){Ee=t;return}Ee=t=a}while(t!==null);on=6,Ee=null}function bv(t,n,a,s,u,f,v,T,P,W,ot,gt){t.cancelPendingCommit=null;do Vu();while(en!==0);if((Be&6)!==0)throw Error(r(327));if(n!==null){if(n===t.current)throw Error(r(177));t===je&&(Ee=je=null,Re=0),Fr=n,wi=t,Zi=a,Oh=u,pv=s,wM(t,n,a,v,T,P,gt)}}function wM(t,n,a,s,u,f,v){var T=n.lanes|n.childLanes;if(Lh=T,T|=_f,Wc(t,a,T,s,u,f),Rs=null,(a&335544064)===a?(Cs=iM(t),s=10262):(Cs=null,s=10256),(n.subtreeFlags&s)!==0||(n.flags&s)!==0?(t.callbackNode=null,t.callbackPriority=0,PM(bt,function(){return Hh(),null})):(t.callbackNode=null,t.callbackPriority=0),Ru=!1,s=(n.flags&13878)!==0,(n.subtreeFlags&13878)!==0||s){s=St.T,St.T=null,u=kt.p,kt.p=2,f=Be,Be|=4;try{SM(t,n,a)}finally{Be=f,kt.p=u,St.T=s}}en=1,Ru?As=eE(v,t.containerInfo,Cs,Ih,Bh,UM,Fh,Hh,DM):(Ih(),Bh(),Fh())}function DM(t){if(en!==0){var n=wi.onRecoverableError;n(t,{componentStack:null})}}function UM(){en===3&&(en=0,ov(Fr,wi),en=4)}function Ih(){if(en===1){en=0;var t=wi,n=Fr,a=Zi,s=(n.flags&13878)!==0;if((n.subtreeFlags&13878)!==0||s){s=St.T,St.T=null;var u=kt.p;kt.p=2;var f=Be;Be|=4;try{jo=Du=!1,rv(n,t,a),a=Jh;var v=ng(t.containerInfo),T=a.focusedElem,P=a.selectionRange;if(v!==T&&T&&T.ownerDocument&&eg(T.ownerDocument.documentElement,T)){if(P!==null&&hf(T)){var W=P.start,ot=P.end;if(ot===void 0&&(ot=W),"selectionStart"in T)T.selectionStart=W,T.selectionEnd=Math.min(ot,T.value.length);else{var gt=T.ownerDocument||document,q=gt&&gt.defaultView||window;if(q.getSelection){var nt=q.getSelection(),Pt=T.textContent.length,jt=Math.min(P.start,Pt),pe=P.end===void 0?jt:Math.min(P.end,Pt);!nt.extend&&jt>pe&&(v=pe,pe=jt,jt=v);var Y=tg(T,jt),V=tg(T,pe);if(Y&&V&&(nt.rangeCount!==1||nt.anchorNode!==Y.node||nt.anchorOffset!==Y.offset||nt.focusNode!==V.node||nt.focusOffset!==V.offset)){var tt=gt.createRange();tt.setStart(Y.node,Y.offset),nt.removeAllRanges(),jt>pe?(nt.addRange(tt),nt.extend(V.node,V.offset)):(tt.setEnd(V.node,V.offset),nt.addRange(tt))}}}}for(gt=[],nt=T;nt=nt.parentNode;)nt.nodeType===1&&gt.push({element:nt,left:nt.scrollLeft,top:nt.scrollTop});for(typeof T.focus=="function"&&T.focus(),T=0;T<gt.length;T++){var pt=gt[T];pt.element.scrollLeft=pt.left,pt.element.scrollTop=pt.top}}Fs=!!Qh,Jh=Qh=null}finally{Be=f,kt.p=u,St.T=s}}t.current=n,en=2}}function Bh(){if(en===2){en=0;var t=wi,n=Fr,a=(n.flags&8772)!==0;if((n.subtreeFlags&8772)!==0||a){a=St.T,St.T=null;var s=kt.p;kt.p=2;var u=Be;Be|=4;try{$_(t,n.alternate,n)}finally{Be=u,kt.p=s,St.T=a}}en=3}}function Fh(){if(en===4||en===3){en=0;var t=As;As=null,he();var n=wi,a=Fr,s=Zi,u=pv,f=(s&335544064)===s?10262:10256;if((a.subtreeFlags&f)!==0||(a.flags&f)!==0?en=5:(en=0,Fr=wi=null,Av(n,n.pendingLanes)),f=n.pendingLanes,f===0&&(Ka=null),Q(s),a=a.stateNode,tn&&typeof tn.onCommitFiberRoot=="function")try{tn.onCommitFiberRoot(Ae,a,void 0,(a.current.flags&128)===128)}catch{}if(u!==null){a=St.T,f=kt.p,kt.p=2,St.T=null;try{for(var v=n.onRecoverableError,T=0;T<u.length;T++){var P=u[T];v(P.value,{componentStack:P.stack})}}finally{St.T=a,kt.p=f}}if(u=Rs,v=Cs,Cs=null,u!==null&&(Rs=null,v===null&&(v=[]),t!==null))for(P=0;P<u.length;P++)a=(0,u[P])(v),a!==void 0&&t.finished.finally(a);(Zi&3)!==0&&Vu(),Ki(n),f=n.pendingLanes,(s&261930)!==0&&(f&42)!==0?n===Bu?Jo++:(Jo=0,Bu=n):(Jo=0,Bu=null),$o(0)}}function Av(t,n){(t.pooledCacheLanes&=n)===0&&(n=t.pooledCache,n!=null&&(t.pooledCache=null,Lo(n)))}function Vu(){return As!==null&&(As.skipTransition(),As=null),Ih(),Bh(),Fh(),Hh()}function Hh(){if(en!==5)return!1;var t=wi,n=Lh;Lh=0;var a=Q(Zi),s=St.T,u=kt.p;try{kt.p=32>a?32:a,St.T=null,a=Oh,Oh=null;var f=wi,v=Zi;if(en=0,Fr=wi=null,Zi=0,(Be&6)!==0)throw Error(r(331));var T=Be;if(Be|=4,fv(f.current),lv(f,f.current,v,a),Be=T,$o(0,!1),tn&&typeof tn.onPostCommitFiberRoot=="function")try{tn.onPostCommitFiberRoot(Ae,f)}catch{}return!0}finally{kt.p=u,St.T=s,Av(t,n)}}function Rv(t,n,a){n=pi(a,n),n=ih(t.stateNode,n,2),t=Va(t,n,2),t!==null&&(yr(t,2),Ki(t))}function Ve(t,n,a){if(t.tag===3)Rv(t,t,a);else for(;n!==null;){if(n.tag===3){Rv(n,t,a);break}else if(n.tag===1){var s=n.stateNode;if(typeof n.type.getDerivedStateFromError=="function"||typeof s.componentDidCatch=="function"&&(Ka===null||!Ka.has(s))){t=pi(a,t),a=E_(2),s=Va(n,a,2),s!==null&&(T_(a,s,n,t),yr(s,2),Ki(s));break}}n=n.return}}function Gh(t,n,a){var s=t.pingCache;if(s===null){s=t.pingCache=new TM;var u=new Set;s.set(n,u)}else u=s.get(n),u===void 0&&(u=new Set,s.set(n,u));u.has(a)||(Uh=!0,u.add(a),t=NM.bind(null,t,n,a),n.then(t,t))}function NM(t,n,a){var s=t.pingCache;s!==null&&s.delete(n),t.pingedLanes|=t.suspendedLanes&a,t.warmLanes&=~a,je===t&&(Re&a)===a&&((on===4||on===3&&(Re&62914560)===Re&&300>X()-Pu)&&(Be&2)===0?Ds(t,0):Ou|=a,bs===Re&&(bs=0)),Ki(t)}function Cv(t,n){n===0&&(n=zl()),t=Er(t,n),t!==null&&(yr(t,n),Ki(t))}function LM(t){var n=t.memoizedState,a=0;n!==null&&(a=n.retryLane),Cv(t,a)}function OM(t,n){var a=0;switch(t.tag){case 31:case 13:var s=t.stateNode,u=t.memoizedState;u!==null&&(a=u.retryLane);break;case 19:s=t.stateNode;break;case 22:s=t.stateNode._retryCache;break;default:throw Error(r(314))}s!==null&&s.delete(n),Cv(t,a)}function PM(t,n){return se(t,n)}var Ns=null,Ls=null,Vh=!1,Xu=!1,Xh=!1,Ja=0;function Ki(t){t!==Ls&&t.next===null&&(Ls===null?Ns=Ls=t:Ls=Ls.next=t),Xu=!0,Vh||(Vh=!0,IM())}function $o(t,n){if(!Xh&&Xu){Xh=!0;do for(var a=!1,s=Ns;s!==null;){if(t!==0){var u=s.pendingLanes;if(u===0)var f=0;else{var v=s.suspendedLanes,T=s.pingedLanes;f=(1<<31-Ln(42|t)+1)-1,f&=u&~(v&~T),f=f&201326741?f&201326741|1:f?f|2:0}f!==0&&(a=!0,Nv(s,f))}else f=Re,f=xr(s,s===je?f:0,s.cancelPendingCommit!==null||s.timeoutHandle!==-1),(f&3)===0||Ua(s,f)||(a=!0,Nv(s,f));s=s.next}while(a);Xh=!1}}function zM(){wv()}function wv(){Xu=Vh=!1;var t=0;Ja!==0&&jM()&&(t=Ja);for(var n=X(),a=null,s=Ns;s!==null;){var u=s.next,f=Dv(s,n);f===0?(s.next=null,a===null?Ns=u:a.next=u,u===null&&(Ls=a)):(a=s,(t!==0||(f&3)!==0)&&(Xu=!0)),s=u}en!==0&&en!==5||$o(t),Ja!==0&&(Ja=0)}function Dv(t,n){for(var a=t.suspendedLanes,s=t.pingedLanes,u=t.expirationTimes,f=t.pendingLanes&-62914561;0<f;){var v=31-Ln(f),T=1<<v,P=u[v];P===-1?((T&a)===0||(T&s)!==0)&&(u[v]=Yc(T,n)):P<=n&&(t.expiredLanes|=T),f&=~T}if(n=je,a=Re,a=xr(t,t===n?a:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),s=t.callbackNode,a===0||t===n&&(Ge===2||Ge===9)||t.cancelPendingCommit!==null)return s!==null&&s!==null&&Jt(s),t.callbackNode=null,t.callbackPriority=0;if((a&3)===0||Ua(t,a)){if(n=a&-a,n===t.callbackPriority)return n;switch(s!==null&&Jt(s),Q(a)){case 2:case 8:a=qt;break;case 32:a=bt;break;case 268435456:a=Zt;break;default:a=bt}return s=Uv.bind(null,t),a=se(a,s),t.callbackPriority=n,t.callbackNode=a,n}return s!==null&&s!==null&&Jt(s),t.callbackPriority=2,t.callbackNode=null,2}function Uv(t,n){if(en!==0&&en!==5)return t.callbackNode=null,t.callbackPriority=0,null;var a=t.callbackNode;if(Vu()&&t.callbackNode!==a)return null;var s=Re;return s=xr(t,t===je?s:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),s===0?null:(gv(t,s,n),Dv(t,X()),t.callbackNode!=null&&t.callbackNode===a?Uv.bind(null,t):null)}function Nv(t,n){if(Vu())return null;gv(t,n,!0)}function IM(){KM(function(){(Be&6)!==0?se(Lt,zM):wv()})}function kh(){if(Ja===0){var t=wr;t===0&&(t=_r,_r<<=1,(_r&261888)===0&&(_r=256)),Ja=t}return Ja}function Lv(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:Fl(t)}function BM(t,n,a,s,u){if(n==="submit"&&a&&a.stateNode===u){var f=Lv((u[Wt]||null).action),v=s.submitter;v&&(n=(n=v[Wt]||null)?Lv(n.formAction):v.getAttribute("formAction"),n!==null&&(f=n,v=null));var T=new Xl("action","action",null,s,u);t.push({event:T,listeners:[{instance:null,listener:function(){if(s.defaultPrevented){if(Ja!==0){var P=new FormData(u,v);Jf(a,{pending:!0,data:P,method:u.method,action:f},null,P)}}else typeof f=="function"&&(T.preventDefault(),P=new FormData(u,v),Jf(a,{pending:!0,data:P,method:u.method,action:f},f,P))},currentTarget:u}]})}}for(var qh=0;qh<gf.length;qh++){var Yh=gf[qh],FM=Yh.toLowerCase(),HM=Yh[0].toUpperCase()+Yh.slice(1);bi(FM,"on"+HM)}bi(rg,"onAnimationEnd"),bi(sg,"onAnimationIteration"),bi(og,"onAnimationStart"),bi("dblclick","onDoubleClick"),bi("focusin","onFocus"),bi("focusout","onBlur"),bi(ZS,"onTransitionRun"),bi(KS,"onTransitionStart"),bi(QS,"onTransitionCancel"),bi(lg,"onTransitionEnd"),rn("onMouseEnter",["mouseout","mouseover"]),rn("onMouseLeave",["mouseout","mouseover"]),rn("onPointerEnter",["pointerout","pointerover"]),rn("onPointerLeave",["pointerout","pointerover"]),un("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),un("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),un("onBeforeInput",["compositionend","keypress","textInput","paste"]),un("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),un("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),un("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var tl="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),GM=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(tl));function Ov(t,n){n=(n&4)!==0;for(var a=0;a<t.length;a++){var s=t[a],u=s.event;s=s.listeners;t:{var f=void 0;if(n)for(var v=s.length-1;0<=v;v--){var T=s[v],P=T.instance,W=T.currentTarget;if(T=T.listener,P!==f&&u.isPropagationStopped())break t;f=T,u.currentTarget=W;try{f(u)}catch(ot){Yl(ot)}u.currentTarget=null,f=P}else for(v=0;v<s.length;v++){if(T=s[v],P=T.instance,W=T.currentTarget,T=T.listener,P!==f&&u.isPropagationStopped())break t;f=T,u.currentTarget=W;try{f(u)}catch(ot){Yl(ot)}u.currentTarget=null,f=P}}}}function Te(t,n){var a=n[ee];a===void 0&&(a=n[ee]=new Set);var s=t+"__bubble";a.has(s)||(Pv(n,t,2,!1),a.add(s))}function Wh(t,n,a){var s=0;n&&(s|=4),Pv(a,t,s,n)}var ku="_reactListening"+Math.random().toString(36).slice(2);function jh(t){if(!t[ku]){t[ku]=!0,Ze.forEach(function(a){a!=="selectionchange"&&(GM.has(a)||Wh(a,!1,t),Wh(a,!0,t))});var n=t.nodeType===9?t:t.ownerDocument;n===null||n[ku]||(n[ku]=!0,Wh("selectionchange",!1,n))}}function Pv(t,n,a,s){switch(T0(n)){case 2:var u=LE;break;case 8:u=OE;break;default:u=pd}a=u.bind(null,n,a,t),u=void 0,!ef||n!=="touchstart"&&n!=="touchmove"&&n!=="wheel"||(u=!0),s?u!==void 0?t.addEventListener(n,a,{capture:!0,passive:u}):t.addEventListener(n,a,!0):u!==void 0?t.addEventListener(n,a,{passive:u}):t.addEventListener(n,a,!1)}function Zh(t,n,a,s,u){var f=s;if((n&1)===0&&(n&2)===0&&s!==null)t:for(;;){if(s===null)return;var v=s.tag;if(v===3||v===4){var T=s.stateNode.containerInfo;if(T===u)break;if(v===4)for(v=s.return;v!==null;){var P=v.tag;if((P===3||P===4)&&v.stateNode.containerInfo===u)return;v=v.return}for(;T!==null;){if(v=Ie(T),v===null)return;if(P=v.tag,P===5||P===6||P===26||P===27){s=f=v;continue t}T=T.parentNode}}s=s.return}Pm(function(){var W=f,ot=$c(a),gt=[];t:{var q=ug.get(t);if(q!==void 0){var nt=Xl,Pt=t;switch(t){case"keypress":if(Gl(a)===0)break t;case"keydown":case"keyup":nt=bS;break;case"focusin":Pt="focus",nt=sf;break;case"focusout":Pt="blur",nt=sf;break;case"beforeblur":case"afterblur":nt=sf;break;case"click":if(a.button===2)break t;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":nt=Bm;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":nt=dS;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":nt=DS;break;case rg:case sg:case og:nt=gS;break;case lg:nt=NS;break;case"scroll":case"scrollend":nt=fS;break;case"wheel":nt=OS;break;case"copy":case"cut":case"paste":nt=vS;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":nt=Hm;break;case"submit":nt=CS;break;case"toggle":case"beforetoggle":nt=zS}var jt=(n&4)!==0,pe=!jt&&(t==="scroll"||t==="scrollend"),Y=jt?q!==null?q+"Capture":null:q;jt=[];for(var V=W,tt;V!==null;){var pt=V;if(tt=pt.stateNode,pt=pt.tag,pt!==5&&pt!==26&&pt!==27||tt===null||Y===null||(pt=Mo(V,Y),pt!=null&&jt.push(el(V,pt,tt))),pe)break;V=V.return}0<jt.length&&(q=new nt(q,Pt,null,a,ot),gt.push({event:q,listeners:jt}))}}if((n&7)===0){t:{if(nt=t==="mouseover"||t==="pointerover",q=t==="mouseout"||t==="pointerout",nt&&a!==Jc&&(Pt=a.relatedTarget||a.fromElement)&&(Ie(Pt)||Pt[ae]))break t;(q||nt)&&(Pt=ot.window===ot?ot:(nt=ot.ownerDocument)?nt.defaultView||nt.parentWindow:window,q?(nt=a.relatedTarget||a.toElement,q=W,nt=nt?Ie(nt):null,nt!==null&&(pe=c(nt),jt=nt.tag,nt!==pe||jt!==5&&jt!==27&&jt!==6)&&(nt=null)):(q=null,nt=W),q!==nt&&(jt=Bm,pt="onMouseLeave",Y="onMouseEnter",V="mouse",(t==="pointerout"||t==="pointerover")&&(jt=Hm,pt="onPointerLeave",Y="onPointerEnter",V="pointer"),pe=q==null?Pt:_n(q),tt=nt==null?Pt:_n(nt),Pt=new jt(pt,V+"leave",q,a,ot),Pt.target=pe,Pt.relatedTarget=tt,pt=null,Ie(ot)===W&&(jt=new jt(Y,V+"enter",nt,a,ot),jt.target=tt,jt.relatedTarget=pe,pt=jt),pe=pt,jt=q&&nt?z(q,nt,VM):null,q!==null&&zv(gt,Pt,q,jt,!1),nt!==null&&pe!==null&&zv(gt,pe,nt,jt,!0)))}t:{if(q=W?_n(W):window,nt=q.nodeName&&q.nodeName.toLowerCase(),nt==="select"||nt==="input"&&q.type==="file")var Xt=jm;else if(Ym(q))if(Zm)Xt=YS;else{Xt=kS;var Ce=XS}else nt=q.nodeName,!nt||nt.toLowerCase()!=="input"||q.type!=="checkbox"&&q.type!=="radio"?W&&Qc(W.elementType)&&(Xt=jm):Xt=qS;if(Xt&&(Xt=Xt(t,W))){Wm(gt,Xt,a,ot);break t}Ce&&Ce(t,q,W)}switch(Ce=W?_n(W):window,t){case"focusin":(Ym(Ce)||Ce.contentEditable==="true")&&(os=Ce,df=W,Do=null);break;case"focusout":Do=df=os=null;break;case"mousedown":pf=!0;break;case"contextmenu":case"mouseup":case"dragend":pf=!1,ig(gt,a,ot);break;case"selectionchange":if(jS)break;case"keydown":case"keyup":ig(gt,a,ot)}var te;if(lf)t:{switch(t){case"compositionstart":var ue="onCompositionStart";break t;case"compositionend":ue="onCompositionEnd";break t;case"compositionupdate":ue="onCompositionUpdate";break t}ue=void 0}else ss?km(t,a)&&(ue="onCompositionEnd"):t==="keydown"&&a.keyCode===229&&(ue="onCompositionStart");ue&&(Gm&&a.locale!=="ko"&&(ss||ue!=="onCompositionStart"?ue==="onCompositionEnd"&&ss&&(te=zm()):(La=ot,nf="value"in La?La.value:La.textContent,ss=!0)),Ce=qu(W,ue),0<Ce.length&&(ue=new Fm(ue,t,null,a,ot),gt.push({event:ue,listeners:Ce}),te?ue.data=te:(te=qm(a),te!==null&&(ue.data=te)))),(te=BS?FS(t,a):HS(t,a))&&(ue=qu(W,"onBeforeInput"),0<ue.length&&(Ce=new Fm("onBeforeInput","beforeinput",null,a,ot),gt.push({event:Ce,listeners:ue}),Ce.data=te)),BM(gt,t,W,a,ot)}Ov(gt,n)})}function el(t,n,a){return{instance:t,listener:n,currentTarget:a}}function qu(t,n){for(var a=n+"Capture",s=[];t!==null;){var u=t,f=u.stateNode;if(u=u.tag,u!==5&&u!==26&&u!==27||f===null||(u=Mo(t,a),u!=null&&s.unshift(el(t,u,f)),u=Mo(t,n),u!=null&&s.push(el(t,u,f))),t.tag===3)return s;t=t.return}return[]}function VM(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function zv(t,n,a,s,u){for(var f=n._reactName,v=[];a!==null&&a!==s;){var T=a,P=T.alternate,W=T.stateNode;if(T=T.tag,P!==null&&P===s)break;T!==5&&T!==26&&T!==27||W===null||(P=W,u?(W=Mo(a,f),W!=null&&v.unshift(el(a,W,P))):u||(W=Mo(a,f),W!=null&&v.push(el(a,W,P)))),a=a.return}v.length!==0&&t.push({event:n,listeners:v})}var XM=/\r\n?/g,kM=/\u0000|\uFFFD/g;function Iv(t){return(typeof t=="string"?t:""+t).replace(XM,`
`).replace(kM,"")}function Bv(t,n){return n=Iv(n),Iv(t)===n}function Xe(t,n,a,s,u,f){switch(a){case"children":if(typeof s=="string")n==="body"||n==="textarea"&&s===""||is(t,s);else if(typeof s=="number"||typeof s=="bigint")n!=="body"&&is(t,""+s);else return;break;case"className":Bl(t,"class",s);break;case"tabIndex":Bl(t,"tabindex",s);break;case"dir":case"role":case"viewBox":case"width":case"height":Bl(t,a,s);break;case"style":Lm(t,s,f);return;case"data":if(n!=="object"){Bl(t,"data",s);break}case"src":case"href":if(s===""&&(n!=="a"||a!=="href")){t.removeAttribute(a);break}if(s==null||typeof s=="function"||typeof s=="symbol"||typeof s=="boolean"){t.removeAttribute(a);break}s=Fl(s),t.setAttribute(a,s);break;case"action":case"formAction":if(typeof s=="function"){t.setAttribute(a,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof f=="function"&&(a==="formAction"?(n!=="input"&&Xe(t,n,"name",u.name,u,null),Xe(t,n,"formEncType",u.formEncType,u,null),Xe(t,n,"formMethod",u.formMethod,u,null),Xe(t,n,"formTarget",u.formTarget,u,null)):(Xe(t,n,"encType",u.encType,u,null),Xe(t,n,"method",u.method,u,null),Xe(t,n,"target",u.target,u,null)));if(s==null||typeof s=="symbol"||typeof s=="boolean"){t.removeAttribute(a);break}s=Fl(s),t.setAttribute(a,s);break;case"onClick":s!=null&&(t.onclick=Hi);return;case"onScroll":s!=null&&Te("scroll",t);return;case"onScrollEnd":s!=null&&Te("scrollend",t);return;case"dangerouslySetInnerHTML":if(s!=null){if(typeof s!="object"||!("__html"in s))throw Error(r(61));if(a=s.__html,a!=null){if(u.children!=null)throw Error(r(60));f?.__html!==a&&(t.innerHTML=a)}}break;case"multiple":t.multiple=s&&typeof s!="function"&&typeof s!="symbol";break;case"muted":t.muted=s&&typeof s!="function"&&typeof s!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(s==null||typeof s=="function"||typeof s=="boolean"||typeof s=="symbol"){t.removeAttribute("xlink:href");break}a=Fl(s),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",a);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":s!=null&&typeof s!="function"&&typeof s!="symbol"?t.setAttribute(a,s):t.removeAttribute(a);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"credentialless":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":s&&typeof s!="function"&&typeof s!="symbol"?t.setAttribute(a,""):t.removeAttribute(a);break;case"capture":case"download":s===!0?t.setAttribute(a,""):s!==!1&&s!=null&&typeof s!="function"&&typeof s!="symbol"?t.setAttribute(a,s):t.removeAttribute(a);break;case"cols":case"rows":case"size":case"span":s!=null&&typeof s!="function"&&typeof s!="symbol"&&!isNaN(s)&&1<=s?t.setAttribute(a,s):t.removeAttribute(a);break;case"rowSpan":case"start":s==null||typeof s=="function"||typeof s=="symbol"||isNaN(s)?t.removeAttribute(a):t.setAttribute(a,s);break;case"popover":Te("beforetoggle",t),Te("toggle",t),Il(t,"popover",s);break;case"xlinkActuate":ra(t,"http://www.w3.org/1999/xlink","xlink:actuate",s);break;case"xlinkArcrole":ra(t,"http://www.w3.org/1999/xlink","xlink:arcrole",s);break;case"xlinkRole":ra(t,"http://www.w3.org/1999/xlink","xlink:role",s);break;case"xlinkShow":ra(t,"http://www.w3.org/1999/xlink","xlink:show",s);break;case"xlinkTitle":ra(t,"http://www.w3.org/1999/xlink","xlink:title",s);break;case"xlinkType":ra(t,"http://www.w3.org/1999/xlink","xlink:type",s);break;case"xmlBase":ra(t,"http://www.w3.org/XML/1998/namespace","xml:base",s);break;case"xmlLang":ra(t,"http://www.w3.org/XML/1998/namespace","xml:lang",s);break;case"xmlSpace":ra(t,"http://www.w3.org/XML/1998/namespace","xml:space",s);break;case"is":Il(t,"is",s);break;case"innerText":case"textContent":return;default:if(!(2<a.length)||a[0]!=="o"&&a[0]!=="O"||a[1]!=="n"&&a[1]!=="N")a=uS.get(a)||a,Il(t,a,s);else return}Le=!0}function Kh(t,n,a,s,u,f){switch(a){case"style":Lm(t,s,f);return;case"dangerouslySetInnerHTML":if(s!=null){if(typeof s!="object"||!("__html"in s))throw Error(r(61));if(a=s.__html,a!=null){if(u.children!=null)throw Error(r(60));f?.__html!==a&&(t.innerHTML=a)}}break;case"children":if(typeof s=="string")is(t,s);else if(typeof s=="number"||typeof s=="bigint")is(t,""+s);else return;break;case"onScroll":s!=null&&Te("scroll",t);return;case"onScrollEnd":s!=null&&Te("scrollend",t);return;case"onClick":s!=null&&(t.onclick=Hi);return;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":return;case"innerText":case"textContent":return;default:if(!Fn.hasOwnProperty(a))t:{if(a[0]==="o"&&a[1]==="n"&&(u=a.endsWith("Capture"),f=a.slice(2,u?a.length-7:void 0),n=t[Wt]||null,n=n!=null?n[a]:null,typeof n=="function"&&t.removeEventListener(f,n,u),typeof s=="function")){typeof n!="function"&&n!==null&&(a in t?t[a]=null:t.hasAttribute(a)&&t.removeAttribute(a)),t.addEventListener(f,s,u);break t}Le=!0,a in t?t[a]=s:s===!0?t.setAttribute(a,""):Il(t,a,s)}return}Le=!0}function Dn(t,n,a){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Te("error",t),Te("load",t);var s=!1,u=!1,f;for(f in a)if(a.hasOwnProperty(f)){var v=a[f];if(v!=null)switch(f){case"src":s=!0;break;case"srcSet":u=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(r(137,n));default:Xe(t,n,f,v,a,null)}}u&&Xe(t,n,"srcSet",a.srcSet,a,null),s&&Xe(t,n,"src",a.src,a,null);return;case"input":Te("invalid",t);var T=f=v=u=null,P=null,W=null;for(s in a)if(a.hasOwnProperty(s)){var ot=a[s];if(ot!=null)switch(s){case"name":u=ot;break;case"type":v=ot;break;case"checked":P=ot;break;case"defaultChecked":W=ot;break;case"value":f=ot;break;case"defaultValue":T=ot;break;case"children":case"dangerouslySetInnerHTML":if(ot!=null)throw Error(r(137,n));break;default:Xe(t,n,s,ot,a,null)}}wm(t,f,T,P,W,v,u,!1);return;case"select":Te("invalid",t),s=v=f=null;for(u in a)if(a.hasOwnProperty(u)&&(T=a[u],T!=null))switch(u){case"value":f=T;break;case"defaultValue":v=T;break;case"multiple":s=T;default:Xe(t,n,u,T,a,null)}n=f,a=v,t.multiple=!!s,n!=null?ns(t,!!s,n,!1):a!=null&&ns(t,!!s,a,!0);return;case"textarea":Te("invalid",t),f=u=s=null;for(v in a)if(a.hasOwnProperty(v)&&(T=a[v],T!=null))switch(v){case"value":s=T;break;case"defaultValue":u=T;break;case"children":f=T;break;case"dangerouslySetInnerHTML":if(T!=null)throw Error(r(91));break;default:Xe(t,n,v,T,a,null)}Um(t,s,u,f);return;case"option":for(P in a)a.hasOwnProperty(P)&&(s=a[P],s!=null)&&(P==="selected"?t.selected=s&&typeof s!="function"&&typeof s!="symbol":Xe(t,n,P,s,a,null));return;case"dialog":Te("beforetoggle",t),Te("toggle",t),Te("cancel",t),Te("close",t);break;case"iframe":case"object":Te("load",t);break;case"video":case"audio":for(s=0;s<tl.length;s++)Te(tl[s],t);break;case"image":Te("error",t),Te("load",t);break;case"details":Te("toggle",t);break;case"embed":case"source":case"link":Te("error",t),Te("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(W in a)if(a.hasOwnProperty(W)&&(s=a[W],s!=null))switch(W){case"children":case"dangerouslySetInnerHTML":throw Error(r(137,n));default:Xe(t,n,W,s,a,null)}return;default:if(Qc(n)){for(ot in a)a.hasOwnProperty(ot)&&(s=a[ot],s!==void 0&&Kh(t,n,ot,s,a,void 0));return}}for(T in a)a.hasOwnProperty(T)&&(s=a[T],s!=null&&Xe(t,n,T,s,a,null))}var qM={};function YM(t,n,a,s){switch(n){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var u=null,f=null,v=null,T=null,P=null,W=null,ot=null;for(nt in a){var gt=a[nt];if(a.hasOwnProperty(nt)&&gt!=null)switch(nt){case"checked":break;case"value":break;case"defaultValue":P=gt;default:s.hasOwnProperty(nt)||Xe(t,n,nt,null,s,gt)}}for(var q in s){var nt=s[q];if(gt=a[q],s.hasOwnProperty(q)&&(nt!=null||gt!=null))switch(q){case"type":nt!==gt&&(Le=!0),f=nt;break;case"name":nt!==gt&&(Le=!0),u=nt;break;case"checked":nt!==gt&&(Le=!0),W=nt;break;case"defaultChecked":nt!==gt&&(Le=!0),ot=nt;break;case"value":nt!==gt&&(Le=!0),v=nt;break;case"defaultValue":nt!==gt&&(Le=!0),T=nt;break;case"children":case"dangerouslySetInnerHTML":if(nt!=null)throw Error(r(137,n));break;default:nt!==gt&&Xe(t,n,q,nt,s,gt)}}Zc(t,v,T,P,W,ot,f,u);return;case"select":nt=v=T=q=null;for(f in a)if(P=a[f],a.hasOwnProperty(f)&&P!=null)switch(f){case"value":break;case"multiple":nt=P;default:s.hasOwnProperty(f)||Xe(t,n,f,null,s,P)}for(u in s)if(f=s[u],P=a[u],s.hasOwnProperty(u)&&(f!=null||P!=null))switch(u){case"value":f!==P&&(Le=!0),q=f;break;case"defaultValue":f!==P&&(Le=!0),T=f;break;case"multiple":f!==P&&(Le=!0),v=f;default:f!==P&&Xe(t,n,u,f,s,P)}n=T,a=v,s=nt,q!=null?ns(t,!!a,q,!1):!!s!=!!a&&(n!=null?ns(t,!!a,n,!0):ns(t,!!a,a?[]:"",!1));return;case"textarea":nt=q=null;for(T in a)if(u=a[T],a.hasOwnProperty(T)&&u!=null&&!s.hasOwnProperty(T))switch(T){case"value":break;case"children":break;default:Xe(t,n,T,null,s,u)}for(v in s)if(u=s[v],f=a[v],s.hasOwnProperty(v)&&(u!=null||f!=null))switch(v){case"value":u!==f&&(Le=!0),q=u;break;case"defaultValue":u!==f&&(Le=!0),nt=u;break;case"children":break;case"dangerouslySetInnerHTML":if(u!=null)throw Error(r(91));break;default:u!==f&&Xe(t,n,v,u,s,f)}Dm(t,q,nt);return;case"option":for(var Pt in a)q=a[Pt],a.hasOwnProperty(Pt)&&q!=null&&!s.hasOwnProperty(Pt)&&(Pt==="selected"?t.selected=!1:Xe(t,n,Pt,null,s,q));for(P in s)q=s[P],nt=a[P],s.hasOwnProperty(P)&&q!==nt&&(q!=null||nt!=null)&&(P==="selected"?(q!==nt&&(Le=!0),t.selected=q&&typeof q!="function"&&typeof q!="symbol"):Xe(t,n,P,q,s,nt));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var jt in a)q=a[jt],a.hasOwnProperty(jt)&&q!=null&&!s.hasOwnProperty(jt)&&Xe(t,n,jt,null,s,q);for(W in s)if(q=s[W],nt=a[W],s.hasOwnProperty(W)&&q!==nt&&(q!=null||nt!=null))switch(W){case"children":case"dangerouslySetInnerHTML":if(q!=null)throw Error(r(137,n));break;default:Xe(t,n,W,q,s,nt)}return;default:if(Qc(n)){for(var pe in a)q=a[pe],a.hasOwnProperty(pe)&&q!==void 0&&!s.hasOwnProperty(pe)&&Kh(t,n,pe,void 0,s,q);for(ot in s)q=s[ot],nt=a[ot],!s.hasOwnProperty(ot)||q===nt||q===void 0&&nt===void 0||Kh(t,n,ot,q,s,nt);return}}for(var Y in a)q=a[Y],a.hasOwnProperty(Y)&&q!=null&&!s.hasOwnProperty(Y)&&Xe(t,n,Y,null,s,q);for(gt in s)q=s[gt],nt=a[gt],!s.hasOwnProperty(gt)||q===nt||q==null&&nt==null||Xe(t,n,gt,q,s,nt)}function Fv(t){switch(t){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function WM(){if(typeof performance.getEntriesByType=="function"){for(var t=0,n=0,a=performance.getEntriesByType("resource"),s=0;s<a.length;s++){var u=a[s],f=u.transferSize,v=u.initiatorType,T=u.duration;if(f&&T&&Fv(v)){for(v=0,T=u.responseEnd,s+=1;s<a.length;s++){var P=a[s],W=P.startTime;if(W>T)break;var ot=P.transferSize,gt=P.initiatorType;ot&&Fv(gt)&&(P=P.responseEnd,v+=ot*(P<T?1:(T-W)/(P-W)))}if(--s,n+=8*(f+v)/(u.duration/1e3),t++,10<t)break}}if(0<t)return n/t/1e6}return navigator.connection&&(t=navigator.connection.downlink,typeof t=="number")?t:5}var Qh=null,Jh=null;function nl(t){return t.nodeType===9?t:t.ownerDocument}function Hv(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function Gv(t,n){if(t===0)switch(n){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&n==="foreignObject"?0:t}function Vv(t,n,a,s){return a=nl(a).createElement(t),a[Nt]=s,a[Wt]=n,Dn(a,t,n),Ne(a),a}function $h(t,n){return t==="textarea"||t==="noscript"||typeof n.children=="string"||typeof n.children=="number"||typeof n.children=="bigint"||typeof n.dangerouslySetInnerHTML=="object"&&n.dangerouslySetInnerHTML!==null&&n.dangerouslySetInnerHTML.__html!=null}var td=null;function jM(){var t=window.event;return t&&t.type==="popstate"?t===td?!1:(td=t,!0):(td=null,!1)}var ed=typeof setTimeout=="function"?setTimeout:void 0,ZM=typeof clearTimeout=="function"?clearTimeout:void 0,Xv=typeof Promise=="function"?Promise:void 0,kv=typeof requestAnimationFrame=="function"?requestAnimationFrame:ed,KM=typeof queueMicrotask=="function"?queueMicrotask:typeof Xv<"u"?function(t){return Xv.resolve(null).then(t).catch(QM)}:ed;function QM(t){setTimeout(function(){throw t})}function $a(t){return t==="head"}function qv(t,n){var a=n,s=0;do{var u=a.nextSibling;if(t.removeChild(a),u&&u.nodeType===8)if(a=u.data,a==="/$"||a==="/&"){if(s===0){t.removeChild(u),Hs(n);return}s--}else if(a==="$"||a==="$?"||a==="$~"||a==="$!"||a==="&")s++;else if(a==="html")ud(t.ownerDocument.documentElement);else if(a==="head"){a=t.ownerDocument.head,ud(a);for(var f=a.firstChild;f;){var v=f.nextSibling,T=f.nodeName;f[ze]||T==="SCRIPT"||T==="STYLE"||T==="LINK"&&f.rel.toLowerCase()==="stylesheet"||a.removeChild(f),f=v}}else a==="body"&&ud(t.ownerDocument.body);a=u}while(a);Hs(n)}function Yv(t,n){var a=t;t=0;do{var s=a.nextSibling;if(a.nodeType===1?n?(a._stashedDisplay=a.style.display,a.style.display="none"):(a.style.display=a._stashedDisplay||"",a.getAttribute("style")===""&&a.removeAttribute("style")):a.nodeType===3&&(n?(a._stashedText=a.nodeValue,a.nodeValue=""):a.nodeValue=a._stashedText||""),s&&s.nodeType===8)if(a=s.data,a==="/$"){if(t===0)break;t--}else a!=="$"&&a!=="$?"&&a!=="$~"&&a!=="$!"||t++;a=s}while(a)}function Wv(t,n,a){if(n=CSS.escape(n)!==n?"r-"+btoa(n).replace(/=/g,""):n,t.style.viewTransitionName=n,a!=null&&(t.style.viewTransitionClass=a),a=getComputedStyle(t),a.display==="inline"){if(n=t.getClientRects(),n.length===1)var s=1;else for(var u=s=0;u<n.length;u++){var f=n[u];0<f.width&&0<f.height&&s++}s===1&&(t=t.style,t.display=n.length===1?"inline-block":"block",t.marginTop="-"+a.paddingTop,t.marginBottom="-"+a.paddingBottom)}}function jv(t,n){t=t.style,n=n.style;var a=n!=null?n.hasOwnProperty("viewTransitionName")?n.viewTransitionName:n.hasOwnProperty("view-transition-name")?n["view-transition-name"]:null:null;t.viewTransitionName=a==null||typeof a=="boolean"?"":(""+a).trim(),a=n!=null?n.hasOwnProperty("viewTransitionClass")?n.viewTransitionClass:n.hasOwnProperty("view-transition-class")?n["view-transition-class"]:null:null,t.viewTransitionClass=a==null||typeof a=="boolean"?"":(""+a).trim(),t.display==="inline-block"&&(n==null?t.display=t.margin="":(a=n.display,t.display=a==null||typeof a=="boolean"?"":a,a=n.margin,a!=null?t.margin=a:(a=n.hasOwnProperty("marginTop")?n.marginTop:n["margin-top"],t.marginTop=a==null||typeof a=="boolean"?"":a,n=n.hasOwnProperty("marginBottom")?n.marginBottom:n["margin-bottom"],t.marginBottom=n==null||typeof n=="boolean"?"":n)))}function JM(t,n,a){return a=a.ownerDocument.defaultView,{rect:t,abs:n.position==="absolute"||n.position==="fixed",clip:n.clipPath!=="none"||n.overflow!=="visible"||n.filter!=="none"||n.mask!=="none"||n.mask!=="none"||n.borderRadius!=="0px",view:0<=t.bottom&&0<=t.right&&t.top<=a.innerHeight&&t.left<=a.innerWidth}}function nd(t){var n=t.getBoundingClientRect(),a=getComputedStyle(t);return JM(n,a,t)}function $M(t){return t.documentElement.clientHeight}function tE(t){this.addEventListener("load",t),this.addEventListener("error",t)}function eE(t,n,a,s,u,f,v,T,P){var W=n.nodeType===9?n:n.ownerDocument;try{var ot=W.startViewTransition({update:function(){var q=W.defaultView,nt=q.navigation&&q.navigation.transition,Pt=W.fonts.status;s();var jt=[];if(Pt==="loaded"&&($M(W),W.fonts.status==="loading"&&jt.push(W.fonts.ready)),Pt=jt.length,t!==null)for(var pe=t.suspenseyImages,Y=0,V=0;V<pe.length;V++){var tt=pe[V];if(!tt.complete){var pt=tt.getBoundingClientRect();if(0<pt.bottom&&0<pt.right&&pt.top<q.innerHeight&&pt.left<q.innerWidth){if(Y+=m0(tt),Y>ju){jt.length=Pt;break}tt=new Promise(tE.bind(tt)),jt.push(tt)}}}if(0<jt.length)return q=Promise.race([Promise.all(jt),new Promise(function(Xt){return setTimeout(Xt,500)})]).then(u,u),(nt?Promise.allSettled([nt.finished,q]):q).then(f,f);if(u(),nt)return nt.finished.then(f,f);f()},types:a});W.__reactViewTransition=ot;var gt=[];return ot.ready.then(function(){for(var q=W.documentElement.getAnimations({subtree:!0}),nt=0;nt<q.length;nt++){var Pt=q[nt],jt=Pt.effect,pe=jt.pseudoElement;if(pe!=null&&pe.startsWith("::view-transition")){gt.push(Pt),Pt=jt.getKeyframes();for(var Y=pe=void 0,V=!0,tt=0;tt<Pt.length;tt++){var pt=Pt[tt],Xt=pt.width;if(pe===void 0)pe=Xt;else if(pe!==Xt){V=!1;break}if(Xt=pt.height,Y===void 0)Y=Xt;else if(Y!==Xt){V=!1;break}delete pt.width,delete pt.height,pt.transform==="none"&&delete pt.transform}V&&pe!==void 0&&Y!==void 0&&(jt.setKeyframes(Pt),V=getComputedStyle(jt.target,jt.pseudoElement),V.width!==pe||V.height!==Y)&&(V=Pt[0],V.width=pe,V.height=Y,V=Pt[Pt.length-1],V.width=pe,V.height=Y,jt.setKeyframes(Pt))}}v()},function(q){W.__reactViewTransition===ot&&(W.__reactViewTransition=null);try{typeof q=="object"&&q!==null&&q.name==="InvalidStateError"&&(q.message==="View transition was skipped because document visibility state is hidden."||q.message==="Skipping view transition because document visibility state has become hidden."||q.message==="Skipping view transition because viewport size changed."||q.message==="Transition was aborted because of invalid state")&&(q=null),q!==null&&P(q)}finally{s(),u(),v()}}),ot.finished.finally(function(){for(var q=0;q<gt.length;q++)gt[q].cancel();W.__reactViewTransition===ot&&(W.__reactViewTransition=null),T()}),ot}catch{return s(),u(),v(),null}}function Hr(t,n){this._scope=document.documentElement,this._selector="::view-transition-"+t+"("+n+")"}Hr.prototype.animate=function(t,n){return n=typeof n=="number"?{duration:n}:L({},n),n.pseudoElement=this._selector,this._scope.animate(t,n)},Hr.prototype.getAnimations=function(){for(var t=this._scope,n=this._selector,a=t.getAnimations({subtree:!0}),s=[],u=0;u<a.length;u++){var f=a[u].effect;f!==null&&f.target===t&&f.pseudoElement===n&&s.push(a[u])}return s},Hr.prototype.getComputedStyle=function(){return getComputedStyle(this._scope,this._selector)};function Zv(t){return{name:t,group:new Hr("group",t),imagePair:new Hr("image-pair",t),old:new Hr("old",t),new:new Hr("new",t)}}function oi(t){this._fragmentFiber=t,this._observers=this._eventListeners=null}oi.prototype.addEventListener=function(t,n,a){var s=null,u=null;if(!(a!=null&&typeof a!="boolean"&&(s=a.signal||null,s!==null&&s.aborted))){this._eventListeners===null&&(this._eventListeners=[]);var f=this._eventListeners;if(Qv(f,t,n,a)===-1){var v=this,T=n;a!=null&&typeof a!="boolean"&&a.once===!0&&(T=function(P){v.removeEventListener(t,n,a),typeof n=="function"?n.call(this,P):n.handleEvent(P)}),s!==null&&(u=v.removeEventListener.bind(v,t,n,a),s.addEventListener("abort",u,{once:!0}),u=s.removeEventListener.bind(s,"abort",u)),s=Os(a),f.push({type:t,listener:n,optionsOrUseCapture:a,attachedListener:T,cleanup:u}),p(this._fragmentFiber.child,!1,nE,t,T,s)}this._eventListeners=f}};function nE(t,n,a,s){return y(t).addEventListener(n,a,s),!1}oi.prototype.removeEventListener=function(t,n,a){var s=this._eventListeners;if(s!==null&&(n=Qv(s,t,n,a),n!==-1)){var u=s[n];a=u.attachedListener;var f=u.cleanup;u=Os(u.optionsOrUseCapture),p(this._fragmentFiber.child,!1,iE,t,a,u),s.splice(n,1),f!==null&&f()}};function iE(t,n,a,s){return y(t).removeEventListener(n,a,s),!1}function Os(t){return t!=null&&typeof t!="boolean"&&(t.once===!0||t.signal instanceof AbortSignal)?{capture:t.capture,passive:t.passive}:t}function Kv(t){return t==null?"c=0":typeof t=="boolean"?"c="+(t?"1":"0"):"c="+(t.capture?"1":"0")}function Qv(t,n,a,s){if(t.length===0)return-1;s=Kv(s);for(var u=0;u<t.length;u++){var f=t[u];if(f.type===n&&f.listener===a&&Kv(f.optionsOrUseCapture)===s)return u}return-1}oi.prototype.dispatchEvent=function(t){var n=x(this._fragmentFiber);if(n===null)return!0;n=y(n);var a=this._eventListeners;if(a!==null&&0<a.length||!t.bubbles){var s=n.nodeType===9?n.createComment(""):document.createTextNode("");if(a)for(var u=0;u<a.length;u++){var f=a[u];s.addEventListener(f.type,f.attachedListener,Os(f.optionsOrUseCapture))}if(n.appendChild(s),t=s.dispatchEvent(t),a)for(u=0;u<a.length;u++)f=a[u],s.removeEventListener(f.type,f.attachedListener,Os(f.optionsOrUseCapture));return n.removeChild(s),t}return n.dispatchEvent(t)},oi.prototype.focus=function(t){p(this._fragmentFiber.child,!0,Jv,t,void 0,void 0)};function Jv(t,n){return t.tag===6?!1:(t=y(t),mE(t,n))}oi.prototype.focusLast=function(t){var n=[];p(this._fragmentFiber.child,!0,id,n,void 0,void 0);for(var a=n.length-1;0<=a&&!Jv(n[a],t);a--);};function id(t,n){return n.push(t),!1}oi.prototype.blur=function(){var t=x(this._fragmentFiber);t!==null&&(t=y(t),t=nl(t).activeElement,t!==null&&p(this._fragmentFiber.child,!1,aE,t,void 0,void 0))};function aE(t,n){return t.tag===6?!1:(t=y(t),t===n||t.contains(n)?(n.blur(),!0):!1)}oi.prototype.observeUsing=function(t){this._observers===null&&(this._observers=new Set),this._observers.add(t),p(this._fragmentFiber.child,!1,rE,t,void 0,void 0)};function rE(t,n){return t.tag===6||(t=y(t),n.observe(t)),!1}oi.prototype.unobserveUsing=function(t){var n=this._observers;if(n!==null&&n.has(t)){n.delete(t),p(this._fragmentFiber.child,!1,sE,t,void 0,void 0);for(var a=n=0;a<Di.length;a++){var s=Di[a];s.fragmentInstance===this&&s.observer===t?t.unobserve(s.instance):Di[n++]=s}Di.length=n}};function sE(t,n){return t.tag===6||(t=y(t),n.unobserve(t)),!1}var Di=[],ad=!1;function oE(t,n,a){Di.push({fragmentInstance:t,observer:n,instance:a}),ad||(ad=!0,gE(function(){ad=!1;var s=Di;Di=[];for(var u=0;u<s.length;u++){var f=s[u];f.observer.unobserve(f.instance)}}))}oi.prototype.getClientRects=function(){var t=[];return p(this._fragmentFiber.child,!1,lE,t,void 0,void 0),t};function lE(t,n){if(t.tag===6){t=t.stateNode;var a=t.ownerDocument.createRange();a.selectNodeContents(t),n.push.apply(n,a.getClientRects())}else t=y(t),n.push.apply(n,t.getClientRects());return!1}oi.prototype.getRootNode=function(t){var n=x(this._fragmentFiber);return n===null?this:y(n).getRootNode(t)},oi.prototype.compareDocumentPosition=function(t){var n=x(this._fragmentFiber);if(n===null)return Node.DOCUMENT_POSITION_DISCONNECTED;var a=[];p(this._fragmentFiber.child,!1,id,a,void 0,void 0);var s=y(n);if(a.length===0){if(a=s,M(this._fragmentFiber)){t:{for(n=this._fragmentFiber.return;n!==null;){if(n.tag===4){n=n.stateNode.containerInfo;break t}if(n.tag===3||n.tag===5||n.tag===27)break;n=n.return}n=null}n!=null&&(a=n)}n=this._fragmentFiber;var u=s=a.compareDocumentPosition(t);return a===t?u=Node.DOCUMENT_POSITION_CONTAINS:s&Node.DOCUMENT_POSITION_CONTAINED_BY&&(a=E(n)[1],a===null?u=Node.DOCUMENT_POSITION_PRECEDING:(t=y(a).compareDocumentPosition(t),u=t===0||t&Node.DOCUMENT_POSITION_FOLLOWING?Node.DOCUMENT_POSITION_FOLLOWING:Node.DOCUMENT_POSITION_PRECEDING)),u|=Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC}n=y(a[0]),u=y(a[a.length-1]);var f=M(this._fragmentFiber)?n.parentElement:s;if(f==null)return Node.DOCUMENT_POSITION_DISCONNECTED;s=f.compareDocumentPosition(n)&Node.DOCUMENT_POSITION_CONTAINED_BY,f=f.compareDocumentPosition(u)&Node.DOCUMENT_POSITION_CONTAINED_BY;var v=n.compareDocumentPosition(t),T=u.compareDocumentPosition(t),P=v&Node.DOCUMENT_POSITION_CONTAINED_BY||T&Node.DOCUMENT_POSITION_CONTAINED_BY;return T=s&&f&&v&Node.DOCUMENT_POSITION_FOLLOWING&&T&Node.DOCUMENT_POSITION_PRECEDING,n=s&&n===t||f&&u===t||P||T?Node.DOCUMENT_POSITION_CONTAINED_BY:!s&&n===t||!f&&u===t?Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC:v,n&Node.DOCUMENT_POSITION_DISCONNECTED||n&Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC||uE(n,this._fragmentFiber,a[0],a[a.length-1],t)?n:Node.DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC};function uE(t,n,a,s,u){var f=Ie(u);if(t&Node.DOCUMENT_POSITION_CONTAINED_BY){if(a=!!f)t:{for(;f!==null;){if(f.tag===7&&(f===n||f.alternate===n)){a=!0;break t}f=f.return}a=!1}return a}if(t&Node.DOCUMENT_POSITION_CONTAINS){if(f===null)return f=u.ownerDocument,u===f||u===f.documentElement||u===f.body;t:{for(f=n,n=x(n);f!==null;){if(!(f.tag!==5&&f.tag!==3&&f.tag!==27||f!==n&&f.alternate!==n)){f=!0;break t}f=f.return}f=!1}return f}return t&Node.DOCUMENT_POSITION_PRECEDING?((n=!!f)&&!(n=f===a)&&(n=z(a,f,I),n===null?n=!1:(p(n,!0,N,f,a),f=S,S=null,n=f!==null)),n):t&Node.DOCUMENT_POSITION_FOLLOWING?((n=!!f)&&!(n=f===s)&&(n=z(s,f,I),n===null?n=!1:(p(n,!0,D,f,s),f=S,U=S=null,n=f!==null)),n):!1}function $v(t,n){var a=t.ownerDocument.createRange();a.selectNodeContents(t),t=a.getBoundingClientRect(),window.scrollTo(window.scrollX+t.left,n?window.scrollY+t.top:window.scrollY+t.bottom-window.innerHeight)}oi.prototype.scrollIntoView=function(t){if(typeof t=="object")throw Error(r(566));var n=[];p(this._fragmentFiber.child,!1,id,n,void 0,void 0);var a=t!==!1;if(n.length===0){var s=E(this._fragmentFiber);if(s=a?s[1]||s[0]||x(this._fragmentFiber):s[0]||s[1],s===null)return;if(s.tag===6){t=y(s),$v(t,a);return}if(s=y(s),s.nodeType!==9){if(s.nodeType===11){a="host"in s?s.host:null,a!==null&&a.scrollIntoView(t);return}s.scrollIntoView(t)}}for(s=a?n.length-1:0;s!==(a?-1:n.length);){var u=n[s];u.tag===6?(u=y(u),$v(u,a)):y(u).scrollIntoView(t),s+=a?-1:1}};function cE(t,n){return t=y(t),t0(t,n),!1}function t0(t,n){t.reactFragments==null&&(t.reactFragments=new Set),t.reactFragments.add(n)}function e0(t,n){var a=n._eventListeners;if(a!==null)for(var s=0;s<a.length;s++){var u=a[s];t.addEventListener(u.type,u.attachedListener,Os(u.optionsOrUseCapture))}t.nodeType!==3&&(a=n._observers,a!==null&&a.forEach(function(f){for(var v=0,T=0;T<Di.length;T++){var P=Di[T];(P.fragmentInstance!==n||P.observer!==f||P.instance!==t)&&(Di[v++]=P)}Di.length=v,f.observe(t)}),t0(t,n))}function fE(t,n){var a=n._eventListeners;if(a!==null)for(var s=0;s<a.length;s++){var u=a[s];t.removeEventListener(u.type,u.attachedListener,Os(u.optionsOrUseCapture))}t.nodeType!==3&&(a=n._observers,a!==null&&a.forEach(function(f){typeof f.rootMargin=="string"?oE(n,f,t):f.unobserve(t)}),t.reactFragments!=null&&t.reactFragments.delete(n))}function rd(t){var n=t.firstChild;for(n&&n.nodeType===10&&(n=n.nextSibling);n;){var a=n;switch(n=n.nextSibling,a.nodeName){case"HTML":case"HEAD":case"BODY":rd(a),ne(a);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(a.rel.toLowerCase()==="stylesheet")continue}t.removeChild(a)}}function hE(t,n,a,s){for(;t.nodeType===1;){var u=a;if(t.nodeName.toLowerCase()!==n.toLowerCase()){if(!s&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(s){if(!t[ze])switch(n){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(f=t.getAttribute("rel"),f==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(f!==u.rel||t.getAttribute("href")!==(u.href==null||u.href===""?null:u.href)||t.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin)||t.getAttribute("title")!==(u.title==null?null:u.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(f=t.getAttribute("src"),(f!==(u.src==null?null:u.src)||t.getAttribute("type")!==(u.type==null?null:u.type)||t.getAttribute("crossorigin")!==(u.crossOrigin==null?null:u.crossOrigin))&&f&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(n==="input"&&t.type==="hidden"){var f=u.name==null?null:""+u.name;if(u.type==="hidden"&&t.getAttribute("name")===f)return t}else return t;if(t=xi(t.nextSibling),t===null)break}return null}function dE(t,n,a){if(n==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!a||(t=xi(t.nextSibling),t===null))return null;return t}function n0(t,n){for(;t.nodeType!==8;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!n||(t=xi(t.nextSibling),t===null))return null;return t}function sd(t){return t.data==="$?"||t.data==="$~"}function od(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState!=="loading"}function pE(t,n){var a=t.ownerDocument;if(t.data==="$~")t._reactRetry=n;else if(t.data!=="$?"||a.readyState!=="loading")n();else{var s=function(){n(),a.removeEventListener("DOMContentLoaded",s)};a.addEventListener("DOMContentLoaded",s),t._reactRetry=s}}function xi(t){for(;t!=null;t=t.nextSibling){var n=t.nodeType;if(n===1||n===3)break;if(n===8){if(n=t.data,n==="$"||n==="$!"||n==="$?"||n==="$~"||n==="&"||n==="F!"||n==="F")break;if(n==="/$"||n==="/&")return null}}return t}var ld=null;function i0(t){t=t.nextSibling;for(var n=0;t;){if(t.nodeType===8){var a=t.data;if(a==="/$"||a==="/&"){if(n===0)return xi(t.nextSibling);n--}else a!=="$"&&a!=="$!"&&a!=="$?"&&a!=="$~"&&a!=="&"||n++}t=t.nextSibling}return null}function a0(t){t=t.previousSibling;for(var n=0;t;){if(t.nodeType===8){var a=t.data;if(a==="$"||a==="$!"||a==="$?"||a==="$~"||a==="&"){if(n===0)return t;n--}else a!=="/$"&&a!=="/&"||n++}t=t.previousSibling}return null}function mE(t,n){function a(){s=!0}if(t.ownerDocument.activeElement===t)return!0;var s=!1;try{t.ownerDocument.addEventListener("focus",a,!0),(t.focus||HTMLElement.prototype.focus).call(t,n)}finally{t.ownerDocument.removeEventListener("focus",a,!0)}return s}function gE(t){kv(function(){kv(function(n){return t(n)})})}function r0(t,n,a){switch(n=nl(a),t){case"html":if(t=n.documentElement,!t)throw Error(r(452));return t;case"head":if(t=n.head,!t)throw Error(r(453));return t;case"body":if(t=n.body,!t)throw Error(r(454));return t;default:throw Error(r(451))}}function s0(t,n,a){for(var s in a){var u=a[s];a.hasOwnProperty(s)&&u!=null&&Xe(t,n,s,null,qM,u)}a.dangerouslySetInnerHTML!=null&&(t.textContent=""),t.onclick===Hi&&(t.onclick=null),ne(t)}function ud(t){for(var n=t.attributes;n.length;)t.removeAttributeNode(n[0]);ne(t)}var yi=new Map,o0=new Set;function il(t){if(typeof t.getRootNode=="function"){var n=t.getRootNode();if(n.nodeType===9||n.nodeType===11)return n}return t.nodeType===9?t:t.ownerDocument}var va=kt.d;kt.d={f:_E,r:vE,D:xE,C:yE,L:SE,m:ME,X:TE,S:EE,M:bE};function _E(){var t=va.f(),n=Fu();return t||n}function vE(t){var n=_e(t);n!==null&&n.tag===5&&n.type==="form"?u_(n):va.r(t)}var Ps=typeof document>"u"?null:document;function l0(t,n,a){var s=Ps;if(s&&typeof n=="string"&&n){var u=hi(n);u='link[rel="'+t+'"][href="'+u+'"]',typeof a=="string"&&(u+='[crossorigin="'+a+'"]'),o0.has(u)||(o0.add(u),t={rel:t,crossOrigin:a,href:n},s.querySelector(u)===null&&(n=s.createElement("link"),Dn(n,"link",t),Ne(n),s.head.appendChild(n)))}}function xE(t){va.D(t),l0("dns-prefetch",t,null)}function yE(t,n){va.C(t,n),l0("preconnect",t,n)}function SE(t,n,a){va.L(t,n,a);var s=Ps;if(s&&t&&n){var u='link[rel="preload"][as="'+hi(n)+'"]';n==="image"&&a&&a.imageSrcSet?(u+='[imagesrcset="'+hi(a.imageSrcSet)+'"]',typeof a.imageSizes=="string"&&(u+='[imagesizes="'+hi(a.imageSizes)+'"]')):u+='[href="'+hi(t)+'"]';var f=u;switch(n){case"style":f=zs(t);break;case"script":f=Is(t)}if(!(yi.has(f)||(t=L({rel:"preload",href:n==="image"&&a&&a.imageSrcSet?void 0:t,as:n},a),yi.set(f,t),s.querySelector(u)!==null||n==="style"&&s.querySelector(al(f))||n==="script"&&s.querySelector(rl(f))))){var v=s.createElement("link");Dn(v,"link",t),n==="style"&&(v[Ue]=!0,v.onload=v.onerror=function(){Na(v)}),Ne(v),s.head.appendChild(v)}}}function ME(t,n){va.m(t,n);var a=Ps;if(a&&t){var s=n&&typeof n.as=="string"?n.as:"script",u='link[rel="modulepreload"][as="'+hi(s)+'"][href="'+hi(t)+'"]',f=u;switch(s){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":f=Is(t)}if(!yi.has(f)&&(t=L({rel:"modulepreload",href:t},n),yi.set(f,t),a.querySelector(u)===null)){switch(s){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(a.querySelector(rl(f)))return}s=a.createElement("link"),Dn(s,"link",t),Ne(s),a.head.appendChild(s)}}}function EE(t,n,a){va.S(t,n,a);var s=Ps;if(s&&t){var u=$n(s).hoistableStyles,f=zs(t);n=n||"default";var v=u.get(f);if(!v){var T={loading:0,preload:null};if(v=s.querySelector(al(f)))T.loading=5;else{t=L({rel:"stylesheet",href:t,"data-precedence":n},a),(a=yi.get(f))&&cd(t,a);var P=v=s.createElement("link");Ne(P),Dn(P,"link",t),P._p=new Promise(function(W,ot){P.onload=W,P.onerror=ot}),P.addEventListener("load",function(){T.loading|=1}),P.addEventListener("error",function(){T.loading|=2}),T.loading|=4,Yu(v,n,s)}v={type:"stylesheet",instance:v,count:1,state:T},u.set(f,v)}}}function TE(t,n){va.X(t,n);var a=Ps;if(a&&t){var s=$n(a).hoistableScripts,u=Is(t),f=s.get(u);f||(f=a.querySelector(rl(u)),f||(t=L({src:t,async:!0},n),(n=yi.get(u))&&fd(t,n),f=a.createElement("script"),Ne(f),Dn(f,"link",t),a.head.appendChild(f)),f={type:"script",instance:f,count:1,state:null},s.set(u,f))}}function bE(t,n){va.M(t,n);var a=Ps;if(a&&t){var s=$n(a).hoistableScripts,u=Is(t),f=s.get(u);f||(f=a.querySelector(rl(u)),f||(t=L({src:t,async:!0,type:"module"},n),(n=yi.get(u))&&fd(t,n),f=a.createElement("script"),Ne(f),Dn(f,"link",t),a.head.appendChild(f)),f={type:"script",instance:f,count:1,state:null},s.set(u,f))}}function u0(t,n,a,s){var u=(u=le.current)?il(u):null;if(!u)throw Error(r(446));switch(t){case"meta":case"title":return null;case"style":return typeof a.precedence=="string"&&typeof a.href=="string"?(a=zs(a.href),n=$n(u).hoistableStyles,s=n.get(a),s||(s={type:"style",instance:null,count:0,state:null},n.set(a,s)),s):{type:"void",instance:null,count:0,state:null};case"link":if(a.rel==="stylesheet"&&typeof a.href=="string"&&typeof a.precedence=="string"){t=zs(a.href);var f=$n(u).hoistableStyles,v=f.get(t);if(v||(u=u.ownerDocument||u,v={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},f.set(t,v),(f=u.querySelector(al(t)))?f._p||(v.instance=f,v.state.loading=5):(f=yi.get(t),f||(f={rel:"preload",as:"style",href:a.href,crossOrigin:a.crossOrigin,integrity:a.integrity,media:a.media,hrefLang:a.hrefLang,referrerPolicy:a.referrerPolicy},yi.set(t,f)),AE(u,t,f,v.state))),n&&s===null)throw Error(r(528,""));return v}if(n&&s!==null)throw Error(r(529,""));return null;case"script":return n=a.async,a=a.src,typeof a=="string"&&n&&typeof n!="function"&&typeof n!="symbol"?(a=Is(a),n=$n(u).hoistableScripts,s=n.get(a),s||(s={type:"script",instance:null,count:0,state:null},n.set(a,s)),s):{type:"void",instance:null,count:0,state:null};default:throw Error(r(444,t))}}function zs(t){return'href="'+hi(t)+'"'}function al(t){return'link[rel="stylesheet"]['+t+"]"}function c0(t){return L({},t,{"data-precedence":t.precedence,precedence:null})}function AE(t,n,a,s){if(n=t.querySelector('link[rel="preload"][as="style"]['+n+"]")){if(n[Ue]!==!0){s.loading=1;return}}else n=t.createElement("link"),n[Ue]=!0,n.onload=n.onerror=Na.bind(null,n),Dn(n,"link",a),Ne(n),t.head.appendChild(n);s.preload=n,n.addEventListener("load",function(){return s.loading|=1}),n.addEventListener("error",function(){return s.loading|=2})}function Is(t){return'[src="'+hi(t)+'"]'}function rl(t){return"script[async]"+t}function f0(t,n,a){if(n.count++,n.instance===null)switch(n.type){case"style":var s=t.querySelector('style[data-href~="'+hi(a.href)+'"]');if(s)return n.instance=s,Ne(s),s;var u=L({},a,{"data-href":a.href,"data-precedence":a.precedence,href:null,precedence:null});return s=(t.ownerDocument||t).createElement("style"),Ne(s),Dn(s,"style",u),Yu(s,a.precedence,t),n.instance=s;case"stylesheet":u=zs(a.href);var f=t.querySelector(al(u));if(f)return n.state.loading|=4,n.instance=f,Ne(f),f;s=c0(a),(u=yi.get(u))&&cd(s,u),f=(t.ownerDocument||t).createElement("link"),Ne(f);var v=f;return v._p=new Promise(function(T,P){v.onload=T,v.onerror=P}),Dn(f,"link",s),n.state.loading|=4,Yu(f,a.precedence,t),n.instance=f;case"script":return f=Is(a.src),(u=t.querySelector(rl(f)))?(n.instance=u,Ne(u),u):(s=a,(u=yi.get(f))&&(s=L({},a),fd(s,u)),t=t.ownerDocument||t,u=t.createElement("script"),Ne(u),Dn(u,"link",s),t.head.appendChild(u),n.instance=u);case"void":return null;default:throw Error(r(443,n.type))}else n.type==="stylesheet"&&(n.state.loading&4)===0&&(s=n.instance,n.state.loading|=4,Yu(s,a.precedence,t));return n.instance}function Yu(t,n,a){for(var s=a.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),u=s.length?s[s.length-1]:null,f=u,v=0;v<s.length;v++){var T=s[v];if(T.dataset.precedence===n)f=T;else if(f!==u)break}f?f.parentNode.insertBefore(t,f.nextSibling):(n=a.nodeType===9?a.head:a,n.insertBefore(t,n.firstChild))}function cd(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.title==null&&(t.title=n.title)}function fd(t,n){t.crossOrigin==null&&(t.crossOrigin=n.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=n.referrerPolicy),t.integrity==null&&(t.integrity=n.integrity)}var Wu=null;function h0(t,n,a){if(Wu===null){var s=new Map,u=Wu=new Map;u.set(a,s)}else u=Wu,s=u.get(a),s||(s=new Map,u.set(a,s));if(s.has(t))return s;for(s.set(t,null),a=a.getElementsByTagName(t),u=0;u<a.length;u++){var f=a[u];if(!(f[ze]||f[Nt]||t==="link"&&f.getAttribute("rel")==="stylesheet")&&f.namespaceURI!=="http://www.w3.org/2000/svg"){var v=f.getAttribute(n)||"";v=t+v;var T=s.get(v);T?T.push(f):s.set(v,[f])}}return s}function hd(t,n,a){t=t.ownerDocument||t,t.head.insertBefore(a,n==="title"?t.querySelector("head > title"):null)}function RE(t,n,a){if(a===1||n.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof n.precedence!="string"||typeof n.href!="string"||n.href==="")break;return!0;case"link":if(typeof n.rel!="string"||typeof n.href!="string"||n.href===""||n.onLoad||n.onError)break;return n.rel==="stylesheet"?(t=n.disabled,typeof n.precedence=="string"&&t==null):!0;case"script":if(n.async&&typeof n.async!="function"&&typeof n.async!="symbol"&&!n.onLoad&&!n.onError&&n.src&&typeof n.src=="string")return!0}return!1}function d0(t,n){return t==="img"&&n.src!=null&&n.src!==""&&n.onLoad==null&&n.loading!=="lazy"}function p0(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}function m0(t){return(t.width||100)*(t.height||100)*(typeof devicePixelRatio=="number"?devicePixelRatio:1)*.25}function g0(t,n){typeof n.decode=="function"&&(t.imgCount++,n.complete||(t.imgBytes+=m0(n),t.suspenseyImages.push(n)),t=DE.bind(t),n.decode().then(t,t))}function CE(t,n,a,s){if(a.type==="stylesheet"&&(typeof s.media!="string"||matchMedia(s.media).matches!==!1)&&(a.state.loading&4)===0){if(a.instance===null){var u=zs(s.href),f=n.querySelector(al(u));if(f){n=f._p,n!==null&&typeof n=="object"&&typeof n.then=="function"&&(t.count++,t=sl.bind(t),n.then(t,t)),a.state.loading|=4,a.instance=f,Ne(f);return}f=n.ownerDocument||n,s=c0(s),(u=yi.get(u))&&cd(s,u),f=f.createElement("link"),Ne(f);var v=f;v._p=new Promise(function(T,P){v.onload=T,v.onerror=P}),Dn(f,"link",s),a.instance=f}t.stylesheets===null&&(t.stylesheets=new Map),t.stylesheets.set(a,n),(n=a.state.preload)&&(a.state.loading&3)===0&&(t.count++,a=sl.bind(t),n.addEventListener("load",a),n.addEventListener("error",a))}}var ju=0;function wE(t,n){return t.stylesheets&&t.count===0&&Ku(t,t.stylesheets),0<t.count||0<t.imgCount?function(a){var s=setTimeout(function(){if(t.stylesheets&&Ku(t,t.stylesheets),t.unsuspend){var f=t.unsuspend;t.unsuspend=null,f()}},6e4+n);0<t.imgBytes&&ju===0&&(ju=62500*WM());var u=setTimeout(function(){if(t.waitingForImages=!1,t.count===0&&(t.stylesheets&&Ku(t,t.stylesheets),t.unsuspend)){var f=t.unsuspend;t.unsuspend=null,f()}},(t.imgBytes>ju?50:800)+n);return t.unsuspend=a,function(){t.unsuspend=null,clearTimeout(s),clearTimeout(u)}}:null}function _0(t){if(t.count===0&&(t.imgCount===0||!t.waitingForImages)){if(t.stylesheets)Ku(t,t.stylesheets);else if(t.unsuspend){var n=t.unsuspend;t.unsuspend=null,n()}}}function sl(){this.count--,_0(this)}function DE(){this.imgCount--,_0(this)}var Zu=null;function Ku(t,n){t.stylesheets=null,t.unsuspend!==null&&(t.count++,Zu=new Map,n.forEach(UE,t),Zu=null,sl.call(t))}function UE(t,n){if(!(n.state.loading&4)){var a=Zu.get(t);if(a)var s=a.get(null);else{a=new Map,Zu.set(t,a);for(var u=t.querySelectorAll("link[data-precedence],style[data-precedence]"),f=0;f<u.length;f++){var v=u[f];(v.nodeName==="LINK"||v.getAttribute("media")!=="not all")&&(a.set(v.dataset.precedence,v),s=v)}s&&a.set(null,s)}u=n.instance,v=u.getAttribute("data-precedence"),f=a.get(v)||s,f===s&&a.set(null,u),a.set(v,u),this.count++,s=sl.bind(this),u.addEventListener("load",s),u.addEventListener("error",s),f?f.parentNode.insertBefore(u,f.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(u,t.firstChild)),n.state.loading|=4}}var Bs={$$typeof:st,Provider:null,Consumer:null,_currentValue:F,_currentValue2:F,_threadCount:0};function NE(t,n,a,s,u,f,v,T,P){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=So(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=So(0),this.hiddenUpdates=So(null),this.identifierPrefix=s,this.onUncaughtError=u,this.onCaughtError=f,this.onRecoverableError=v,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=P,this.transitionTypes=null,this.incompleteTransitions=new Map}function v0(t,n,a,s,u,f,v,T,P,W,ot,gt){return t=new NE(t,n,a,v,P,W,ot,gt,T),n=1,f===!0&&(n|=24),f=qn(3,null,null,n),t.current=f,f.stateNode=t,n=Rf(),n.refCount++,t.pooledCache=n,n.refCount++,f.memoizedState={element:s,isDehydrated:a,cache:n},Uf(f),t}function x0(t){return t?(t=cs,t):cs}function y0(t,n,a,s,u,f){u=x0(u),s.context===null?s.context=u:s.pendingContext=u,s=Ga(n),s.payload={element:a},f=f===void 0?null:f,f!==null&&(s.callback=f),a=Va(t,s,n),a!==null&&(Zn(a,t,n),Io(a,t,n))}function S0(t,n){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var a=t.retryLane;t.retryLane=a!==0&&a<n?a:n}}function dd(t,n){S0(t,n),(t=t.alternate)&&S0(t,n)}function M0(t){if(t.tag===13||t.tag===31){var n=Er(t,67108864);n!==null&&Zn(n,t,67108864),dd(t,67108864)}}function E0(t){if(t.tag===13||t.tag===31){var n=si();n=ut(n);var a=Er(t,n);a!==null&&Zn(a,t,n),dd(t,n)}}var Fs=!0;function LE(t,n,a,s){var u=St.T;St.T=null;var f=kt.p;try{kt.p=2,pd(t,n,a,s)}finally{kt.p=f,St.T=u}}function OE(t,n,a,s){var u=St.T;St.T=null;var f=kt.p;try{kt.p=8,pd(t,n,a,s)}finally{kt.p=f,St.T=u}}function pd(t,n,a,s){if(Fs){var u=md(s);if(u===null)Zh(t,n,s,Qu,a),b0(t,s);else if(zE(u,t,n,a,s))s.stopPropagation();else if(b0(t,s),n&4&&-1<PE.indexOf(t)){for(;u!==null;){var f=_e(u);if(f!==null)switch(f.tag){case 3:if(f=f.stateNode,f.current.memoizedState.isDehydrated){var v=fi(f.pendingLanes);if(v!==0){var T=f;for(T.pendingLanes|=2,T.entangledLanes|=2;v;){var P=1<<31-Ln(v);T.entanglements[1]|=P,v&=~P}Ki(f),(Be&6)===0&&(zu=X()+500,$o(0))}}break;case 31:case 13:T=Er(f,2),T!==null&&Zn(T,f,2),Fu(),dd(f,2)}if(f=md(s),f===null&&Zh(t,n,s,Qu,a),f===u)break;u=f}u!==null&&s.stopPropagation()}else Zh(t,n,s,null,a)}}function md(t){return t=$c(t),gd(t)}var Qu=null;function gd(t){if(Qu=null,t=Ie(t),t!==null){var n=c(t);if(n===null)t=null;else{var a=n.tag;if(a===13){if(t=h(n),t!==null)return t;t=null}else if(a===31){if(t=d(n),t!==null)return t;t=null}else if(a===3){if(n.stateNode.current.memoizedState.isDehydrated)return n.tag===3?n.stateNode.containerInfo:null;t=null}else n!==t&&(t=null)}}return Qu=t,null}function T0(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"fullscreenerror":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"resize":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(wt()){case Lt:return 2;case qt:return 8;case bt:case yt:return 32;case Zt:return 268435456;default:return 32}default:return 32}}var _d=!1,tr=null,er=null,nr=null,ol=new Map,ll=new Map,ir=[],PE="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function b0(t,n){switch(t){case"focusin":case"focusout":tr=null;break;case"dragenter":case"dragleave":er=null;break;case"mouseover":case"mouseout":nr=null;break;case"pointerover":case"pointerout":ol.delete(n.pointerId);break;case"gotpointercapture":case"lostpointercapture":ll.delete(n.pointerId)}}function ul(t,n,a,s,u,f){return t===null||t.nativeEvent!==f?(t={blockedOn:n,domEventName:a,eventSystemFlags:s,nativeEvent:f,targetContainers:[u]},n!==null&&(n=_e(n),n!==null&&M0(n)),t):(t.eventSystemFlags|=s,n=t.targetContainers,u!==null&&n.indexOf(u)===-1&&n.push(u),t)}function zE(t,n,a,s,u){switch(n){case"focusin":return tr=ul(tr,t,n,a,s,u),!0;case"dragenter":return er=ul(er,t,n,a,s,u),!0;case"mouseover":return nr=ul(nr,t,n,a,s,u),!0;case"pointerover":var f=u.pointerId;return ol.set(f,ul(ol.get(f)||null,t,n,a,s,u)),!0;case"gotpointercapture":return f=u.pointerId,ll.set(f,ul(ll.get(f)||null,t,n,a,s,u)),!0}return!1}function A0(t){var n=Ie(t.target);if(n!==null){var a=c(n);if(a!==null){if(n=a.tag,n===13){if(n=h(a),n!==null){t.blockedOn=n,Bt(t.priority,function(){E0(a)});return}}else if(n===31){if(n=d(a),n!==null){t.blockedOn=n,Bt(t.priority,function(){E0(a)});return}}else if(n===3&&a.stateNode.current.memoizedState.isDehydrated){t.blockedOn=a.tag===3?a.stateNode.containerInfo:null;return}}}t.blockedOn=null}function Ju(t){if(t.blockedOn!==null)return!1;for(var n=t.targetContainers;0<n.length;){var a=md(t.nativeEvent);if(a===null){a=t.nativeEvent;var s=new a.constructor(a.type,a);Jc=s,a.target.dispatchEvent(s),Jc=null}else return n=_e(a),n!==null&&M0(n),t.blockedOn=a,!1;n.shift()}return!0}function R0(t,n,a){Ju(t)&&a.delete(n)}function IE(){_d=!1,tr!==null&&Ju(tr)&&(tr=null),er!==null&&Ju(er)&&(er=null),nr!==null&&Ju(nr)&&(nr=null),ol.forEach(R0),ll.forEach(R0)}function $u(t,n){t.blockedOn===n&&(t.blockedOn=null,_d||(_d=!0,o.unstable_scheduleCallback(o.unstable_NormalPriority,IE)))}var tc=null;function C0(t){tc!==t&&(tc=t,o.unstable_scheduleCallback(o.unstable_NormalPriority,function(){tc===t&&(tc=null);for(var n=0;n<t.length;n+=3){var a=t[n],s=t[n+1],u=t[n+2];if(typeof s!="function"){if(gd(s||a)===null)continue;break}var f=_e(a);f!==null&&(t.splice(n,3),n-=3,Jf(f,{pending:!0,data:u,method:a.method,action:s},s,u))}}))}function Hs(t){function n(P){return $u(P,t)}tr!==null&&$u(tr,t),er!==null&&$u(er,t),nr!==null&&$u(nr,t),ol.forEach(n),ll.forEach(n);for(var a=0;a<ir.length;a++){var s=ir[a];s.blockedOn===t&&(s.blockedOn=null)}for(;0<ir.length&&(a=ir[0],a.blockedOn===null);)A0(a),a.blockedOn===null&&ir.shift();if(a=(t.ownerDocument||t).$$reactFormReplay,a!=null)for(s=0;s<a.length;s+=3){var u=a[s],f=a[s+1],v=u[Wt]||null;if(typeof f=="function")v||C0(a);else if(v){var T=null;if(f&&f.hasAttribute("formAction")){if(u=f,v=f[Wt]||null)T=v.formAction;else if(gd(u)!==null)continue}else T=v.action;typeof T=="function"?a[s+1]=T:(a.splice(s,3),s-=3),C0(a)}}}function w0(){function t(f){f.canIntercept&&f.info==="react-transition"&&f.intercept({handler:function(){return new Promise(function(v){return u=v})},focusReset:"manual",scroll:"manual"})}function n(){u!==null&&(u(),u=null),s||setTimeout(a,20)}function a(){if(!s&&!navigation.transition){var f=navigation.currentEntry;f&&f.url!=null&&navigation.navigate(f.url,{state:f.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var s=!1,u=null;return navigation.addEventListener("navigate",t),navigation.addEventListener("navigatesuccess",n),navigation.addEventListener("navigateerror",n),setTimeout(a,100),function(){s=!0,navigation.removeEventListener("navigate",t),navigation.removeEventListener("navigatesuccess",n),navigation.removeEventListener("navigateerror",n),u!==null&&(u(),u=null)}}}function vd(t){this._internalRoot=t}ec.prototype.render=vd.prototype.render=function(t){var n=this._internalRoot;if(n===null)throw Error(r(409));var a=n.current,s=si();y0(a,s,t,n,null,null)},ec.prototype.unmount=vd.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var n=t.containerInfo;y0(t.current,2,null,t,null,null),Fu(),n[ae]=null}};function ec(t){this._internalRoot=t}ec.prototype.unstable_scheduleHydration=function(t){if(t){var n=At();t={blockedOn:null,target:t,priority:n};for(var a=0;a<ir.length&&n!==0&&n<ir[a].priority;a++);ir.splice(a,0,t),a===0&&A0(t)}};var D0=e.version;if(D0!=="19.3.1")throw Error(r(527,D0,"19.3.1"));kt.findDOMNode=function(t){var n=t._reactInternals;if(n===void 0)throw typeof t.render=="function"?Error(r(188)):(t=Object.keys(t).join(","),Error(r(268,t)));return t=g(n),t=t!==null?_(t):null,t=t===null?null:t.stateNode,t};var BE={bundleType:0,version:"19.3.1",rendererPackageName:"react-dom",currentDispatcherRef:St,reconcilerVersion:"19.3.1"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var nc=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!nc.isDisabled&&nc.supportsFiber)try{Ae=nc.inject(BE),tn=nc}catch{}}return fl.createRoot=function(t,n){if(!l(t))throw Error(r(299));var a=!1,s="",u=x_,f=y_,v=S_;return n!=null&&(n.unstable_strictMode===!0&&(a=!0),n.identifierPrefix!==void 0&&(s=n.identifierPrefix),n.onUncaughtError!==void 0&&(u=n.onUncaughtError),n.onCaughtError!==void 0&&(f=n.onCaughtError),n.onRecoverableError!==void 0&&(v=n.onRecoverableError)),n=v0(t,1,!1,null,null,a,s,null,u,f,v,w0),t[ae]=n.current,jh(t),new vd(n)},fl.hydrateRoot=function(t,n,a){if(!l(t))throw Error(r(299));var s=!1,u="",f=x_,v=y_,T=S_,P=null;return a!=null&&(a.unstable_strictMode===!0&&(s=!0),a.identifierPrefix!==void 0&&(u=a.identifierPrefix),a.onUncaughtError!==void 0&&(f=a.onUncaughtError),a.onCaughtError!==void 0&&(v=a.onCaughtError),a.onRecoverableError!==void 0&&(T=a.onRecoverableError),a.formState!==void 0&&(P=a.formState)),n=v0(t,1,!0,n,a??null,s,u,P,f,v,T,w0),n.context=x0(null),a=n.current,s=si(),s=ut(s),u=Ga(s),u.callback=null,Va(a,u,s),a=s,n.current.lanes=a,yr(n,a),Ki(n),t[ae]=n.current,jh(t),new ec(n)},fl.version="19.3.1",fl}var H0;function jE(){if(H0)return Sd.exports;H0=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(e){console.error(e)}}return o(),Sd.exports=WE(),Sd.exports}var ZE=jE();var im=/^(?:[a-z][a-z0-9+.-]*:|[\\/]{2})/i,Qx=/^[\\/]{2}/;function KE(o,e){return e+o.replace(/\\/g,"/")}var G0="popstate";function V0(o){return typeof o=="object"&&o!=null&&"pathname"in o&&"search"in o&&"hash"in o&&"state"in o&&"key"in o}function QE(o={}){function e(r,l){let c=l.state?.masked,{pathname:h,search:d,hash:m}=c||r.location;return up("",{pathname:h,search:d,hash:m},l.state&&l.state.usr||null,l.state&&l.state.key||"default",c?{pathname:r.location.pathname,search:r.location.search,hash:r.location.hash}:void 0)}function i(r,l){return typeof l=="string"?l:oo(l)}return $E(e,i,null,o)}function nn(o,e){if(o===!1||o===null||typeof o>"u")throw new Error(e)}function ta(o,e){if(!o){typeof console<"u"&&console.warn(e);try{throw new Error(e)}catch{}}}function JE(){return Math.random().toString(36).substring(2,10)}function X0(o,e){return{usr:o.state,key:o.key,idx:e,masked:o.mask?{pathname:o.pathname,search:o.search,hash:o.hash}:void 0}}function up(o,e,i=null,r,l){return{pathname:typeof o=="string"?o:o.pathname,search:"",hash:"",...typeof e=="string"?mo(e):e,state:i,key:e&&e.key||r||JE(),mask:l}}function oo({pathname:o="/",search:e="",hash:i=""}){return e&&e!=="?"&&(o+=e.charAt(0)==="?"?e:"?"+e),i&&i!=="#"&&(o+=i.charAt(0)==="#"?i:"#"+i),o}function mo(o){let e={};if(o){let i=o.indexOf("#");i>=0&&(e.hash=o.substring(i),o=o.substring(0,i));let r=o.indexOf("?");r>=0&&(e.search=o.substring(r),o=o.substring(0,r)),o&&(e.pathname=o)}return e}function $E(o,e,i,r={}){let{window:l=document.defaultView,v5Compat:c=!1}=r,h=l.history,d="POP",m=null,g=_();g==null&&(g=0,h.replaceState({...h.state,idx:g},""));function _(){return(h.state||{idx:null}).idx}function p(){d="POP";let y=_(),S=y==null?null:y-g;g=y,m&&m({action:d,location:b.location,delta:S})}function x(y,S){d="PUSH";let U=V0(y)?y:up(b.location,y,S);g=_()+1;let N=X0(U,g),D=b.createHref(U.mask||U);try{h.pushState(N,"",D)}catch(I){if(I instanceof DOMException&&I.name==="DataCloneError")throw I;l.location.assign(D)}c&&m&&m({action:d,location:b.location,delta:1})}function M(y,S){d="REPLACE";let U=V0(y)?y:up(b.location,y,S);g=_();let N=X0(U,g),D=b.createHref(U.mask||U);h.replaceState(N,"",D),c&&m&&m({action:d,location:b.location,delta:0})}function E(y){return tT(l,y)}let b={get action(){return d},get location(){return o(l,h)},listen(y){if(m)throw new Error("A history only accepts one active listener");return l.addEventListener(G0,p),m=y,()=>{l.removeEventListener(G0,p),m=null}},createHref(y){return e(l,y)},createURL:E,encodeLocation(y){let S=E(y);return{pathname:S.pathname,search:S.search,hash:S.hash}},push:x,replace:M,go(y){return h.go(y)}};return b}function tT(o,e,i=!1){let r="http://localhost";o&&(r=o.location.origin!=="null"?o.location.origin:o.location.href),nn(r,"No window.location.(origin|href) available to create URL");let l=typeof e=="string"?e:oo(e);return l=l.replace(/ $/,"%20"),!i&&Qx.test(l)&&(l=r+l),new URL(l,r)}function Jx(o,e,i="/"){return eT(o,e,i,!1)}function eT(o,e,i,r,l){let c=typeof e=="string"?mo(e):e,h=Ca(c.pathname||"/",i);if(h==null)return null;let d=nT(o),m=null,g=dT(h);for(let _=0;m==null&&_<d.length;++_)m=hT(d[_],g,r);return m}function nT(o){let e=$x(o);return iT(e),e}function $x(o,e=[],i=[],r="",l=!1){let c=(h,d,m=l,g)=>{let _={relativePath:g===void 0?h.path||"":g,caseSensitive:h.caseSensitive===!0,childrenIndex:d,route:h};if(_.relativePath.startsWith("/")){if(!_.relativePath.startsWith(r)&&m)return;nn(_.relativePath.startsWith(r),`Absolute route path "${_.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`),_.relativePath=_.relativePath.slice(r.length)}let p=zi([r,_.relativePath]),x=i.concat(_);h.children&&h.children.length>0&&(nn(h.index!==!0,`Index routes must not have child routes. Please remove all child routes from route path "${p}".`),$x(h.children,e,x,p,m)),!(h.path==null&&!h.index)&&e.push({path:p,score:cT(p,h.index),routesMeta:x.map((M,E)=>{let[b,y]=ny(M.relativePath,M.caseSensitive,E===x.length-1);return{...M,matcher:b,compiledParams:y}})})};return o.forEach((h,d)=>{if(h.path===""||!h.path?.includes("?"))c(h,d);else for(let m of ty(h.path))c(h,d,!0,m)}),e}function ty(o){let e=o.split("/");if(e.length===0)return[];let[i,...r]=e,l=i.endsWith("?"),c=i.replace(/\?$/,"");if(r.length===0)return l?[c,""]:[c];let h=ty(r.join("/")),d=[];return d.push(...h.map(m=>m===""?c:[c,m].join("/"))),l&&d.push(...h),d.map(m=>o.startsWith("/")&&m===""?"/":m)}function iT(o){o.sort((e,i)=>e.score!==i.score?i.score-e.score:fT(e.routesMeta.map(r=>r.childrenIndex),i.routesMeta.map(r=>r.childrenIndex)))}var aT=/^:[\w-]+$/,rT=3,sT=2,oT=1,lT=10,uT=-2,k0=o=>o==="*";function cT(o,e){let i=o.split("/"),r=i.length;return i.some(k0)&&(r+=uT),e&&(r+=sT),i.filter(l=>!k0(l)).reduce((l,c)=>l+(aT.test(c)?rT:c===""?oT:lT),r)}function fT(o,e){return o.length===e.length&&o.slice(0,-1).every((r,l)=>r===e[l])?o[o.length-1]-e[e.length-1]:0}function hT(o,e,i=!1){let{routesMeta:r}=o,l={},c="/",h=[];for(let d=0;d<r.length;++d){let m=r[d],g=d===r.length-1,_=c==="/"?e:e.slice(c.length)||"/",p={path:m.relativePath,caseSensitive:m.caseSensitive,end:g},x=m.matcher&&m.compiledParams?ey(p,_,m.matcher,m.compiledParams):Oc(p,_),M=m.route;if(!x&&g&&i&&!r[r.length-1].route.index&&(x=Oc({path:m.relativePath,caseSensitive:m.caseSensitive,end:!1},_)),!x)return null;Object.assign(l,x.params),h.push({params:l,pathname:zi([c,x.pathname]),pathnameBase:gT(zi([c,x.pathnameBase])),route:M}),x.pathnameBase!=="/"&&(c=zi([c,x.pathnameBase]))}return h}function Oc(o,e){typeof o=="string"&&(o={path:o,caseSensitive:!1,end:!0});let[i,r]=ny(o.path,o.caseSensitive,o.end);return ey(o,e,i,r)}function ey(o,e,i,r){let l=e.match(i);if(!l)return null;let c=l[0],h=lo(c,1),d=l.slice(1);return{params:r.reduce((g,{paramName:_,isOptional:p},x)=>{if(_==="*"){let E=d[x]||"";h=lo(c.slice(0,c.length-E.length),1)}const M=d[x];return p&&!M?g[_]=void 0:g[_]=(M||"").replace(/%2F/g,"/"),g},{}),pathname:c,pathnameBase:h,pattern:o}}function ny(o,e=!1,i=!0){ta(o==="*"||!o.endsWith("*")||o.endsWith("/*"),`Route path "${o}" will be treated as if it were "${o.replace(/\*$/,"/*")}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${o.replace(/\*$/,"/*")}".`);let r=[],l="^"+o.replace(/\/*\*?$/,"").replace(/^\/*/,"/").replace(/[\\.*+^${}|()[\]]/g,"\\$&").replace(/\/:([\w-]+)(\?)?/g,(h,d,m,g,_)=>{if(r.push({paramName:d,isOptional:m!=null}),m){let p=_.charAt(g+h.length);return p&&p!=="/"?"/([^\\/]*)":"(?:/([^\\/]*))?"}return"/([^\\/]+)"}).replace(/\/([\w-]+)\?(\/|$)/g,"(/$1)?$2");return o.endsWith("*")?(r.push({paramName:"*"}),l+=o==="*"||o==="/*"?"(.*)$":"(?:\\/(.+)|\\/*)$"):i?l+="\\/*$":o!==""&&o!=="/"&&(l+="(?:(?=\\/|$))"),[new RegExp(l,e?void 0:"i"),r]}function dT(o){try{return o.split("/").map(e=>decodeURIComponent(e).replace(/\//g,"%2F")).join("/")}catch(e){return ta(!1,`The URL path "${o}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${e}).`),o}}function Ca(o,e){if(e==="/")return o;if(!o.toLowerCase().startsWith(e.toLowerCase()))return null;let i=e.endsWith("/")?e.length-1:e.length,r=o.charAt(i);return r&&r!=="/"?null:o.slice(i)||"/"}function pT(o,e="/"){let{pathname:i,search:r="",hash:l=""}=typeof o=="string"?mo(o):o,c;return i?(i=ay(i),i.startsWith("/")||i.startsWith("\\")?c=q0(i.substring(1),"/"):c=q0(i,e)):c=e,{pathname:c,search:_T(r),hash:vT(l)}}function q0(o,e){let i=lo(e).split("/");return o.split("/").forEach(l=>{l===".."?i.length>1&&i.pop():l!=="."&&i.push(l)}),i.length>1?i.join("/"):"/"}function bd(o,e,i,r){return`Cannot include a '${o}' character in a manually specified \`to.${e}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${i}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`}function mT(o){return o.filter((e,i)=>i===0||e.route.path&&e.route.path.length>0)}function iy(o){let e=mT(o);return e.map((i,r)=>r===e.length-1?i.pathname:i.pathnameBase)}function am(o,e,i,r=!1){let l;typeof o=="string"?l=mo(o):(l={...o},nn(!l.pathname||!l.pathname.includes("?"),bd("?","pathname","search",l)),nn(!l.pathname||!l.pathname.includes("#"),bd("#","pathname","hash",l)),nn(!l.search||!l.search.includes("#"),bd("#","search","hash",l)));let c=o===""||l.pathname==="",h=c?"/":l.pathname,d;if(h==null)d=i;else{let p=e.length-1;if(!r&&h.startsWith("..")){let x=h.split("/");for(;x[0]==="..";)x.shift(),p-=1;l.pathname=x.join("/")}d=p>=0?e[p]:"/"}let m=pT(l,d),g=h&&h!=="/"&&h.endsWith("/"),_=(c||h===".")&&i.endsWith("/");return!m.pathname.endsWith("/")&&(g||_)&&(m.pathname+="/"),m}var ay=o=>o.replace(/[\\/]{2,}/g,"/"),zi=o=>ay(o.join("/"));function lo(o,e=0){let i=o.length;for(;i>e&&o.charCodeAt(i-1)===47;)i--;return i===o.length?o:o.slice(0,i)}var gT=o=>lo(o).replace(/^\/*/,"/"),_T=o=>!o||o==="?"?"":o.startsWith("?")?o:"?"+o,vT=o=>!o||o==="#"?"":o.startsWith("#")?o:"#"+o,xT=class{constructor(o,e,i,r=!1){this.status=o,this.statusText=e||"",this.internal=r,i instanceof Error?(this.data=i.toString(),this.error=i):this.data=i}};function yT(o){return o!=null&&typeof o.status=="number"&&typeof o.statusText=="string"&&typeof o.internal=="boolean"&&"data"in o}function ST(o){let e=o.map(i=>i.route.path).filter(Boolean);return zi(e)||"/"}var ry=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";function sy(o,e){let i=o;if(typeof i!="string"||!im.test(i))return{absoluteURL:void 0,isExternal:!1,to:i};let r=i,l=!1;if(ry)try{let c=new URL(window.location.href),h=Qx.test(i)?new URL(KE(i,c.protocol)):new URL(i),d=Ca(h.pathname,e);h.origin===c.origin&&d!=null?i=d+h.search+h.hash:l=!0}catch{ta(!1,`<Link to="${i}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)}return{absoluteURL:r,isExternal:l,to:i}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");var Y0=new URL("http://localhost");function oy(o){if(o.createURL)return o.createURL("/");try{return new URL(o.createHref("/"),Y0)}catch{return Y0}}function Ad(o,e){return o.origin===e.origin&&(o.origin!=="null"||o.protocol===e.protocol&&o.host===e.host)}function MT(o,e){if(o.startsWith("//"))return!0;let i=e.protocol.toLowerCase();return o.toLowerCase().startsWith(i)?e.host===""||o.slice(i.length).startsWith("//"):!1}function ly(o,e,i,r){let l=null;try{l=o==null?null:new URL(o,i)}catch{}let c=new URL(e,i),h=l!=null&&!Ad(l,i),d=!Ad(c,i);if(r==="reject"){if(h||d)throw new Error("External navigation is not allowed")}else if(d&&(l==null||!MT(o,l)||!Ad(l,c)))throw new Error("External navigation is not allowed")}var uy=["POST","PUT","PATCH","DELETE"];new Set(uy);var ET=["GET",...uy];new Set(ET);var TT=["about:","blob:","chrome:","chrome-untrusted:","content:","data:","devtools:","file:","filesystem:","javascript:"];function bT(o){try{return TT.includes(new URL(o).protocol)}catch{return!1}}var go=dt.createContext(null);go.displayName="DataRouter";var Fc=dt.createContext(null);Fc.displayName="DataRouterState";var cy=dt.createContext(!1);function AT(){return dt.useContext(cy)}var fy=dt.createContext({isTransitioning:!1});fy.displayName="ViewTransition";var RT=dt.createContext(new Map);RT.displayName="Fetchers";var CT=dt.createContext(null);CT.displayName="Await";var Ei=dt.createContext(null);Ei.displayName="Navigation";var Al=dt.createContext(null);Al.displayName="Location";var wa=dt.createContext({outlet:null,matches:[],isDataRoute:!1});wa.displayName="Route";var rm=dt.createContext(null);rm.displayName="RouteError";var hy="REACT_ROUTER_ERROR",wT="REDIRECT",DT="ROUTE_ERROR_RESPONSE";function UT(o){if(o.startsWith(`${hy}:${wT}:{`))try{let e=JSON.parse(o.slice(28));if(typeof e=="object"&&e&&typeof e.status=="number"&&typeof e.statusText=="string"&&typeof e.location=="string"&&typeof e.reloadDocument=="boolean"&&typeof e.replace=="boolean")return e}catch{}}function NT(o){if(o.startsWith(`${hy}:${DT}:{`))try{let e=JSON.parse(o.slice(40));if(typeof e=="object"&&e&&typeof e.status=="number"&&typeof e.statusText=="string")return new xT(e.status,e.statusText,e.data)}catch{}}function LT(o,{relative:e}={}){nn(Rl(),"useHref() may be used only in the context of a <Router> component.");let{basename:i,navigator:r}=dt.useContext(Ei),{hash:l,pathname:c,search:h}=Cl(o,{relative:e}),d=c;return i!=="/"&&(d=c==="/"?i:zi([i,c])),r.createHref({pathname:d,search:h,hash:l})}function Rl(){return dt.useContext(Al)!=null}function Da(){return nn(Rl(),"useLocation() may be used only in the context of a <Router> component."),dt.useContext(Al).location}var dy="You should call navigate() in a React.useEffect(), not when your component is first rendered.";function py(o){dt.useContext(Ei).static||dt.useLayoutEffect(o)}function OT(){let{isDataRoute:o}=dt.useContext(wa);return o?WT():PT()}function PT(){nn(Rl(),"useNavigate() may be used only in the context of a <Router> component.");let o=dt.useContext(go),{basename:e,navigator:i}=dt.useContext(Ei),{matches:r}=dt.useContext(wa),{pathname:l}=Da(),c=JSON.stringify(iy(r)),h=dt.useRef(!1);return py(()=>{h.current=!0}),dt.useCallback((m,g={})=>{if(ta(h.current,dy),!h.current)return;if(typeof m=="number"){i.go(m);return}let _=am(m,JSON.parse(c),l,g.relative==="path");o==null&&e!=="/"&&(_.pathname=_.pathname==="/"?e:zi([e,_.pathname])),ly(typeof m=="string"?m:oo(m),i.createHref(_),oy(i),"reject"),(g.replace?i.replace:i.push)(_,g.state,g)},[e,i,c,l,o])}dt.createContext(null);function Cl(o,{relative:e}={}){let{matches:i}=dt.useContext(wa),{pathname:r}=Da(),l=JSON.stringify(iy(i));return dt.useMemo(()=>am(o,JSON.parse(l),r,e==="path"),[o,l,r,e])}function zT(o,e){return my(o,e)}function my(o,e,i){nn(Rl(),"useRoutes() may be used only in the context of a <Router> component.");let{navigator:r}=dt.useContext(Ei),{matches:l}=dt.useContext(wa),c=l[l.length-1],h=c?c.params:{},d=c?c.pathname:"/",m=c?c.pathnameBase:"/",g=c&&c.route;{let y=g&&g.path||"";_y(d,!g||y.endsWith("*")||y.endsWith("*?"),`You rendered descendant <Routes> (or called \`useRoutes()\`) at "${d}" (under <Route path="${y}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${y}"> to <Route path="${y==="/"?"*":`${y}/*`}">.`)}let _=Da(),p;if(e){let y=typeof e=="string"?mo(e):e;nn(m==="/"||y.pathname?.startsWith(m),`When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${m}" but pathname "${y.pathname}" was given in the \`location\` prop.`),p=y}else p=_;let x=p.pathname||"/",M=x;if(m!=="/"){let y=m.replace(/^\//,"").split("/");M="/"+x.replace(/^\//,"").split("/").slice(y.length).join("/")}let E=i&&i.state.matches.length?i.state.matches.map(y=>Object.assign(y,{route:i.manifest[y.route.id]||y.route})):Jx(o,{pathname:M});ta(g||E!=null,`No routes matched location "${p.pathname}${p.search}${p.hash}" `),ta(E==null||E[E.length-1].route.element!==void 0||E[E.length-1].route.Component!==void 0||E[E.length-1].route.lazy!==void 0,`Matched leaf route at location "${p.pathname}${p.search}${p.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);let b=GT(E&&E.map(y=>Object.assign({},y,{params:Object.assign({},h,y.params),pathname:zi([m,r.encodeLocation?r.encodeLocation(y.pathname.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:y.pathname]),pathnameBase:y.pathnameBase==="/"?m:zi([m,r.encodeLocation?r.encodeLocation(y.pathnameBase.replace(/%/g,"%25").replace(/\?/g,"%3F").replace(/#/g,"%23")).pathname:y.pathnameBase])})),l,i);return e&&b?dt.createElement(Al.Provider,{value:{location:{pathname:"/",search:"",hash:"",state:null,key:"default",mask:void 0,...p},navigationType:"POP"}},b):b}function IT(){let o=YT(),e=yT(o)?`${o.status} ${o.statusText}`:o instanceof Error?o.message:JSON.stringify(o),i=o instanceof Error?o.stack:null,r="rgba(200,200,200, 0.5)",l={padding:"0.5rem",backgroundColor:r},c={padding:"2px 4px",backgroundColor:r},h=null;return console.error("Error handled by React Router default ErrorBoundary:",o),h=dt.createElement(dt.Fragment,null,dt.createElement("p",null,"💿 Hey developer 👋"),dt.createElement("p",null,"You can provide a way better UX than this when your app throws errors by providing your own ",dt.createElement("code",{style:c},"ErrorBoundary")," or"," ",dt.createElement("code",{style:c},"errorElement")," prop on your route.")),dt.createElement(dt.Fragment,null,dt.createElement("h2",null,"Unexpected Application Error!"),dt.createElement("h3",{style:{fontStyle:"italic"}},e),i?dt.createElement("pre",{style:l},i):null,h)}var BT=dt.createElement(IT,null),gy=class extends dt.Component{constructor(o){super(o),this.state={location:o.location,revalidation:o.revalidation,error:o.error}}static getDerivedStateFromError(o){return{error:o}}static getDerivedStateFromProps(o,e){return e.location!==o.location||e.revalidation!=="idle"&&o.revalidation==="idle"?{error:o.error,location:o.location,revalidation:o.revalidation}:{error:o.error!==void 0?o.error:e.error,location:e.location,revalidation:o.revalidation||e.revalidation}}componentDidCatch(o,e){this.props.onError?this.props.onError(o,e):console.error("React Router caught the following error during render",o)}render(){let o=this.state.error;if(this.context&&typeof o=="object"&&o&&"digest"in o&&typeof o.digest=="string"){const i=NT(o.digest);i&&(o=i)}let e=o!==void 0?dt.createElement(wa.Provider,{value:this.props.routeContext},dt.createElement(rm.Provider,{value:o,children:this.props.component})):this.props.children;return this.context?dt.createElement(FT,{error:o},e):e}};gy.contextType=cy;var Rd=new WeakMap;function FT({children:o,error:e}){let{basename:i,navigator:r}=dt.useContext(Ei);if(typeof e=="object"&&e&&"digest"in e&&typeof e.digest=="string"){let l=UT(e.digest);if(l){let c=Rd.get(e);if(c)throw c;let h=sy(l.location,i),d=h.absoluteURL||h.to;if(ly(l.location,d,oy(r),"allow-explicit"),bT(d))throw new Error("Invalid redirect location");if(ry&&!Rd.get(e))if(h.isExternal||l.reloadDocument)window.location.href=d;else{const m=Promise.resolve().then(()=>window.__reactRouterDataRouter.navigate(h.to,{replace:l.replace}));throw Rd.set(e,m),m}return dt.createElement("meta",{httpEquiv:"refresh",content:`0;url=${d}`})}}return o}function HT({routeContext:o,match:e,children:i}){let r=dt.useContext(go);return r&&r.static&&r.staticContext&&(e.route.errorElement||e.route.ErrorBoundary)&&(r.staticContext._deepestRenderedBoundaryId=e.route.id),dt.createElement(wa.Provider,{value:o},i)}function GT(o,e=[],i){let r=i?.state;if(o==null){if(!r)return null;if(r.errors)o=r.matches;else if(e.length===0&&!r.initialized&&r.matches.length>0)o=r.matches;else return null}let l=o,c=r?.errors;if(c!=null){let _=l.findIndex(p=>p.route.id&&c?.[p.route.id]!==void 0);nn(_>=0,`Could not find a matching route for errors on route IDs: ${Object.keys(c).join(",")}`),l=l.slice(0,Math.min(l.length,_+1))}let h=!1,d=-1;if(i&&r){h=r.renderFallback;for(let _=0;_<l.length;_++){let p=l[_];if((p.route.HydrateFallback||p.route.hydrateFallbackElement)&&(d=_),p.route.id){let{loaderData:x,errors:M}=r,E=p.route.loader&&!x.hasOwnProperty(p.route.id)&&(!M||M[p.route.id]===void 0);if(p.route.lazy||E){i.isStatic&&(h=!0),d>=0?l=l.slice(0,d+1):l=[l[0]];break}}}}let m=i?.onError,g=r&&m?(_,p)=>{m(_,{location:r.location,params:r.matches?.[0]?.params??{},pattern:ST(r.matches),errorInfo:p})}:void 0;return l.reduceRight((_,p,x)=>{let M,E=!1,b=null,y=null;r&&(M=c&&p.route.id?c[p.route.id]:void 0,b=p.route.errorElement||BT,h&&(d<0&&x===0?(_y("route-fallback",!1,"No `HydrateFallback` element provided to render during initial hydration"),E=!0,y=null):d===x&&(E=!0,y=p.route.hydrateFallbackElement||null)));let S=e.concat(l.slice(0,x+1)),U=()=>{let N;return M?N=b:E?N=y:p.route.Component?N=dt.createElement(p.route.Component,null):p.route.element?N=p.route.element:N=_,dt.createElement(HT,{match:p,routeContext:{outlet:_,matches:S,isDataRoute:r!=null},children:N})};return r&&(p.route.ErrorBoundary||p.route.errorElement||x===0)?dt.createElement(gy,{location:r.location,revalidation:r.revalidation,component:b,error:M,children:U(),routeContext:{outlet:null,matches:S,isDataRoute:!0},onError:g}):U()},null)}function sm(o){return`${o} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function VT(o){let e=dt.useContext(go);return nn(e,sm(o)),e}function XT(o){let e=dt.useContext(Fc);return nn(e,sm(o)),e}function kT(o){let e=dt.useContext(wa);return nn(e,sm(o)),e}function om(o){let e=kT(o),i=e.matches[e.matches.length-1];return nn(i.route.id,`${o} can only be used on routes that contain a unique "id"`),i.route.id}function qT(){return om("useRouteId")}function YT(){let o=dt.useContext(rm),e=XT("useRouteError"),i=om("useRouteError");return o!==void 0?o:e.errors?.[i]}function WT(){let{router:o}=VT("useNavigate"),e=om("useNavigate"),i=dt.useRef(!1);return py(()=>{i.current=!0}),dt.useCallback(async(l,c={})=>{ta(i.current,dy),i.current&&(typeof l=="number"?await o.navigate(l):await o.navigate(l,{fromRouteId:e,...c}))},[o,e])}var W0={};function _y(o,e,i){!e&&!W0[o]&&(W0[o]=!0,ta(!1,i))}dt.memo(jT);function jT({routes:o,manifest:e,future:i,state:r,isStatic:l,onError:c}){return my(o,void 0,{manifest:e,state:r,isStatic:l,onError:c})}function vy(o){nn(!1,"A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.")}function ZT({basename:o="/",children:e=null,location:i,navigationType:r="POP",navigator:l,static:c=!1,useTransitions:h}){nn(!Rl(),"You cannot render a <Router> inside another <Router>. You should never have more than one in your app.");let d=o.replace(/^\/*/,"/"),m=dt.useMemo(()=>({basename:d,navigator:l,static:c,useTransitions:h,future:{}}),[d,l,c,h]);typeof i=="string"&&(i=mo(i));let{pathname:g="/",search:_="",hash:p="",state:x=null,key:M="default",mask:E}=i,b=dt.useMemo(()=>{let y=Ca(g,d);return y==null?null:{location:{pathname:y,search:_,hash:p,state:x,key:M,mask:E},navigationType:r}},[d,g,_,p,x,M,r,E]);return ta(b!=null,`<Router basename="${d}"> is not able to match the URL "${g}${_}${p}" because it does not start with the basename, so the <Router> won't render anything.`),b==null?null:dt.createElement(Ei.Provider,{value:m},dt.createElement(Al.Provider,{children:e,value:b}))}function KT({children:o,location:e}){return zT(cp(o),e)}function cp(o,e=[]){let i=[];return dt.Children.forEach(o,(r,l)=>{if(!dt.isValidElement(r))return;let c=[...e,l];if(r.type===dt.Fragment){i.push.apply(i,cp(r.props.children,c));return}nn(r.type===vy,`[${typeof r.type=="string"?r.type:r.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`),nn(!r.props.index||!r.props.children,"An index route cannot have child routes.");let h={id:r.props.id||c.join("-"),caseSensitive:r.props.caseSensitive,element:r.props.element,Component:r.props.Component,index:r.props.index,path:r.props.path,middleware:r.props.middleware,loader:r.props.loader,action:r.props.action,hydrateFallbackElement:r.props.hydrateFallbackElement,HydrateFallback:r.props.HydrateFallback,errorElement:r.props.errorElement,ErrorBoundary:r.props.ErrorBoundary,hasErrorBoundary:r.props.hasErrorBoundary===!0||r.props.ErrorBoundary!=null||r.props.errorElement!=null,shouldRevalidate:r.props.shouldRevalidate,handle:r.props.handle,lazy:r.props.lazy};r.props.children&&(h.children=cp(r.props.children,c)),i.push(h)}),i}var Rc="get",Cc="application/x-www-form-urlencoded";function Hc(o){return typeof HTMLElement<"u"&&o instanceof HTMLElement}function QT(o){return Hc(o)&&o.tagName.toLowerCase()==="button"}function JT(o){return Hc(o)&&o.tagName.toLowerCase()==="form"}function $T(o){return Hc(o)&&o.tagName.toLowerCase()==="input"}function tb(o){return!!(o.metaKey||o.altKey||o.ctrlKey||o.shiftKey)}function eb(o,e){return o.button===0&&(!e||e==="_self")&&!tb(o)}var ic=null;function nb(){if(ic===null)try{new FormData(document.createElement("form"),0),ic=!1}catch{ic=!0}return ic}var ib=new Set(["application/x-www-form-urlencoded","multipart/form-data","text/plain"]);function Cd(o){return o!=null&&!ib.has(o)?(ta(!1,`"${o}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Cc}"`),null):o}function ab(o,e){let i,r,l,c,h;if(JT(o)){let d=o.getAttribute("action");r=d?Ca(d,e):null,i=o.getAttribute("method")||Rc,l=Cd(o.getAttribute("enctype"))||Cc,c=new FormData(o)}else if(QT(o)||$T(o)&&(o.type==="submit"||o.type==="image")){let d=o.form;if(d==null)throw new Error('Cannot submit a <button> or <input type="submit"> without a <form>');let m=o.getAttribute("formaction")||d.getAttribute("action");if(r=m?Ca(m,e):null,i=o.getAttribute("formmethod")||d.getAttribute("method")||Rc,l=Cd(o.getAttribute("formenctype"))||Cd(d.getAttribute("enctype"))||Cc,c=new FormData(d,o),!nb()){let{name:g,type:_,value:p}=o;if(_==="image"){let x=g?`${g}.`:"";c.append(`${x}x`,"0"),c.append(`${x}y`,"0")}else g&&c.append(g,p)}}else{if(Hc(o))throw new Error('Cannot submit element that is not <form>, <button>, or <input type="submit|image">');i=Rc,r=null,l=Cc,h=o}return c&&l==="text/plain"&&(h=c,c=void 0),{action:r,method:i.toLowerCase(),encType:l,formData:c,body:h}}Object.getOwnPropertyNames(Object.prototype).sort().join("\0");function lm(o,e){if(o===!1||o===null||typeof o>"u")throw new Error(e)}function xy(o,e,i,r){let l=typeof o=="string"?new URL(o,typeof window>"u"?"server://singlefetch/":window.location.origin):o;return i?l.pathname.endsWith("/")?l.pathname=`${l.pathname}_.${r}`:l.pathname=`${l.pathname}.${r}`:l.pathname==="/"?l.pathname=`_root.${r}`:e&&Ca(l.pathname,e)==="/"?l.pathname=`${lo(e)}/_root.${r}`:l.pathname=`${lo(l.pathname)}.${r}`,l}async function rb(o,e){if(o.id in e)return e[o.id];try{let i=await import(o.module);return e[o.id]=i,i}catch(i){return console.error(`Error loading route module \`${o.module}\`, reloading page...`),console.error(i),window.__reactRouterContext&&window.__reactRouterContext.isSpaMode,window.location.reload(),new Promise(()=>{})}}function sb(o){return o==null?!1:o.href==null?o.rel==="preload"&&typeof o.imageSrcSet=="string"&&typeof o.imageSizes=="string":typeof o.rel=="string"&&typeof o.href=="string"}async function ob(o,e,i){let r=await Promise.all(o.map(async l=>{let c=e.routes[l.route.id];if(c){let h=await rb(c,i);return h.links?h.links():[]}return[]}));return fb(r.flat(1).filter(sb).filter(l=>l.rel==="stylesheet"||l.rel==="preload").map(l=>l.rel==="stylesheet"?{...l,rel:"prefetch",as:"style"}:{...l,rel:"prefetch"}))}function j0(o,e,i,r,l,c){let h=(m,g)=>i[g]?m.route.id!==i[g].route.id:!0,d=(m,g)=>i[g].pathname!==m.pathname||i[g].route.path?.endsWith("*")&&i[g].params["*"]!==m.params["*"];return c==="assets"?e.filter((m,g)=>h(m,g)||d(m,g)):c==="data"?e.filter((m,g)=>{let _=r.routes[m.route.id];if(!_||!_.hasLoader)return!1;if(h(m,g)||d(m,g))return!0;if(m.route.shouldRevalidate){let p=m.route.shouldRevalidate({currentUrl:new URL(l.pathname+l.search+l.hash,window.origin),currentParams:i[0]?.params||{},nextUrl:new URL(o,window.origin),nextParams:m.params,defaultShouldRevalidate:!0});if(typeof p=="boolean")return p}return!0}):[]}function lb(o,e,{includeHydrateFallback:i}={}){return ub(o.map(r=>{let l=e.routes[r.route.id];if(!l)return[];let c=[l.module];return l.clientActionModule&&(c=c.concat(l.clientActionModule)),l.clientLoaderModule&&(c=c.concat(l.clientLoaderModule)),i&&l.hydrateFallbackModule&&(c=c.concat(l.hydrateFallbackModule)),l.imports&&(c=c.concat(l.imports)),c}).flat(1))}function ub(o){return[...new Set(o)]}function cb(o){let e={},i=Object.keys(o).sort();for(let r of i)e[r]=o[r];return e}function fb(o,e){let i=new Set;return new Set(e),o.reduce((r,l)=>{let c=JSON.stringify(cb(l));return i.has(c)||(i.add(c),r.push({key:c,link:l})),r},[])}function um(){let o=dt.useContext(go);return lm(o,"You must render this element inside a <DataRouterContext.Provider> element"),o}function hb(){let o=dt.useContext(Fc);return lm(o,"You must render this element inside a <DataRouterStateContext.Provider> element"),o}var cm=dt.createContext(void 0);cm.displayName="FrameworkContext";function Gc(){let o=dt.useContext(cm);return lm(o,"You must render this element inside a <HydratedRouter> element"),o}function db(o,e){let i=dt.useContext(cm),[r,l]=dt.useState(!1),[c,h]=dt.useState(!1),{onFocus:d,onBlur:m,onMouseEnter:g,onMouseLeave:_,onTouchStart:p}=e,x=dt.useRef(null);dt.useEffect(()=>{if(o==="render"&&h(!0),o==="viewport"){let b=S=>{S.forEach(U=>{h(U.isIntersecting)})},y=new IntersectionObserver(b,{threshold:.5});return x.current&&y.observe(x.current),()=>{y.disconnect()}}},[o]),dt.useEffect(()=>{if(r){let b=setTimeout(()=>{h(!0)},100);return()=>{clearTimeout(b)}}},[r]);let M=()=>{l(!0)},E=()=>{l(!1),h(!1)};return i?o!=="intent"?[c,x,{}]:[c,x,{onFocus:hl(d,M),onBlur:hl(m,E),onMouseEnter:hl(g,M),onMouseLeave:hl(_,E),onTouchStart:hl(p,M)}]:[!1,x,{}]}function hl(o,e){return i=>{o&&o(i),i.defaultPrevented||e(i)}}function pb({page:o,...e}){let i=AT(),{nonce:r}=Gc(),{router:l}=um(),c=dt.useMemo(()=>Jx(l.routes,o,l.basename),[l.routes,o,l.basename]);return c?(e.nonce==null&&r&&(e={...e,nonce:r}),i?dt.createElement(gb,{page:o,matches:c,...e}):dt.createElement(_b,{page:o,matches:c,...e})):null}function mb(o){let{manifest:e,routeModules:i}=Gc(),[r,l]=dt.useState([]);return dt.useEffect(()=>{let c=!1;return ob(o,e,i).then(h=>{c||l(h)}),()=>{c=!0}},[o,e,i]),r}function gb({page:o,matches:e,...i}){let r=Da(),{future:l}=Gc(),{basename:c}=um(),h=dt.useMemo(()=>{if(o===r.pathname+r.search+r.hash)return[];let d=xy(o,c,l.v8_trailingSlashAwareDataRequests,"rsc"),m=!1,g=[];for(let _ of e)typeof _.route.shouldRevalidate=="function"?m=!0:g.push(_.route.id);return m&&g.length>0&&d.searchParams.set("_routes",g.join(",")),[d.pathname+d.search]},[c,l.v8_trailingSlashAwareDataRequests,o,r,e]);return dt.createElement(dt.Fragment,null,h.map(d=>dt.createElement("link",{key:d,rel:"prefetch",as:"fetch",href:d,...i})))}function _b({page:o,matches:e,...i}){let r=Da(),{future:l,manifest:c,routeModules:h}=Gc(),{basename:d}=um(),{loaderData:m,matches:g}=hb(),_=dt.useMemo(()=>j0(o,e,g,c,r,"data"),[o,e,g,c,r]),p=dt.useMemo(()=>j0(o,e,g,c,r,"assets"),[o,e,g,c,r]),x=dt.useMemo(()=>{if(o===r.pathname+r.search+r.hash)return[];let b=new Set,y=!1;if(e.forEach(U=>{let N=c.routes[U.route.id];!N||!N.hasLoader||(!_.some(D=>D.route.id===U.route.id)&&U.route.id in m&&h[U.route.id]?.shouldRevalidate||N.hasClientLoader?y=!0:b.add(U.route.id))}),b.size===0)return[];let S=xy(o,d,l.v8_trailingSlashAwareDataRequests,"data");return y&&b.size>0&&S.searchParams.set("_routes",e.filter(U=>b.has(U.route.id)).map(U=>U.route.id).join(",")),[S.pathname+S.search]},[d,l.v8_trailingSlashAwareDataRequests,m,r,c,_,e,o,h]),M=dt.useMemo(()=>lb(p,c),[p,c]),E=mb(p);return dt.createElement(dt.Fragment,null,x.map(b=>dt.createElement("link",{key:b,rel:"prefetch",as:"fetch",href:b,...i})),M.map(b=>dt.createElement("link",{key:b,rel:"modulepreload",href:b,...i})),E.map(({key:b,link:y})=>dt.createElement("link",{key:b,nonce:i.nonce,...y,crossOrigin:y.crossOrigin??i.crossOrigin})))}function vb(...o){return e=>{o.forEach(i=>{typeof i=="function"?i(e):i!=null&&(i.current=e)})}}var xb=typeof window<"u"&&typeof window.document<"u"&&typeof window.document.createElement<"u";try{xb&&(window.__reactRouterVersion="7.18.5")}catch{}function yb({basename:o,children:e,useTransitions:i,window:r}){let l=dt.useRef();l.current==null&&(l.current=QE({window:r,v5Compat:!0}));let c=l.current,[h,d]=dt.useState({action:c.action,location:c.location}),m=dt.useCallback(g=>{i===!1?d(g):dt.startTransition(()=>d(g))},[i]);return dt.useLayoutEffect(()=>c.listen(m),[c,m]),dt.createElement(ZT,{basename:o,children:e,location:h.location,navigationType:h.action,navigator:c,useTransitions:i})}var yy=dt.forwardRef(function({onClick:e,discover:i="render",prefetch:r="none",relative:l,reloadDocument:c,replace:h,mask:d,state:m,target:g,to:_,preventScrollReset:p,viewTransition:x,defaultShouldRevalidate:M,...E},b){let{basename:y,navigator:S,useTransitions:U}=dt.useContext(Ei),N=typeof _=="string"&&im.test(_),D=sy(_,y);_=D.to;let I=LT(_,{relative:l}),z=Da(),L=null;if(d){let st=am(d,[],z.mask?z.mask.pathname:"/",!0);y!=="/"&&(st.pathname=st.pathname==="/"?y:zi([y,st.pathname])),L=S.createHref(st)}let[B,C,R]=db(r,E),G=Tb(_,{replace:h,mask:d,state:m,target:g,preventScrollReset:p,relative:l,viewTransition:x,defaultShouldRevalidate:M,useTransitions:U});function Z(st){e&&e(st),st.defaultPrevented||G(st)}let et=!(D.isExternal||c),ct=dt.createElement("a",{...E,...R,href:(et?L:void 0)||D.absoluteURL||I,onClick:et?Z:e,ref:vb(b,C),target:g,"data-discover":!N&&i==="render"?"true":void 0});return B&&!N?dt.createElement(dt.Fragment,null,ct,dt.createElement(pb,{page:I})):ct});yy.displayName="Link";var Sb=dt.forwardRef(function({"aria-current":e="page",caseSensitive:i=!1,className:r="",end:l=!1,style:c,to:h,viewTransition:d,children:m,...g},_){let p=Cl(h,{relative:g.relative}),x=Da(),M=dt.useContext(Fc),{navigator:E,basename:b}=dt.useContext(Ei),y=M!=null&&wb(p)&&d===!0,S=E.encodeLocation?E.encodeLocation(p).pathname:p.pathname,U=x.pathname,N=M&&M.navigation&&M.navigation.location?M.navigation.location.pathname:null;i||(U=U.toLowerCase(),N=N?N.toLowerCase():null,S=S.toLowerCase()),N&&b&&(N=Ca(N,b)||N);const D=S!=="/"&&S.endsWith("/")?S.length-1:S.length;let I=U===S||!l&&U.startsWith(S)&&U.charAt(D)==="/",z=N!=null&&(N===S||!l&&N.startsWith(S)&&N.charAt(S.length)==="/"),L={isActive:I,isPending:z,isTransitioning:y},B=I?e:void 0,C;typeof r=="function"?C=r(L):C=[r,I?"active":null,z?"pending":null,y?"transitioning":null].filter(Boolean).join(" ");let R=typeof c=="function"?c(L):c;return dt.createElement(yy,{...g,"aria-current":B,className:C,ref:_,style:R,to:h,viewTransition:d},typeof m=="function"?m(L):m)});Sb.displayName="NavLink";var Mb=dt.forwardRef(({discover:o="render",fetcherKey:e,navigate:i,reloadDocument:r,replace:l,state:c,method:h=Rc,action:d,onSubmit:m,relative:g,preventScrollReset:_,viewTransition:p,defaultShouldRevalidate:x,...M},E)=>{let{useTransitions:b}=dt.useContext(Ei),y=Rb(),S=Cb(d,{relative:g}),U=h.toLowerCase()==="get"?"get":"post",N=typeof d=="string"&&im.test(d),D=I=>{if(m&&m(I),I.defaultPrevented)return;I.preventDefault();let z=I.nativeEvent.submitter,L=z?.getAttribute("formmethod")||h,B=()=>y(z||I.currentTarget,{fetcherKey:e,method:L,navigate:i,replace:l,state:c,relative:g,preventScrollReset:_,viewTransition:p,defaultShouldRevalidate:x});b&&i!==!1?dt.startTransition(()=>B()):B()};return dt.createElement("form",{ref:E,method:U,action:S,onSubmit:r?m:D,...M,"data-discover":!N&&o==="render"?"true":void 0})});Mb.displayName="Form";function Eb(o){return`${o} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`}function Sy(o){let e=dt.useContext(go);return nn(e,Eb(o)),e}function Tb(o,{target:e,replace:i,mask:r,state:l,preventScrollReset:c,relative:h,viewTransition:d,defaultShouldRevalidate:m,useTransitions:g}={}){let _=OT(),p=Da(),x=Cl(o,{relative:h});return dt.useCallback(M=>{if(eb(M,e)){M.preventDefault();let E=i!==void 0?i:oo(p)===oo(x),b=()=>_(o,{replace:E,mask:r,state:l,preventScrollReset:c,relative:h,viewTransition:d,defaultShouldRevalidate:m});g?dt.startTransition(()=>b()):b()}},[p,_,x,i,r,l,e,o,c,h,d,m,g])}var bb=0,Ab=()=>`__${String(++bb)}__`;function Rb(){let{router:o}=Sy("useSubmit"),{basename:e}=dt.useContext(Ei),i=qT(),r=o.fetch,l=o.navigate;return dt.useCallback(async(c,h={})=>{let{action:d,method:m,encType:g,formData:_,body:p}=ab(c,e);if(h.navigate===!1){let x=h.fetcherKey||Ab();await r(x,i,h.action||d,{defaultShouldRevalidate:h.defaultShouldRevalidate,preventScrollReset:h.preventScrollReset,formData:_,body:p,formMethod:h.method||m,formEncType:h.encType||g,flushSync:h.flushSync})}else await l(h.action||d,{defaultShouldRevalidate:h.defaultShouldRevalidate,preventScrollReset:h.preventScrollReset,formData:_,body:p,formMethod:h.method||m,formEncType:h.encType||g,replace:h.replace,state:h.state,fromRouteId:i,flushSync:h.flushSync,viewTransition:h.viewTransition})},[r,l,e,i])}function Cb(o,{relative:e}={}){let{basename:i}=dt.useContext(Ei),r=dt.useContext(wa);nn(r,"useFormAction must be used inside a RouteContext");let[l]=r.matches.slice(-1),c={...Cl(o||".",{relative:e})},h=Da();if(o==null){c.search=h.search;let d=new URLSearchParams(c.search),m=d.getAll("index");if(m.some(_=>_==="")){d.delete("index"),m.filter(p=>p).forEach(p=>d.append("index",p));let _=d.toString();c.search=_?`?${_}`:""}}return(!o||o===".")&&l.route.index&&(c.search=c.search?c.search.replace(/^\?/,"?index&"):"?index"),i!=="/"&&(c.pathname=c.pathname==="/"?i:zi([i,c.pathname])),oo(c)}function wb(o,{relative:e}={}){let i=dt.useContext(fy);nn(i!=null,"`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");let{basename:r}=Sy("useViewTransitionState"),l=Cl(o,{relative:e});if(!i.isTransitioning)return!1;let c=Ca(i.currentLocation.pathname,r)||i.currentLocation.pathname,h=Ca(i.nextLocation.pathname,r)||i.nextLocation.pathname;return Oc(l.pathname,h)!=null||Oc(l.pathname,c)!=null}const fm="180",Db=0,Z0=1,Ub=2,My=1,Ey=2,Ta=3,mr=0,Qn=1,ba=2,dr=0,ro=1,K0=2,Q0=3,J0=4,Nb=5,Zr=100,Lb=101,Ob=102,Pb=103,zb=104,Ib=200,Bb=201,Fb=202,Hb=203,fp=204,hp=205,Gb=206,Vb=207,Xb=208,kb=209,qb=210,Yb=211,Wb=212,jb=213,Zb=214,dp=0,pp=1,mp=2,uo=3,gp=4,_p=5,vp=6,xp=7,Ty=0,Kb=1,Qb=2,pr=0,Jb=1,$b=2,t1=3,by=4,e1=5,n1=6,i1=7,Ay=300,co=301,fo=302,yp=303,Sp=304,Vc=306,Mp=1e3,Qr=1001,Ep=1002,Ii=1003,a1=1004,ac=1005,Ji=1006,wd=1007,Jr=1008,ea=1009,Ry=1010,Cy=1011,Sl=1012,hm=1013,$r=1014,Aa=1015,wl=1016,dm=1017,pm=1018,Ml=1020,wy=35902,Dy=35899,Uy=1021,Ny=1022,Pi=1023,El=1026,Tl=1027,Ly=1028,mm=1029,Oy=1030,gm=1031,_m=1033,wc=33776,Dc=33777,Uc=33778,Nc=33779,Tp=35840,bp=35841,Ap=35842,Rp=35843,Cp=36196,wp=37492,Dp=37496,Up=37808,Np=37809,Lp=37810,Op=37811,Pp=37812,zp=37813,Ip=37814,Bp=37815,Fp=37816,Hp=37817,Gp=37818,Vp=37819,Xp=37820,kp=37821,qp=36492,Yp=36494,Wp=36495,jp=36283,Zp=36284,Kp=36285,Qp=36286,r1=3200,s1=3201,Py=0,o1=1,hr="",Mi="srgb",ho="srgb-linear",Pc="linear",Ye="srgb",Gs=7680,$0=519,l1=512,u1=513,c1=514,zy=515,f1=516,h1=517,d1=518,p1=519,tx=35044,ex="300 es",$i=2e3,zc=2001;class _o{addEventListener(e,i){this._listeners===void 0&&(this._listeners={});const r=this._listeners;r[e]===void 0&&(r[e]=[]),r[e].indexOf(i)===-1&&r[e].push(i)}hasEventListener(e,i){const r=this._listeners;return r===void 0?!1:r[e]!==void 0&&r[e].indexOf(i)!==-1}removeEventListener(e,i){const r=this._listeners;if(r===void 0)return;const l=r[e];if(l!==void 0){const c=l.indexOf(i);c!==-1&&l.splice(c,1)}}dispatchEvent(e){const i=this._listeners;if(i===void 0)return;const r=i[e.type];if(r!==void 0){e.target=this;const l=r.slice(0);for(let c=0,h=l.length;c<h;c++)l[c].call(this,e);e.target=null}}}const zn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Dd=Math.PI/180,Jp=180/Math.PI;function Dl(){const o=Math.random()*4294967295|0,e=Math.random()*4294967295|0,i=Math.random()*4294967295|0,r=Math.random()*4294967295|0;return(zn[o&255]+zn[o>>8&255]+zn[o>>16&255]+zn[o>>24&255]+"-"+zn[e&255]+zn[e>>8&255]+"-"+zn[e>>16&15|64]+zn[e>>24&255]+"-"+zn[i&63|128]+zn[i>>8&255]+"-"+zn[i>>16&255]+zn[i>>24&255]+zn[r&255]+zn[r>>8&255]+zn[r>>16&255]+zn[r>>24&255]).toLowerCase()}function we(o,e,i){return Math.max(e,Math.min(i,o))}function m1(o,e){return(o%e+e)%e}function Ud(o,e,i){return(1-i)*o+i*e}function dl(o,e){switch(e.constructor){case Float32Array:return o;case Uint32Array:return o/4294967295;case Uint16Array:return o/65535;case Uint8Array:return o/255;case Int32Array:return Math.max(o/2147483647,-1);case Int16Array:return Math.max(o/32767,-1);case Int8Array:return Math.max(o/127,-1);default:throw new Error("Invalid component type.")}}function Kn(o,e){switch(e.constructor){case Float32Array:return o;case Uint32Array:return Math.round(o*4294967295);case Uint16Array:return Math.round(o*65535);case Uint8Array:return Math.round(o*255);case Int32Array:return Math.round(o*2147483647);case Int16Array:return Math.round(o*32767);case Int8Array:return Math.round(o*127);default:throw new Error("Invalid component type.")}}class be{constructor(e=0,i=0){be.prototype.isVector2=!0,this.x=e,this.y=i}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,i){return this.x=e,this.y=i,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const i=this.x,r=this.y,l=e.elements;return this.x=l[0]*i+l[3]*r+l[6],this.y=l[1]*i+l[4]*r+l[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,i){return this.x=we(this.x,e.x,i.x),this.y=we(this.y,e.y,i.y),this}clampScalar(e,i){return this.x=we(this.x,e,i),this.y=we(this.y,e,i),this}clampLength(e,i){const r=this.length();return this.divideScalar(r||1).multiplyScalar(we(r,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const i=Math.sqrt(this.lengthSq()*e.lengthSq());if(i===0)return Math.PI/2;const r=this.dot(e)/i;return Math.acos(we(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const i=this.x-e.x,r=this.y-e.y;return i*i+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this}lerpVectors(e,i,r){return this.x=e.x+(i.x-e.x)*r,this.y=e.y+(i.y-e.y)*r,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this}rotateAround(e,i){const r=Math.cos(i),l=Math.sin(i),c=this.x-e.x,h=this.y-e.y;return this.x=c*r-h*l+e.x,this.y=c*l+h*r+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class Ul{constructor(e=0,i=0,r=0,l=1){this.isQuaternion=!0,this._x=e,this._y=i,this._z=r,this._w=l}static slerpFlat(e,i,r,l,c,h,d){let m=r[l+0],g=r[l+1],_=r[l+2],p=r[l+3];const x=c[h+0],M=c[h+1],E=c[h+2],b=c[h+3];if(d===0){e[i+0]=m,e[i+1]=g,e[i+2]=_,e[i+3]=p;return}if(d===1){e[i+0]=x,e[i+1]=M,e[i+2]=E,e[i+3]=b;return}if(p!==b||m!==x||g!==M||_!==E){let y=1-d;const S=m*x+g*M+_*E+p*b,U=S>=0?1:-1,N=1-S*S;if(N>Number.EPSILON){const I=Math.sqrt(N),z=Math.atan2(I,S*U);y=Math.sin(y*z)/I,d=Math.sin(d*z)/I}const D=d*U;if(m=m*y+x*D,g=g*y+M*D,_=_*y+E*D,p=p*y+b*D,y===1-d){const I=1/Math.sqrt(m*m+g*g+_*_+p*p);m*=I,g*=I,_*=I,p*=I}}e[i]=m,e[i+1]=g,e[i+2]=_,e[i+3]=p}static multiplyQuaternionsFlat(e,i,r,l,c,h){const d=r[l],m=r[l+1],g=r[l+2],_=r[l+3],p=c[h],x=c[h+1],M=c[h+2],E=c[h+3];return e[i]=d*E+_*p+m*M-g*x,e[i+1]=m*E+_*x+g*p-d*M,e[i+2]=g*E+_*M+d*x-m*p,e[i+3]=_*E-d*p-m*x-g*M,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,i,r,l){return this._x=e,this._y=i,this._z=r,this._w=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,i=!0){const r=e._x,l=e._y,c=e._z,h=e._order,d=Math.cos,m=Math.sin,g=d(r/2),_=d(l/2),p=d(c/2),x=m(r/2),M=m(l/2),E=m(c/2);switch(h){case"XYZ":this._x=x*_*p+g*M*E,this._y=g*M*p-x*_*E,this._z=g*_*E+x*M*p,this._w=g*_*p-x*M*E;break;case"YXZ":this._x=x*_*p+g*M*E,this._y=g*M*p-x*_*E,this._z=g*_*E-x*M*p,this._w=g*_*p+x*M*E;break;case"ZXY":this._x=x*_*p-g*M*E,this._y=g*M*p+x*_*E,this._z=g*_*E+x*M*p,this._w=g*_*p-x*M*E;break;case"ZYX":this._x=x*_*p-g*M*E,this._y=g*M*p+x*_*E,this._z=g*_*E-x*M*p,this._w=g*_*p+x*M*E;break;case"YZX":this._x=x*_*p+g*M*E,this._y=g*M*p+x*_*E,this._z=g*_*E-x*M*p,this._w=g*_*p-x*M*E;break;case"XZY":this._x=x*_*p-g*M*E,this._y=g*M*p-x*_*E,this._z=g*_*E+x*M*p,this._w=g*_*p+x*M*E;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+h)}return i===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,i){const r=i/2,l=Math.sin(r);return this._x=e.x*l,this._y=e.y*l,this._z=e.z*l,this._w=Math.cos(r),this._onChangeCallback(),this}setFromRotationMatrix(e){const i=e.elements,r=i[0],l=i[4],c=i[8],h=i[1],d=i[5],m=i[9],g=i[2],_=i[6],p=i[10],x=r+d+p;if(x>0){const M=.5/Math.sqrt(x+1);this._w=.25/M,this._x=(_-m)*M,this._y=(c-g)*M,this._z=(h-l)*M}else if(r>d&&r>p){const M=2*Math.sqrt(1+r-d-p);this._w=(_-m)/M,this._x=.25*M,this._y=(l+h)/M,this._z=(c+g)/M}else if(d>p){const M=2*Math.sqrt(1+d-r-p);this._w=(c-g)/M,this._x=(l+h)/M,this._y=.25*M,this._z=(m+_)/M}else{const M=2*Math.sqrt(1+p-r-d);this._w=(h-l)/M,this._x=(c+g)/M,this._y=(m+_)/M,this._z=.25*M}return this._onChangeCallback(),this}setFromUnitVectors(e,i){let r=e.dot(i)+1;return r<1e-8?(r=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=r):(this._x=0,this._y=-e.z,this._z=e.y,this._w=r)):(this._x=e.y*i.z-e.z*i.y,this._y=e.z*i.x-e.x*i.z,this._z=e.x*i.y-e.y*i.x,this._w=r),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(we(this.dot(e),-1,1)))}rotateTowards(e,i){const r=this.angleTo(e);if(r===0)return this;const l=Math.min(1,i/r);return this.slerp(e,l),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,i){const r=e._x,l=e._y,c=e._z,h=e._w,d=i._x,m=i._y,g=i._z,_=i._w;return this._x=r*_+h*d+l*g-c*m,this._y=l*_+h*m+c*d-r*g,this._z=c*_+h*g+r*m-l*d,this._w=h*_-r*d-l*m-c*g,this._onChangeCallback(),this}slerp(e,i){if(i===0)return this;if(i===1)return this.copy(e);const r=this._x,l=this._y,c=this._z,h=this._w;let d=h*e._w+r*e._x+l*e._y+c*e._z;if(d<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,d=-d):this.copy(e),d>=1)return this._w=h,this._x=r,this._y=l,this._z=c,this;const m=1-d*d;if(m<=Number.EPSILON){const M=1-i;return this._w=M*h+i*this._w,this._x=M*r+i*this._x,this._y=M*l+i*this._y,this._z=M*c+i*this._z,this.normalize(),this}const g=Math.sqrt(m),_=Math.atan2(g,d),p=Math.sin((1-i)*_)/g,x=Math.sin(i*_)/g;return this._w=h*p+this._w*x,this._x=r*p+this._x*x,this._y=l*p+this._y*x,this._z=c*p+this._z*x,this._onChangeCallback(),this}slerpQuaternions(e,i,r){return this.copy(e).slerp(i,r)}random(){const e=2*Math.PI*Math.random(),i=2*Math.PI*Math.random(),r=Math.random(),l=Math.sqrt(1-r),c=Math.sqrt(r);return this.set(l*Math.sin(e),l*Math.cos(e),c*Math.sin(i),c*Math.cos(i))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,i=0){return this._x=e[i],this._y=e[i+1],this._z=e[i+2],this._w=e[i+3],this._onChangeCallback(),this}toArray(e=[],i=0){return e[i]=this._x,e[i+1]=this._y,e[i+2]=this._z,e[i+3]=this._w,e}fromBufferAttribute(e,i){return this._x=e.getX(i),this._y=e.getY(i),this._z=e.getZ(i),this._w=e.getW(i),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class J{constructor(e=0,i=0,r=0){J.prototype.isVector3=!0,this.x=e,this.y=i,this.z=r}set(e,i,r){return r===void 0&&(r=this.z),this.x=e,this.y=i,this.z=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this.z=e.z+i.z,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this.z+=e.z*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this.z=e.z-i.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,i){return this.x=e.x*i.x,this.y=e.y*i.y,this.z=e.z*i.z,this}applyEuler(e){return this.applyQuaternion(nx.setFromEuler(e))}applyAxisAngle(e,i){return this.applyQuaternion(nx.setFromAxisAngle(e,i))}applyMatrix3(e){const i=this.x,r=this.y,l=this.z,c=e.elements;return this.x=c[0]*i+c[3]*r+c[6]*l,this.y=c[1]*i+c[4]*r+c[7]*l,this.z=c[2]*i+c[5]*r+c[8]*l,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const i=this.x,r=this.y,l=this.z,c=e.elements,h=1/(c[3]*i+c[7]*r+c[11]*l+c[15]);return this.x=(c[0]*i+c[4]*r+c[8]*l+c[12])*h,this.y=(c[1]*i+c[5]*r+c[9]*l+c[13])*h,this.z=(c[2]*i+c[6]*r+c[10]*l+c[14])*h,this}applyQuaternion(e){const i=this.x,r=this.y,l=this.z,c=e.x,h=e.y,d=e.z,m=e.w,g=2*(h*l-d*r),_=2*(d*i-c*l),p=2*(c*r-h*i);return this.x=i+m*g+h*p-d*_,this.y=r+m*_+d*g-c*p,this.z=l+m*p+c*_-h*g,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const i=this.x,r=this.y,l=this.z,c=e.elements;return this.x=c[0]*i+c[4]*r+c[8]*l,this.y=c[1]*i+c[5]*r+c[9]*l,this.z=c[2]*i+c[6]*r+c[10]*l,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,i){return this.x=we(this.x,e.x,i.x),this.y=we(this.y,e.y,i.y),this.z=we(this.z,e.z,i.z),this}clampScalar(e,i){return this.x=we(this.x,e,i),this.y=we(this.y,e,i),this.z=we(this.z,e,i),this}clampLength(e,i){const r=this.length();return this.divideScalar(r||1).multiplyScalar(we(r,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this.z+=(e.z-this.z)*i,this}lerpVectors(e,i,r){return this.x=e.x+(i.x-e.x)*r,this.y=e.y+(i.y-e.y)*r,this.z=e.z+(i.z-e.z)*r,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,i){const r=e.x,l=e.y,c=e.z,h=i.x,d=i.y,m=i.z;return this.x=l*m-c*d,this.y=c*h-r*m,this.z=r*d-l*h,this}projectOnVector(e){const i=e.lengthSq();if(i===0)return this.set(0,0,0);const r=e.dot(this)/i;return this.copy(e).multiplyScalar(r)}projectOnPlane(e){return Nd.copy(this).projectOnVector(e),this.sub(Nd)}reflect(e){return this.sub(Nd.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const i=Math.sqrt(this.lengthSq()*e.lengthSq());if(i===0)return Math.PI/2;const r=this.dot(e)/i;return Math.acos(we(r,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const i=this.x-e.x,r=this.y-e.y,l=this.z-e.z;return i*i+r*r+l*l}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,i,r){const l=Math.sin(i)*e;return this.x=l*Math.sin(r),this.y=Math.cos(i)*e,this.z=l*Math.cos(r),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,i,r){return this.x=e*Math.sin(i),this.y=r,this.z=e*Math.cos(i),this}setFromMatrixPosition(e){const i=e.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this}setFromMatrixScale(e){const i=this.setFromMatrixColumn(e,0).length(),r=this.setFromMatrixColumn(e,1).length(),l=this.setFromMatrixColumn(e,2).length();return this.x=i,this.y=r,this.z=l,this}setFromMatrixColumn(e,i){return this.fromArray(e.elements,i*4)}setFromMatrix3Column(e,i){return this.fromArray(e.elements,i*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this.z=e[i+2],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e[i+2]=this.z,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this.z=e.getZ(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,i=Math.random()*2-1,r=Math.sqrt(1-i*i);return this.x=r*Math.cos(e),this.y=i,this.z=r*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Nd=new J,nx=new Ul;class me{constructor(e,i,r,l,c,h,d,m,g){me.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,i,r,l,c,h,d,m,g)}set(e,i,r,l,c,h,d,m,g){const _=this.elements;return _[0]=e,_[1]=l,_[2]=d,_[3]=i,_[4]=c,_[5]=m,_[6]=r,_[7]=h,_[8]=g,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const i=this.elements,r=e.elements;return i[0]=r[0],i[1]=r[1],i[2]=r[2],i[3]=r[3],i[4]=r[4],i[5]=r[5],i[6]=r[6],i[7]=r[7],i[8]=r[8],this}extractBasis(e,i,r){return e.setFromMatrix3Column(this,0),i.setFromMatrix3Column(this,1),r.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const i=e.elements;return this.set(i[0],i[4],i[8],i[1],i[5],i[9],i[2],i[6],i[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,i){const r=e.elements,l=i.elements,c=this.elements,h=r[0],d=r[3],m=r[6],g=r[1],_=r[4],p=r[7],x=r[2],M=r[5],E=r[8],b=l[0],y=l[3],S=l[6],U=l[1],N=l[4],D=l[7],I=l[2],z=l[5],L=l[8];return c[0]=h*b+d*U+m*I,c[3]=h*y+d*N+m*z,c[6]=h*S+d*D+m*L,c[1]=g*b+_*U+p*I,c[4]=g*y+_*N+p*z,c[7]=g*S+_*D+p*L,c[2]=x*b+M*U+E*I,c[5]=x*y+M*N+E*z,c[8]=x*S+M*D+E*L,this}multiplyScalar(e){const i=this.elements;return i[0]*=e,i[3]*=e,i[6]*=e,i[1]*=e,i[4]*=e,i[7]*=e,i[2]*=e,i[5]*=e,i[8]*=e,this}determinant(){const e=this.elements,i=e[0],r=e[1],l=e[2],c=e[3],h=e[4],d=e[5],m=e[6],g=e[7],_=e[8];return i*h*_-i*d*g-r*c*_+r*d*m+l*c*g-l*h*m}invert(){const e=this.elements,i=e[0],r=e[1],l=e[2],c=e[3],h=e[4],d=e[5],m=e[6],g=e[7],_=e[8],p=_*h-d*g,x=d*m-_*c,M=g*c-h*m,E=i*p+r*x+l*M;if(E===0)return this.set(0,0,0,0,0,0,0,0,0);const b=1/E;return e[0]=p*b,e[1]=(l*g-_*r)*b,e[2]=(d*r-l*h)*b,e[3]=x*b,e[4]=(_*i-l*m)*b,e[5]=(l*c-d*i)*b,e[6]=M*b,e[7]=(r*m-g*i)*b,e[8]=(h*i-r*c)*b,this}transpose(){let e;const i=this.elements;return e=i[1],i[1]=i[3],i[3]=e,e=i[2],i[2]=i[6],i[6]=e,e=i[5],i[5]=i[7],i[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const i=this.elements;return e[0]=i[0],e[1]=i[3],e[2]=i[6],e[3]=i[1],e[4]=i[4],e[5]=i[7],e[6]=i[2],e[7]=i[5],e[8]=i[8],this}setUvTransform(e,i,r,l,c,h,d){const m=Math.cos(c),g=Math.sin(c);return this.set(r*m,r*g,-r*(m*h+g*d)+h+e,-l*g,l*m,-l*(-g*h+m*d)+d+i,0,0,1),this}scale(e,i){return this.premultiply(Ld.makeScale(e,i)),this}rotate(e){return this.premultiply(Ld.makeRotation(-e)),this}translate(e,i){return this.premultiply(Ld.makeTranslation(e,i)),this}makeTranslation(e,i){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,i,0,0,1),this}makeRotation(e){const i=Math.cos(e),r=Math.sin(e);return this.set(i,-r,0,r,i,0,0,0,1),this}makeScale(e,i){return this.set(e,0,0,0,i,0,0,0,1),this}equals(e){const i=this.elements,r=e.elements;for(let l=0;l<9;l++)if(i[l]!==r[l])return!1;return!0}fromArray(e,i=0){for(let r=0;r<9;r++)this.elements[r]=e[r+i];return this}toArray(e=[],i=0){const r=this.elements;return e[i]=r[0],e[i+1]=r[1],e[i+2]=r[2],e[i+3]=r[3],e[i+4]=r[4],e[i+5]=r[5],e[i+6]=r[6],e[i+7]=r[7],e[i+8]=r[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Ld=new me;function Iy(o){for(let e=o.length-1;e>=0;--e)if(o[e]>=65535)return!0;return!1}function Ic(o){return document.createElementNS("http://www.w3.org/1999/xhtml",o)}function g1(){const o=Ic("canvas");return o.style.display="block",o}const ix={};function bl(o){o in ix||(ix[o]=!0,console.warn(o))}function _1(o,e,i){return new Promise(function(r,l){function c(){switch(o.clientWaitSync(e,o.SYNC_FLUSH_COMMANDS_BIT,0)){case o.WAIT_FAILED:l();break;case o.TIMEOUT_EXPIRED:setTimeout(c,i);break;default:r()}}setTimeout(c,i)})}const ax=new me().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),rx=new me().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function v1(){const o={enabled:!0,workingColorSpace:ho,spaces:{},convert:function(l,c,h){return this.enabled===!1||c===h||!c||!h||(this.spaces[c].transfer===Ye&&(l.r=Ra(l.r),l.g=Ra(l.g),l.b=Ra(l.b)),this.spaces[c].primaries!==this.spaces[h].primaries&&(l.applyMatrix3(this.spaces[c].toXYZ),l.applyMatrix3(this.spaces[h].fromXYZ)),this.spaces[h].transfer===Ye&&(l.r=so(l.r),l.g=so(l.g),l.b=so(l.b))),l},workingToColorSpace:function(l,c){return this.convert(l,this.workingColorSpace,c)},colorSpaceToWorking:function(l,c){return this.convert(l,c,this.workingColorSpace)},getPrimaries:function(l){return this.spaces[l].primaries},getTransfer:function(l){return l===hr?Pc:this.spaces[l].transfer},getToneMappingMode:function(l){return this.spaces[l].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(l,c=this.workingColorSpace){return l.fromArray(this.spaces[c].luminanceCoefficients)},define:function(l){Object.assign(this.spaces,l)},_getMatrix:function(l,c,h){return l.copy(this.spaces[c].toXYZ).multiply(this.spaces[h].fromXYZ)},_getDrawingBufferColorSpace:function(l){return this.spaces[l].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(l=this.workingColorSpace){return this.spaces[l].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(l,c){return bl("THREE.ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),o.workingToColorSpace(l,c)},toWorkingColorSpace:function(l,c){return bl("THREE.ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),o.colorSpaceToWorking(l,c)}},e=[.64,.33,.3,.6,.15,.06],i=[.2126,.7152,.0722],r=[.3127,.329];return o.define({[ho]:{primaries:e,whitePoint:r,transfer:Pc,toXYZ:ax,fromXYZ:rx,luminanceCoefficients:i,workingColorSpaceConfig:{unpackColorSpace:Mi},outputColorSpaceConfig:{drawingBufferColorSpace:Mi}},[Mi]:{primaries:e,whitePoint:r,transfer:Ye,toXYZ:ax,fromXYZ:rx,luminanceCoefficients:i,outputColorSpaceConfig:{drawingBufferColorSpace:Mi}}}),o}const Oe=v1();function Ra(o){return o<.04045?o*.0773993808:Math.pow(o*.9478672986+.0521327014,2.4)}function so(o){return o<.0031308?o*12.92:1.055*Math.pow(o,.41666)-.055}let Vs;class x1{static getDataURL(e,i="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let r;if(e instanceof HTMLCanvasElement)r=e;else{Vs===void 0&&(Vs=Ic("canvas")),Vs.width=e.width,Vs.height=e.height;const l=Vs.getContext("2d");e instanceof ImageData?l.putImageData(e,0,0):l.drawImage(e,0,0,e.width,e.height),r=Vs}return r.toDataURL(i)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const i=Ic("canvas");i.width=e.width,i.height=e.height;const r=i.getContext("2d");r.drawImage(e,0,0,e.width,e.height);const l=r.getImageData(0,0,e.width,e.height),c=l.data;for(let h=0;h<c.length;h++)c[h]=Ra(c[h]/255)*255;return r.putImageData(l,0,0),i}else if(e.data){const i=e.data.slice(0);for(let r=0;r<i.length;r++)i instanceof Uint8Array||i instanceof Uint8ClampedArray?i[r]=Math.floor(Ra(i[r]/255)*255):i[r]=Ra(i[r]);return{data:i,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let y1=0;class vm{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:y1++}),this.uuid=Dl(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const i=this.data;return typeof HTMLVideoElement<"u"&&i instanceof HTMLVideoElement?e.set(i.videoWidth,i.videoHeight,0):i instanceof VideoFrame?e.set(i.displayHeight,i.displayWidth,0):i!==null?e.set(i.width,i.height,i.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const i=e===void 0||typeof e=="string";if(!i&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const r={uuid:this.uuid,url:""},l=this.data;if(l!==null){let c;if(Array.isArray(l)){c=[];for(let h=0,d=l.length;h<d;h++)l[h].isDataTexture?c.push(Od(l[h].image)):c.push(Od(l[h]))}else c=Od(l);r.url=c}return i||(e.images[this.uuid]=r),r}}function Od(o){return typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&o instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&o instanceof ImageBitmap?x1.getDataURL(o):o.data?{data:Array.from(o.data),width:o.width,height:o.height,type:o.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let S1=0;const Pd=new J;class Jn extends _o{constructor(e=Jn.DEFAULT_IMAGE,i=Jn.DEFAULT_MAPPING,r=Qr,l=Qr,c=Ji,h=Jr,d=Pi,m=ea,g=Jn.DEFAULT_ANISOTROPY,_=hr){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:S1++}),this.uuid=Dl(),this.name="",this.source=new vm(e),this.mipmaps=[],this.mapping=i,this.channel=0,this.wrapS=r,this.wrapT=l,this.magFilter=c,this.minFilter=h,this.anisotropy=g,this.format=d,this.internalFormat=null,this.type=m,this.offset=new be(0,0),this.repeat=new be(1,1),this.center=new be(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new me,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=_,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0}get width(){return this.source.getSize(Pd).x}get height(){return this.source.getSize(Pd).y}get depth(){return this.source.getSize(Pd).z}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,i){this.updateRanges.push({start:e,count:i})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const i in e){const r=e[i];if(r===void 0){console.warn(`THREE.Texture.setValues(): parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){console.warn(`THREE.Texture.setValues(): property '${i}' does not exist.`);continue}l&&r&&l.isVector2&&r.isVector2||l&&r&&l.isVector3&&r.isVector3||l&&r&&l.isMatrix3&&r.isMatrix3?l.copy(r):this[i]=r}}toJSON(e){const i=e===void 0||typeof e=="string";if(!i&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const r={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(r.userData=this.userData),i||(e.textures[this.uuid]=r),r}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Ay)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Mp:e.x=e.x-Math.floor(e.x);break;case Qr:e.x=e.x<0?0:1;break;case Ep:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Mp:e.y=e.y-Math.floor(e.y);break;case Qr:e.y=e.y<0?0:1;break;case Ep:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Jn.DEFAULT_IMAGE=null;Jn.DEFAULT_MAPPING=Ay;Jn.DEFAULT_ANISOTROPY=1;class We{constructor(e=0,i=0,r=0,l=1){We.prototype.isVector4=!0,this.x=e,this.y=i,this.z=r,this.w=l}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,i,r,l){return this.x=e,this.y=i,this.z=r,this.w=l,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,i){switch(e){case 0:this.x=i;break;case 1:this.y=i;break;case 2:this.z=i;break;case 3:this.w=i;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,i){return this.x=e.x+i.x,this.y=e.y+i.y,this.z=e.z+i.z,this.w=e.w+i.w,this}addScaledVector(e,i){return this.x+=e.x*i,this.y+=e.y*i,this.z+=e.z*i,this.w+=e.w*i,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,i){return this.x=e.x-i.x,this.y=e.y-i.y,this.z=e.z-i.z,this.w=e.w-i.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const i=this.x,r=this.y,l=this.z,c=this.w,h=e.elements;return this.x=h[0]*i+h[4]*r+h[8]*l+h[12]*c,this.y=h[1]*i+h[5]*r+h[9]*l+h[13]*c,this.z=h[2]*i+h[6]*r+h[10]*l+h[14]*c,this.w=h[3]*i+h[7]*r+h[11]*l+h[15]*c,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const i=Math.sqrt(1-e.w*e.w);return i<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/i,this.y=e.y/i,this.z=e.z/i),this}setAxisAngleFromRotationMatrix(e){let i,r,l,c;const m=e.elements,g=m[0],_=m[4],p=m[8],x=m[1],M=m[5],E=m[9],b=m[2],y=m[6],S=m[10];if(Math.abs(_-x)<.01&&Math.abs(p-b)<.01&&Math.abs(E-y)<.01){if(Math.abs(_+x)<.1&&Math.abs(p+b)<.1&&Math.abs(E+y)<.1&&Math.abs(g+M+S-3)<.1)return this.set(1,0,0,0),this;i=Math.PI;const N=(g+1)/2,D=(M+1)/2,I=(S+1)/2,z=(_+x)/4,L=(p+b)/4,B=(E+y)/4;return N>D&&N>I?N<.01?(r=0,l=.707106781,c=.707106781):(r=Math.sqrt(N),l=z/r,c=L/r):D>I?D<.01?(r=.707106781,l=0,c=.707106781):(l=Math.sqrt(D),r=z/l,c=B/l):I<.01?(r=.707106781,l=.707106781,c=0):(c=Math.sqrt(I),r=L/c,l=B/c),this.set(r,l,c,i),this}let U=Math.sqrt((y-E)*(y-E)+(p-b)*(p-b)+(x-_)*(x-_));return Math.abs(U)<.001&&(U=1),this.x=(y-E)/U,this.y=(p-b)/U,this.z=(x-_)/U,this.w=Math.acos((g+M+S-1)/2),this}setFromMatrixPosition(e){const i=e.elements;return this.x=i[12],this.y=i[13],this.z=i[14],this.w=i[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,i){return this.x=we(this.x,e.x,i.x),this.y=we(this.y,e.y,i.y),this.z=we(this.z,e.z,i.z),this.w=we(this.w,e.w,i.w),this}clampScalar(e,i){return this.x=we(this.x,e,i),this.y=we(this.y,e,i),this.z=we(this.z,e,i),this.w=we(this.w,e,i),this}clampLength(e,i){const r=this.length();return this.divideScalar(r||1).multiplyScalar(we(r,e,i))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,i){return this.x+=(e.x-this.x)*i,this.y+=(e.y-this.y)*i,this.z+=(e.z-this.z)*i,this.w+=(e.w-this.w)*i,this}lerpVectors(e,i,r){return this.x=e.x+(i.x-e.x)*r,this.y=e.y+(i.y-e.y)*r,this.z=e.z+(i.z-e.z)*r,this.w=e.w+(i.w-e.w)*r,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,i=0){return this.x=e[i],this.y=e[i+1],this.z=e[i+2],this.w=e[i+3],this}toArray(e=[],i=0){return e[i]=this.x,e[i+1]=this.y,e[i+2]=this.z,e[i+3]=this.w,e}fromBufferAttribute(e,i){return this.x=e.getX(i),this.y=e.getY(i),this.z=e.getZ(i),this.w=e.getW(i),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class M1 extends _o{constructor(e=1,i=1,r={}){super(),r=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ji,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},r),this.isRenderTarget=!0,this.width=e,this.height=i,this.depth=r.depth,this.scissor=new We(0,0,e,i),this.scissorTest=!1,this.viewport=new We(0,0,e,i);const l={width:e,height:i,depth:r.depth},c=new Jn(l);this.textures=[];const h=r.count;for(let d=0;d<h;d++)this.textures[d]=c.clone(),this.textures[d].isRenderTargetTexture=!0,this.textures[d].renderTarget=this;this._setTextureOptions(r),this.depthBuffer=r.depthBuffer,this.stencilBuffer=r.stencilBuffer,this.resolveDepthBuffer=r.resolveDepthBuffer,this.resolveStencilBuffer=r.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=r.depthTexture,this.samples=r.samples,this.multiview=r.multiview}_setTextureOptions(e={}){const i={minFilter:Ji,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(i.mapping=e.mapping),e.wrapS!==void 0&&(i.wrapS=e.wrapS),e.wrapT!==void 0&&(i.wrapT=e.wrapT),e.wrapR!==void 0&&(i.wrapR=e.wrapR),e.magFilter!==void 0&&(i.magFilter=e.magFilter),e.minFilter!==void 0&&(i.minFilter=e.minFilter),e.format!==void 0&&(i.format=e.format),e.type!==void 0&&(i.type=e.type),e.anisotropy!==void 0&&(i.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(i.colorSpace=e.colorSpace),e.flipY!==void 0&&(i.flipY=e.flipY),e.generateMipmaps!==void 0&&(i.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(i.internalFormat=e.internalFormat);for(let r=0;r<this.textures.length;r++)this.textures[r].setValues(i)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,i,r=1){if(this.width!==e||this.height!==i||this.depth!==r){this.width=e,this.height=i,this.depth=r;for(let l=0,c=this.textures.length;l<c;l++)this.textures[l].image.width=e,this.textures[l].image.height=i,this.textures[l].image.depth=r,this.textures[l].isArrayTexture=this.textures[l].image.depth>1;this.dispose()}this.viewport.set(0,0,e,i),this.scissor.set(0,0,e,i)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let i=0,r=e.textures.length;i<r;i++){this.textures[i]=e.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0,this.textures[i].renderTarget=this;const l=Object.assign({},e.textures[i].image);this.textures[i].source=new vm(l)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ts extends M1{constructor(e=1,i=1,r={}){super(e,i,r),this.isWebGLRenderTarget=!0}}class By extends Jn{constructor(e=null,i=1,r=1,l=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:i,height:r,depth:l},this.magFilter=Ii,this.minFilter=Ii,this.wrapR=Qr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class E1 extends Jn{constructor(e=null,i=1,r=1,l=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:i,height:r,depth:l},this.magFilter=Ii,this.minFilter=Ii,this.wrapR=Qr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Nl{constructor(e=new J(1/0,1/0,1/0),i=new J(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=i}set(e,i){return this.min.copy(e),this.max.copy(i),this}setFromArray(e){this.makeEmpty();for(let i=0,r=e.length;i<r;i+=3)this.expandByPoint(Ui.fromArray(e,i));return this}setFromBufferAttribute(e){this.makeEmpty();for(let i=0,r=e.count;i<r;i++)this.expandByPoint(Ui.fromBufferAttribute(e,i));return this}setFromPoints(e){this.makeEmpty();for(let i=0,r=e.length;i<r;i++)this.expandByPoint(e[i]);return this}setFromCenterAndSize(e,i){const r=Ui.copy(i).multiplyScalar(.5);return this.min.copy(e).sub(r),this.max.copy(e).add(r),this}setFromObject(e,i=!1){return this.makeEmpty(),this.expandByObject(e,i)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,i=!1){e.updateWorldMatrix(!1,!1);const r=e.geometry;if(r!==void 0){const c=r.getAttribute("position");if(i===!0&&c!==void 0&&e.isInstancedMesh!==!0)for(let h=0,d=c.count;h<d;h++)e.isMesh===!0?e.getVertexPosition(h,Ui):Ui.fromBufferAttribute(c,h),Ui.applyMatrix4(e.matrixWorld),this.expandByPoint(Ui);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),rc.copy(e.boundingBox)):(r.boundingBox===null&&r.computeBoundingBox(),rc.copy(r.boundingBox)),rc.applyMatrix4(e.matrixWorld),this.union(rc)}const l=e.children;for(let c=0,h=l.length;c<h;c++)this.expandByObject(l[c],i);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,i){return i.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Ui),Ui.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let i,r;return e.normal.x>0?(i=e.normal.x*this.min.x,r=e.normal.x*this.max.x):(i=e.normal.x*this.max.x,r=e.normal.x*this.min.x),e.normal.y>0?(i+=e.normal.y*this.min.y,r+=e.normal.y*this.max.y):(i+=e.normal.y*this.max.y,r+=e.normal.y*this.min.y),e.normal.z>0?(i+=e.normal.z*this.min.z,r+=e.normal.z*this.max.z):(i+=e.normal.z*this.max.z,r+=e.normal.z*this.min.z),i<=-e.constant&&r>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(pl),sc.subVectors(this.max,pl),Xs.subVectors(e.a,pl),ks.subVectors(e.b,pl),qs.subVectors(e.c,pl),rr.subVectors(ks,Xs),sr.subVectors(qs,ks),Gr.subVectors(Xs,qs);let i=[0,-rr.z,rr.y,0,-sr.z,sr.y,0,-Gr.z,Gr.y,rr.z,0,-rr.x,sr.z,0,-sr.x,Gr.z,0,-Gr.x,-rr.y,rr.x,0,-sr.y,sr.x,0,-Gr.y,Gr.x,0];return!zd(i,Xs,ks,qs,sc)||(i=[1,0,0,0,1,0,0,0,1],!zd(i,Xs,ks,qs,sc))?!1:(oc.crossVectors(rr,sr),i=[oc.x,oc.y,oc.z],zd(i,Xs,ks,qs,sc))}clampPoint(e,i){return i.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ui).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Ui).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(xa[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),xa[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),xa[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),xa[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),xa[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),xa[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),xa[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),xa[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(xa),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const xa=[new J,new J,new J,new J,new J,new J,new J,new J],Ui=new J,rc=new Nl,Xs=new J,ks=new J,qs=new J,rr=new J,sr=new J,Gr=new J,pl=new J,sc=new J,oc=new J,Vr=new J;function zd(o,e,i,r,l){for(let c=0,h=o.length-3;c<=h;c+=3){Vr.fromArray(o,c);const d=l.x*Math.abs(Vr.x)+l.y*Math.abs(Vr.y)+l.z*Math.abs(Vr.z),m=e.dot(Vr),g=i.dot(Vr),_=r.dot(Vr);if(Math.max(-Math.max(m,g,_),Math.min(m,g,_))>d)return!1}return!0}const T1=new Nl,ml=new J,Id=new J;class Xc{constructor(e=new J,i=-1){this.isSphere=!0,this.center=e,this.radius=i}set(e,i){return this.center.copy(e),this.radius=i,this}setFromPoints(e,i){const r=this.center;i!==void 0?r.copy(i):T1.setFromPoints(e).getCenter(r);let l=0;for(let c=0,h=e.length;c<h;c++)l=Math.max(l,r.distanceToSquared(e[c]));return this.radius=Math.sqrt(l),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const i=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=i*i}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,i){const r=this.center.distanceToSquared(e);return i.copy(e),r>this.radius*this.radius&&(i.sub(this.center).normalize(),i.multiplyScalar(this.radius).add(this.center)),i}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;ml.subVectors(e,this.center);const i=ml.lengthSq();if(i>this.radius*this.radius){const r=Math.sqrt(i),l=(r-this.radius)*.5;this.center.addScaledVector(ml,l/r),this.radius+=l}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Id.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(ml.copy(e.center).add(Id)),this.expandByPoint(ml.copy(e.center).sub(Id))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}const ya=new J,Bd=new J,lc=new J,or=new J,Fd=new J,uc=new J,Hd=new J;class Fy{constructor(e=new J,i=new J(0,0,-1)){this.origin=e,this.direction=i}set(e,i){return this.origin.copy(e),this.direction.copy(i),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,i){return i.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,ya)),this}closestPointToPoint(e,i){i.subVectors(e,this.origin);const r=i.dot(this.direction);return r<0?i.copy(this.origin):i.copy(this.origin).addScaledVector(this.direction,r)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const i=ya.subVectors(e,this.origin).dot(this.direction);return i<0?this.origin.distanceToSquared(e):(ya.copy(this.origin).addScaledVector(this.direction,i),ya.distanceToSquared(e))}distanceSqToSegment(e,i,r,l){Bd.copy(e).add(i).multiplyScalar(.5),lc.copy(i).sub(e).normalize(),or.copy(this.origin).sub(Bd);const c=e.distanceTo(i)*.5,h=-this.direction.dot(lc),d=or.dot(this.direction),m=-or.dot(lc),g=or.lengthSq(),_=Math.abs(1-h*h);let p,x,M,E;if(_>0)if(p=h*m-d,x=h*d-m,E=c*_,p>=0)if(x>=-E)if(x<=E){const b=1/_;p*=b,x*=b,M=p*(p+h*x+2*d)+x*(h*p+x+2*m)+g}else x=c,p=Math.max(0,-(h*x+d)),M=-p*p+x*(x+2*m)+g;else x=-c,p=Math.max(0,-(h*x+d)),M=-p*p+x*(x+2*m)+g;else x<=-E?(p=Math.max(0,-(-h*c+d)),x=p>0?-c:Math.min(Math.max(-c,-m),c),M=-p*p+x*(x+2*m)+g):x<=E?(p=0,x=Math.min(Math.max(-c,-m),c),M=x*(x+2*m)+g):(p=Math.max(0,-(h*c+d)),x=p>0?c:Math.min(Math.max(-c,-m),c),M=-p*p+x*(x+2*m)+g);else x=h>0?-c:c,p=Math.max(0,-(h*x+d)),M=-p*p+x*(x+2*m)+g;return r&&r.copy(this.origin).addScaledVector(this.direction,p),l&&l.copy(Bd).addScaledVector(lc,x),M}intersectSphere(e,i){ya.subVectors(e.center,this.origin);const r=ya.dot(this.direction),l=ya.dot(ya)-r*r,c=e.radius*e.radius;if(l>c)return null;const h=Math.sqrt(c-l),d=r-h,m=r+h;return m<0?null:d<0?this.at(m,i):this.at(d,i)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const i=e.normal.dot(this.direction);if(i===0)return e.distanceToPoint(this.origin)===0?0:null;const r=-(this.origin.dot(e.normal)+e.constant)/i;return r>=0?r:null}intersectPlane(e,i){const r=this.distanceToPlane(e);return r===null?null:this.at(r,i)}intersectsPlane(e){const i=e.distanceToPoint(this.origin);return i===0||e.normal.dot(this.direction)*i<0}intersectBox(e,i){let r,l,c,h,d,m;const g=1/this.direction.x,_=1/this.direction.y,p=1/this.direction.z,x=this.origin;return g>=0?(r=(e.min.x-x.x)*g,l=(e.max.x-x.x)*g):(r=(e.max.x-x.x)*g,l=(e.min.x-x.x)*g),_>=0?(c=(e.min.y-x.y)*_,h=(e.max.y-x.y)*_):(c=(e.max.y-x.y)*_,h=(e.min.y-x.y)*_),r>h||c>l||((c>r||isNaN(r))&&(r=c),(h<l||isNaN(l))&&(l=h),p>=0?(d=(e.min.z-x.z)*p,m=(e.max.z-x.z)*p):(d=(e.max.z-x.z)*p,m=(e.min.z-x.z)*p),r>m||d>l)||((d>r||r!==r)&&(r=d),(m<l||l!==l)&&(l=m),l<0)?null:this.at(r>=0?r:l,i)}intersectsBox(e){return this.intersectBox(e,ya)!==null}intersectTriangle(e,i,r,l,c){Fd.subVectors(i,e),uc.subVectors(r,e),Hd.crossVectors(Fd,uc);let h=this.direction.dot(Hd),d;if(h>0){if(l)return null;d=1}else if(h<0)d=-1,h=-h;else return null;or.subVectors(this.origin,e);const m=d*this.direction.dot(uc.crossVectors(or,uc));if(m<0)return null;const g=d*this.direction.dot(Fd.cross(or));if(g<0||m+g>h)return null;const _=-d*or.dot(Hd);return _<0?null:this.at(_/h,c)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class an{constructor(e,i,r,l,c,h,d,m,g,_,p,x,M,E,b,y){an.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,i,r,l,c,h,d,m,g,_,p,x,M,E,b,y)}set(e,i,r,l,c,h,d,m,g,_,p,x,M,E,b,y){const S=this.elements;return S[0]=e,S[4]=i,S[8]=r,S[12]=l,S[1]=c,S[5]=h,S[9]=d,S[13]=m,S[2]=g,S[6]=_,S[10]=p,S[14]=x,S[3]=M,S[7]=E,S[11]=b,S[15]=y,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new an().fromArray(this.elements)}copy(e){const i=this.elements,r=e.elements;return i[0]=r[0],i[1]=r[1],i[2]=r[2],i[3]=r[3],i[4]=r[4],i[5]=r[5],i[6]=r[6],i[7]=r[7],i[8]=r[8],i[9]=r[9],i[10]=r[10],i[11]=r[11],i[12]=r[12],i[13]=r[13],i[14]=r[14],i[15]=r[15],this}copyPosition(e){const i=this.elements,r=e.elements;return i[12]=r[12],i[13]=r[13],i[14]=r[14],this}setFromMatrix3(e){const i=e.elements;return this.set(i[0],i[3],i[6],0,i[1],i[4],i[7],0,i[2],i[5],i[8],0,0,0,0,1),this}extractBasis(e,i,r){return e.setFromMatrixColumn(this,0),i.setFromMatrixColumn(this,1),r.setFromMatrixColumn(this,2),this}makeBasis(e,i,r){return this.set(e.x,i.x,r.x,0,e.y,i.y,r.y,0,e.z,i.z,r.z,0,0,0,0,1),this}extractRotation(e){const i=this.elements,r=e.elements,l=1/Ys.setFromMatrixColumn(e,0).length(),c=1/Ys.setFromMatrixColumn(e,1).length(),h=1/Ys.setFromMatrixColumn(e,2).length();return i[0]=r[0]*l,i[1]=r[1]*l,i[2]=r[2]*l,i[3]=0,i[4]=r[4]*c,i[5]=r[5]*c,i[6]=r[6]*c,i[7]=0,i[8]=r[8]*h,i[9]=r[9]*h,i[10]=r[10]*h,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromEuler(e){const i=this.elements,r=e.x,l=e.y,c=e.z,h=Math.cos(r),d=Math.sin(r),m=Math.cos(l),g=Math.sin(l),_=Math.cos(c),p=Math.sin(c);if(e.order==="XYZ"){const x=h*_,M=h*p,E=d*_,b=d*p;i[0]=m*_,i[4]=-m*p,i[8]=g,i[1]=M+E*g,i[5]=x-b*g,i[9]=-d*m,i[2]=b-x*g,i[6]=E+M*g,i[10]=h*m}else if(e.order==="YXZ"){const x=m*_,M=m*p,E=g*_,b=g*p;i[0]=x+b*d,i[4]=E*d-M,i[8]=h*g,i[1]=h*p,i[5]=h*_,i[9]=-d,i[2]=M*d-E,i[6]=b+x*d,i[10]=h*m}else if(e.order==="ZXY"){const x=m*_,M=m*p,E=g*_,b=g*p;i[0]=x-b*d,i[4]=-h*p,i[8]=E+M*d,i[1]=M+E*d,i[5]=h*_,i[9]=b-x*d,i[2]=-h*g,i[6]=d,i[10]=h*m}else if(e.order==="ZYX"){const x=h*_,M=h*p,E=d*_,b=d*p;i[0]=m*_,i[4]=E*g-M,i[8]=x*g+b,i[1]=m*p,i[5]=b*g+x,i[9]=M*g-E,i[2]=-g,i[6]=d*m,i[10]=h*m}else if(e.order==="YZX"){const x=h*m,M=h*g,E=d*m,b=d*g;i[0]=m*_,i[4]=b-x*p,i[8]=E*p+M,i[1]=p,i[5]=h*_,i[9]=-d*_,i[2]=-g*_,i[6]=M*p+E,i[10]=x-b*p}else if(e.order==="XZY"){const x=h*m,M=h*g,E=d*m,b=d*g;i[0]=m*_,i[4]=-p,i[8]=g*_,i[1]=x*p+b,i[5]=h*_,i[9]=M*p-E,i[2]=E*p-M,i[6]=d*_,i[10]=b*p+x}return i[3]=0,i[7]=0,i[11]=0,i[12]=0,i[13]=0,i[14]=0,i[15]=1,this}makeRotationFromQuaternion(e){return this.compose(b1,e,A1)}lookAt(e,i,r){const l=this.elements;return li.subVectors(e,i),li.lengthSq()===0&&(li.z=1),li.normalize(),lr.crossVectors(r,li),lr.lengthSq()===0&&(Math.abs(r.z)===1?li.x+=1e-4:li.z+=1e-4,li.normalize(),lr.crossVectors(r,li)),lr.normalize(),cc.crossVectors(li,lr),l[0]=lr.x,l[4]=cc.x,l[8]=li.x,l[1]=lr.y,l[5]=cc.y,l[9]=li.y,l[2]=lr.z,l[6]=cc.z,l[10]=li.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,i){const r=e.elements,l=i.elements,c=this.elements,h=r[0],d=r[4],m=r[8],g=r[12],_=r[1],p=r[5],x=r[9],M=r[13],E=r[2],b=r[6],y=r[10],S=r[14],U=r[3],N=r[7],D=r[11],I=r[15],z=l[0],L=l[4],B=l[8],C=l[12],R=l[1],G=l[5],Z=l[9],et=l[13],ct=l[2],st=l[6],k=l[10],it=l[14],j=l[3],xt=l[7],Mt=l[11],Ht=l[15];return c[0]=h*z+d*R+m*ct+g*j,c[4]=h*L+d*G+m*st+g*xt,c[8]=h*B+d*Z+m*k+g*Mt,c[12]=h*C+d*et+m*it+g*Ht,c[1]=_*z+p*R+x*ct+M*j,c[5]=_*L+p*G+x*st+M*xt,c[9]=_*B+p*Z+x*k+M*Mt,c[13]=_*C+p*et+x*it+M*Ht,c[2]=E*z+b*R+y*ct+S*j,c[6]=E*L+b*G+y*st+S*xt,c[10]=E*B+b*Z+y*k+S*Mt,c[14]=E*C+b*et+y*it+S*Ht,c[3]=U*z+N*R+D*ct+I*j,c[7]=U*L+N*G+D*st+I*xt,c[11]=U*B+N*Z+D*k+I*Mt,c[15]=U*C+N*et+D*it+I*Ht,this}multiplyScalar(e){const i=this.elements;return i[0]*=e,i[4]*=e,i[8]*=e,i[12]*=e,i[1]*=e,i[5]*=e,i[9]*=e,i[13]*=e,i[2]*=e,i[6]*=e,i[10]*=e,i[14]*=e,i[3]*=e,i[7]*=e,i[11]*=e,i[15]*=e,this}determinant(){const e=this.elements,i=e[0],r=e[4],l=e[8],c=e[12],h=e[1],d=e[5],m=e[9],g=e[13],_=e[2],p=e[6],x=e[10],M=e[14],E=e[3],b=e[7],y=e[11],S=e[15];return E*(+c*m*p-l*g*p-c*d*x+r*g*x+l*d*M-r*m*M)+b*(+i*m*M-i*g*x+c*h*x-l*h*M+l*g*_-c*m*_)+y*(+i*g*p-i*d*M-c*h*p+r*h*M+c*d*_-r*g*_)+S*(-l*d*_-i*m*p+i*d*x+l*h*p-r*h*x+r*m*_)}transpose(){const e=this.elements;let i;return i=e[1],e[1]=e[4],e[4]=i,i=e[2],e[2]=e[8],e[8]=i,i=e[6],e[6]=e[9],e[9]=i,i=e[3],e[3]=e[12],e[12]=i,i=e[7],e[7]=e[13],e[13]=i,i=e[11],e[11]=e[14],e[14]=i,this}setPosition(e,i,r){const l=this.elements;return e.isVector3?(l[12]=e.x,l[13]=e.y,l[14]=e.z):(l[12]=e,l[13]=i,l[14]=r),this}invert(){const e=this.elements,i=e[0],r=e[1],l=e[2],c=e[3],h=e[4],d=e[5],m=e[6],g=e[7],_=e[8],p=e[9],x=e[10],M=e[11],E=e[12],b=e[13],y=e[14],S=e[15],U=p*y*g-b*x*g+b*m*M-d*y*M-p*m*S+d*x*S,N=E*x*g-_*y*g-E*m*M+h*y*M+_*m*S-h*x*S,D=_*b*g-E*p*g+E*d*M-h*b*M-_*d*S+h*p*S,I=E*p*m-_*b*m-E*d*x+h*b*x+_*d*y-h*p*y,z=i*U+r*N+l*D+c*I;if(z===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const L=1/z;return e[0]=U*L,e[1]=(b*x*c-p*y*c-b*l*M+r*y*M+p*l*S-r*x*S)*L,e[2]=(d*y*c-b*m*c+b*l*g-r*y*g-d*l*S+r*m*S)*L,e[3]=(p*m*c-d*x*c-p*l*g+r*x*g+d*l*M-r*m*M)*L,e[4]=N*L,e[5]=(_*y*c-E*x*c+E*l*M-i*y*M-_*l*S+i*x*S)*L,e[6]=(E*m*c-h*y*c-E*l*g+i*y*g+h*l*S-i*m*S)*L,e[7]=(h*x*c-_*m*c+_*l*g-i*x*g-h*l*M+i*m*M)*L,e[8]=D*L,e[9]=(E*p*c-_*b*c-E*r*M+i*b*M+_*r*S-i*p*S)*L,e[10]=(h*b*c-E*d*c+E*r*g-i*b*g-h*r*S+i*d*S)*L,e[11]=(_*d*c-h*p*c-_*r*g+i*p*g+h*r*M-i*d*M)*L,e[12]=I*L,e[13]=(_*b*l-E*p*l+E*r*x-i*b*x-_*r*y+i*p*y)*L,e[14]=(E*d*l-h*b*l-E*r*m+i*b*m+h*r*y-i*d*y)*L,e[15]=(h*p*l-_*d*l+_*r*m-i*p*m-h*r*x+i*d*x)*L,this}scale(e){const i=this.elements,r=e.x,l=e.y,c=e.z;return i[0]*=r,i[4]*=l,i[8]*=c,i[1]*=r,i[5]*=l,i[9]*=c,i[2]*=r,i[6]*=l,i[10]*=c,i[3]*=r,i[7]*=l,i[11]*=c,this}getMaxScaleOnAxis(){const e=this.elements,i=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],r=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],l=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(i,r,l))}makeTranslation(e,i,r){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,i,0,0,1,r,0,0,0,1),this}makeRotationX(e){const i=Math.cos(e),r=Math.sin(e);return this.set(1,0,0,0,0,i,-r,0,0,r,i,0,0,0,0,1),this}makeRotationY(e){const i=Math.cos(e),r=Math.sin(e);return this.set(i,0,r,0,0,1,0,0,-r,0,i,0,0,0,0,1),this}makeRotationZ(e){const i=Math.cos(e),r=Math.sin(e);return this.set(i,-r,0,0,r,i,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,i){const r=Math.cos(i),l=Math.sin(i),c=1-r,h=e.x,d=e.y,m=e.z,g=c*h,_=c*d;return this.set(g*h+r,g*d-l*m,g*m+l*d,0,g*d+l*m,_*d+r,_*m-l*h,0,g*m-l*d,_*m+l*h,c*m*m+r,0,0,0,0,1),this}makeScale(e,i,r){return this.set(e,0,0,0,0,i,0,0,0,0,r,0,0,0,0,1),this}makeShear(e,i,r,l,c,h){return this.set(1,r,c,0,e,1,h,0,i,l,1,0,0,0,0,1),this}compose(e,i,r){const l=this.elements,c=i._x,h=i._y,d=i._z,m=i._w,g=c+c,_=h+h,p=d+d,x=c*g,M=c*_,E=c*p,b=h*_,y=h*p,S=d*p,U=m*g,N=m*_,D=m*p,I=r.x,z=r.y,L=r.z;return l[0]=(1-(b+S))*I,l[1]=(M+D)*I,l[2]=(E-N)*I,l[3]=0,l[4]=(M-D)*z,l[5]=(1-(x+S))*z,l[6]=(y+U)*z,l[7]=0,l[8]=(E+N)*L,l[9]=(y-U)*L,l[10]=(1-(x+b))*L,l[11]=0,l[12]=e.x,l[13]=e.y,l[14]=e.z,l[15]=1,this}decompose(e,i,r){const l=this.elements;let c=Ys.set(l[0],l[1],l[2]).length();const h=Ys.set(l[4],l[5],l[6]).length(),d=Ys.set(l[8],l[9],l[10]).length();this.determinant()<0&&(c=-c),e.x=l[12],e.y=l[13],e.z=l[14],Ni.copy(this);const g=1/c,_=1/h,p=1/d;return Ni.elements[0]*=g,Ni.elements[1]*=g,Ni.elements[2]*=g,Ni.elements[4]*=_,Ni.elements[5]*=_,Ni.elements[6]*=_,Ni.elements[8]*=p,Ni.elements[9]*=p,Ni.elements[10]*=p,i.setFromRotationMatrix(Ni),r.x=c,r.y=h,r.z=d,this}makePerspective(e,i,r,l,c,h,d=$i,m=!1){const g=this.elements,_=2*c/(i-e),p=2*c/(r-l),x=(i+e)/(i-e),M=(r+l)/(r-l);let E,b;if(m)E=c/(h-c),b=h*c/(h-c);else if(d===$i)E=-(h+c)/(h-c),b=-2*h*c/(h-c);else if(d===zc)E=-h/(h-c),b=-h*c/(h-c);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+d);return g[0]=_,g[4]=0,g[8]=x,g[12]=0,g[1]=0,g[5]=p,g[9]=M,g[13]=0,g[2]=0,g[6]=0,g[10]=E,g[14]=b,g[3]=0,g[7]=0,g[11]=-1,g[15]=0,this}makeOrthographic(e,i,r,l,c,h,d=$i,m=!1){const g=this.elements,_=2/(i-e),p=2/(r-l),x=-(i+e)/(i-e),M=-(r+l)/(r-l);let E,b;if(m)E=1/(h-c),b=h/(h-c);else if(d===$i)E=-2/(h-c),b=-(h+c)/(h-c);else if(d===zc)E=-1/(h-c),b=-c/(h-c);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+d);return g[0]=_,g[4]=0,g[8]=0,g[12]=x,g[1]=0,g[5]=p,g[9]=0,g[13]=M,g[2]=0,g[6]=0,g[10]=E,g[14]=b,g[3]=0,g[7]=0,g[11]=0,g[15]=1,this}equals(e){const i=this.elements,r=e.elements;for(let l=0;l<16;l++)if(i[l]!==r[l])return!1;return!0}fromArray(e,i=0){for(let r=0;r<16;r++)this.elements[r]=e[r+i];return this}toArray(e=[],i=0){const r=this.elements;return e[i]=r[0],e[i+1]=r[1],e[i+2]=r[2],e[i+3]=r[3],e[i+4]=r[4],e[i+5]=r[5],e[i+6]=r[6],e[i+7]=r[7],e[i+8]=r[8],e[i+9]=r[9],e[i+10]=r[10],e[i+11]=r[11],e[i+12]=r[12],e[i+13]=r[13],e[i+14]=r[14],e[i+15]=r[15],e}}const Ys=new J,Ni=new an,b1=new J(0,0,0),A1=new J(1,1,1),lr=new J,cc=new J,li=new J,sx=new an,ox=new Ul;class na{constructor(e=0,i=0,r=0,l=na.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=i,this._z=r,this._order=l}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,i,r,l=this._order){return this._x=e,this._y=i,this._z=r,this._order=l,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,i=this._order,r=!0){const l=e.elements,c=l[0],h=l[4],d=l[8],m=l[1],g=l[5],_=l[9],p=l[2],x=l[6],M=l[10];switch(i){case"XYZ":this._y=Math.asin(we(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-_,M),this._z=Math.atan2(-h,c)):(this._x=Math.atan2(x,g),this._z=0);break;case"YXZ":this._x=Math.asin(-we(_,-1,1)),Math.abs(_)<.9999999?(this._y=Math.atan2(d,M),this._z=Math.atan2(m,g)):(this._y=Math.atan2(-p,c),this._z=0);break;case"ZXY":this._x=Math.asin(we(x,-1,1)),Math.abs(x)<.9999999?(this._y=Math.atan2(-p,M),this._z=Math.atan2(-h,g)):(this._y=0,this._z=Math.atan2(m,c));break;case"ZYX":this._y=Math.asin(-we(p,-1,1)),Math.abs(p)<.9999999?(this._x=Math.atan2(x,M),this._z=Math.atan2(m,c)):(this._x=0,this._z=Math.atan2(-h,g));break;case"YZX":this._z=Math.asin(we(m,-1,1)),Math.abs(m)<.9999999?(this._x=Math.atan2(-_,g),this._y=Math.atan2(-p,c)):(this._x=0,this._y=Math.atan2(d,M));break;case"XZY":this._z=Math.asin(-we(h,-1,1)),Math.abs(h)<.9999999?(this._x=Math.atan2(x,g),this._y=Math.atan2(d,c)):(this._x=Math.atan2(-_,M),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+i)}return this._order=i,r===!0&&this._onChangeCallback(),this}setFromQuaternion(e,i,r){return sx.makeRotationFromQuaternion(e),this.setFromRotationMatrix(sx,i,r)}setFromVector3(e,i=this._order){return this.set(e.x,e.y,e.z,i)}reorder(e){return ox.setFromEuler(this),this.setFromQuaternion(ox,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],i=0){return e[i]=this._x,e[i+1]=this._y,e[i+2]=this._z,e[i+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}na.DEFAULT_ORDER="XYZ";class Hy{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let R1=0;const lx=new J,Ws=new Ul,Sa=new an,fc=new J,gl=new J,C1=new J,w1=new Ul,ux=new J(1,0,0),cx=new J(0,1,0),fx=new J(0,0,1),hx={type:"added"},D1={type:"removed"},js={type:"childadded",child:null},Gd={type:"childremoved",child:null};class bn extends _o{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:R1++}),this.uuid=Dl(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=bn.DEFAULT_UP.clone();const e=new J,i=new na,r=new Ul,l=new J(1,1,1);function c(){r.setFromEuler(i,!1)}function h(){i.setFromQuaternion(r,void 0,!1)}i._onChange(c),r._onChange(h),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:i},quaternion:{configurable:!0,enumerable:!0,value:r},scale:{configurable:!0,enumerable:!0,value:l},modelViewMatrix:{value:new an},normalMatrix:{value:new me}}),this.matrix=new an,this.matrixWorld=new an,this.matrixAutoUpdate=bn.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=bn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Hy,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,i){this.quaternion.setFromAxisAngle(e,i)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,i){return Ws.setFromAxisAngle(e,i),this.quaternion.multiply(Ws),this}rotateOnWorldAxis(e,i){return Ws.setFromAxisAngle(e,i),this.quaternion.premultiply(Ws),this}rotateX(e){return this.rotateOnAxis(ux,e)}rotateY(e){return this.rotateOnAxis(cx,e)}rotateZ(e){return this.rotateOnAxis(fx,e)}translateOnAxis(e,i){return lx.copy(e).applyQuaternion(this.quaternion),this.position.add(lx.multiplyScalar(i)),this}translateX(e){return this.translateOnAxis(ux,e)}translateY(e){return this.translateOnAxis(cx,e)}translateZ(e){return this.translateOnAxis(fx,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Sa.copy(this.matrixWorld).invert())}lookAt(e,i,r){e.isVector3?fc.copy(e):fc.set(e,i,r);const l=this.parent;this.updateWorldMatrix(!0,!1),gl.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Sa.lookAt(gl,fc,this.up):Sa.lookAt(fc,gl,this.up),this.quaternion.setFromRotationMatrix(Sa),l&&(Sa.extractRotation(l.matrixWorld),Ws.setFromRotationMatrix(Sa),this.quaternion.premultiply(Ws.invert()))}add(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.add(arguments[i]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(hx),js.child=e,this.dispatchEvent(js),js.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let r=0;r<arguments.length;r++)this.remove(arguments[r]);return this}const i=this.children.indexOf(e);return i!==-1&&(e.parent=null,this.children.splice(i,1),e.dispatchEvent(D1),Gd.child=e,this.dispatchEvent(Gd),Gd.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Sa.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Sa.multiply(e.parent.matrixWorld)),e.applyMatrix4(Sa),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(hx),js.child=e,this.dispatchEvent(js),js.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,i){if(this[e]===i)return this;for(let r=0,l=this.children.length;r<l;r++){const h=this.children[r].getObjectByProperty(e,i);if(h!==void 0)return h}}getObjectsByProperty(e,i,r=[]){this[e]===i&&r.push(this);const l=this.children;for(let c=0,h=l.length;c<h;c++)l[c].getObjectsByProperty(e,i,r);return r}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(gl,e,C1),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(gl,w1,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const i=this.matrixWorld.elements;return e.set(i[8],i[9],i[10]).normalize()}raycast(){}traverse(e){e(this);const i=this.children;for(let r=0,l=i.length;r<l;r++)i[r].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const i=this.children;for(let r=0,l=i.length;r<l;r++)i[r].traverseVisible(e)}traverseAncestors(e){const i=this.parent;i!==null&&(e(i),i.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const i=this.children;for(let r=0,l=i.length;r<l;r++)i[r].updateMatrixWorld(e)}updateWorldMatrix(e,i){const r=this.parent;if(e===!0&&r!==null&&r.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),i===!0){const l=this.children;for(let c=0,h=l.length;c<h;c++)l[c].updateWorldMatrix(!1,!0)}}toJSON(e){const i=e===void 0||typeof e=="string",r={};i&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},r.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const l={};l.uuid=this.uuid,l.type=this.type,this.name!==""&&(l.name=this.name),this.castShadow===!0&&(l.castShadow=!0),this.receiveShadow===!0&&(l.receiveShadow=!0),this.visible===!1&&(l.visible=!1),this.frustumCulled===!1&&(l.frustumCulled=!1),this.renderOrder!==0&&(l.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(l.userData=this.userData),l.layers=this.layers.mask,l.matrix=this.matrix.toArray(),l.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(l.matrixAutoUpdate=!1),this.isInstancedMesh&&(l.type="InstancedMesh",l.count=this.count,l.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(l.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(l.type="BatchedMesh",l.perObjectFrustumCulled=this.perObjectFrustumCulled,l.sortObjects=this.sortObjects,l.drawRanges=this._drawRanges,l.reservedRanges=this._reservedRanges,l.geometryInfo=this._geometryInfo.map(d=>({...d,boundingBox:d.boundingBox?d.boundingBox.toJSON():void 0,boundingSphere:d.boundingSphere?d.boundingSphere.toJSON():void 0})),l.instanceInfo=this._instanceInfo.map(d=>({...d})),l.availableInstanceIds=this._availableInstanceIds.slice(),l.availableGeometryIds=this._availableGeometryIds.slice(),l.nextIndexStart=this._nextIndexStart,l.nextVertexStart=this._nextVertexStart,l.geometryCount=this._geometryCount,l.maxInstanceCount=this._maxInstanceCount,l.maxVertexCount=this._maxVertexCount,l.maxIndexCount=this._maxIndexCount,l.geometryInitialized=this._geometryInitialized,l.matricesTexture=this._matricesTexture.toJSON(e),l.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(l.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(l.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(l.boundingBox=this.boundingBox.toJSON()));function c(d,m){return d[m.uuid]===void 0&&(d[m.uuid]=m.toJSON(e)),m.uuid}if(this.isScene)this.background&&(this.background.isColor?l.background=this.background.toJSON():this.background.isTexture&&(l.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(l.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){l.geometry=c(e.geometries,this.geometry);const d=this.geometry.parameters;if(d!==void 0&&d.shapes!==void 0){const m=d.shapes;if(Array.isArray(m))for(let g=0,_=m.length;g<_;g++){const p=m[g];c(e.shapes,p)}else c(e.shapes,m)}}if(this.isSkinnedMesh&&(l.bindMode=this.bindMode,l.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(c(e.skeletons,this.skeleton),l.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const d=[];for(let m=0,g=this.material.length;m<g;m++)d.push(c(e.materials,this.material[m]));l.material=d}else l.material=c(e.materials,this.material);if(this.children.length>0){l.children=[];for(let d=0;d<this.children.length;d++)l.children.push(this.children[d].toJSON(e).object)}if(this.animations.length>0){l.animations=[];for(let d=0;d<this.animations.length;d++){const m=this.animations[d];l.animations.push(c(e.animations,m))}}if(i){const d=h(e.geometries),m=h(e.materials),g=h(e.textures),_=h(e.images),p=h(e.shapes),x=h(e.skeletons),M=h(e.animations),E=h(e.nodes);d.length>0&&(r.geometries=d),m.length>0&&(r.materials=m),g.length>0&&(r.textures=g),_.length>0&&(r.images=_),p.length>0&&(r.shapes=p),x.length>0&&(r.skeletons=x),M.length>0&&(r.animations=M),E.length>0&&(r.nodes=E)}return r.object=l,r;function h(d){const m=[];for(const g in d){const _=d[g];delete _.metadata,m.push(_)}return m}}clone(e){return new this.constructor().copy(this,e)}copy(e,i=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),i===!0)for(let r=0;r<e.children.length;r++){const l=e.children[r];this.add(l.clone())}return this}}bn.DEFAULT_UP=new J(0,1,0);bn.DEFAULT_MATRIX_AUTO_UPDATE=!0;bn.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Li=new J,Ma=new J,Vd=new J,Ea=new J,Zs=new J,Ks=new J,dx=new J,Xd=new J,kd=new J,qd=new J,Yd=new We,Wd=new We,jd=new We;class Oi{constructor(e=new J,i=new J,r=new J){this.a=e,this.b=i,this.c=r}static getNormal(e,i,r,l){l.subVectors(r,i),Li.subVectors(e,i),l.cross(Li);const c=l.lengthSq();return c>0?l.multiplyScalar(1/Math.sqrt(c)):l.set(0,0,0)}static getBarycoord(e,i,r,l,c){Li.subVectors(l,i),Ma.subVectors(r,i),Vd.subVectors(e,i);const h=Li.dot(Li),d=Li.dot(Ma),m=Li.dot(Vd),g=Ma.dot(Ma),_=Ma.dot(Vd),p=h*g-d*d;if(p===0)return c.set(0,0,0),null;const x=1/p,M=(g*m-d*_)*x,E=(h*_-d*m)*x;return c.set(1-M-E,E,M)}static containsPoint(e,i,r,l){return this.getBarycoord(e,i,r,l,Ea)===null?!1:Ea.x>=0&&Ea.y>=0&&Ea.x+Ea.y<=1}static getInterpolation(e,i,r,l,c,h,d,m){return this.getBarycoord(e,i,r,l,Ea)===null?(m.x=0,m.y=0,"z"in m&&(m.z=0),"w"in m&&(m.w=0),null):(m.setScalar(0),m.addScaledVector(c,Ea.x),m.addScaledVector(h,Ea.y),m.addScaledVector(d,Ea.z),m)}static getInterpolatedAttribute(e,i,r,l,c,h){return Yd.setScalar(0),Wd.setScalar(0),jd.setScalar(0),Yd.fromBufferAttribute(e,i),Wd.fromBufferAttribute(e,r),jd.fromBufferAttribute(e,l),h.setScalar(0),h.addScaledVector(Yd,c.x),h.addScaledVector(Wd,c.y),h.addScaledVector(jd,c.z),h}static isFrontFacing(e,i,r,l){return Li.subVectors(r,i),Ma.subVectors(e,i),Li.cross(Ma).dot(l)<0}set(e,i,r){return this.a.copy(e),this.b.copy(i),this.c.copy(r),this}setFromPointsAndIndices(e,i,r,l){return this.a.copy(e[i]),this.b.copy(e[r]),this.c.copy(e[l]),this}setFromAttributeAndIndices(e,i,r,l){return this.a.fromBufferAttribute(e,i),this.b.fromBufferAttribute(e,r),this.c.fromBufferAttribute(e,l),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Li.subVectors(this.c,this.b),Ma.subVectors(this.a,this.b),Li.cross(Ma).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return Oi.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,i){return Oi.getBarycoord(e,this.a,this.b,this.c,i)}getInterpolation(e,i,r,l,c){return Oi.getInterpolation(e,this.a,this.b,this.c,i,r,l,c)}containsPoint(e){return Oi.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return Oi.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,i){const r=this.a,l=this.b,c=this.c;let h,d;Zs.subVectors(l,r),Ks.subVectors(c,r),Xd.subVectors(e,r);const m=Zs.dot(Xd),g=Ks.dot(Xd);if(m<=0&&g<=0)return i.copy(r);kd.subVectors(e,l);const _=Zs.dot(kd),p=Ks.dot(kd);if(_>=0&&p<=_)return i.copy(l);const x=m*p-_*g;if(x<=0&&m>=0&&_<=0)return h=m/(m-_),i.copy(r).addScaledVector(Zs,h);qd.subVectors(e,c);const M=Zs.dot(qd),E=Ks.dot(qd);if(E>=0&&M<=E)return i.copy(c);const b=M*g-m*E;if(b<=0&&g>=0&&E<=0)return d=g/(g-E),i.copy(r).addScaledVector(Ks,d);const y=_*E-M*p;if(y<=0&&p-_>=0&&M-E>=0)return dx.subVectors(c,l),d=(p-_)/(p-_+(M-E)),i.copy(l).addScaledVector(dx,d);const S=1/(y+b+x);return h=b*S,d=x*S,i.copy(r).addScaledVector(Zs,h).addScaledVector(Ks,d)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Gy={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ur={h:0,s:0,l:0},hc={h:0,s:0,l:0};function Zd(o,e,i){return i<0&&(i+=1),i>1&&(i-=1),i<1/6?o+(e-o)*6*i:i<1/2?e:i<2/3?o+(e-o)*6*(2/3-i):o}class Se{constructor(e,i,r){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,i,r)}set(e,i,r){if(i===void 0&&r===void 0){const l=e;l&&l.isColor?this.copy(l):typeof l=="number"?this.setHex(l):typeof l=="string"&&this.setStyle(l)}else this.setRGB(e,i,r);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,i=Mi){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Oe.colorSpaceToWorking(this,i),this}setRGB(e,i,r,l=Oe.workingColorSpace){return this.r=e,this.g=i,this.b=r,Oe.colorSpaceToWorking(this,l),this}setHSL(e,i,r,l=Oe.workingColorSpace){if(e=m1(e,1),i=we(i,0,1),r=we(r,0,1),i===0)this.r=this.g=this.b=r;else{const c=r<=.5?r*(1+i):r+i-r*i,h=2*r-c;this.r=Zd(h,c,e+1/3),this.g=Zd(h,c,e),this.b=Zd(h,c,e-1/3)}return Oe.colorSpaceToWorking(this,l),this}setStyle(e,i=Mi){function r(c){c!==void 0&&parseFloat(c)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let l;if(l=/^(\w+)\(([^\)]*)\)/.exec(e)){let c;const h=l[1],d=l[2];switch(h){case"rgb":case"rgba":if(c=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(c[4]),this.setRGB(Math.min(255,parseInt(c[1],10))/255,Math.min(255,parseInt(c[2],10))/255,Math.min(255,parseInt(c[3],10))/255,i);if(c=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(c[4]),this.setRGB(Math.min(100,parseInt(c[1],10))/100,Math.min(100,parseInt(c[2],10))/100,Math.min(100,parseInt(c[3],10))/100,i);break;case"hsl":case"hsla":if(c=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(d))return r(c[4]),this.setHSL(parseFloat(c[1])/360,parseFloat(c[2])/100,parseFloat(c[3])/100,i);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(l=/^\#([A-Fa-f\d]+)$/.exec(e)){const c=l[1],h=c.length;if(h===3)return this.setRGB(parseInt(c.charAt(0),16)/15,parseInt(c.charAt(1),16)/15,parseInt(c.charAt(2),16)/15,i);if(h===6)return this.setHex(parseInt(c,16),i);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,i);return this}setColorName(e,i=Mi){const r=Gy[e.toLowerCase()];return r!==void 0?this.setHex(r,i):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ra(e.r),this.g=Ra(e.g),this.b=Ra(e.b),this}copyLinearToSRGB(e){return this.r=so(e.r),this.g=so(e.g),this.b=so(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Mi){return Oe.workingToColorSpace(In.copy(this),e),Math.round(we(In.r*255,0,255))*65536+Math.round(we(In.g*255,0,255))*256+Math.round(we(In.b*255,0,255))}getHexString(e=Mi){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,i=Oe.workingColorSpace){Oe.workingToColorSpace(In.copy(this),i);const r=In.r,l=In.g,c=In.b,h=Math.max(r,l,c),d=Math.min(r,l,c);let m,g;const _=(d+h)/2;if(d===h)m=0,g=0;else{const p=h-d;switch(g=_<=.5?p/(h+d):p/(2-h-d),h){case r:m=(l-c)/p+(l<c?6:0);break;case l:m=(c-r)/p+2;break;case c:m=(r-l)/p+4;break}m/=6}return e.h=m,e.s=g,e.l=_,e}getRGB(e,i=Oe.workingColorSpace){return Oe.workingToColorSpace(In.copy(this),i),e.r=In.r,e.g=In.g,e.b=In.b,e}getStyle(e=Mi){Oe.workingToColorSpace(In.copy(this),e);const i=In.r,r=In.g,l=In.b;return e!==Mi?`color(${e} ${i.toFixed(3)} ${r.toFixed(3)} ${l.toFixed(3)})`:`rgb(${Math.round(i*255)},${Math.round(r*255)},${Math.round(l*255)})`}offsetHSL(e,i,r){return this.getHSL(ur),this.setHSL(ur.h+e,ur.s+i,ur.l+r)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,i){return this.r=e.r+i.r,this.g=e.g+i.g,this.b=e.b+i.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,i){return this.r+=(e.r-this.r)*i,this.g+=(e.g-this.g)*i,this.b+=(e.b-this.b)*i,this}lerpColors(e,i,r){return this.r=e.r+(i.r-e.r)*r,this.g=e.g+(i.g-e.g)*r,this.b=e.b+(i.b-e.b)*r,this}lerpHSL(e,i){this.getHSL(ur),e.getHSL(hc);const r=Ud(ur.h,hc.h,i),l=Ud(ur.s,hc.s,i),c=Ud(ur.l,hc.l,i);return this.setHSL(r,l,c),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const i=this.r,r=this.g,l=this.b,c=e.elements;return this.r=c[0]*i+c[3]*r+c[6]*l,this.g=c[1]*i+c[4]*r+c[7]*l,this.b=c[2]*i+c[5]*r+c[8]*l,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,i=0){return this.r=e[i],this.g=e[i+1],this.b=e[i+2],this}toArray(e=[],i=0){return e[i]=this.r,e[i+1]=this.g,e[i+2]=this.b,e}fromBufferAttribute(e,i){return this.r=e.getX(i),this.g=e.getY(i),this.b=e.getZ(i),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const In=new Se;Se.NAMES=Gy;let U1=0;class vo extends _o{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:U1++}),this.uuid=Dl(),this.name="",this.type="Material",this.blending=ro,this.side=mr,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=fp,this.blendDst=hp,this.blendEquation=Zr,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Se(0,0,0),this.blendAlpha=0,this.depthFunc=uo,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=$0,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Gs,this.stencilZFail=Gs,this.stencilZPass=Gs,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const i in e){const r=e[i];if(r===void 0){console.warn(`THREE.Material: parameter '${i}' has value of undefined.`);continue}const l=this[i];if(l===void 0){console.warn(`THREE.Material: '${i}' is not a property of THREE.${this.type}.`);continue}l&&l.isColor?l.set(r):l&&l.isVector3&&r&&r.isVector3?l.copy(r):this[i]=r}}toJSON(e){const i=e===void 0||typeof e=="string";i&&(e={textures:{},images:{}});const r={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.color&&this.color.isColor&&(r.color=this.color.getHex()),this.roughness!==void 0&&(r.roughness=this.roughness),this.metalness!==void 0&&(r.metalness=this.metalness),this.sheen!==void 0&&(r.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(r.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(r.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(r.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(r.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(r.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(r.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(r.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(r.shininess=this.shininess),this.clearcoat!==void 0&&(r.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(r.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(r.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(r.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(r.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,r.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(r.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(r.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(r.dispersion=this.dispersion),this.iridescence!==void 0&&(r.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(r.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(r.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(r.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(r.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(r.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(r.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(r.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(r.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(r.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(r.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(r.lightMap=this.lightMap.toJSON(e).uuid,r.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(r.aoMap=this.aoMap.toJSON(e).uuid,r.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(r.bumpMap=this.bumpMap.toJSON(e).uuid,r.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(r.normalMap=this.normalMap.toJSON(e).uuid,r.normalMapType=this.normalMapType,r.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(r.displacementMap=this.displacementMap.toJSON(e).uuid,r.displacementScale=this.displacementScale,r.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(r.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(r.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(r.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(r.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(r.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(r.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(r.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(r.combine=this.combine)),this.envMapRotation!==void 0&&(r.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(r.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(r.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(r.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(r.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(r.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(r.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(r.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(r.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(r.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(r.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(r.size=this.size),this.shadowSide!==null&&(r.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(r.sizeAttenuation=this.sizeAttenuation),this.blending!==ro&&(r.blending=this.blending),this.side!==mr&&(r.side=this.side),this.vertexColors===!0&&(r.vertexColors=!0),this.opacity<1&&(r.opacity=this.opacity),this.transparent===!0&&(r.transparent=!0),this.blendSrc!==fp&&(r.blendSrc=this.blendSrc),this.blendDst!==hp&&(r.blendDst=this.blendDst),this.blendEquation!==Zr&&(r.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(r.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(r.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(r.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(r.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(r.blendAlpha=this.blendAlpha),this.depthFunc!==uo&&(r.depthFunc=this.depthFunc),this.depthTest===!1&&(r.depthTest=this.depthTest),this.depthWrite===!1&&(r.depthWrite=this.depthWrite),this.colorWrite===!1&&(r.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(r.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==$0&&(r.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(r.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(r.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Gs&&(r.stencilFail=this.stencilFail),this.stencilZFail!==Gs&&(r.stencilZFail=this.stencilZFail),this.stencilZPass!==Gs&&(r.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(r.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(r.rotation=this.rotation),this.polygonOffset===!0&&(r.polygonOffset=!0),this.polygonOffsetFactor!==0&&(r.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(r.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(r.linewidth=this.linewidth),this.dashSize!==void 0&&(r.dashSize=this.dashSize),this.gapSize!==void 0&&(r.gapSize=this.gapSize),this.scale!==void 0&&(r.scale=this.scale),this.dithering===!0&&(r.dithering=!0),this.alphaTest>0&&(r.alphaTest=this.alphaTest),this.alphaHash===!0&&(r.alphaHash=!0),this.alphaToCoverage===!0&&(r.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(r.premultipliedAlpha=!0),this.forceSinglePass===!0&&(r.forceSinglePass=!0),this.wireframe===!0&&(r.wireframe=!0),this.wireframeLinewidth>1&&(r.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(r.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(r.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(r.flatShading=!0),this.visible===!1&&(r.visible=!1),this.toneMapped===!1&&(r.toneMapped=!1),this.fog===!1&&(r.fog=!1),Object.keys(this.userData).length>0&&(r.userData=this.userData);function l(c){const h=[];for(const d in c){const m=c[d];delete m.metadata,h.push(m)}return h}if(i){const c=l(e.textures),h=l(e.images);c.length>0&&(r.textures=c),h.length>0&&(r.images=h)}return r}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const i=e.clippingPlanes;let r=null;if(i!==null){const l=i.length;r=new Array(l);for(let c=0;c!==l;++c)r[c]=i[c].clone()}return this.clippingPlanes=r,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}class xm extends vo{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Se(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new na,this.combine=Ty,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const pn=new J,dc=new be;let N1=0;class Bi{constructor(e,i,r=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:N1++}),this.name="",this.array=e,this.itemSize=i,this.count=e!==void 0?e.length/i:0,this.normalized=r,this.usage=tx,this.updateRanges=[],this.gpuType=Aa,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,i){this.updateRanges.push({start:e,count:i})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,i,r){e*=this.itemSize,r*=i.itemSize;for(let l=0,c=this.itemSize;l<c;l++)this.array[e+l]=i.array[r+l];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let i=0,r=this.count;i<r;i++)dc.fromBufferAttribute(this,i),dc.applyMatrix3(e),this.setXY(i,dc.x,dc.y);else if(this.itemSize===3)for(let i=0,r=this.count;i<r;i++)pn.fromBufferAttribute(this,i),pn.applyMatrix3(e),this.setXYZ(i,pn.x,pn.y,pn.z);return this}applyMatrix4(e){for(let i=0,r=this.count;i<r;i++)pn.fromBufferAttribute(this,i),pn.applyMatrix4(e),this.setXYZ(i,pn.x,pn.y,pn.z);return this}applyNormalMatrix(e){for(let i=0,r=this.count;i<r;i++)pn.fromBufferAttribute(this,i),pn.applyNormalMatrix(e),this.setXYZ(i,pn.x,pn.y,pn.z);return this}transformDirection(e){for(let i=0,r=this.count;i<r;i++)pn.fromBufferAttribute(this,i),pn.transformDirection(e),this.setXYZ(i,pn.x,pn.y,pn.z);return this}set(e,i=0){return this.array.set(e,i),this}getComponent(e,i){let r=this.array[e*this.itemSize+i];return this.normalized&&(r=dl(r,this.array)),r}setComponent(e,i,r){return this.normalized&&(r=Kn(r,this.array)),this.array[e*this.itemSize+i]=r,this}getX(e){let i=this.array[e*this.itemSize];return this.normalized&&(i=dl(i,this.array)),i}setX(e,i){return this.normalized&&(i=Kn(i,this.array)),this.array[e*this.itemSize]=i,this}getY(e){let i=this.array[e*this.itemSize+1];return this.normalized&&(i=dl(i,this.array)),i}setY(e,i){return this.normalized&&(i=Kn(i,this.array)),this.array[e*this.itemSize+1]=i,this}getZ(e){let i=this.array[e*this.itemSize+2];return this.normalized&&(i=dl(i,this.array)),i}setZ(e,i){return this.normalized&&(i=Kn(i,this.array)),this.array[e*this.itemSize+2]=i,this}getW(e){let i=this.array[e*this.itemSize+3];return this.normalized&&(i=dl(i,this.array)),i}setW(e,i){return this.normalized&&(i=Kn(i,this.array)),this.array[e*this.itemSize+3]=i,this}setXY(e,i,r){return e*=this.itemSize,this.normalized&&(i=Kn(i,this.array),r=Kn(r,this.array)),this.array[e+0]=i,this.array[e+1]=r,this}setXYZ(e,i,r,l){return e*=this.itemSize,this.normalized&&(i=Kn(i,this.array),r=Kn(r,this.array),l=Kn(l,this.array)),this.array[e+0]=i,this.array[e+1]=r,this.array[e+2]=l,this}setXYZW(e,i,r,l,c){return e*=this.itemSize,this.normalized&&(i=Kn(i,this.array),r=Kn(r,this.array),l=Kn(l,this.array),c=Kn(c,this.array)),this.array[e+0]=i,this.array[e+1]=r,this.array[e+2]=l,this.array[e+3]=c,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==tx&&(e.usage=this.usage),e}}class Vy extends Bi{constructor(e,i,r){super(new Uint16Array(e),i,r)}}class Xy extends Bi{constructor(e,i,r){super(new Uint32Array(e),i,r)}}class Bn extends Bi{constructor(e,i,r){super(new Float32Array(e),i,r)}}let L1=0;const Si=new an,Kd=new bn,Qs=new J,ui=new Nl,_l=new Nl,Tn=new J;class Ti extends _o{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:L1++}),this.uuid=Dl(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Iy(e)?Xy:Vy)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,i){return this.attributes[e]=i,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,i,r=0){this.groups.push({start:e,count:i,materialIndex:r})}clearGroups(){this.groups=[]}setDrawRange(e,i){this.drawRange.start=e,this.drawRange.count=i}applyMatrix4(e){const i=this.attributes.position;i!==void 0&&(i.applyMatrix4(e),i.needsUpdate=!0);const r=this.attributes.normal;if(r!==void 0){const c=new me().getNormalMatrix(e);r.applyNormalMatrix(c),r.needsUpdate=!0}const l=this.attributes.tangent;return l!==void 0&&(l.transformDirection(e),l.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Si.makeRotationFromQuaternion(e),this.applyMatrix4(Si),this}rotateX(e){return Si.makeRotationX(e),this.applyMatrix4(Si),this}rotateY(e){return Si.makeRotationY(e),this.applyMatrix4(Si),this}rotateZ(e){return Si.makeRotationZ(e),this.applyMatrix4(Si),this}translate(e,i,r){return Si.makeTranslation(e,i,r),this.applyMatrix4(Si),this}scale(e,i,r){return Si.makeScale(e,i,r),this.applyMatrix4(Si),this}lookAt(e){return Kd.lookAt(e),Kd.updateMatrix(),this.applyMatrix4(Kd.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Qs).negate(),this.translate(Qs.x,Qs.y,Qs.z),this}setFromPoints(e){const i=this.getAttribute("position");if(i===void 0){const r=[];for(let l=0,c=e.length;l<c;l++){const h=e[l];r.push(h.x,h.y,h.z||0)}this.setAttribute("position",new Bn(r,3))}else{const r=Math.min(e.length,i.count);for(let l=0;l<r;l++){const c=e[l];i.setXYZ(l,c.x,c.y,c.z||0)}e.length>i.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),i.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Nl);const e=this.attributes.position,i=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new J(-1/0,-1/0,-1/0),new J(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),i)for(let r=0,l=i.length;r<l;r++){const c=i[r];ui.setFromBufferAttribute(c),this.morphTargetsRelative?(Tn.addVectors(this.boundingBox.min,ui.min),this.boundingBox.expandByPoint(Tn),Tn.addVectors(this.boundingBox.max,ui.max),this.boundingBox.expandByPoint(Tn)):(this.boundingBox.expandByPoint(ui.min),this.boundingBox.expandByPoint(ui.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Xc);const e=this.attributes.position,i=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new J,1/0);return}if(e){const r=this.boundingSphere.center;if(ui.setFromBufferAttribute(e),i)for(let c=0,h=i.length;c<h;c++){const d=i[c];_l.setFromBufferAttribute(d),this.morphTargetsRelative?(Tn.addVectors(ui.min,_l.min),ui.expandByPoint(Tn),Tn.addVectors(ui.max,_l.max),ui.expandByPoint(Tn)):(ui.expandByPoint(_l.min),ui.expandByPoint(_l.max))}ui.getCenter(r);let l=0;for(let c=0,h=e.count;c<h;c++)Tn.fromBufferAttribute(e,c),l=Math.max(l,r.distanceToSquared(Tn));if(i)for(let c=0,h=i.length;c<h;c++){const d=i[c],m=this.morphTargetsRelative;for(let g=0,_=d.count;g<_;g++)Tn.fromBufferAttribute(d,g),m&&(Qs.fromBufferAttribute(e,g),Tn.add(Qs)),l=Math.max(l,r.distanceToSquared(Tn))}this.boundingSphere.radius=Math.sqrt(l),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,i=this.attributes;if(e===null||i.position===void 0||i.normal===void 0||i.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const r=i.position,l=i.normal,c=i.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Bi(new Float32Array(4*r.count),4));const h=this.getAttribute("tangent"),d=[],m=[];for(let B=0;B<r.count;B++)d[B]=new J,m[B]=new J;const g=new J,_=new J,p=new J,x=new be,M=new be,E=new be,b=new J,y=new J;function S(B,C,R){g.fromBufferAttribute(r,B),_.fromBufferAttribute(r,C),p.fromBufferAttribute(r,R),x.fromBufferAttribute(c,B),M.fromBufferAttribute(c,C),E.fromBufferAttribute(c,R),_.sub(g),p.sub(g),M.sub(x),E.sub(x);const G=1/(M.x*E.y-E.x*M.y);isFinite(G)&&(b.copy(_).multiplyScalar(E.y).addScaledVector(p,-M.y).multiplyScalar(G),y.copy(p).multiplyScalar(M.x).addScaledVector(_,-E.x).multiplyScalar(G),d[B].add(b),d[C].add(b),d[R].add(b),m[B].add(y),m[C].add(y),m[R].add(y))}let U=this.groups;U.length===0&&(U=[{start:0,count:e.count}]);for(let B=0,C=U.length;B<C;++B){const R=U[B],G=R.start,Z=R.count;for(let et=G,ct=G+Z;et<ct;et+=3)S(e.getX(et+0),e.getX(et+1),e.getX(et+2))}const N=new J,D=new J,I=new J,z=new J;function L(B){I.fromBufferAttribute(l,B),z.copy(I);const C=d[B];N.copy(C),N.sub(I.multiplyScalar(I.dot(C))).normalize(),D.crossVectors(z,C);const G=D.dot(m[B])<0?-1:1;h.setXYZW(B,N.x,N.y,N.z,G)}for(let B=0,C=U.length;B<C;++B){const R=U[B],G=R.start,Z=R.count;for(let et=G,ct=G+Z;et<ct;et+=3)L(e.getX(et+0)),L(e.getX(et+1)),L(e.getX(et+2))}}computeVertexNormals(){const e=this.index,i=this.getAttribute("position");if(i!==void 0){let r=this.getAttribute("normal");if(r===void 0)r=new Bi(new Float32Array(i.count*3),3),this.setAttribute("normal",r);else for(let x=0,M=r.count;x<M;x++)r.setXYZ(x,0,0,0);const l=new J,c=new J,h=new J,d=new J,m=new J,g=new J,_=new J,p=new J;if(e)for(let x=0,M=e.count;x<M;x+=3){const E=e.getX(x+0),b=e.getX(x+1),y=e.getX(x+2);l.fromBufferAttribute(i,E),c.fromBufferAttribute(i,b),h.fromBufferAttribute(i,y),_.subVectors(h,c),p.subVectors(l,c),_.cross(p),d.fromBufferAttribute(r,E),m.fromBufferAttribute(r,b),g.fromBufferAttribute(r,y),d.add(_),m.add(_),g.add(_),r.setXYZ(E,d.x,d.y,d.z),r.setXYZ(b,m.x,m.y,m.z),r.setXYZ(y,g.x,g.y,g.z)}else for(let x=0,M=i.count;x<M;x+=3)l.fromBufferAttribute(i,x+0),c.fromBufferAttribute(i,x+1),h.fromBufferAttribute(i,x+2),_.subVectors(h,c),p.subVectors(l,c),_.cross(p),r.setXYZ(x+0,_.x,_.y,_.z),r.setXYZ(x+1,_.x,_.y,_.z),r.setXYZ(x+2,_.x,_.y,_.z);this.normalizeNormals(),r.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let i=0,r=e.count;i<r;i++)Tn.fromBufferAttribute(e,i),Tn.normalize(),e.setXYZ(i,Tn.x,Tn.y,Tn.z)}toNonIndexed(){function e(d,m){const g=d.array,_=d.itemSize,p=d.normalized,x=new g.constructor(m.length*_);let M=0,E=0;for(let b=0,y=m.length;b<y;b++){d.isInterleavedBufferAttribute?M=m[b]*d.data.stride+d.offset:M=m[b]*_;for(let S=0;S<_;S++)x[E++]=g[M++]}return new Bi(x,_,p)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const i=new Ti,r=this.index.array,l=this.attributes;for(const d in l){const m=l[d],g=e(m,r);i.setAttribute(d,g)}const c=this.morphAttributes;for(const d in c){const m=[],g=c[d];for(let _=0,p=g.length;_<p;_++){const x=g[_],M=e(x,r);m.push(M)}i.morphAttributes[d]=m}i.morphTargetsRelative=this.morphTargetsRelative;const h=this.groups;for(let d=0,m=h.length;d<m;d++){const g=h[d];i.addGroup(g.start,g.count,g.materialIndex)}return i}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const m=this.parameters;for(const g in m)m[g]!==void 0&&(e[g]=m[g]);return e}e.data={attributes:{}};const i=this.index;i!==null&&(e.data.index={type:i.array.constructor.name,array:Array.prototype.slice.call(i.array)});const r=this.attributes;for(const m in r){const g=r[m];e.data.attributes[m]=g.toJSON(e.data)}const l={};let c=!1;for(const m in this.morphAttributes){const g=this.morphAttributes[m],_=[];for(let p=0,x=g.length;p<x;p++){const M=g[p];_.push(M.toJSON(e.data))}_.length>0&&(l[m]=_,c=!0)}c&&(e.data.morphAttributes=l,e.data.morphTargetsRelative=this.morphTargetsRelative);const h=this.groups;h.length>0&&(e.data.groups=JSON.parse(JSON.stringify(h)));const d=this.boundingSphere;return d!==null&&(e.data.boundingSphere=d.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const i={};this.name=e.name;const r=e.index;r!==null&&this.setIndex(r.clone());const l=e.attributes;for(const g in l){const _=l[g];this.setAttribute(g,_.clone(i))}const c=e.morphAttributes;for(const g in c){const _=[],p=c[g];for(let x=0,M=p.length;x<M;x++)_.push(p[x].clone(i));this.morphAttributes[g]=_}this.morphTargetsRelative=e.morphTargetsRelative;const h=e.groups;for(let g=0,_=h.length;g<_;g++){const p=h[g];this.addGroup(p.start,p.count,p.materialIndex)}const d=e.boundingBox;d!==null&&(this.boundingBox=d.clone());const m=e.boundingSphere;return m!==null&&(this.boundingSphere=m.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const px=new an,Xr=new Fy,pc=new Xc,mx=new J,mc=new J,gc=new J,_c=new J,Qd=new J,vc=new J,gx=new J,xc=new J;class Nn extends bn{constructor(e=new Ti,i=new xm){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,i){return super.copy(e,i),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const i=this.geometry.morphAttributes,r=Object.keys(i);if(r.length>0){const l=i[r[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,h=l.length;c<h;c++){const d=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=c}}}}getVertexPosition(e,i){const r=this.geometry,l=r.attributes.position,c=r.morphAttributes.position,h=r.morphTargetsRelative;i.fromBufferAttribute(l,e);const d=this.morphTargetInfluences;if(c&&d){vc.set(0,0,0);for(let m=0,g=c.length;m<g;m++){const _=d[m],p=c[m];_!==0&&(Qd.fromBufferAttribute(p,e),h?vc.addScaledVector(Qd,_):vc.addScaledVector(Qd.sub(i),_))}i.add(vc)}return i}raycast(e,i){const r=this.geometry,l=this.material,c=this.matrixWorld;l!==void 0&&(r.boundingSphere===null&&r.computeBoundingSphere(),pc.copy(r.boundingSphere),pc.applyMatrix4(c),Xr.copy(e.ray).recast(e.near),!(pc.containsPoint(Xr.origin)===!1&&(Xr.intersectSphere(pc,mx)===null||Xr.origin.distanceToSquared(mx)>(e.far-e.near)**2))&&(px.copy(c).invert(),Xr.copy(e.ray).applyMatrix4(px),!(r.boundingBox!==null&&Xr.intersectsBox(r.boundingBox)===!1)&&this._computeIntersections(e,i,Xr)))}_computeIntersections(e,i,r){let l;const c=this.geometry,h=this.material,d=c.index,m=c.attributes.position,g=c.attributes.uv,_=c.attributes.uv1,p=c.attributes.normal,x=c.groups,M=c.drawRange;if(d!==null)if(Array.isArray(h))for(let E=0,b=x.length;E<b;E++){const y=x[E],S=h[y.materialIndex],U=Math.max(y.start,M.start),N=Math.min(d.count,Math.min(y.start+y.count,M.start+M.count));for(let D=U,I=N;D<I;D+=3){const z=d.getX(D),L=d.getX(D+1),B=d.getX(D+2);l=yc(this,S,e,r,g,_,p,z,L,B),l&&(l.faceIndex=Math.floor(D/3),l.face.materialIndex=y.materialIndex,i.push(l))}}else{const E=Math.max(0,M.start),b=Math.min(d.count,M.start+M.count);for(let y=E,S=b;y<S;y+=3){const U=d.getX(y),N=d.getX(y+1),D=d.getX(y+2);l=yc(this,h,e,r,g,_,p,U,N,D),l&&(l.faceIndex=Math.floor(y/3),i.push(l))}}else if(m!==void 0)if(Array.isArray(h))for(let E=0,b=x.length;E<b;E++){const y=x[E],S=h[y.materialIndex],U=Math.max(y.start,M.start),N=Math.min(m.count,Math.min(y.start+y.count,M.start+M.count));for(let D=U,I=N;D<I;D+=3){const z=D,L=D+1,B=D+2;l=yc(this,S,e,r,g,_,p,z,L,B),l&&(l.faceIndex=Math.floor(D/3),l.face.materialIndex=y.materialIndex,i.push(l))}}else{const E=Math.max(0,M.start),b=Math.min(m.count,M.start+M.count);for(let y=E,S=b;y<S;y+=3){const U=y,N=y+1,D=y+2;l=yc(this,h,e,r,g,_,p,U,N,D),l&&(l.faceIndex=Math.floor(y/3),i.push(l))}}}}function O1(o,e,i,r,l,c,h,d){let m;if(e.side===Qn?m=r.intersectTriangle(h,c,l,!0,d):m=r.intersectTriangle(l,c,h,e.side===mr,d),m===null)return null;xc.copy(d),xc.applyMatrix4(o.matrixWorld);const g=i.ray.origin.distanceTo(xc);return g<i.near||g>i.far?null:{distance:g,point:xc.clone(),object:o}}function yc(o,e,i,r,l,c,h,d,m,g){o.getVertexPosition(d,mc),o.getVertexPosition(m,gc),o.getVertexPosition(g,_c);const _=O1(o,e,i,r,mc,gc,_c,gx);if(_){const p=new J;Oi.getBarycoord(gx,mc,gc,_c,p),l&&(_.uv=Oi.getInterpolatedAttribute(l,d,m,g,p,new be)),c&&(_.uv1=Oi.getInterpolatedAttribute(c,d,m,g,p,new be)),h&&(_.normal=Oi.getInterpolatedAttribute(h,d,m,g,p,new J),_.normal.dot(r.direction)>0&&_.normal.multiplyScalar(-1));const x={a:d,b:m,c:g,normal:new J,materialIndex:0};Oi.getNormal(mc,gc,_c,x.normal),_.face=x,_.barycoord=p}return _}class Ll extends Ti{constructor(e=1,i=1,r=1,l=1,c=1,h=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:i,depth:r,widthSegments:l,heightSegments:c,depthSegments:h};const d=this;l=Math.floor(l),c=Math.floor(c),h=Math.floor(h);const m=[],g=[],_=[],p=[];let x=0,M=0;E("z","y","x",-1,-1,r,i,e,h,c,0),E("z","y","x",1,-1,r,i,-e,h,c,1),E("x","z","y",1,1,e,r,i,l,h,2),E("x","z","y",1,-1,e,r,-i,l,h,3),E("x","y","z",1,-1,e,i,r,l,c,4),E("x","y","z",-1,-1,e,i,-r,l,c,5),this.setIndex(m),this.setAttribute("position",new Bn(g,3)),this.setAttribute("normal",new Bn(_,3)),this.setAttribute("uv",new Bn(p,2));function E(b,y,S,U,N,D,I,z,L,B,C){const R=D/L,G=I/B,Z=D/2,et=I/2,ct=z/2,st=L+1,k=B+1;let it=0,j=0;const xt=new J;for(let Mt=0;Mt<k;Mt++){const Ht=Mt*G-et;for(let oe=0;oe<st;oe++){const xe=oe*R-Z;xt[b]=xe*U,xt[y]=Ht*N,xt[S]=ct,g.push(xt.x,xt.y,xt.z),xt[b]=0,xt[y]=0,xt[S]=z>0?1:-1,_.push(xt.x,xt.y,xt.z),p.push(oe/L),p.push(1-Mt/B),it+=1}}for(let Mt=0;Mt<B;Mt++)for(let Ht=0;Ht<L;Ht++){const oe=x+Ht+st*Mt,xe=x+Ht+st*(Mt+1),H=x+(Ht+1)+st*(Mt+1),ft=x+(Ht+1)+st*Mt;m.push(oe,xe,ft),m.push(xe,H,ft),j+=6}d.addGroup(M,j,C),M+=j,x+=it}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Ll(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function po(o){const e={};for(const i in o){e[i]={};for(const r in o[i]){const l=o[i][r];l&&(l.isColor||l.isMatrix3||l.isMatrix4||l.isVector2||l.isVector3||l.isVector4||l.isTexture||l.isQuaternion)?l.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[i][r]=null):e[i][r]=l.clone():Array.isArray(l)?e[i][r]=l.slice():e[i][r]=l}}return e}function kn(o){const e={};for(let i=0;i<o.length;i++){const r=po(o[i]);for(const l in r)e[l]=r[l]}return e}function P1(o){const e=[];for(let i=0;i<o.length;i++)e.push(o[i].clone());return e}function ky(o){const e=o.getRenderTarget();return e===null?o.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Oe.workingColorSpace}const z1={clone:po,merge:kn};var I1=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,B1=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class gr extends vo{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=I1,this.fragmentShader=B1,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=po(e.uniforms),this.uniformsGroups=P1(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const i=super.toJSON(e);i.glslVersion=this.glslVersion,i.uniforms={};for(const l in this.uniforms){const h=this.uniforms[l].value;h&&h.isTexture?i.uniforms[l]={type:"t",value:h.toJSON(e).uuid}:h&&h.isColor?i.uniforms[l]={type:"c",value:h.getHex()}:h&&h.isVector2?i.uniforms[l]={type:"v2",value:h.toArray()}:h&&h.isVector3?i.uniforms[l]={type:"v3",value:h.toArray()}:h&&h.isVector4?i.uniforms[l]={type:"v4",value:h.toArray()}:h&&h.isMatrix3?i.uniforms[l]={type:"m3",value:h.toArray()}:h&&h.isMatrix4?i.uniforms[l]={type:"m4",value:h.toArray()}:i.uniforms[l]={value:h}}Object.keys(this.defines).length>0&&(i.defines=this.defines),i.vertexShader=this.vertexShader,i.fragmentShader=this.fragmentShader,i.lights=this.lights,i.clipping=this.clipping;const r={};for(const l in this.extensions)this.extensions[l]===!0&&(r[l]=!0);return Object.keys(r).length>0&&(i.extensions=r),i}}class qy extends bn{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new an,this.projectionMatrix=new an,this.projectionMatrixInverse=new an,this.coordinateSystem=$i,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,i){return super.copy(e,i),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,i){super.updateWorldMatrix(e,i),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const cr=new J,_x=new be,vx=new be;class ci extends qy{constructor(e=50,i=1,r=.1,l=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=r,this.far=l,this.focus=10,this.aspect=i,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,i){return super.copy(e,i),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const i=.5*this.getFilmHeight()/e;this.fov=Jp*2*Math.atan(i),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Dd*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return Jp*2*Math.atan(Math.tan(Dd*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,i,r){cr.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(cr.x,cr.y).multiplyScalar(-e/cr.z),cr.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),r.set(cr.x,cr.y).multiplyScalar(-e/cr.z)}getViewSize(e,i){return this.getViewBounds(e,_x,vx),i.subVectors(vx,_x)}setViewOffset(e,i,r,l,c,h){this.aspect=e/i,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=i,this.view.offsetX=r,this.view.offsetY=l,this.view.width=c,this.view.height=h,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let i=e*Math.tan(Dd*.5*this.fov)/this.zoom,r=2*i,l=this.aspect*r,c=-.5*l;const h=this.view;if(this.view!==null&&this.view.enabled){const m=h.fullWidth,g=h.fullHeight;c+=h.offsetX*l/m,i-=h.offsetY*r/g,l*=h.width/m,r*=h.height/g}const d=this.filmOffset;d!==0&&(c+=e*d/this.getFilmWidth()),this.projectionMatrix.makePerspective(c,c+l,i,i-r,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const i=super.toJSON(e);return i.object.fov=this.fov,i.object.zoom=this.zoom,i.object.near=this.near,i.object.far=this.far,i.object.focus=this.focus,i.object.aspect=this.aspect,this.view!==null&&(i.object.view=Object.assign({},this.view)),i.object.filmGauge=this.filmGauge,i.object.filmOffset=this.filmOffset,i}}const Js=-90,$s=1;class F1 extends bn{constructor(e,i,r){super(),this.type="CubeCamera",this.renderTarget=r,this.coordinateSystem=null,this.activeMipmapLevel=0;const l=new ci(Js,$s,e,i);l.layers=this.layers,this.add(l);const c=new ci(Js,$s,e,i);c.layers=this.layers,this.add(c);const h=new ci(Js,$s,e,i);h.layers=this.layers,this.add(h);const d=new ci(Js,$s,e,i);d.layers=this.layers,this.add(d);const m=new ci(Js,$s,e,i);m.layers=this.layers,this.add(m);const g=new ci(Js,$s,e,i);g.layers=this.layers,this.add(g)}updateCoordinateSystem(){const e=this.coordinateSystem,i=this.children.concat(),[r,l,c,h,d,m]=i;for(const g of i)this.remove(g);if(e===$i)r.up.set(0,1,0),r.lookAt(1,0,0),l.up.set(0,1,0),l.lookAt(-1,0,0),c.up.set(0,0,-1),c.lookAt(0,1,0),h.up.set(0,0,1),h.lookAt(0,-1,0),d.up.set(0,1,0),d.lookAt(0,0,1),m.up.set(0,1,0),m.lookAt(0,0,-1);else if(e===zc)r.up.set(0,-1,0),r.lookAt(-1,0,0),l.up.set(0,-1,0),l.lookAt(1,0,0),c.up.set(0,0,1),c.lookAt(0,1,0),h.up.set(0,0,-1),h.lookAt(0,-1,0),d.up.set(0,-1,0),d.lookAt(0,0,1),m.up.set(0,-1,0),m.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const g of i)this.add(g),g.updateMatrixWorld()}update(e,i){this.parent===null&&this.updateMatrixWorld();const{renderTarget:r,activeMipmapLevel:l}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[c,h,d,m,g,_]=this.children,p=e.getRenderTarget(),x=e.getActiveCubeFace(),M=e.getActiveMipmapLevel(),E=e.xr.enabled;e.xr.enabled=!1;const b=r.texture.generateMipmaps;r.texture.generateMipmaps=!1,e.setRenderTarget(r,0,l),e.render(i,c),e.setRenderTarget(r,1,l),e.render(i,h),e.setRenderTarget(r,2,l),e.render(i,d),e.setRenderTarget(r,3,l),e.render(i,m),e.setRenderTarget(r,4,l),e.render(i,g),r.texture.generateMipmaps=b,e.setRenderTarget(r,5,l),e.render(i,_),e.setRenderTarget(p,x,M),e.xr.enabled=E,r.texture.needsPMREMUpdate=!0}}class Yy extends Jn{constructor(e=[],i=co,r,l,c,h,d,m,g,_){super(e,i,r,l,c,h,d,m,g,_),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class H1 extends ts{constructor(e=1,i={}){super(e,e,i),this.isWebGLCubeRenderTarget=!0;const r={width:e,height:e,depth:1},l=[r,r,r,r,r,r];this.texture=new Yy(l),this._setTextureOptions(i),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,i){this.texture.type=i.type,this.texture.colorSpace=i.colorSpace,this.texture.generateMipmaps=i.generateMipmaps,this.texture.minFilter=i.minFilter,this.texture.magFilter=i.magFilter;const r={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},l=new Ll(5,5,5),c=new gr({name:"CubemapFromEquirect",uniforms:po(r.uniforms),vertexShader:r.vertexShader,fragmentShader:r.fragmentShader,side:Qn,blending:dr});c.uniforms.tEquirect.value=i;const h=new Nn(l,c),d=i.minFilter;return i.minFilter===Jr&&(i.minFilter=Ji),new F1(1,10,this).update(e,h),i.minFilter=d,h.geometry.dispose(),h.material.dispose(),this}clear(e,i=!0,r=!0,l=!0){const c=e.getRenderTarget();for(let h=0;h<6;h++)e.setRenderTarget(this,h),e.clear(i,r,l);e.setRenderTarget(c)}}class xl extends bn{constructor(){super(),this.isGroup=!0,this.type="Group"}}const G1={type:"move"};class Jd{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new xl,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new xl,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new J,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new J),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new xl,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new J,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new J),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const i=this._hand;if(i)for(const r of e.hand.values())this._getHandJoint(i,r)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,i,r){let l=null,c=null,h=null;const d=this._targetRay,m=this._grip,g=this._hand;if(e&&i.session.visibilityState!=="visible-blurred"){if(g&&e.hand){h=!0;for(const b of e.hand.values()){const y=i.getJointPose(b,r),S=this._getHandJoint(g,b);y!==null&&(S.matrix.fromArray(y.transform.matrix),S.matrix.decompose(S.position,S.rotation,S.scale),S.matrixWorldNeedsUpdate=!0,S.jointRadius=y.radius),S.visible=y!==null}const _=g.joints["index-finger-tip"],p=g.joints["thumb-tip"],x=_.position.distanceTo(p.position),M=.02,E=.005;g.inputState.pinching&&x>M+E?(g.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!g.inputState.pinching&&x<=M-E&&(g.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else m!==null&&e.gripSpace&&(c=i.getPose(e.gripSpace,r),c!==null&&(m.matrix.fromArray(c.transform.matrix),m.matrix.decompose(m.position,m.rotation,m.scale),m.matrixWorldNeedsUpdate=!0,c.linearVelocity?(m.hasLinearVelocity=!0,m.linearVelocity.copy(c.linearVelocity)):m.hasLinearVelocity=!1,c.angularVelocity?(m.hasAngularVelocity=!0,m.angularVelocity.copy(c.angularVelocity)):m.hasAngularVelocity=!1));d!==null&&(l=i.getPose(e.targetRaySpace,r),l===null&&c!==null&&(l=c),l!==null&&(d.matrix.fromArray(l.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,l.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(l.linearVelocity)):d.hasLinearVelocity=!1,l.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(l.angularVelocity)):d.hasAngularVelocity=!1,this.dispatchEvent(G1)))}return d!==null&&(d.visible=l!==null),m!==null&&(m.visible=c!==null),g!==null&&(g.visible=h!==null),this}_getHandJoint(e,i){if(e.joints[i.jointName]===void 0){const r=new xl;r.matrixAutoUpdate=!1,r.visible=!1,e.joints[i.jointName]=r,e.add(r)}return e.joints[i.jointName]}}class ym{constructor(e,i=1,r=1e3){this.isFog=!0,this.name="",this.color=new Se(e),this.near=i,this.far=r}clone(){return new ym(this.color,this.near,this.far)}toJSON(){return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}}}class V1 extends bn{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new na,this.environmentIntensity=1,this.environmentRotation=new na,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,i){return super.copy(e,i),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const i=super.toJSON(e);return this.fog!==null&&(i.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(i.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(i.object.backgroundIntensity=this.backgroundIntensity),i.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(i.object.environmentIntensity=this.environmentIntensity),i.object.environmentRotation=this.environmentRotation.toArray(),i}}const $d=new J,X1=new J,k1=new me;class Wr{constructor(e=new J(1,0,0),i=0){this.isPlane=!0,this.normal=e,this.constant=i}set(e,i){return this.normal.copy(e),this.constant=i,this}setComponents(e,i,r,l){return this.normal.set(e,i,r),this.constant=l,this}setFromNormalAndCoplanarPoint(e,i){return this.normal.copy(e),this.constant=-i.dot(this.normal),this}setFromCoplanarPoints(e,i,r){const l=$d.subVectors(r,i).cross(X1.subVectors(e,i)).normalize();return this.setFromNormalAndCoplanarPoint(l,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,i){return i.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,i){const r=e.delta($d),l=this.normal.dot(r);if(l===0)return this.distanceToPoint(e.start)===0?i.copy(e.start):null;const c=-(e.start.dot(this.normal)+this.constant)/l;return c<0||c>1?null:i.copy(e.start).addScaledVector(r,c)}intersectsLine(e){const i=this.distanceToPoint(e.start),r=this.distanceToPoint(e.end);return i<0&&r>0||r<0&&i>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,i){const r=i||k1.getNormalMatrix(e),l=this.coplanarPoint($d).applyMatrix4(e),c=this.normal.applyMatrix3(r).normalize();return this.constant=-l.dot(c),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const kr=new Xc,q1=new be(.5,.5),Sc=new J;class Sm{constructor(e=new Wr,i=new Wr,r=new Wr,l=new Wr,c=new Wr,h=new Wr){this.planes=[e,i,r,l,c,h]}set(e,i,r,l,c,h){const d=this.planes;return d[0].copy(e),d[1].copy(i),d[2].copy(r),d[3].copy(l),d[4].copy(c),d[5].copy(h),this}copy(e){const i=this.planes;for(let r=0;r<6;r++)i[r].copy(e.planes[r]);return this}setFromProjectionMatrix(e,i=$i,r=!1){const l=this.planes,c=e.elements,h=c[0],d=c[1],m=c[2],g=c[3],_=c[4],p=c[5],x=c[6],M=c[7],E=c[8],b=c[9],y=c[10],S=c[11],U=c[12],N=c[13],D=c[14],I=c[15];if(l[0].setComponents(g-h,M-_,S-E,I-U).normalize(),l[1].setComponents(g+h,M+_,S+E,I+U).normalize(),l[2].setComponents(g+d,M+p,S+b,I+N).normalize(),l[3].setComponents(g-d,M-p,S-b,I-N).normalize(),r)l[4].setComponents(m,x,y,D).normalize(),l[5].setComponents(g-m,M-x,S-y,I-D).normalize();else if(l[4].setComponents(g-m,M-x,S-y,I-D).normalize(),i===$i)l[5].setComponents(g+m,M+x,S+y,I+D).normalize();else if(i===zc)l[5].setComponents(m,x,y,D).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+i);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),kr.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const i=e.geometry;i.boundingSphere===null&&i.computeBoundingSphere(),kr.copy(i.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(kr)}intersectsSprite(e){kr.center.set(0,0,0);const i=q1.distanceTo(e.center);return kr.radius=.7071067811865476+i,kr.applyMatrix4(e.matrixWorld),this.intersectsSphere(kr)}intersectsSphere(e){const i=this.planes,r=e.center,l=-e.radius;for(let c=0;c<6;c++)if(i[c].distanceToPoint(r)<l)return!1;return!0}intersectsBox(e){const i=this.planes;for(let r=0;r<6;r++){const l=i[r];if(Sc.x=l.normal.x>0?e.max.x:e.min.x,Sc.y=l.normal.y>0?e.max.y:e.min.y,Sc.z=l.normal.z>0?e.max.z:e.min.z,l.distanceToPoint(Sc)<0)return!1}return!0}containsPoint(e){const i=this.planes;for(let r=0;r<6;r++)if(i[r].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Wy extends vo{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Se(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const xx=new an,$p=new Fy,Mc=new Xc,Ec=new J;class yx extends bn{constructor(e=new Ti,i=new Wy){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=i,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,i){return super.copy(e,i),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,i){const r=this.geometry,l=this.matrixWorld,c=e.params.Points.threshold,h=r.drawRange;if(r.boundingSphere===null&&r.computeBoundingSphere(),Mc.copy(r.boundingSphere),Mc.applyMatrix4(l),Mc.radius+=c,e.ray.intersectsSphere(Mc)===!1)return;xx.copy(l).invert(),$p.copy(e.ray).applyMatrix4(xx);const d=c/((this.scale.x+this.scale.y+this.scale.z)/3),m=d*d,g=r.index,p=r.attributes.position;if(g!==null){const x=Math.max(0,h.start),M=Math.min(g.count,h.start+h.count);for(let E=x,b=M;E<b;E++){const y=g.getX(E);Ec.fromBufferAttribute(p,y),Sx(Ec,y,m,l,e,i,this)}}else{const x=Math.max(0,h.start),M=Math.min(p.count,h.start+h.count);for(let E=x,b=M;E<b;E++)Ec.fromBufferAttribute(p,E),Sx(Ec,E,m,l,e,i,this)}}updateMorphTargets(){const i=this.geometry.morphAttributes,r=Object.keys(i);if(r.length>0){const l=i[r[0]];if(l!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let c=0,h=l.length;c<h;c++){const d=l[c].name||String(c);this.morphTargetInfluences.push(0),this.morphTargetDictionary[d]=c}}}}}function Sx(o,e,i,r,l,c,h){const d=$p.distanceSqToPoint(o);if(d<i){const m=new J;$p.closestPointToPoint(o,m),m.applyMatrix4(r);const g=l.ray.origin.distanceTo(m);if(g<l.near||g>l.far)return;c.push({distance:g,distanceToRay:Math.sqrt(d),point:m,index:e,face:null,faceIndex:null,barycoord:null,object:h})}}class jy extends Jn{constructor(e,i,r=$r,l,c,h,d=Ii,m=Ii,g,_=El,p=1){if(_!==El&&_!==Tl)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const x={width:e,height:i,depth:p};super(x,l,c,h,d,m,_,r,g),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new vm(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const i=super.toJSON(e);return this.compareFunction!==null&&(i.compareFunction=this.compareFunction),i}}class Zy extends Jn{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class io extends Ti{constructor(e=1,i=1,r=1,l=32,c=1,h=!1,d=0,m=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:i,height:r,radialSegments:l,heightSegments:c,openEnded:h,thetaStart:d,thetaLength:m};const g=this;l=Math.floor(l),c=Math.floor(c);const _=[],p=[],x=[],M=[];let E=0;const b=[],y=r/2;let S=0;U(),h===!1&&(e>0&&N(!0),i>0&&N(!1)),this.setIndex(_),this.setAttribute("position",new Bn(p,3)),this.setAttribute("normal",new Bn(x,3)),this.setAttribute("uv",new Bn(M,2));function U(){const D=new J,I=new J;let z=0;const L=(i-e)/r;for(let B=0;B<=c;B++){const C=[],R=B/c,G=R*(i-e)+e;for(let Z=0;Z<=l;Z++){const et=Z/l,ct=et*m+d,st=Math.sin(ct),k=Math.cos(ct);I.x=G*st,I.y=-R*r+y,I.z=G*k,p.push(I.x,I.y,I.z),D.set(st,L,k).normalize(),x.push(D.x,D.y,D.z),M.push(et,1-R),C.push(E++)}b.push(C)}for(let B=0;B<l;B++)for(let C=0;C<c;C++){const R=b[C][B],G=b[C+1][B],Z=b[C+1][B+1],et=b[C][B+1];(e>0||C!==0)&&(_.push(R,G,et),z+=3),(i>0||C!==c-1)&&(_.push(G,Z,et),z+=3)}g.addGroup(S,z,0),S+=z}function N(D){const I=E,z=new be,L=new J;let B=0;const C=D===!0?e:i,R=D===!0?1:-1;for(let Z=1;Z<=l;Z++)p.push(0,y*R,0),x.push(0,R,0),M.push(.5,.5),E++;const G=E;for(let Z=0;Z<=l;Z++){const ct=Z/l*m+d,st=Math.cos(ct),k=Math.sin(ct);L.x=C*k,L.y=y*R,L.z=C*st,p.push(L.x,L.y,L.z),x.push(0,R,0),z.x=st*.5+.5,z.y=k*.5*R+.5,M.push(z.x,z.y),E++}for(let Z=0;Z<l;Z++){const et=I+Z,ct=G+Z;D===!0?_.push(ct,ct+1,et):_.push(ct+1,ct,et),B+=3}g.addGroup(S,B,D===!0?1:2),S+=B}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new io(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Mm extends Ti{constructor(e=[],i=[],r=1,l=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:i,radius:r,detail:l};const c=[],h=[];d(l),g(r),_(),this.setAttribute("position",new Bn(c,3)),this.setAttribute("normal",new Bn(c.slice(),3)),this.setAttribute("uv",new Bn(h,2)),l===0?this.computeVertexNormals():this.normalizeNormals();function d(U){const N=new J,D=new J,I=new J;for(let z=0;z<i.length;z+=3)M(i[z+0],N),M(i[z+1],D),M(i[z+2],I),m(N,D,I,U)}function m(U,N,D,I){const z=I+1,L=[];for(let B=0;B<=z;B++){L[B]=[];const C=U.clone().lerp(D,B/z),R=N.clone().lerp(D,B/z),G=z-B;for(let Z=0;Z<=G;Z++)Z===0&&B===z?L[B][Z]=C:L[B][Z]=C.clone().lerp(R,Z/G)}for(let B=0;B<z;B++)for(let C=0;C<2*(z-B)-1;C++){const R=Math.floor(C/2);C%2===0?(x(L[B][R+1]),x(L[B+1][R]),x(L[B][R])):(x(L[B][R+1]),x(L[B+1][R+1]),x(L[B+1][R]))}}function g(U){const N=new J;for(let D=0;D<c.length;D+=3)N.x=c[D+0],N.y=c[D+1],N.z=c[D+2],N.normalize().multiplyScalar(U),c[D+0]=N.x,c[D+1]=N.y,c[D+2]=N.z}function _(){const U=new J;for(let N=0;N<c.length;N+=3){U.x=c[N+0],U.y=c[N+1],U.z=c[N+2];const D=y(U)/2/Math.PI+.5,I=S(U)/Math.PI+.5;h.push(D,1-I)}E(),p()}function p(){for(let U=0;U<h.length;U+=6){const N=h[U+0],D=h[U+2],I=h[U+4],z=Math.max(N,D,I),L=Math.min(N,D,I);z>.9&&L<.1&&(N<.2&&(h[U+0]+=1),D<.2&&(h[U+2]+=1),I<.2&&(h[U+4]+=1))}}function x(U){c.push(U.x,U.y,U.z)}function M(U,N){const D=U*3;N.x=e[D+0],N.y=e[D+1],N.z=e[D+2]}function E(){const U=new J,N=new J,D=new J,I=new J,z=new be,L=new be,B=new be;for(let C=0,R=0;C<c.length;C+=9,R+=6){U.set(c[C+0],c[C+1],c[C+2]),N.set(c[C+3],c[C+4],c[C+5]),D.set(c[C+6],c[C+7],c[C+8]),z.set(h[R+0],h[R+1]),L.set(h[R+2],h[R+3]),B.set(h[R+4],h[R+5]),I.copy(U).add(N).add(D).divideScalar(3);const G=y(I);b(z,R+0,U,G),b(L,R+2,N,G),b(B,R+4,D,G)}}function b(U,N,D,I){I<0&&U.x===1&&(h[N]=U.x-1),D.x===0&&D.z===0&&(h[N]=I/2/Math.PI+.5)}function y(U){return Math.atan2(U.z,-U.x)}function S(U){return Math.atan2(-U.y,Math.sqrt(U.x*U.x+U.z*U.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Mm(e.vertices,e.indices,e.radius,e.details)}}class Bc extends Mm{constructor(e=1,i=0){const r=(1+Math.sqrt(5))/2,l=[-1,r,0,1,r,0,-1,-r,0,1,-r,0,0,-1,r,0,1,r,0,-1,-r,0,1,-r,r,0,-1,r,0,1,-r,0,-1,-r,0,1],c=[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1];super(l,c,e,i),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:i}}static fromJSON(e){return new Bc(e.radius,e.detail)}}class kc extends Ti{constructor(e=1,i=1,r=1,l=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:i,widthSegments:r,heightSegments:l};const c=e/2,h=i/2,d=Math.floor(r),m=Math.floor(l),g=d+1,_=m+1,p=e/d,x=i/m,M=[],E=[],b=[],y=[];for(let S=0;S<_;S++){const U=S*x-h;for(let N=0;N<g;N++){const D=N*p-c;E.push(D,-U,0),b.push(0,0,1),y.push(N/d),y.push(1-S/m)}}for(let S=0;S<m;S++)for(let U=0;U<d;U++){const N=U+g*S,D=U+g*(S+1),I=U+1+g*(S+1),z=U+1+g*S;M.push(N,D,z),M.push(D,I,z)}this.setIndex(M),this.setAttribute("position",new Bn(E,3)),this.setAttribute("normal",new Bn(b,3)),this.setAttribute("uv",new Bn(y,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new kc(e.width,e.height,e.widthSegments,e.heightSegments)}}class Em extends Ti{constructor(e=1,i=.4,r=12,l=48,c=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:i,radialSegments:r,tubularSegments:l,arc:c},r=Math.floor(r),l=Math.floor(l);const h=[],d=[],m=[],g=[],_=new J,p=new J,x=new J;for(let M=0;M<=r;M++)for(let E=0;E<=l;E++){const b=E/l*c,y=M/r*Math.PI*2;p.x=(e+i*Math.cos(y))*Math.cos(b),p.y=(e+i*Math.cos(y))*Math.sin(b),p.z=i*Math.sin(y),d.push(p.x,p.y,p.z),_.x=e*Math.cos(b),_.y=e*Math.sin(b),x.subVectors(p,_).normalize(),m.push(x.x,x.y,x.z),g.push(E/l),g.push(M/r)}for(let M=1;M<=r;M++)for(let E=1;E<=l;E++){const b=(l+1)*M+E-1,y=(l+1)*(M-1)+E-1,S=(l+1)*(M-1)+E,U=(l+1)*M+E;h.push(b,y,U),h.push(y,S,U)}this.setIndex(h),this.setAttribute("position",new Bn(d,3)),this.setAttribute("normal",new Bn(m,3)),this.setAttribute("uv",new Bn(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Em(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class no extends vo{constructor(e){super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new Se(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Se(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Py,this.normalScale=new be(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new na,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Y1 extends no{constructor(e){super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new be(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){return we(2.5*(this.ior-1)/(this.ior+1),0,1)},set:function(i){this.ior=(1+.4*i)/(1-.4*i)}}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new Se(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new Se(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new Se(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(e)}get anisotropy(){return this._anisotropy}set anisotropy(e){this._anisotropy>0!=e>0&&this.version++,this._anisotropy=e}get clearcoat(){return this._clearcoat}set clearcoat(e){this._clearcoat>0!=e>0&&this.version++,this._clearcoat=e}get iridescence(){return this._iridescence}set iridescence(e){this._iridescence>0!=e>0&&this.version++,this._iridescence=e}get dispersion(){return this._dispersion}set dispersion(e){this._dispersion>0!=e>0&&this.version++,this._dispersion=e}get sheen(){return this._sheen}set sheen(e){this._sheen>0!=e>0&&this.version++,this._sheen=e}get transmission(){return this._transmission}set transmission(e){this._transmission>0!=e>0&&this.version++,this._transmission=e}copy(e){return super.copy(e),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=e.anisotropy,this.anisotropyRotation=e.anisotropyRotation,this.anisotropyMap=e.anisotropyMap,this.clearcoat=e.clearcoat,this.clearcoatMap=e.clearcoatMap,this.clearcoatRoughness=e.clearcoatRoughness,this.clearcoatRoughnessMap=e.clearcoatRoughnessMap,this.clearcoatNormalMap=e.clearcoatNormalMap,this.clearcoatNormalScale.copy(e.clearcoatNormalScale),this.dispersion=e.dispersion,this.ior=e.ior,this.iridescence=e.iridescence,this.iridescenceMap=e.iridescenceMap,this.iridescenceIOR=e.iridescenceIOR,this.iridescenceThicknessRange=[...e.iridescenceThicknessRange],this.iridescenceThicknessMap=e.iridescenceThicknessMap,this.sheen=e.sheen,this.sheenColor.copy(e.sheenColor),this.sheenColorMap=e.sheenColorMap,this.sheenRoughness=e.sheenRoughness,this.sheenRoughnessMap=e.sheenRoughnessMap,this.transmission=e.transmission,this.transmissionMap=e.transmissionMap,this.thickness=e.thickness,this.thicknessMap=e.thicknessMap,this.attenuationDistance=e.attenuationDistance,this.attenuationColor.copy(e.attenuationColor),this.specularIntensity=e.specularIntensity,this.specularIntensityMap=e.specularIntensityMap,this.specularColor.copy(e.specularColor),this.specularColorMap=e.specularColorMap,this}}class W1 extends vo{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=r1,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class j1 extends vo{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}class Tm extends bn{constructor(e,i=1){super(),this.isLight=!0,this.type="Light",this.color=new Se(e),this.intensity=i}dispose(){}copy(e,i){return super.copy(e,i),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const i=super.toJSON(e);return i.object.color=this.color.getHex(),i.object.intensity=this.intensity,this.groundColor!==void 0&&(i.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(i.object.distance=this.distance),this.angle!==void 0&&(i.object.angle=this.angle),this.decay!==void 0&&(i.object.decay=this.decay),this.penumbra!==void 0&&(i.object.penumbra=this.penumbra),this.shadow!==void 0&&(i.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(i.object.target=this.target.uuid),i}}class Z1 extends Tm{constructor(e,i,r){super(e,r),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(bn.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Se(i)}copy(e,i){return super.copy(e,i),this.groundColor.copy(e.groundColor),this}}const tp=new an,Mx=new J,Ex=new J;class Ky{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new be(512,512),this.mapType=ea,this.map=null,this.mapPass=null,this.matrix=new an,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Sm,this._frameExtents=new be(1,1),this._viewportCount=1,this._viewports=[new We(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const i=this.camera,r=this.matrix;Mx.setFromMatrixPosition(e.matrixWorld),i.position.copy(Mx),Ex.setFromMatrixPosition(e.target.matrixWorld),i.lookAt(Ex),i.updateMatrixWorld(),tp.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse),this._frustum.setFromProjectionMatrix(tp,i.coordinateSystem,i.reversedDepth),i.reversedDepth?r.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):r.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),r.multiply(tp)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.autoUpdate=e.autoUpdate,this.needsUpdate=e.needsUpdate,this.normalBias=e.normalBias,this.blurSamples=e.blurSamples,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}const Tx=new an,vl=new J,ep=new J;class K1 extends Ky{constructor(){super(new ci(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new be(4,2),this._viewportCount=6,this._viewports=[new We(2,1,1,1),new We(0,1,1,1),new We(3,1,1,1),new We(1,1,1,1),new We(3,0,1,1),new We(1,0,1,1)],this._cubeDirections=[new J(1,0,0),new J(-1,0,0),new J(0,0,1),new J(0,0,-1),new J(0,1,0),new J(0,-1,0)],this._cubeUps=[new J(0,1,0),new J(0,1,0),new J(0,1,0),new J(0,1,0),new J(0,0,1),new J(0,0,-1)]}updateMatrices(e,i=0){const r=this.camera,l=this.matrix,c=e.distance||r.far;c!==r.far&&(r.far=c,r.updateProjectionMatrix()),vl.setFromMatrixPosition(e.matrixWorld),r.position.copy(vl),ep.copy(r.position),ep.add(this._cubeDirections[i]),r.up.copy(this._cubeUps[i]),r.lookAt(ep),r.updateMatrixWorld(),l.makeTranslation(-vl.x,-vl.y,-vl.z),Tx.multiplyMatrices(r.projectionMatrix,r.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Tx,r.coordinateSystem,r.reversedDepth)}}class Q1 extends Tm{constructor(e,i,r=0,l=2){super(e,i),this.isPointLight=!0,this.type="PointLight",this.distance=r,this.decay=l,this.shadow=new K1}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,i){return super.copy(e,i),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Qy extends qy{constructor(e=-1,i=1,r=1,l=-1,c=.1,h=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=i,this.top=r,this.bottom=l,this.near=c,this.far=h,this.updateProjectionMatrix()}copy(e,i){return super.copy(e,i),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,i,r,l,c,h){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=i,this.view.offsetX=r,this.view.offsetY=l,this.view.width=c,this.view.height=h,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),i=(this.top-this.bottom)/(2*this.zoom),r=(this.right+this.left)/2,l=(this.top+this.bottom)/2;let c=r-e,h=r+e,d=l+i,m=l-i;if(this.view!==null&&this.view.enabled){const g=(this.right-this.left)/this.view.fullWidth/this.zoom,_=(this.top-this.bottom)/this.view.fullHeight/this.zoom;c+=g*this.view.offsetX,h=c+g*this.view.width,d-=_*this.view.offsetY,m=d-_*this.view.height}this.projectionMatrix.makeOrthographic(c,h,d,m,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const i=super.toJSON(e);return i.object.zoom=this.zoom,i.object.left=this.left,i.object.right=this.right,i.object.top=this.top,i.object.bottom=this.bottom,i.object.near=this.near,i.object.far=this.far,this.view!==null&&(i.object.view=Object.assign({},this.view)),i}}class J1 extends Ky{constructor(){super(new Qy(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class $1 extends Tm{constructor(e,i){super(e,i),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(bn.DEFAULT_UP),this.updateMatrix(),this.target=new bn,this.shadow=new J1}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class tA extends ci{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}function bx(o,e,i,r){const l=eA(r);switch(i){case Uy:return o*e;case Ly:return o*e/l.components*l.byteLength;case mm:return o*e/l.components*l.byteLength;case Oy:return o*e*2/l.components*l.byteLength;case gm:return o*e*2/l.components*l.byteLength;case Ny:return o*e*3/l.components*l.byteLength;case Pi:return o*e*4/l.components*l.byteLength;case _m:return o*e*4/l.components*l.byteLength;case wc:case Dc:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*8;case Uc:case Nc:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case bp:case Rp:return Math.max(o,16)*Math.max(e,8)/4;case Tp:case Ap:return Math.max(o,8)*Math.max(e,8)/2;case Cp:case wp:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*8;case Dp:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case Up:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case Np:return Math.floor((o+4)/5)*Math.floor((e+3)/4)*16;case Lp:return Math.floor((o+4)/5)*Math.floor((e+4)/5)*16;case Op:return Math.floor((o+5)/6)*Math.floor((e+4)/5)*16;case Pp:return Math.floor((o+5)/6)*Math.floor((e+5)/6)*16;case zp:return Math.floor((o+7)/8)*Math.floor((e+4)/5)*16;case Ip:return Math.floor((o+7)/8)*Math.floor((e+5)/6)*16;case Bp:return Math.floor((o+7)/8)*Math.floor((e+7)/8)*16;case Fp:return Math.floor((o+9)/10)*Math.floor((e+4)/5)*16;case Hp:return Math.floor((o+9)/10)*Math.floor((e+5)/6)*16;case Gp:return Math.floor((o+9)/10)*Math.floor((e+7)/8)*16;case Vp:return Math.floor((o+9)/10)*Math.floor((e+9)/10)*16;case Xp:return Math.floor((o+11)/12)*Math.floor((e+9)/10)*16;case kp:return Math.floor((o+11)/12)*Math.floor((e+11)/12)*16;case qp:case Yp:case Wp:return Math.ceil(o/4)*Math.ceil(e/4)*16;case jp:case Zp:return Math.ceil(o/4)*Math.ceil(e/4)*8;case Kp:case Qp:return Math.ceil(o/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${i} format.`)}function eA(o){switch(o){case ea:case Ry:return{byteLength:1,components:1};case Sl:case Cy:case wl:return{byteLength:2,components:1};case dm:case pm:return{byteLength:2,components:4};case $r:case hm:case Aa:return{byteLength:4,components:1};case wy:case Dy:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${o}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:fm}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=fm);function Jy(){let o=null,e=!1,i=null,r=null;function l(c,h){i(c,h),r=o.requestAnimationFrame(l)}return{start:function(){e!==!0&&i!==null&&(r=o.requestAnimationFrame(l),e=!0)},stop:function(){o.cancelAnimationFrame(r),e=!1},setAnimationLoop:function(c){i=c},setContext:function(c){o=c}}}function nA(o){const e=new WeakMap;function i(d,m){const g=d.array,_=d.usage,p=g.byteLength,x=o.createBuffer();o.bindBuffer(m,x),o.bufferData(m,g,_),d.onUploadCallback();let M;if(g instanceof Float32Array)M=o.FLOAT;else if(typeof Float16Array<"u"&&g instanceof Float16Array)M=o.HALF_FLOAT;else if(g instanceof Uint16Array)d.isFloat16BufferAttribute?M=o.HALF_FLOAT:M=o.UNSIGNED_SHORT;else if(g instanceof Int16Array)M=o.SHORT;else if(g instanceof Uint32Array)M=o.UNSIGNED_INT;else if(g instanceof Int32Array)M=o.INT;else if(g instanceof Int8Array)M=o.BYTE;else if(g instanceof Uint8Array)M=o.UNSIGNED_BYTE;else if(g instanceof Uint8ClampedArray)M=o.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+g);return{buffer:x,type:M,bytesPerElement:g.BYTES_PER_ELEMENT,version:d.version,size:p}}function r(d,m,g){const _=m.array,p=m.updateRanges;if(o.bindBuffer(g,d),p.length===0)o.bufferSubData(g,0,_);else{p.sort((M,E)=>M.start-E.start);let x=0;for(let M=1;M<p.length;M++){const E=p[x],b=p[M];b.start<=E.start+E.count+1?E.count=Math.max(E.count,b.start+b.count-E.start):(++x,p[x]=b)}p.length=x+1;for(let M=0,E=p.length;M<E;M++){const b=p[M];o.bufferSubData(g,b.start*_.BYTES_PER_ELEMENT,_,b.start,b.count)}m.clearUpdateRanges()}m.onUploadCallback()}function l(d){return d.isInterleavedBufferAttribute&&(d=d.data),e.get(d)}function c(d){d.isInterleavedBufferAttribute&&(d=d.data);const m=e.get(d);m&&(o.deleteBuffer(m.buffer),e.delete(d))}function h(d,m){if(d.isInterleavedBufferAttribute&&(d=d.data),d.isGLBufferAttribute){const _=e.get(d);(!_||_.version<d.version)&&e.set(d,{buffer:d.buffer,type:d.type,bytesPerElement:d.elementSize,version:d.version});return}const g=e.get(d);if(g===void 0)e.set(d,i(d,m));else if(g.version<d.version){if(g.size!==d.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");r(g.buffer,d,m),g.version=d.version}}return{get:l,remove:c,update:h}}var iA=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,aA=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,rA=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,sA=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,oA=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,lA=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,uA=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,cA=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,fA=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,hA=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,dA=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,pA=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,mA=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,gA=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,_A=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,vA=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,xA=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,yA=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,SA=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,MA=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,EA=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,TA=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,bA=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,AA=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,RA=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,CA=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,wA=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,DA=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,UA=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,NA=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,LA="gl_FragColor = linearToOutputTexel( gl_FragColor );",OA=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,PA=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,zA=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,IA=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,BA=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,FA=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,HA=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,GA=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,VA=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,XA=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,kA=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,qA=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,YA=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,WA=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,jA=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,ZA=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,KA=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,QA=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,JA=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,$A=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,tR=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,eR=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,nR=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,iR=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,aR=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,rR=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,sR=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,oR=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,lR=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,uR=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,cR=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,fR=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,hR=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,dR=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,pR=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,mR=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,gR=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,_R=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,vR=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,xR=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,yR=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,SR=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,MR=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,ER=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,TR=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,bR=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,AR=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,RR=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,CR=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,wR=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,DR=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,UR=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,NR=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,LR=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,OR=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,PR=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,zR=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,IR=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,BR=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		float depth = unpackRGBAToDepth( texture2D( depths, uv ) );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			return step( depth, compare );
		#else
			return step( compare, depth );
		#endif
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow( sampler2D shadow, vec2 uv, float compare ) {
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		#ifdef USE_REVERSED_DEPTH_BUFFER
			float hard_shadow = step( distribution.x, compare );
		#else
			float hard_shadow = step( compare, distribution.x );
		#endif
		if ( hard_shadow != 1.0 ) {
			float distance = compare - distribution.x;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,FR=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,HR=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,GR=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,VR=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,XR=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,kR=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,qR=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,YR=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,WR=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,jR=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,ZR=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,KR=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,QR=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,JR=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,$R=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,tC=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,eC=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const nC=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,iC=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,aC=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,rC=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,sC=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,oC=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,lC=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,uC=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,cC=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,fC=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,hC=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,dC=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,pC=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,mC=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,gC=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,_C=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,vC=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,xC=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,yC=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,SC=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,MC=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,EC=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,TC=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,bC=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,AC=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,RC=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,CC=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,wC=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,DC=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,UC=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,NC=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,LC=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,OC=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,PC=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ge={alphahash_fragment:iA,alphahash_pars_fragment:aA,alphamap_fragment:rA,alphamap_pars_fragment:sA,alphatest_fragment:oA,alphatest_pars_fragment:lA,aomap_fragment:uA,aomap_pars_fragment:cA,batching_pars_vertex:fA,batching_vertex:hA,begin_vertex:dA,beginnormal_vertex:pA,bsdfs:mA,iridescence_fragment:gA,bumpmap_pars_fragment:_A,clipping_planes_fragment:vA,clipping_planes_pars_fragment:xA,clipping_planes_pars_vertex:yA,clipping_planes_vertex:SA,color_fragment:MA,color_pars_fragment:EA,color_pars_vertex:TA,color_vertex:bA,common:AA,cube_uv_reflection_fragment:RA,defaultnormal_vertex:CA,displacementmap_pars_vertex:wA,displacementmap_vertex:DA,emissivemap_fragment:UA,emissivemap_pars_fragment:NA,colorspace_fragment:LA,colorspace_pars_fragment:OA,envmap_fragment:PA,envmap_common_pars_fragment:zA,envmap_pars_fragment:IA,envmap_pars_vertex:BA,envmap_physical_pars_fragment:ZA,envmap_vertex:FA,fog_vertex:HA,fog_pars_vertex:GA,fog_fragment:VA,fog_pars_fragment:XA,gradientmap_pars_fragment:kA,lightmap_pars_fragment:qA,lights_lambert_fragment:YA,lights_lambert_pars_fragment:WA,lights_pars_begin:jA,lights_toon_fragment:KA,lights_toon_pars_fragment:QA,lights_phong_fragment:JA,lights_phong_pars_fragment:$A,lights_physical_fragment:tR,lights_physical_pars_fragment:eR,lights_fragment_begin:nR,lights_fragment_maps:iR,lights_fragment_end:aR,logdepthbuf_fragment:rR,logdepthbuf_pars_fragment:sR,logdepthbuf_pars_vertex:oR,logdepthbuf_vertex:lR,map_fragment:uR,map_pars_fragment:cR,map_particle_fragment:fR,map_particle_pars_fragment:hR,metalnessmap_fragment:dR,metalnessmap_pars_fragment:pR,morphinstance_vertex:mR,morphcolor_vertex:gR,morphnormal_vertex:_R,morphtarget_pars_vertex:vR,morphtarget_vertex:xR,normal_fragment_begin:yR,normal_fragment_maps:SR,normal_pars_fragment:MR,normal_pars_vertex:ER,normal_vertex:TR,normalmap_pars_fragment:bR,clearcoat_normal_fragment_begin:AR,clearcoat_normal_fragment_maps:RR,clearcoat_pars_fragment:CR,iridescence_pars_fragment:wR,opaque_fragment:DR,packing:UR,premultiplied_alpha_fragment:NR,project_vertex:LR,dithering_fragment:OR,dithering_pars_fragment:PR,roughnessmap_fragment:zR,roughnessmap_pars_fragment:IR,shadowmap_pars_fragment:BR,shadowmap_pars_vertex:FR,shadowmap_vertex:HR,shadowmask_pars_fragment:GR,skinbase_vertex:VR,skinning_pars_vertex:XR,skinning_vertex:kR,skinnormal_vertex:qR,specularmap_fragment:YR,specularmap_pars_fragment:WR,tonemapping_fragment:jR,tonemapping_pars_fragment:ZR,transmission_fragment:KR,transmission_pars_fragment:QR,uv_pars_fragment:JR,uv_pars_vertex:$R,uv_vertex:tC,worldpos_vertex:eC,background_vert:nC,background_frag:iC,backgroundCube_vert:aC,backgroundCube_frag:rC,cube_vert:sC,cube_frag:oC,depth_vert:lC,depth_frag:uC,distanceRGBA_vert:cC,distanceRGBA_frag:fC,equirect_vert:hC,equirect_frag:dC,linedashed_vert:pC,linedashed_frag:mC,meshbasic_vert:gC,meshbasic_frag:_C,meshlambert_vert:vC,meshlambert_frag:xC,meshmatcap_vert:yC,meshmatcap_frag:SC,meshnormal_vert:MC,meshnormal_frag:EC,meshphong_vert:TC,meshphong_frag:bC,meshphysical_vert:AC,meshphysical_frag:RC,meshtoon_vert:CC,meshtoon_frag:wC,points_vert:DC,points_frag:UC,shadow_vert:NC,shadow_frag:LC,sprite_vert:OC,sprite_frag:PC},Ft={common:{diffuse:{value:new Se(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new me},alphaMap:{value:null},alphaMapTransform:{value:new me},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new me}},envmap:{envMap:{value:null},envMapRotation:{value:new me},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new me}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new me}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new me},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new me},normalScale:{value:new be(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new me},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new me}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new me}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new me}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Se(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Se(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new me},alphaTest:{value:0},uvTransform:{value:new me}},sprite:{diffuse:{value:new Se(16777215)},opacity:{value:1},center:{value:new be(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new me},alphaMap:{value:null},alphaMapTransform:{value:new me},alphaTest:{value:0}}},Qi={basic:{uniforms:kn([Ft.common,Ft.specularmap,Ft.envmap,Ft.aomap,Ft.lightmap,Ft.fog]),vertexShader:ge.meshbasic_vert,fragmentShader:ge.meshbasic_frag},lambert:{uniforms:kn([Ft.common,Ft.specularmap,Ft.envmap,Ft.aomap,Ft.lightmap,Ft.emissivemap,Ft.bumpmap,Ft.normalmap,Ft.displacementmap,Ft.fog,Ft.lights,{emissive:{value:new Se(0)}}]),vertexShader:ge.meshlambert_vert,fragmentShader:ge.meshlambert_frag},phong:{uniforms:kn([Ft.common,Ft.specularmap,Ft.envmap,Ft.aomap,Ft.lightmap,Ft.emissivemap,Ft.bumpmap,Ft.normalmap,Ft.displacementmap,Ft.fog,Ft.lights,{emissive:{value:new Se(0)},specular:{value:new Se(1118481)},shininess:{value:30}}]),vertexShader:ge.meshphong_vert,fragmentShader:ge.meshphong_frag},standard:{uniforms:kn([Ft.common,Ft.envmap,Ft.aomap,Ft.lightmap,Ft.emissivemap,Ft.bumpmap,Ft.normalmap,Ft.displacementmap,Ft.roughnessmap,Ft.metalnessmap,Ft.fog,Ft.lights,{emissive:{value:new Se(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:ge.meshphysical_vert,fragmentShader:ge.meshphysical_frag},toon:{uniforms:kn([Ft.common,Ft.aomap,Ft.lightmap,Ft.emissivemap,Ft.bumpmap,Ft.normalmap,Ft.displacementmap,Ft.gradientmap,Ft.fog,Ft.lights,{emissive:{value:new Se(0)}}]),vertexShader:ge.meshtoon_vert,fragmentShader:ge.meshtoon_frag},matcap:{uniforms:kn([Ft.common,Ft.bumpmap,Ft.normalmap,Ft.displacementmap,Ft.fog,{matcap:{value:null}}]),vertexShader:ge.meshmatcap_vert,fragmentShader:ge.meshmatcap_frag},points:{uniforms:kn([Ft.points,Ft.fog]),vertexShader:ge.points_vert,fragmentShader:ge.points_frag},dashed:{uniforms:kn([Ft.common,Ft.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:ge.linedashed_vert,fragmentShader:ge.linedashed_frag},depth:{uniforms:kn([Ft.common,Ft.displacementmap]),vertexShader:ge.depth_vert,fragmentShader:ge.depth_frag},normal:{uniforms:kn([Ft.common,Ft.bumpmap,Ft.normalmap,Ft.displacementmap,{opacity:{value:1}}]),vertexShader:ge.meshnormal_vert,fragmentShader:ge.meshnormal_frag},sprite:{uniforms:kn([Ft.sprite,Ft.fog]),vertexShader:ge.sprite_vert,fragmentShader:ge.sprite_frag},background:{uniforms:{uvTransform:{value:new me},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:ge.background_vert,fragmentShader:ge.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new me}},vertexShader:ge.backgroundCube_vert,fragmentShader:ge.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:ge.cube_vert,fragmentShader:ge.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:ge.equirect_vert,fragmentShader:ge.equirect_frag},distanceRGBA:{uniforms:kn([Ft.common,Ft.displacementmap,{referencePosition:{value:new J},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:ge.distanceRGBA_vert,fragmentShader:ge.distanceRGBA_frag},shadow:{uniforms:kn([Ft.lights,Ft.fog,{color:{value:new Se(0)},opacity:{value:1}}]),vertexShader:ge.shadow_vert,fragmentShader:ge.shadow_frag}};Qi.physical={uniforms:kn([Qi.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new me},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new me},clearcoatNormalScale:{value:new be(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new me},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new me},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new me},sheen:{value:0},sheenColor:{value:new Se(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new me},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new me},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new me},transmissionSamplerSize:{value:new be},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new me},attenuationDistance:{value:0},attenuationColor:{value:new Se(0)},specularColor:{value:new Se(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new me},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new me},anisotropyVector:{value:new be},anisotropyMap:{value:null},anisotropyMapTransform:{value:new me}}]),vertexShader:ge.meshphysical_vert,fragmentShader:ge.meshphysical_frag};const Tc={r:0,b:0,g:0},qr=new na,zC=new an;function IC(o,e,i,r,l,c,h){const d=new Se(0);let m=c===!0?0:1,g,_,p=null,x=0,M=null;function E(N){let D=N.isScene===!0?N.background:null;return D&&D.isTexture&&(D=(N.backgroundBlurriness>0?i:e).get(D)),D}function b(N){let D=!1;const I=E(N);I===null?S(d,m):I&&I.isColor&&(S(I,1),D=!0);const z=o.xr.getEnvironmentBlendMode();z==="additive"?r.buffers.color.setClear(0,0,0,1,h):z==="alpha-blend"&&r.buffers.color.setClear(0,0,0,0,h),(o.autoClear||D)&&(r.buffers.depth.setTest(!0),r.buffers.depth.setMask(!0),r.buffers.color.setMask(!0),o.clear(o.autoClearColor,o.autoClearDepth,o.autoClearStencil))}function y(N,D){const I=E(D);I&&(I.isCubeTexture||I.mapping===Vc)?(_===void 0&&(_=new Nn(new Ll(1,1,1),new gr({name:"BackgroundCubeMaterial",uniforms:po(Qi.backgroundCube.uniforms),vertexShader:Qi.backgroundCube.vertexShader,fragmentShader:Qi.backgroundCube.fragmentShader,side:Qn,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),_.geometry.deleteAttribute("normal"),_.geometry.deleteAttribute("uv"),_.onBeforeRender=function(z,L,B){this.matrixWorld.copyPosition(B.matrixWorld)},Object.defineProperty(_.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),l.update(_)),qr.copy(D.backgroundRotation),qr.x*=-1,qr.y*=-1,qr.z*=-1,I.isCubeTexture&&I.isRenderTargetTexture===!1&&(qr.y*=-1,qr.z*=-1),_.material.uniforms.envMap.value=I,_.material.uniforms.flipEnvMap.value=I.isCubeTexture&&I.isRenderTargetTexture===!1?-1:1,_.material.uniforms.backgroundBlurriness.value=D.backgroundBlurriness,_.material.uniforms.backgroundIntensity.value=D.backgroundIntensity,_.material.uniforms.backgroundRotation.value.setFromMatrix4(zC.makeRotationFromEuler(qr)),_.material.toneMapped=Oe.getTransfer(I.colorSpace)!==Ye,(p!==I||x!==I.version||M!==o.toneMapping)&&(_.material.needsUpdate=!0,p=I,x=I.version,M=o.toneMapping),_.layers.enableAll(),N.unshift(_,_.geometry,_.material,0,0,null)):I&&I.isTexture&&(g===void 0&&(g=new Nn(new kc(2,2),new gr({name:"BackgroundMaterial",uniforms:po(Qi.background.uniforms),vertexShader:Qi.background.vertexShader,fragmentShader:Qi.background.fragmentShader,side:mr,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),g.geometry.deleteAttribute("normal"),Object.defineProperty(g.material,"map",{get:function(){return this.uniforms.t2D.value}}),l.update(g)),g.material.uniforms.t2D.value=I,g.material.uniforms.backgroundIntensity.value=D.backgroundIntensity,g.material.toneMapped=Oe.getTransfer(I.colorSpace)!==Ye,I.matrixAutoUpdate===!0&&I.updateMatrix(),g.material.uniforms.uvTransform.value.copy(I.matrix),(p!==I||x!==I.version||M!==o.toneMapping)&&(g.material.needsUpdate=!0,p=I,x=I.version,M=o.toneMapping),g.layers.enableAll(),N.unshift(g,g.geometry,g.material,0,0,null))}function S(N,D){N.getRGB(Tc,ky(o)),r.buffers.color.setClear(Tc.r,Tc.g,Tc.b,D,h)}function U(){_!==void 0&&(_.geometry.dispose(),_.material.dispose(),_=void 0),g!==void 0&&(g.geometry.dispose(),g.material.dispose(),g=void 0)}return{getClearColor:function(){return d},setClearColor:function(N,D=1){d.set(N),m=D,S(d,m)},getClearAlpha:function(){return m},setClearAlpha:function(N){m=N,S(d,m)},render:b,addToRenderList:y,dispose:U}}function BC(o,e){const i=o.getParameter(o.MAX_VERTEX_ATTRIBS),r={},l=x(null);let c=l,h=!1;function d(R,G,Z,et,ct){let st=!1;const k=p(et,Z,G);c!==k&&(c=k,g(c.object)),st=M(R,et,Z,ct),st&&E(R,et,Z,ct),ct!==null&&e.update(ct,o.ELEMENT_ARRAY_BUFFER),(st||h)&&(h=!1,D(R,G,Z,et),ct!==null&&o.bindBuffer(o.ELEMENT_ARRAY_BUFFER,e.get(ct).buffer))}function m(){return o.createVertexArray()}function g(R){return o.bindVertexArray(R)}function _(R){return o.deleteVertexArray(R)}function p(R,G,Z){const et=Z.wireframe===!0;let ct=r[R.id];ct===void 0&&(ct={},r[R.id]=ct);let st=ct[G.id];st===void 0&&(st={},ct[G.id]=st);let k=st[et];return k===void 0&&(k=x(m()),st[et]=k),k}function x(R){const G=[],Z=[],et=[];for(let ct=0;ct<i;ct++)G[ct]=0,Z[ct]=0,et[ct]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:G,enabledAttributes:Z,attributeDivisors:et,object:R,attributes:{},index:null}}function M(R,G,Z,et){const ct=c.attributes,st=G.attributes;let k=0;const it=Z.getAttributes();for(const j in it)if(it[j].location>=0){const Mt=ct[j];let Ht=st[j];if(Ht===void 0&&(j==="instanceMatrix"&&R.instanceMatrix&&(Ht=R.instanceMatrix),j==="instanceColor"&&R.instanceColor&&(Ht=R.instanceColor)),Mt===void 0||Mt.attribute!==Ht||Ht&&Mt.data!==Ht.data)return!0;k++}return c.attributesNum!==k||c.index!==et}function E(R,G,Z,et){const ct={},st=G.attributes;let k=0;const it=Z.getAttributes();for(const j in it)if(it[j].location>=0){let Mt=st[j];Mt===void 0&&(j==="instanceMatrix"&&R.instanceMatrix&&(Mt=R.instanceMatrix),j==="instanceColor"&&R.instanceColor&&(Mt=R.instanceColor));const Ht={};Ht.attribute=Mt,Mt&&Mt.data&&(Ht.data=Mt.data),ct[j]=Ht,k++}c.attributes=ct,c.attributesNum=k,c.index=et}function b(){const R=c.newAttributes;for(let G=0,Z=R.length;G<Z;G++)R[G]=0}function y(R){S(R,0)}function S(R,G){const Z=c.newAttributes,et=c.enabledAttributes,ct=c.attributeDivisors;Z[R]=1,et[R]===0&&(o.enableVertexAttribArray(R),et[R]=1),ct[R]!==G&&(o.vertexAttribDivisor(R,G),ct[R]=G)}function U(){const R=c.newAttributes,G=c.enabledAttributes;for(let Z=0,et=G.length;Z<et;Z++)G[Z]!==R[Z]&&(o.disableVertexAttribArray(Z),G[Z]=0)}function N(R,G,Z,et,ct,st,k){k===!0?o.vertexAttribIPointer(R,G,Z,ct,st):o.vertexAttribPointer(R,G,Z,et,ct,st)}function D(R,G,Z,et){b();const ct=et.attributes,st=Z.getAttributes(),k=G.defaultAttributeValues;for(const it in st){const j=st[it];if(j.location>=0){let xt=ct[it];if(xt===void 0&&(it==="instanceMatrix"&&R.instanceMatrix&&(xt=R.instanceMatrix),it==="instanceColor"&&R.instanceColor&&(xt=R.instanceColor)),xt!==void 0){const Mt=xt.normalized,Ht=xt.itemSize,oe=e.get(xt);if(oe===void 0)continue;const xe=oe.buffer,H=oe.type,ft=oe.bytesPerElement,$=H===o.INT||H===o.UNSIGNED_INT||xt.gpuType===hm;if(xt.isInterleavedBufferAttribute){const at=xt.data,Et=at.stride,Ut=xt.offset;if(at.isInstancedInterleavedBuffer){for(let Rt=0;Rt<j.locationSize;Rt++)S(j.location+Rt,at.meshPerAttribute);R.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=at.meshPerAttribute*at.count)}else for(let Rt=0;Rt<j.locationSize;Rt++)y(j.location+Rt);o.bindBuffer(o.ARRAY_BUFFER,xe);for(let Rt=0;Rt<j.locationSize;Rt++)N(j.location+Rt,Ht/j.locationSize,H,Mt,Et*ft,(Ut+Ht/j.locationSize*Rt)*ft,$)}else{if(xt.isInstancedBufferAttribute){for(let at=0;at<j.locationSize;at++)S(j.location+at,xt.meshPerAttribute);R.isInstancedMesh!==!0&&et._maxInstanceCount===void 0&&(et._maxInstanceCount=xt.meshPerAttribute*xt.count)}else for(let at=0;at<j.locationSize;at++)y(j.location+at);o.bindBuffer(o.ARRAY_BUFFER,xe);for(let at=0;at<j.locationSize;at++)N(j.location+at,Ht/j.locationSize,H,Mt,Ht*ft,Ht/j.locationSize*at*ft,$)}}else if(k!==void 0){const Mt=k[it];if(Mt!==void 0)switch(Mt.length){case 2:o.vertexAttrib2fv(j.location,Mt);break;case 3:o.vertexAttrib3fv(j.location,Mt);break;case 4:o.vertexAttrib4fv(j.location,Mt);break;default:o.vertexAttrib1fv(j.location,Mt)}}}}U()}function I(){B();for(const R in r){const G=r[R];for(const Z in G){const et=G[Z];for(const ct in et)_(et[ct].object),delete et[ct];delete G[Z]}delete r[R]}}function z(R){if(r[R.id]===void 0)return;const G=r[R.id];for(const Z in G){const et=G[Z];for(const ct in et)_(et[ct].object),delete et[ct];delete G[Z]}delete r[R.id]}function L(R){for(const G in r){const Z=r[G];if(Z[R.id]===void 0)continue;const et=Z[R.id];for(const ct in et)_(et[ct].object),delete et[ct];delete Z[R.id]}}function B(){C(),h=!0,c!==l&&(c=l,g(c.object))}function C(){l.geometry=null,l.program=null,l.wireframe=!1}return{setup:d,reset:B,resetDefaultState:C,dispose:I,releaseStatesOfGeometry:z,releaseStatesOfProgram:L,initAttributes:b,enableAttribute:y,disableUnusedAttributes:U}}function FC(o,e,i){let r;function l(g){r=g}function c(g,_){o.drawArrays(r,g,_),i.update(_,r,1)}function h(g,_,p){p!==0&&(o.drawArraysInstanced(r,g,_,p),i.update(_,r,p))}function d(g,_,p){if(p===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(r,g,0,_,0,p);let M=0;for(let E=0;E<p;E++)M+=_[E];i.update(M,r,1)}function m(g,_,p,x){if(p===0)return;const M=e.get("WEBGL_multi_draw");if(M===null)for(let E=0;E<g.length;E++)h(g[E],_[E],x[E]);else{M.multiDrawArraysInstancedWEBGL(r,g,0,_,0,x,0,p);let E=0;for(let b=0;b<p;b++)E+=_[b]*x[b];i.update(E,r,1)}}this.setMode=l,this.render=c,this.renderInstances=h,this.renderMultiDraw=d,this.renderMultiDrawInstances=m}function HC(o,e,i,r){let l;function c(){if(l!==void 0)return l;if(e.has("EXT_texture_filter_anisotropic")===!0){const L=e.get("EXT_texture_filter_anisotropic");l=o.getParameter(L.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else l=0;return l}function h(L){return!(L!==Pi&&r.convert(L)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_FORMAT))}function d(L){const B=L===wl&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(L!==ea&&r.convert(L)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_TYPE)&&L!==Aa&&!B)}function m(L){if(L==="highp"){if(o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.HIGH_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.HIGH_FLOAT).precision>0)return"highp";L="mediump"}return L==="mediump"&&o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.MEDIUM_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let g=i.precision!==void 0?i.precision:"highp";const _=m(g);_!==g&&(console.warn("THREE.WebGLRenderer:",g,"not supported, using",_,"instead."),g=_);const p=i.logarithmicDepthBuffer===!0,x=i.reversedDepthBuffer===!0&&e.has("EXT_clip_control"),M=o.getParameter(o.MAX_TEXTURE_IMAGE_UNITS),E=o.getParameter(o.MAX_VERTEX_TEXTURE_IMAGE_UNITS),b=o.getParameter(o.MAX_TEXTURE_SIZE),y=o.getParameter(o.MAX_CUBE_MAP_TEXTURE_SIZE),S=o.getParameter(o.MAX_VERTEX_ATTRIBS),U=o.getParameter(o.MAX_VERTEX_UNIFORM_VECTORS),N=o.getParameter(o.MAX_VARYING_VECTORS),D=o.getParameter(o.MAX_FRAGMENT_UNIFORM_VECTORS),I=E>0,z=o.getParameter(o.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:c,getMaxPrecision:m,textureFormatReadable:h,textureTypeReadable:d,precision:g,logarithmicDepthBuffer:p,reversedDepthBuffer:x,maxTextures:M,maxVertexTextures:E,maxTextureSize:b,maxCubemapSize:y,maxAttributes:S,maxVertexUniforms:U,maxVaryings:N,maxFragmentUniforms:D,vertexTextures:I,maxSamples:z}}function GC(o){const e=this;let i=null,r=0,l=!1,c=!1;const h=new Wr,d=new me,m={value:null,needsUpdate:!1};this.uniform=m,this.numPlanes=0,this.numIntersection=0,this.init=function(p,x){const M=p.length!==0||x||r!==0||l;return l=x,r=p.length,M},this.beginShadows=function(){c=!0,_(null)},this.endShadows=function(){c=!1},this.setGlobalState=function(p,x){i=_(p,x,0)},this.setState=function(p,x,M){const E=p.clippingPlanes,b=p.clipIntersection,y=p.clipShadows,S=o.get(p);if(!l||E===null||E.length===0||c&&!y)c?_(null):g();else{const U=c?0:r,N=U*4;let D=S.clippingState||null;m.value=D,D=_(E,x,N,M);for(let I=0;I!==N;++I)D[I]=i[I];S.clippingState=D,this.numIntersection=b?this.numPlanes:0,this.numPlanes+=U}};function g(){m.value!==i&&(m.value=i,m.needsUpdate=r>0),e.numPlanes=r,e.numIntersection=0}function _(p,x,M,E){const b=p!==null?p.length:0;let y=null;if(b!==0){if(y=m.value,E!==!0||y===null){const S=M+b*4,U=x.matrixWorldInverse;d.getNormalMatrix(U),(y===null||y.length<S)&&(y=new Float32Array(S));for(let N=0,D=M;N!==b;++N,D+=4)h.copy(p[N]).applyMatrix4(U,d),h.normal.toArray(y,D),y[D+3]=h.constant}m.value=y,m.needsUpdate=!0}return e.numPlanes=b,e.numIntersection=0,y}}function VC(o){let e=new WeakMap;function i(h,d){return d===yp?h.mapping=co:d===Sp&&(h.mapping=fo),h}function r(h){if(h&&h.isTexture){const d=h.mapping;if(d===yp||d===Sp)if(e.has(h)){const m=e.get(h).texture;return i(m,h.mapping)}else{const m=h.image;if(m&&m.height>0){const g=new H1(m.height);return g.fromEquirectangularTexture(o,h),e.set(h,g),h.addEventListener("dispose",l),i(g.texture,h.mapping)}else return null}}return h}function l(h){const d=h.target;d.removeEventListener("dispose",l);const m=e.get(d);m!==void 0&&(e.delete(d),m.dispose())}function c(){e=new WeakMap}return{get:r,dispose:c}}const ao=4,Ax=[.125,.215,.35,.446,.526,.582],Kr=20,np=new Qy,Rx=new Se;let ip=null,ap=0,rp=0,sp=!1;const jr=(1+Math.sqrt(5))/2,to=1/jr,Cx=[new J(-jr,to,0),new J(jr,to,0),new J(-to,0,jr),new J(to,0,jr),new J(0,jr,-to),new J(0,jr,to),new J(-1,1,-1),new J(1,1,-1),new J(-1,1,1),new J(1,1,1)],XC=new J;class wx{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,i=0,r=.1,l=100,c={}){const{size:h=256,position:d=XC}=c;ip=this._renderer.getRenderTarget(),ap=this._renderer.getActiveCubeFace(),rp=this._renderer.getActiveMipmapLevel(),sp=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(h);const m=this._allocateTargets();return m.depthBuffer=!0,this._sceneToCubeUV(e,r,l,m,d),i>0&&this._blur(m,0,0,i),this._applyPMREM(m),this._cleanup(m),m}fromEquirectangular(e,i=null){return this._fromTexture(e,i)}fromCubemap(e,i=null){return this._fromTexture(e,i)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Nx(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Ux(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(ip,ap,rp),this._renderer.xr.enabled=sp,e.scissorTest=!1,bc(e,0,0,e.width,e.height)}_fromTexture(e,i){e.mapping===co||e.mapping===fo?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),ip=this._renderer.getRenderTarget(),ap=this._renderer.getActiveCubeFace(),rp=this._renderer.getActiveMipmapLevel(),sp=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const r=i||this._allocateTargets();return this._textureToCubeUV(e,r),this._applyPMREM(r),this._cleanup(r),r}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),i=4*this._cubeSize,r={magFilter:Ji,minFilter:Ji,generateMipmaps:!1,type:wl,format:Pi,colorSpace:ho,depthBuffer:!1},l=Dx(e,i,r);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==i){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Dx(e,i,r);const{_lodMax:c}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=kC(c)),this._blurMaterial=qC(c,e,i)}return l}_compileMaterial(e){const i=new Nn(this._lodPlanes[0],e);this._renderer.compile(i,np)}_sceneToCubeUV(e,i,r,l,c){const m=new ci(90,1,i,r),g=[1,-1,1,1,1,1],_=[1,1,1,-1,-1,-1],p=this._renderer,x=p.autoClear,M=p.toneMapping;p.getClearColor(Rx),p.toneMapping=pr,p.autoClear=!1,p.state.buffers.depth.getReversed()&&(p.setRenderTarget(l),p.clearDepth(),p.setRenderTarget(null));const b=new xm({name:"PMREM.Background",side:Qn,depthWrite:!1,depthTest:!1}),y=new Nn(new Ll,b);let S=!1;const U=e.background;U?U.isColor&&(b.color.copy(U),e.background=null,S=!0):(b.color.copy(Rx),S=!0);for(let N=0;N<6;N++){const D=N%3;D===0?(m.up.set(0,g[N],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x+_[N],c.y,c.z)):D===1?(m.up.set(0,0,g[N]),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y+_[N],c.z)):(m.up.set(0,g[N],0),m.position.set(c.x,c.y,c.z),m.lookAt(c.x,c.y,c.z+_[N]));const I=this._cubeSize;bc(l,D*I,N>2?I:0,I,I),p.setRenderTarget(l),S&&p.render(y,m),p.render(e,m)}y.geometry.dispose(),y.material.dispose(),p.toneMapping=M,p.autoClear=x,e.background=U}_textureToCubeUV(e,i){const r=this._renderer,l=e.mapping===co||e.mapping===fo;l?(this._cubemapMaterial===null&&(this._cubemapMaterial=Nx()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Ux());const c=l?this._cubemapMaterial:this._equirectMaterial,h=new Nn(this._lodPlanes[0],c),d=c.uniforms;d.envMap.value=e;const m=this._cubeSize;bc(i,0,0,3*m,2*m),r.setRenderTarget(i),r.render(h,np)}_applyPMREM(e){const i=this._renderer,r=i.autoClear;i.autoClear=!1;const l=this._lodPlanes.length;for(let c=1;c<l;c++){const h=Math.sqrt(this._sigmas[c]*this._sigmas[c]-this._sigmas[c-1]*this._sigmas[c-1]),d=Cx[(l-c-1)%Cx.length];this._blur(e,c-1,c,h,d)}i.autoClear=r}_blur(e,i,r,l,c){const h=this._pingPongRenderTarget;this._halfBlur(e,h,i,r,l,"latitudinal",c),this._halfBlur(h,e,r,r,l,"longitudinal",c)}_halfBlur(e,i,r,l,c,h,d){const m=this._renderer,g=this._blurMaterial;h!=="latitudinal"&&h!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const _=3,p=new Nn(this._lodPlanes[l],g),x=g.uniforms,M=this._sizeLods[r]-1,E=isFinite(c)?Math.PI/(2*M):2*Math.PI/(2*Kr-1),b=c/E,y=isFinite(c)?1+Math.floor(_*b):Kr;y>Kr&&console.warn(`sigmaRadians, ${c}, is too large and will clip, as it requested ${y} samples when the maximum is set to ${Kr}`);const S=[];let U=0;for(let L=0;L<Kr;++L){const B=L/b,C=Math.exp(-B*B/2);S.push(C),L===0?U+=C:L<y&&(U+=2*C)}for(let L=0;L<S.length;L++)S[L]=S[L]/U;x.envMap.value=e.texture,x.samples.value=y,x.weights.value=S,x.latitudinal.value=h==="latitudinal",d&&(x.poleAxis.value=d);const{_lodMax:N}=this;x.dTheta.value=E,x.mipInt.value=N-r;const D=this._sizeLods[l],I=3*D*(l>N-ao?l-N+ao:0),z=4*(this._cubeSize-D);bc(i,I,z,3*D,2*D),m.setRenderTarget(i),m.render(p,np)}}function kC(o){const e=[],i=[],r=[];let l=o;const c=o-ao+1+Ax.length;for(let h=0;h<c;h++){const d=Math.pow(2,l);i.push(d);let m=1/d;h>o-ao?m=Ax[h-o+ao-1]:h===0&&(m=0),r.push(m);const g=1/(d-2),_=-g,p=1+g,x=[_,_,p,_,p,p,_,_,p,p,_,p],M=6,E=6,b=3,y=2,S=1,U=new Float32Array(b*E*M),N=new Float32Array(y*E*M),D=new Float32Array(S*E*M);for(let z=0;z<M;z++){const L=z%3*2/3-1,B=z>2?0:-1,C=[L,B,0,L+2/3,B,0,L+2/3,B+1,0,L,B,0,L+2/3,B+1,0,L,B+1,0];U.set(C,b*E*z),N.set(x,y*E*z);const R=[z,z,z,z,z,z];D.set(R,S*E*z)}const I=new Ti;I.setAttribute("position",new Bi(U,b)),I.setAttribute("uv",new Bi(N,y)),I.setAttribute("faceIndex",new Bi(D,S)),e.push(I),l>ao&&l--}return{lodPlanes:e,sizeLods:i,sigmas:r}}function Dx(o,e,i){const r=new ts(o,e,i);return r.texture.mapping=Vc,r.texture.name="PMREM.cubeUv",r.scissorTest=!0,r}function bc(o,e,i,r,l){o.viewport.set(e,i,r,l),o.scissor.set(e,i,r,l)}function qC(o,e,i){const r=new Float32Array(Kr),l=new J(0,1,0);return new gr({name:"SphericalGaussianBlur",defines:{n:Kr,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/i,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:r},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:l}},vertexShader:bm(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:dr,depthTest:!1,depthWrite:!1})}function Ux(){return new gr({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:bm(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:dr,depthTest:!1,depthWrite:!1})}function Nx(){return new gr({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:bm(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:dr,depthTest:!1,depthWrite:!1})}function bm(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function YC(o){let e=new WeakMap,i=null;function r(d){if(d&&d.isTexture){const m=d.mapping,g=m===yp||m===Sp,_=m===co||m===fo;if(g||_){let p=e.get(d);const x=p!==void 0?p.texture.pmremVersion:0;if(d.isRenderTargetTexture&&d.pmremVersion!==x)return i===null&&(i=new wx(o)),p=g?i.fromEquirectangular(d,p):i.fromCubemap(d,p),p.texture.pmremVersion=d.pmremVersion,e.set(d,p),p.texture;if(p!==void 0)return p.texture;{const M=d.image;return g&&M&&M.height>0||_&&M&&l(M)?(i===null&&(i=new wx(o)),p=g?i.fromEquirectangular(d):i.fromCubemap(d),p.texture.pmremVersion=d.pmremVersion,e.set(d,p),d.addEventListener("dispose",c),p.texture):null}}}return d}function l(d){let m=0;const g=6;for(let _=0;_<g;_++)d[_]!==void 0&&m++;return m===g}function c(d){const m=d.target;m.removeEventListener("dispose",c);const g=e.get(m);g!==void 0&&(e.delete(m),g.dispose())}function h(){e=new WeakMap,i!==null&&(i.dispose(),i=null)}return{get:r,dispose:h}}function WC(o){const e={};function i(r){if(e[r]!==void 0)return e[r];let l;switch(r){case"WEBGL_depth_texture":l=o.getExtension("WEBGL_depth_texture")||o.getExtension("MOZ_WEBGL_depth_texture")||o.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":l=o.getExtension("EXT_texture_filter_anisotropic")||o.getExtension("MOZ_EXT_texture_filter_anisotropic")||o.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":l=o.getExtension("WEBGL_compressed_texture_s3tc")||o.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":l=o.getExtension("WEBGL_compressed_texture_pvrtc")||o.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:l=o.getExtension(r)}return e[r]=l,l}return{has:function(r){return i(r)!==null},init:function(){i("EXT_color_buffer_float"),i("WEBGL_clip_cull_distance"),i("OES_texture_float_linear"),i("EXT_color_buffer_half_float"),i("WEBGL_multisampled_render_to_texture"),i("WEBGL_render_shared_exponent")},get:function(r){const l=i(r);return l===null&&bl("THREE.WebGLRenderer: "+r+" extension not supported."),l}}}function jC(o,e,i,r){const l={},c=new WeakMap;function h(p){const x=p.target;x.index!==null&&e.remove(x.index);for(const E in x.attributes)e.remove(x.attributes[E]);x.removeEventListener("dispose",h),delete l[x.id];const M=c.get(x);M&&(e.remove(M),c.delete(x)),r.releaseStatesOfGeometry(x),x.isInstancedBufferGeometry===!0&&delete x._maxInstanceCount,i.memory.geometries--}function d(p,x){return l[x.id]===!0||(x.addEventListener("dispose",h),l[x.id]=!0,i.memory.geometries++),x}function m(p){const x=p.attributes;for(const M in x)e.update(x[M],o.ARRAY_BUFFER)}function g(p){const x=[],M=p.index,E=p.attributes.position;let b=0;if(M!==null){const U=M.array;b=M.version;for(let N=0,D=U.length;N<D;N+=3){const I=U[N+0],z=U[N+1],L=U[N+2];x.push(I,z,z,L,L,I)}}else if(E!==void 0){const U=E.array;b=E.version;for(let N=0,D=U.length/3-1;N<D;N+=3){const I=N+0,z=N+1,L=N+2;x.push(I,z,z,L,L,I)}}else return;const y=new(Iy(x)?Xy:Vy)(x,1);y.version=b;const S=c.get(p);S&&e.remove(S),c.set(p,y)}function _(p){const x=c.get(p);if(x){const M=p.index;M!==null&&x.version<M.version&&g(p)}else g(p);return c.get(p)}return{get:d,update:m,getWireframeAttribute:_}}function ZC(o,e,i){let r;function l(x){r=x}let c,h;function d(x){c=x.type,h=x.bytesPerElement}function m(x,M){o.drawElements(r,M,c,x*h),i.update(M,r,1)}function g(x,M,E){E!==0&&(o.drawElementsInstanced(r,M,c,x*h,E),i.update(M,r,E))}function _(x,M,E){if(E===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(r,M,0,c,x,0,E);let y=0;for(let S=0;S<E;S++)y+=M[S];i.update(y,r,1)}function p(x,M,E,b){if(E===0)return;const y=e.get("WEBGL_multi_draw");if(y===null)for(let S=0;S<x.length;S++)g(x[S]/h,M[S],b[S]);else{y.multiDrawElementsInstancedWEBGL(r,M,0,c,x,0,b,0,E);let S=0;for(let U=0;U<E;U++)S+=M[U]*b[U];i.update(S,r,1)}}this.setMode=l,this.setIndex=d,this.render=m,this.renderInstances=g,this.renderMultiDraw=_,this.renderMultiDrawInstances=p}function KC(o){const e={geometries:0,textures:0},i={frame:0,calls:0,triangles:0,points:0,lines:0};function r(c,h,d){switch(i.calls++,h){case o.TRIANGLES:i.triangles+=d*(c/3);break;case o.LINES:i.lines+=d*(c/2);break;case o.LINE_STRIP:i.lines+=d*(c-1);break;case o.LINE_LOOP:i.lines+=d*c;break;case o.POINTS:i.points+=d*c;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",h);break}}function l(){i.calls=0,i.triangles=0,i.points=0,i.lines=0}return{memory:e,render:i,programs:null,autoReset:!0,reset:l,update:r}}function QC(o,e,i){const r=new WeakMap,l=new We;function c(h,d,m){const g=h.morphTargetInfluences,_=d.morphAttributes.position||d.morphAttributes.normal||d.morphAttributes.color,p=_!==void 0?_.length:0;let x=r.get(d);if(x===void 0||x.count!==p){let R=function(){B.dispose(),r.delete(d),d.removeEventListener("dispose",R)};var M=R;x!==void 0&&x.texture.dispose();const E=d.morphAttributes.position!==void 0,b=d.morphAttributes.normal!==void 0,y=d.morphAttributes.color!==void 0,S=d.morphAttributes.position||[],U=d.morphAttributes.normal||[],N=d.morphAttributes.color||[];let D=0;E===!0&&(D=1),b===!0&&(D=2),y===!0&&(D=3);let I=d.attributes.position.count*D,z=1;I>e.maxTextureSize&&(z=Math.ceil(I/e.maxTextureSize),I=e.maxTextureSize);const L=new Float32Array(I*z*4*p),B=new By(L,I,z,p);B.type=Aa,B.needsUpdate=!0;const C=D*4;for(let G=0;G<p;G++){const Z=S[G],et=U[G],ct=N[G],st=I*z*4*G;for(let k=0;k<Z.count;k++){const it=k*C;E===!0&&(l.fromBufferAttribute(Z,k),L[st+it+0]=l.x,L[st+it+1]=l.y,L[st+it+2]=l.z,L[st+it+3]=0),b===!0&&(l.fromBufferAttribute(et,k),L[st+it+4]=l.x,L[st+it+5]=l.y,L[st+it+6]=l.z,L[st+it+7]=0),y===!0&&(l.fromBufferAttribute(ct,k),L[st+it+8]=l.x,L[st+it+9]=l.y,L[st+it+10]=l.z,L[st+it+11]=ct.itemSize===4?l.w:1)}}x={count:p,texture:B,size:new be(I,z)},r.set(d,x),d.addEventListener("dispose",R)}if(h.isInstancedMesh===!0&&h.morphTexture!==null)m.getUniforms().setValue(o,"morphTexture",h.morphTexture,i);else{let E=0;for(let y=0;y<g.length;y++)E+=g[y];const b=d.morphTargetsRelative?1:1-E;m.getUniforms().setValue(o,"morphTargetBaseInfluence",b),m.getUniforms().setValue(o,"morphTargetInfluences",g)}m.getUniforms().setValue(o,"morphTargetsTexture",x.texture,i),m.getUniforms().setValue(o,"morphTargetsTextureSize",x.size)}return{update:c}}function JC(o,e,i,r){let l=new WeakMap;function c(m){const g=r.render.frame,_=m.geometry,p=e.get(m,_);if(l.get(p)!==g&&(e.update(p),l.set(p,g)),m.isInstancedMesh&&(m.hasEventListener("dispose",d)===!1&&m.addEventListener("dispose",d),l.get(m)!==g&&(i.update(m.instanceMatrix,o.ARRAY_BUFFER),m.instanceColor!==null&&i.update(m.instanceColor,o.ARRAY_BUFFER),l.set(m,g))),m.isSkinnedMesh){const x=m.skeleton;l.get(x)!==g&&(x.update(),l.set(x,g))}return p}function h(){l=new WeakMap}function d(m){const g=m.target;g.removeEventListener("dispose",d),i.remove(g.instanceMatrix),g.instanceColor!==null&&i.remove(g.instanceColor)}return{update:c,dispose:h}}const $y=new Jn,Lx=new jy(1,1),tS=new By,eS=new E1,nS=new Yy,Ox=[],Px=[],zx=new Float32Array(16),Ix=new Float32Array(9),Bx=new Float32Array(4);function xo(o,e,i){const r=o[0];if(r<=0||r>0)return o;const l=e*i;let c=Ox[l];if(c===void 0&&(c=new Float32Array(l),Ox[l]=c),e!==0){r.toArray(c,0);for(let h=1,d=0;h!==e;++h)d+=i,o[h].toArray(c,d)}return c}function xn(o,e){if(o.length!==e.length)return!1;for(let i=0,r=o.length;i<r;i++)if(o[i]!==e[i])return!1;return!0}function yn(o,e){for(let i=0,r=e.length;i<r;i++)o[i]=e[i]}function qc(o,e){let i=Px[e];i===void 0&&(i=new Int32Array(e),Px[e]=i);for(let r=0;r!==e;++r)i[r]=o.allocateTextureUnit();return i}function $C(o,e){const i=this.cache;i[0]!==e&&(o.uniform1f(this.addr,e),i[0]=e)}function tw(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(o.uniform2f(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(xn(i,e))return;o.uniform2fv(this.addr,e),yn(i,e)}}function ew(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(o.uniform3f(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else if(e.r!==void 0)(i[0]!==e.r||i[1]!==e.g||i[2]!==e.b)&&(o.uniform3f(this.addr,e.r,e.g,e.b),i[0]=e.r,i[1]=e.g,i[2]=e.b);else{if(xn(i,e))return;o.uniform3fv(this.addr,e),yn(i,e)}}function nw(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(o.uniform4f(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(xn(i,e))return;o.uniform4fv(this.addr,e),yn(i,e)}}function iw(o,e){const i=this.cache,r=e.elements;if(r===void 0){if(xn(i,e))return;o.uniformMatrix2fv(this.addr,!1,e),yn(i,e)}else{if(xn(i,r))return;Bx.set(r),o.uniformMatrix2fv(this.addr,!1,Bx),yn(i,r)}}function aw(o,e){const i=this.cache,r=e.elements;if(r===void 0){if(xn(i,e))return;o.uniformMatrix3fv(this.addr,!1,e),yn(i,e)}else{if(xn(i,r))return;Ix.set(r),o.uniformMatrix3fv(this.addr,!1,Ix),yn(i,r)}}function rw(o,e){const i=this.cache,r=e.elements;if(r===void 0){if(xn(i,e))return;o.uniformMatrix4fv(this.addr,!1,e),yn(i,e)}else{if(xn(i,r))return;zx.set(r),o.uniformMatrix4fv(this.addr,!1,zx),yn(i,r)}}function sw(o,e){const i=this.cache;i[0]!==e&&(o.uniform1i(this.addr,e),i[0]=e)}function ow(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(o.uniform2i(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(xn(i,e))return;o.uniform2iv(this.addr,e),yn(i,e)}}function lw(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(o.uniform3i(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else{if(xn(i,e))return;o.uniform3iv(this.addr,e),yn(i,e)}}function uw(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(o.uniform4i(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(xn(i,e))return;o.uniform4iv(this.addr,e),yn(i,e)}}function cw(o,e){const i=this.cache;i[0]!==e&&(o.uniform1ui(this.addr,e),i[0]=e)}function fw(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y)&&(o.uniform2ui(this.addr,e.x,e.y),i[0]=e.x,i[1]=e.y);else{if(xn(i,e))return;o.uniform2uiv(this.addr,e),yn(i,e)}}function hw(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z)&&(o.uniform3ui(this.addr,e.x,e.y,e.z),i[0]=e.x,i[1]=e.y,i[2]=e.z);else{if(xn(i,e))return;o.uniform3uiv(this.addr,e),yn(i,e)}}function dw(o,e){const i=this.cache;if(e.x!==void 0)(i[0]!==e.x||i[1]!==e.y||i[2]!==e.z||i[3]!==e.w)&&(o.uniform4ui(this.addr,e.x,e.y,e.z,e.w),i[0]=e.x,i[1]=e.y,i[2]=e.z,i[3]=e.w);else{if(xn(i,e))return;o.uniform4uiv(this.addr,e),yn(i,e)}}function pw(o,e,i){const r=this.cache,l=i.allocateTextureUnit();r[0]!==l&&(o.uniform1i(this.addr,l),r[0]=l);let c;this.type===o.SAMPLER_2D_SHADOW?(Lx.compareFunction=zy,c=Lx):c=$y,i.setTexture2D(e||c,l)}function mw(o,e,i){const r=this.cache,l=i.allocateTextureUnit();r[0]!==l&&(o.uniform1i(this.addr,l),r[0]=l),i.setTexture3D(e||eS,l)}function gw(o,e,i){const r=this.cache,l=i.allocateTextureUnit();r[0]!==l&&(o.uniform1i(this.addr,l),r[0]=l),i.setTextureCube(e||nS,l)}function _w(o,e,i){const r=this.cache,l=i.allocateTextureUnit();r[0]!==l&&(o.uniform1i(this.addr,l),r[0]=l),i.setTexture2DArray(e||tS,l)}function vw(o){switch(o){case 5126:return $C;case 35664:return tw;case 35665:return ew;case 35666:return nw;case 35674:return iw;case 35675:return aw;case 35676:return rw;case 5124:case 35670:return sw;case 35667:case 35671:return ow;case 35668:case 35672:return lw;case 35669:case 35673:return uw;case 5125:return cw;case 36294:return fw;case 36295:return hw;case 36296:return dw;case 35678:case 36198:case 36298:case 36306:case 35682:return pw;case 35679:case 36299:case 36307:return mw;case 35680:case 36300:case 36308:case 36293:return gw;case 36289:case 36303:case 36311:case 36292:return _w}}function xw(o,e){o.uniform1fv(this.addr,e)}function yw(o,e){const i=xo(e,this.size,2);o.uniform2fv(this.addr,i)}function Sw(o,e){const i=xo(e,this.size,3);o.uniform3fv(this.addr,i)}function Mw(o,e){const i=xo(e,this.size,4);o.uniform4fv(this.addr,i)}function Ew(o,e){const i=xo(e,this.size,4);o.uniformMatrix2fv(this.addr,!1,i)}function Tw(o,e){const i=xo(e,this.size,9);o.uniformMatrix3fv(this.addr,!1,i)}function bw(o,e){const i=xo(e,this.size,16);o.uniformMatrix4fv(this.addr,!1,i)}function Aw(o,e){o.uniform1iv(this.addr,e)}function Rw(o,e){o.uniform2iv(this.addr,e)}function Cw(o,e){o.uniform3iv(this.addr,e)}function ww(o,e){o.uniform4iv(this.addr,e)}function Dw(o,e){o.uniform1uiv(this.addr,e)}function Uw(o,e){o.uniform2uiv(this.addr,e)}function Nw(o,e){o.uniform3uiv(this.addr,e)}function Lw(o,e){o.uniform4uiv(this.addr,e)}function Ow(o,e,i){const r=this.cache,l=e.length,c=qc(i,l);xn(r,c)||(o.uniform1iv(this.addr,c),yn(r,c));for(let h=0;h!==l;++h)i.setTexture2D(e[h]||$y,c[h])}function Pw(o,e,i){const r=this.cache,l=e.length,c=qc(i,l);xn(r,c)||(o.uniform1iv(this.addr,c),yn(r,c));for(let h=0;h!==l;++h)i.setTexture3D(e[h]||eS,c[h])}function zw(o,e,i){const r=this.cache,l=e.length,c=qc(i,l);xn(r,c)||(o.uniform1iv(this.addr,c),yn(r,c));for(let h=0;h!==l;++h)i.setTextureCube(e[h]||nS,c[h])}function Iw(o,e,i){const r=this.cache,l=e.length,c=qc(i,l);xn(r,c)||(o.uniform1iv(this.addr,c),yn(r,c));for(let h=0;h!==l;++h)i.setTexture2DArray(e[h]||tS,c[h])}function Bw(o){switch(o){case 5126:return xw;case 35664:return yw;case 35665:return Sw;case 35666:return Mw;case 35674:return Ew;case 35675:return Tw;case 35676:return bw;case 5124:case 35670:return Aw;case 35667:case 35671:return Rw;case 35668:case 35672:return Cw;case 35669:case 35673:return ww;case 5125:return Dw;case 36294:return Uw;case 36295:return Nw;case 36296:return Lw;case 35678:case 36198:case 36298:case 36306:case 35682:return Ow;case 35679:case 36299:case 36307:return Pw;case 35680:case 36300:case 36308:case 36293:return zw;case 36289:case 36303:case 36311:case 36292:return Iw}}class Fw{constructor(e,i,r){this.id=e,this.addr=r,this.cache=[],this.type=i.type,this.setValue=vw(i.type)}}class Hw{constructor(e,i,r){this.id=e,this.addr=r,this.cache=[],this.type=i.type,this.size=i.size,this.setValue=Bw(i.type)}}class Gw{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,i,r){const l=this.seq;for(let c=0,h=l.length;c!==h;++c){const d=l[c];d.setValue(e,i[d.id],r)}}}const op=/(\w+)(\])?(\[|\.)?/g;function Fx(o,e){o.seq.push(e),o.map[e.id]=e}function Vw(o,e,i){const r=o.name,l=r.length;for(op.lastIndex=0;;){const c=op.exec(r),h=op.lastIndex;let d=c[1];const m=c[2]==="]",g=c[3];if(m&&(d=d|0),g===void 0||g==="["&&h+2===l){Fx(i,g===void 0?new Fw(d,o,e):new Hw(d,o,e));break}else{let p=i.map[d];p===void 0&&(p=new Gw(d),Fx(i,p)),i=p}}}class Lc{constructor(e,i){this.seq=[],this.map={};const r=e.getProgramParameter(i,e.ACTIVE_UNIFORMS);for(let l=0;l<r;++l){const c=e.getActiveUniform(i,l),h=e.getUniformLocation(i,c.name);Vw(c,h,this)}}setValue(e,i,r,l){const c=this.map[i];c!==void 0&&c.setValue(e,r,l)}setOptional(e,i,r){const l=i[r];l!==void 0&&this.setValue(e,r,l)}static upload(e,i,r,l){for(let c=0,h=i.length;c!==h;++c){const d=i[c],m=r[d.id];m.needsUpdate!==!1&&d.setValue(e,m.value,l)}}static seqWithValue(e,i){const r=[];for(let l=0,c=e.length;l!==c;++l){const h=e[l];h.id in i&&r.push(h)}return r}}function Hx(o,e,i){const r=o.createShader(e);return o.shaderSource(r,i),o.compileShader(r),r}const Xw=37297;let kw=0;function qw(o,e){const i=o.split(`
`),r=[],l=Math.max(e-6,0),c=Math.min(e+6,i.length);for(let h=l;h<c;h++){const d=h+1;r.push(`${d===e?">":" "} ${d}: ${i[h]}`)}return r.join(`
`)}const Gx=new me;function Yw(o){Oe._getMatrix(Gx,Oe.workingColorSpace,o);const e=`mat3( ${Gx.elements.map(i=>i.toFixed(4))} )`;switch(Oe.getTransfer(o)){case Pc:return[e,"LinearTransferOETF"];case Ye:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",o),[e,"LinearTransferOETF"]}}function Vx(o,e,i){const r=o.getShaderParameter(e,o.COMPILE_STATUS),c=(o.getShaderInfoLog(e)||"").trim();if(r&&c==="")return"";const h=/ERROR: 0:(\d+)/.exec(c);if(h){const d=parseInt(h[1]);return i.toUpperCase()+`

`+c+`

`+qw(o.getShaderSource(e),d)}else return c}function Ww(o,e){const i=Yw(e);return[`vec4 ${o}( vec4 value ) {`,`	return ${i[1]}( vec4( value.rgb * ${i[0]}, value.a ) );`,"}"].join(`
`)}function jw(o,e){let i;switch(e){case Jb:i="Linear";break;case $b:i="Reinhard";break;case t1:i="Cineon";break;case by:i="ACESFilmic";break;case n1:i="AgX";break;case i1:i="Neutral";break;case e1:i="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),i="Linear"}return"vec3 "+o+"( vec3 color ) { return "+i+"ToneMapping( color ); }"}const Ac=new J;function Zw(){Oe.getLuminanceCoefficients(Ac);const o=Ac.x.toFixed(4),e=Ac.y.toFixed(4),i=Ac.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${o}, ${e}, ${i} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Kw(o){return[o.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",o.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(yl).join(`
`)}function Qw(o){const e=[];for(const i in o){const r=o[i];r!==!1&&e.push("#define "+i+" "+r)}return e.join(`
`)}function Jw(o,e){const i={},r=o.getProgramParameter(e,o.ACTIVE_ATTRIBUTES);for(let l=0;l<r;l++){const c=o.getActiveAttrib(e,l),h=c.name;let d=1;c.type===o.FLOAT_MAT2&&(d=2),c.type===o.FLOAT_MAT3&&(d=3),c.type===o.FLOAT_MAT4&&(d=4),i[h]={type:c.type,location:o.getAttribLocation(e,h),locationSize:d}}return i}function yl(o){return o!==""}function Xx(o,e){const i=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return o.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,i).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function kx(o,e){return o.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const $w=/^[ \t]*#include +<([\w\d./]+)>/gm;function tm(o){return o.replace($w,e2)}const t2=new Map;function e2(o,e){let i=ge[e];if(i===void 0){const r=t2.get(e);if(r!==void 0)i=ge[r],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,r);else throw new Error("Can not resolve #include <"+e+">")}return tm(i)}const n2=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function qx(o){return o.replace(n2,i2)}function i2(o,e,i,r){let l="";for(let c=parseInt(e);c<parseInt(i);c++)l+=r.replace(/\[\s*i\s*\]/g,"[ "+c+" ]").replace(/UNROLLED_LOOP_INDEX/g,c);return l}function Yx(o){let e=`precision ${o.precision} float;
	precision ${o.precision} int;
	precision ${o.precision} sampler2D;
	precision ${o.precision} samplerCube;
	precision ${o.precision} sampler3D;
	precision ${o.precision} sampler2DArray;
	precision ${o.precision} sampler2DShadow;
	precision ${o.precision} samplerCubeShadow;
	precision ${o.precision} sampler2DArrayShadow;
	precision ${o.precision} isampler2D;
	precision ${o.precision} isampler3D;
	precision ${o.precision} isamplerCube;
	precision ${o.precision} isampler2DArray;
	precision ${o.precision} usampler2D;
	precision ${o.precision} usampler3D;
	precision ${o.precision} usamplerCube;
	precision ${o.precision} usampler2DArray;
	`;return o.precision==="highp"?e+=`
#define HIGH_PRECISION`:o.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:o.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function a2(o){let e="SHADOWMAP_TYPE_BASIC";return o.shadowMapType===My?e="SHADOWMAP_TYPE_PCF":o.shadowMapType===Ey?e="SHADOWMAP_TYPE_PCF_SOFT":o.shadowMapType===Ta&&(e="SHADOWMAP_TYPE_VSM"),e}function r2(o){let e="ENVMAP_TYPE_CUBE";if(o.envMap)switch(o.envMapMode){case co:case fo:e="ENVMAP_TYPE_CUBE";break;case Vc:e="ENVMAP_TYPE_CUBE_UV";break}return e}function s2(o){let e="ENVMAP_MODE_REFLECTION";return o.envMap&&o.envMapMode===fo&&(e="ENVMAP_MODE_REFRACTION"),e}function o2(o){let e="ENVMAP_BLENDING_NONE";if(o.envMap)switch(o.combine){case Ty:e="ENVMAP_BLENDING_MULTIPLY";break;case Kb:e="ENVMAP_BLENDING_MIX";break;case Qb:e="ENVMAP_BLENDING_ADD";break}return e}function l2(o){const e=o.envMapCubeUVHeight;if(e===null)return null;const i=Math.log2(e)-2,r=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,i),112)),texelHeight:r,maxMip:i}}function u2(o,e,i,r){const l=o.getContext(),c=i.defines;let h=i.vertexShader,d=i.fragmentShader;const m=a2(i),g=r2(i),_=s2(i),p=o2(i),x=l2(i),M=Kw(i),E=Qw(c),b=l.createProgram();let y,S,U=i.glslVersion?"#version "+i.glslVersion+`
`:"";i.isRawShaderMaterial?(y=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,E].filter(yl).join(`
`),y.length>0&&(y+=`
`),S=["#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,E].filter(yl).join(`
`),S.length>0&&(S+=`
`)):(y=[Yx(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,E,i.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",i.batching?"#define USE_BATCHING":"",i.batchingColor?"#define USE_BATCHING_COLOR":"",i.instancing?"#define USE_INSTANCING":"",i.instancingColor?"#define USE_INSTANCING_COLOR":"",i.instancingMorph?"#define USE_INSTANCING_MORPH":"",i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.map?"#define USE_MAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+_:"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.displacementMap?"#define USE_DISPLACEMENTMAP":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.mapUv?"#define MAP_UV "+i.mapUv:"",i.alphaMapUv?"#define ALPHAMAP_UV "+i.alphaMapUv:"",i.lightMapUv?"#define LIGHTMAP_UV "+i.lightMapUv:"",i.aoMapUv?"#define AOMAP_UV "+i.aoMapUv:"",i.emissiveMapUv?"#define EMISSIVEMAP_UV "+i.emissiveMapUv:"",i.bumpMapUv?"#define BUMPMAP_UV "+i.bumpMapUv:"",i.normalMapUv?"#define NORMALMAP_UV "+i.normalMapUv:"",i.displacementMapUv?"#define DISPLACEMENTMAP_UV "+i.displacementMapUv:"",i.metalnessMapUv?"#define METALNESSMAP_UV "+i.metalnessMapUv:"",i.roughnessMapUv?"#define ROUGHNESSMAP_UV "+i.roughnessMapUv:"",i.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+i.anisotropyMapUv:"",i.clearcoatMapUv?"#define CLEARCOATMAP_UV "+i.clearcoatMapUv:"",i.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+i.clearcoatNormalMapUv:"",i.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+i.clearcoatRoughnessMapUv:"",i.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+i.iridescenceMapUv:"",i.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+i.iridescenceThicknessMapUv:"",i.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+i.sheenColorMapUv:"",i.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+i.sheenRoughnessMapUv:"",i.specularMapUv?"#define SPECULARMAP_UV "+i.specularMapUv:"",i.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+i.specularColorMapUv:"",i.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+i.specularIntensityMapUv:"",i.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+i.transmissionMapUv:"",i.thicknessMapUv?"#define THICKNESSMAP_UV "+i.thicknessMapUv:"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.flatShading?"#define FLAT_SHADED":"",i.skinning?"#define USE_SKINNING":"",i.morphTargets?"#define USE_MORPHTARGETS":"",i.morphNormals&&i.flatShading===!1?"#define USE_MORPHNORMALS":"",i.morphColors?"#define USE_MORPHCOLORS":"",i.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+i.morphTextureStride:"",i.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+i.morphTargetsCount:"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.sizeAttenuation?"#define USE_SIZEATTENUATION":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(yl).join(`
`),S=[Yx(i),"#define SHADER_TYPE "+i.shaderType,"#define SHADER_NAME "+i.shaderName,E,i.useFog&&i.fog?"#define USE_FOG":"",i.useFog&&i.fogExp2?"#define FOG_EXP2":"",i.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",i.map?"#define USE_MAP":"",i.matcap?"#define USE_MATCAP":"",i.envMap?"#define USE_ENVMAP":"",i.envMap?"#define "+g:"",i.envMap?"#define "+_:"",i.envMap?"#define "+p:"",x?"#define CUBEUV_TEXEL_WIDTH "+x.texelWidth:"",x?"#define CUBEUV_TEXEL_HEIGHT "+x.texelHeight:"",x?"#define CUBEUV_MAX_MIP "+x.maxMip+".0":"",i.lightMap?"#define USE_LIGHTMAP":"",i.aoMap?"#define USE_AOMAP":"",i.bumpMap?"#define USE_BUMPMAP":"",i.normalMap?"#define USE_NORMALMAP":"",i.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",i.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",i.emissiveMap?"#define USE_EMISSIVEMAP":"",i.anisotropy?"#define USE_ANISOTROPY":"",i.anisotropyMap?"#define USE_ANISOTROPYMAP":"",i.clearcoat?"#define USE_CLEARCOAT":"",i.clearcoatMap?"#define USE_CLEARCOATMAP":"",i.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",i.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",i.dispersion?"#define USE_DISPERSION":"",i.iridescence?"#define USE_IRIDESCENCE":"",i.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",i.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",i.specularMap?"#define USE_SPECULARMAP":"",i.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",i.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",i.roughnessMap?"#define USE_ROUGHNESSMAP":"",i.metalnessMap?"#define USE_METALNESSMAP":"",i.alphaMap?"#define USE_ALPHAMAP":"",i.alphaTest?"#define USE_ALPHATEST":"",i.alphaHash?"#define USE_ALPHAHASH":"",i.sheen?"#define USE_SHEEN":"",i.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",i.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",i.transmission?"#define USE_TRANSMISSION":"",i.transmissionMap?"#define USE_TRANSMISSIONMAP":"",i.thicknessMap?"#define USE_THICKNESSMAP":"",i.vertexTangents&&i.flatShading===!1?"#define USE_TANGENT":"",i.vertexColors||i.instancingColor||i.batchingColor?"#define USE_COLOR":"",i.vertexAlphas?"#define USE_COLOR_ALPHA":"",i.vertexUv1s?"#define USE_UV1":"",i.vertexUv2s?"#define USE_UV2":"",i.vertexUv3s?"#define USE_UV3":"",i.pointsUvs?"#define USE_POINTS_UV":"",i.gradientMap?"#define USE_GRADIENTMAP":"",i.flatShading?"#define FLAT_SHADED":"",i.doubleSided?"#define DOUBLE_SIDED":"",i.flipSided?"#define FLIP_SIDED":"",i.shadowMapEnabled?"#define USE_SHADOWMAP":"",i.shadowMapEnabled?"#define "+m:"",i.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",i.numLightProbes>0?"#define USE_LIGHT_PROBES":"",i.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",i.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",i.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",i.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",i.toneMapping!==pr?"#define TONE_MAPPING":"",i.toneMapping!==pr?ge.tonemapping_pars_fragment:"",i.toneMapping!==pr?jw("toneMapping",i.toneMapping):"",i.dithering?"#define DITHERING":"",i.opaque?"#define OPAQUE":"",ge.colorspace_pars_fragment,Ww("linearToOutputTexel",i.outputColorSpace),Zw(),i.useDepthPacking?"#define DEPTH_PACKING "+i.depthPacking:"",`
`].filter(yl).join(`
`)),h=tm(h),h=Xx(h,i),h=kx(h,i),d=tm(d),d=Xx(d,i),d=kx(d,i),h=qx(h),d=qx(d),i.isRawShaderMaterial!==!0&&(U=`#version 300 es
`,y=[M,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+y,S=["#define varying in",i.glslVersion===ex?"":"layout(location = 0) out highp vec4 pc_fragColor;",i.glslVersion===ex?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+S);const N=U+y+h,D=U+S+d,I=Hx(l,l.VERTEX_SHADER,N),z=Hx(l,l.FRAGMENT_SHADER,D);l.attachShader(b,I),l.attachShader(b,z),i.index0AttributeName!==void 0?l.bindAttribLocation(b,0,i.index0AttributeName):i.morphTargets===!0&&l.bindAttribLocation(b,0,"position"),l.linkProgram(b);function L(G){if(o.debug.checkShaderErrors){const Z=l.getProgramInfoLog(b)||"",et=l.getShaderInfoLog(I)||"",ct=l.getShaderInfoLog(z)||"",st=Z.trim(),k=et.trim(),it=ct.trim();let j=!0,xt=!0;if(l.getProgramParameter(b,l.LINK_STATUS)===!1)if(j=!1,typeof o.debug.onShaderError=="function")o.debug.onShaderError(l,b,I,z);else{const Mt=Vx(l,I,"vertex"),Ht=Vx(l,z,"fragment");console.error("THREE.WebGLProgram: Shader Error "+l.getError()+" - VALIDATE_STATUS "+l.getProgramParameter(b,l.VALIDATE_STATUS)+`

Material Name: `+G.name+`
Material Type: `+G.type+`

Program Info Log: `+st+`
`+Mt+`
`+Ht)}else st!==""?console.warn("THREE.WebGLProgram: Program Info Log:",st):(k===""||it==="")&&(xt=!1);xt&&(G.diagnostics={runnable:j,programLog:st,vertexShader:{log:k,prefix:y},fragmentShader:{log:it,prefix:S}})}l.deleteShader(I),l.deleteShader(z),B=new Lc(l,b),C=Jw(l,b)}let B;this.getUniforms=function(){return B===void 0&&L(this),B};let C;this.getAttributes=function(){return C===void 0&&L(this),C};let R=i.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return R===!1&&(R=l.getProgramParameter(b,Xw)),R},this.destroy=function(){r.releaseStatesOfProgram(this),l.deleteProgram(b),this.program=void 0},this.type=i.shaderType,this.name=i.shaderName,this.id=kw++,this.cacheKey=e,this.usedTimes=1,this.program=b,this.vertexShader=I,this.fragmentShader=z,this}let c2=0;class f2{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const i=e.vertexShader,r=e.fragmentShader,l=this._getShaderStage(i),c=this._getShaderStage(r),h=this._getShaderCacheForMaterial(e);return h.has(l)===!1&&(h.add(l),l.usedTimes++),h.has(c)===!1&&(h.add(c),c.usedTimes++),this}remove(e){const i=this.materialCache.get(e);for(const r of i)r.usedTimes--,r.usedTimes===0&&this.shaderCache.delete(r.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const i=this.materialCache;let r=i.get(e);return r===void 0&&(r=new Set,i.set(e,r)),r}_getShaderStage(e){const i=this.shaderCache;let r=i.get(e);return r===void 0&&(r=new h2(e),i.set(e,r)),r}}class h2{constructor(e){this.id=c2++,this.code=e,this.usedTimes=0}}function d2(o,e,i,r,l,c,h){const d=new Hy,m=new f2,g=new Set,_=[],p=l.logarithmicDepthBuffer,x=l.vertexTextures;let M=l.precision;const E={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function b(C){return g.add(C),C===0?"uv":`uv${C}`}function y(C,R,G,Z,et){const ct=Z.fog,st=et.geometry,k=C.isMeshStandardMaterial?Z.environment:null,it=(C.isMeshStandardMaterial?i:e).get(C.envMap||k),j=it&&it.mapping===Vc?it.image.height:null,xt=E[C.type];C.precision!==null&&(M=l.getMaxPrecision(C.precision),M!==C.precision&&console.warn("THREE.WebGLProgram.getParameters:",C.precision,"not supported, using",M,"instead."));const Mt=st.morphAttributes.position||st.morphAttributes.normal||st.morphAttributes.color,Ht=Mt!==void 0?Mt.length:0;let oe=0;st.morphAttributes.position!==void 0&&(oe=1),st.morphAttributes.normal!==void 0&&(oe=2),st.morphAttributes.color!==void 0&&(oe=3);let xe,H,ft,$;if(xt){const Ae=Qi[xt];xe=Ae.vertexShader,H=Ae.fragmentShader}else xe=C.vertexShader,H=C.fragmentShader,m.update(C),ft=m.getVertexShaderID(C),$=m.getFragmentShaderID(C);const at=o.getRenderTarget(),Et=o.state.buffers.depth.getReversed(),Ut=et.isInstancedMesh===!0,Rt=et.isBatchedMesh===!0,St=!!C.map,kt=!!C.matcap,F=!!it,Pe=!!C.aoMap,re=!!C.lightMap,Qt=!!C.bumpMap,Ot=!!C.normalMap,ie=!!C.displacementMap,vt=!!C.emissiveMap,Gt=!!C.metalnessMap,le=!!C.roughnessMap,Me=C.anisotropy>0,O=C.clearcoat>0,A=C.dispersion>0,rt=C.iridescence>0,mt=C.sheen>0,Tt=C.transmission>0,ht=Me&&!!C.anisotropyMap,Yt=O&&!!C.clearcoatMap,Dt=O&&!!C.clearcoatNormalMap,Kt=O&&!!C.clearcoatRoughnessMap,$t=rt&&!!C.iridescenceMap,Ct=rt&&!!C.iridescenceThicknessMap,zt=mt&&!!C.sheenColorMap,se=mt&&!!C.sheenRoughnessMap,Jt=!!C.specularMap,It=!!C.specularColorMap,he=!!C.specularIntensityMap,X=Tt&&!!C.transmissionMap,wt=Tt&&!!C.thicknessMap,Lt=!!C.gradientMap,qt=!!C.alphaMap,bt=C.alphaTest>0,yt=!!C.alphaHash,Zt=!!C.extensions;let fe=pr;C.toneMapped&&(at===null||at.isXRRenderTarget===!0)&&(fe=o.toneMapping);const ke={shaderID:xt,shaderType:C.type,shaderName:C.name,vertexShader:xe,fragmentShader:H,defines:C.defines,customVertexShaderID:ft,customFragmentShaderID:$,isRawShaderMaterial:C.isRawShaderMaterial===!0,glslVersion:C.glslVersion,precision:M,batching:Rt,batchingColor:Rt&&et._colorsTexture!==null,instancing:Ut,instancingColor:Ut&&et.instanceColor!==null,instancingMorph:Ut&&et.morphTexture!==null,supportsVertexTextures:x,outputColorSpace:at===null?o.outputColorSpace:at.isXRRenderTarget===!0?at.texture.colorSpace:ho,alphaToCoverage:!!C.alphaToCoverage,map:St,matcap:kt,envMap:F,envMapMode:F&&it.mapping,envMapCubeUVHeight:j,aoMap:Pe,lightMap:re,bumpMap:Qt,normalMap:Ot,displacementMap:x&&ie,emissiveMap:vt,normalMapObjectSpace:Ot&&C.normalMapType===o1,normalMapTangentSpace:Ot&&C.normalMapType===Py,metalnessMap:Gt,roughnessMap:le,anisotropy:Me,anisotropyMap:ht,clearcoat:O,clearcoatMap:Yt,clearcoatNormalMap:Dt,clearcoatRoughnessMap:Kt,dispersion:A,iridescence:rt,iridescenceMap:$t,iridescenceThicknessMap:Ct,sheen:mt,sheenColorMap:zt,sheenRoughnessMap:se,specularMap:Jt,specularColorMap:It,specularIntensityMap:he,transmission:Tt,transmissionMap:X,thicknessMap:wt,gradientMap:Lt,opaque:C.transparent===!1&&C.blending===ro&&C.alphaToCoverage===!1,alphaMap:qt,alphaTest:bt,alphaHash:yt,combine:C.combine,mapUv:St&&b(C.map.channel),aoMapUv:Pe&&b(C.aoMap.channel),lightMapUv:re&&b(C.lightMap.channel),bumpMapUv:Qt&&b(C.bumpMap.channel),normalMapUv:Ot&&b(C.normalMap.channel),displacementMapUv:ie&&b(C.displacementMap.channel),emissiveMapUv:vt&&b(C.emissiveMap.channel),metalnessMapUv:Gt&&b(C.metalnessMap.channel),roughnessMapUv:le&&b(C.roughnessMap.channel),anisotropyMapUv:ht&&b(C.anisotropyMap.channel),clearcoatMapUv:Yt&&b(C.clearcoatMap.channel),clearcoatNormalMapUv:Dt&&b(C.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Kt&&b(C.clearcoatRoughnessMap.channel),iridescenceMapUv:$t&&b(C.iridescenceMap.channel),iridescenceThicknessMapUv:Ct&&b(C.iridescenceThicknessMap.channel),sheenColorMapUv:zt&&b(C.sheenColorMap.channel),sheenRoughnessMapUv:se&&b(C.sheenRoughnessMap.channel),specularMapUv:Jt&&b(C.specularMap.channel),specularColorMapUv:It&&b(C.specularColorMap.channel),specularIntensityMapUv:he&&b(C.specularIntensityMap.channel),transmissionMapUv:X&&b(C.transmissionMap.channel),thicknessMapUv:wt&&b(C.thicknessMap.channel),alphaMapUv:qt&&b(C.alphaMap.channel),vertexTangents:!!st.attributes.tangent&&(Ot||Me),vertexColors:C.vertexColors,vertexAlphas:C.vertexColors===!0&&!!st.attributes.color&&st.attributes.color.itemSize===4,pointsUvs:et.isPoints===!0&&!!st.attributes.uv&&(St||qt),fog:!!ct,useFog:C.fog===!0,fogExp2:!!ct&&ct.isFogExp2,flatShading:C.flatShading===!0&&C.wireframe===!1,sizeAttenuation:C.sizeAttenuation===!0,logarithmicDepthBuffer:p,reversedDepthBuffer:Et,skinning:et.isSkinnedMesh===!0,morphTargets:st.morphAttributes.position!==void 0,morphNormals:st.morphAttributes.normal!==void 0,morphColors:st.morphAttributes.color!==void 0,morphTargetsCount:Ht,morphTextureStride:oe,numDirLights:R.directional.length,numPointLights:R.point.length,numSpotLights:R.spot.length,numSpotLightMaps:R.spotLightMap.length,numRectAreaLights:R.rectArea.length,numHemiLights:R.hemi.length,numDirLightShadows:R.directionalShadowMap.length,numPointLightShadows:R.pointShadowMap.length,numSpotLightShadows:R.spotShadowMap.length,numSpotLightShadowsWithMaps:R.numSpotLightShadowsWithMaps,numLightProbes:R.numLightProbes,numClippingPlanes:h.numPlanes,numClipIntersection:h.numIntersection,dithering:C.dithering,shadowMapEnabled:o.shadowMap.enabled&&G.length>0,shadowMapType:o.shadowMap.type,toneMapping:fe,decodeVideoTexture:St&&C.map.isVideoTexture===!0&&Oe.getTransfer(C.map.colorSpace)===Ye,decodeVideoTextureEmissive:vt&&C.emissiveMap.isVideoTexture===!0&&Oe.getTransfer(C.emissiveMap.colorSpace)===Ye,premultipliedAlpha:C.premultipliedAlpha,doubleSided:C.side===ba,flipSided:C.side===Qn,useDepthPacking:C.depthPacking>=0,depthPacking:C.depthPacking||0,index0AttributeName:C.index0AttributeName,extensionClipCullDistance:Zt&&C.extensions.clipCullDistance===!0&&r.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Zt&&C.extensions.multiDraw===!0||Rt)&&r.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:r.has("KHR_parallel_shader_compile"),customProgramCacheKey:C.customProgramCacheKey()};return ke.vertexUv1s=g.has(1),ke.vertexUv2s=g.has(2),ke.vertexUv3s=g.has(3),g.clear(),ke}function S(C){const R=[];if(C.shaderID?R.push(C.shaderID):(R.push(C.customVertexShaderID),R.push(C.customFragmentShaderID)),C.defines!==void 0)for(const G in C.defines)R.push(G),R.push(C.defines[G]);return C.isRawShaderMaterial===!1&&(U(R,C),N(R,C),R.push(o.outputColorSpace)),R.push(C.customProgramCacheKey),R.join()}function U(C,R){C.push(R.precision),C.push(R.outputColorSpace),C.push(R.envMapMode),C.push(R.envMapCubeUVHeight),C.push(R.mapUv),C.push(R.alphaMapUv),C.push(R.lightMapUv),C.push(R.aoMapUv),C.push(R.bumpMapUv),C.push(R.normalMapUv),C.push(R.displacementMapUv),C.push(R.emissiveMapUv),C.push(R.metalnessMapUv),C.push(R.roughnessMapUv),C.push(R.anisotropyMapUv),C.push(R.clearcoatMapUv),C.push(R.clearcoatNormalMapUv),C.push(R.clearcoatRoughnessMapUv),C.push(R.iridescenceMapUv),C.push(R.iridescenceThicknessMapUv),C.push(R.sheenColorMapUv),C.push(R.sheenRoughnessMapUv),C.push(R.specularMapUv),C.push(R.specularColorMapUv),C.push(R.specularIntensityMapUv),C.push(R.transmissionMapUv),C.push(R.thicknessMapUv),C.push(R.combine),C.push(R.fogExp2),C.push(R.sizeAttenuation),C.push(R.morphTargetsCount),C.push(R.morphAttributeCount),C.push(R.numDirLights),C.push(R.numPointLights),C.push(R.numSpotLights),C.push(R.numSpotLightMaps),C.push(R.numHemiLights),C.push(R.numRectAreaLights),C.push(R.numDirLightShadows),C.push(R.numPointLightShadows),C.push(R.numSpotLightShadows),C.push(R.numSpotLightShadowsWithMaps),C.push(R.numLightProbes),C.push(R.shadowMapType),C.push(R.toneMapping),C.push(R.numClippingPlanes),C.push(R.numClipIntersection),C.push(R.depthPacking)}function N(C,R){d.disableAll(),R.supportsVertexTextures&&d.enable(0),R.instancing&&d.enable(1),R.instancingColor&&d.enable(2),R.instancingMorph&&d.enable(3),R.matcap&&d.enable(4),R.envMap&&d.enable(5),R.normalMapObjectSpace&&d.enable(6),R.normalMapTangentSpace&&d.enable(7),R.clearcoat&&d.enable(8),R.iridescence&&d.enable(9),R.alphaTest&&d.enable(10),R.vertexColors&&d.enable(11),R.vertexAlphas&&d.enable(12),R.vertexUv1s&&d.enable(13),R.vertexUv2s&&d.enable(14),R.vertexUv3s&&d.enable(15),R.vertexTangents&&d.enable(16),R.anisotropy&&d.enable(17),R.alphaHash&&d.enable(18),R.batching&&d.enable(19),R.dispersion&&d.enable(20),R.batchingColor&&d.enable(21),R.gradientMap&&d.enable(22),C.push(d.mask),d.disableAll(),R.fog&&d.enable(0),R.useFog&&d.enable(1),R.flatShading&&d.enable(2),R.logarithmicDepthBuffer&&d.enable(3),R.reversedDepthBuffer&&d.enable(4),R.skinning&&d.enable(5),R.morphTargets&&d.enable(6),R.morphNormals&&d.enable(7),R.morphColors&&d.enable(8),R.premultipliedAlpha&&d.enable(9),R.shadowMapEnabled&&d.enable(10),R.doubleSided&&d.enable(11),R.flipSided&&d.enable(12),R.useDepthPacking&&d.enable(13),R.dithering&&d.enable(14),R.transmission&&d.enable(15),R.sheen&&d.enable(16),R.opaque&&d.enable(17),R.pointsUvs&&d.enable(18),R.decodeVideoTexture&&d.enable(19),R.decodeVideoTextureEmissive&&d.enable(20),R.alphaToCoverage&&d.enable(21),C.push(d.mask)}function D(C){const R=E[C.type];let G;if(R){const Z=Qi[R];G=z1.clone(Z.uniforms)}else G=C.uniforms;return G}function I(C,R){let G;for(let Z=0,et=_.length;Z<et;Z++){const ct=_[Z];if(ct.cacheKey===R){G=ct,++G.usedTimes;break}}return G===void 0&&(G=new u2(o,R,C,c),_.push(G)),G}function z(C){if(--C.usedTimes===0){const R=_.indexOf(C);_[R]=_[_.length-1],_.pop(),C.destroy()}}function L(C){m.remove(C)}function B(){m.dispose()}return{getParameters:y,getProgramCacheKey:S,getUniforms:D,acquireProgram:I,releaseProgram:z,releaseShaderCache:L,programs:_,dispose:B}}function p2(){let o=new WeakMap;function e(h){return o.has(h)}function i(h){let d=o.get(h);return d===void 0&&(d={},o.set(h,d)),d}function r(h){o.delete(h)}function l(h,d,m){o.get(h)[d]=m}function c(){o=new WeakMap}return{has:e,get:i,remove:r,update:l,dispose:c}}function m2(o,e){return o.groupOrder!==e.groupOrder?o.groupOrder-e.groupOrder:o.renderOrder!==e.renderOrder?o.renderOrder-e.renderOrder:o.material.id!==e.material.id?o.material.id-e.material.id:o.z!==e.z?o.z-e.z:o.id-e.id}function Wx(o,e){return o.groupOrder!==e.groupOrder?o.groupOrder-e.groupOrder:o.renderOrder!==e.renderOrder?o.renderOrder-e.renderOrder:o.z!==e.z?e.z-o.z:o.id-e.id}function jx(){const o=[];let e=0;const i=[],r=[],l=[];function c(){e=0,i.length=0,r.length=0,l.length=0}function h(p,x,M,E,b,y){let S=o[e];return S===void 0?(S={id:p.id,object:p,geometry:x,material:M,groupOrder:E,renderOrder:p.renderOrder,z:b,group:y},o[e]=S):(S.id=p.id,S.object=p,S.geometry=x,S.material=M,S.groupOrder=E,S.renderOrder=p.renderOrder,S.z=b,S.group=y),e++,S}function d(p,x,M,E,b,y){const S=h(p,x,M,E,b,y);M.transmission>0?r.push(S):M.transparent===!0?l.push(S):i.push(S)}function m(p,x,M,E,b,y){const S=h(p,x,M,E,b,y);M.transmission>0?r.unshift(S):M.transparent===!0?l.unshift(S):i.unshift(S)}function g(p,x){i.length>1&&i.sort(p||m2),r.length>1&&r.sort(x||Wx),l.length>1&&l.sort(x||Wx)}function _(){for(let p=e,x=o.length;p<x;p++){const M=o[p];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:i,transmissive:r,transparent:l,init:c,push:d,unshift:m,finish:_,sort:g}}function g2(){let o=new WeakMap;function e(r,l){const c=o.get(r);let h;return c===void 0?(h=new jx,o.set(r,[h])):l>=c.length?(h=new jx,c.push(h)):h=c[l],h}function i(){o=new WeakMap}return{get:e,dispose:i}}function _2(){const o={};return{get:function(e){if(o[e.id]!==void 0)return o[e.id];let i;switch(e.type){case"DirectionalLight":i={direction:new J,color:new Se};break;case"SpotLight":i={position:new J,direction:new J,color:new Se,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":i={position:new J,color:new Se,distance:0,decay:0};break;case"HemisphereLight":i={direction:new J,skyColor:new Se,groundColor:new Se};break;case"RectAreaLight":i={color:new Se,position:new J,halfWidth:new J,halfHeight:new J};break}return o[e.id]=i,i}}}function v2(){const o={};return{get:function(e){if(o[e.id]!==void 0)return o[e.id];let i;switch(e.type){case"DirectionalLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new be};break;case"SpotLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new be};break;case"PointLight":i={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new be,shadowCameraNear:1,shadowCameraFar:1e3};break}return o[e.id]=i,i}}}let x2=0;function y2(o,e){return(e.castShadow?2:0)-(o.castShadow?2:0)+(e.map?1:0)-(o.map?1:0)}function S2(o){const e=new _2,i=v2(),r={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let g=0;g<9;g++)r.probe.push(new J);const l=new J,c=new an,h=new an;function d(g){let _=0,p=0,x=0;for(let C=0;C<9;C++)r.probe[C].set(0,0,0);let M=0,E=0,b=0,y=0,S=0,U=0,N=0,D=0,I=0,z=0,L=0;g.sort(y2);for(let C=0,R=g.length;C<R;C++){const G=g[C],Z=G.color,et=G.intensity,ct=G.distance,st=G.shadow&&G.shadow.map?G.shadow.map.texture:null;if(G.isAmbientLight)_+=Z.r*et,p+=Z.g*et,x+=Z.b*et;else if(G.isLightProbe){for(let k=0;k<9;k++)r.probe[k].addScaledVector(G.sh.coefficients[k],et);L++}else if(G.isDirectionalLight){const k=e.get(G);if(k.color.copy(G.color).multiplyScalar(G.intensity),G.castShadow){const it=G.shadow,j=i.get(G);j.shadowIntensity=it.intensity,j.shadowBias=it.bias,j.shadowNormalBias=it.normalBias,j.shadowRadius=it.radius,j.shadowMapSize=it.mapSize,r.directionalShadow[M]=j,r.directionalShadowMap[M]=st,r.directionalShadowMatrix[M]=G.shadow.matrix,U++}r.directional[M]=k,M++}else if(G.isSpotLight){const k=e.get(G);k.position.setFromMatrixPosition(G.matrixWorld),k.color.copy(Z).multiplyScalar(et),k.distance=ct,k.coneCos=Math.cos(G.angle),k.penumbraCos=Math.cos(G.angle*(1-G.penumbra)),k.decay=G.decay,r.spot[b]=k;const it=G.shadow;if(G.map&&(r.spotLightMap[I]=G.map,I++,it.updateMatrices(G),G.castShadow&&z++),r.spotLightMatrix[b]=it.matrix,G.castShadow){const j=i.get(G);j.shadowIntensity=it.intensity,j.shadowBias=it.bias,j.shadowNormalBias=it.normalBias,j.shadowRadius=it.radius,j.shadowMapSize=it.mapSize,r.spotShadow[b]=j,r.spotShadowMap[b]=st,D++}b++}else if(G.isRectAreaLight){const k=e.get(G);k.color.copy(Z).multiplyScalar(et),k.halfWidth.set(G.width*.5,0,0),k.halfHeight.set(0,G.height*.5,0),r.rectArea[y]=k,y++}else if(G.isPointLight){const k=e.get(G);if(k.color.copy(G.color).multiplyScalar(G.intensity),k.distance=G.distance,k.decay=G.decay,G.castShadow){const it=G.shadow,j=i.get(G);j.shadowIntensity=it.intensity,j.shadowBias=it.bias,j.shadowNormalBias=it.normalBias,j.shadowRadius=it.radius,j.shadowMapSize=it.mapSize,j.shadowCameraNear=it.camera.near,j.shadowCameraFar=it.camera.far,r.pointShadow[E]=j,r.pointShadowMap[E]=st,r.pointShadowMatrix[E]=G.shadow.matrix,N++}r.point[E]=k,E++}else if(G.isHemisphereLight){const k=e.get(G);k.skyColor.copy(G.color).multiplyScalar(et),k.groundColor.copy(G.groundColor).multiplyScalar(et),r.hemi[S]=k,S++}}y>0&&(o.has("OES_texture_float_linear")===!0?(r.rectAreaLTC1=Ft.LTC_FLOAT_1,r.rectAreaLTC2=Ft.LTC_FLOAT_2):(r.rectAreaLTC1=Ft.LTC_HALF_1,r.rectAreaLTC2=Ft.LTC_HALF_2)),r.ambient[0]=_,r.ambient[1]=p,r.ambient[2]=x;const B=r.hash;(B.directionalLength!==M||B.pointLength!==E||B.spotLength!==b||B.rectAreaLength!==y||B.hemiLength!==S||B.numDirectionalShadows!==U||B.numPointShadows!==N||B.numSpotShadows!==D||B.numSpotMaps!==I||B.numLightProbes!==L)&&(r.directional.length=M,r.spot.length=b,r.rectArea.length=y,r.point.length=E,r.hemi.length=S,r.directionalShadow.length=U,r.directionalShadowMap.length=U,r.pointShadow.length=N,r.pointShadowMap.length=N,r.spotShadow.length=D,r.spotShadowMap.length=D,r.directionalShadowMatrix.length=U,r.pointShadowMatrix.length=N,r.spotLightMatrix.length=D+I-z,r.spotLightMap.length=I,r.numSpotLightShadowsWithMaps=z,r.numLightProbes=L,B.directionalLength=M,B.pointLength=E,B.spotLength=b,B.rectAreaLength=y,B.hemiLength=S,B.numDirectionalShadows=U,B.numPointShadows=N,B.numSpotShadows=D,B.numSpotMaps=I,B.numLightProbes=L,r.version=x2++)}function m(g,_){let p=0,x=0,M=0,E=0,b=0;const y=_.matrixWorldInverse;for(let S=0,U=g.length;S<U;S++){const N=g[S];if(N.isDirectionalLight){const D=r.directional[p];D.direction.setFromMatrixPosition(N.matrixWorld),l.setFromMatrixPosition(N.target.matrixWorld),D.direction.sub(l),D.direction.transformDirection(y),p++}else if(N.isSpotLight){const D=r.spot[M];D.position.setFromMatrixPosition(N.matrixWorld),D.position.applyMatrix4(y),D.direction.setFromMatrixPosition(N.matrixWorld),l.setFromMatrixPosition(N.target.matrixWorld),D.direction.sub(l),D.direction.transformDirection(y),M++}else if(N.isRectAreaLight){const D=r.rectArea[E];D.position.setFromMatrixPosition(N.matrixWorld),D.position.applyMatrix4(y),h.identity(),c.copy(N.matrixWorld),c.premultiply(y),h.extractRotation(c),D.halfWidth.set(N.width*.5,0,0),D.halfHeight.set(0,N.height*.5,0),D.halfWidth.applyMatrix4(h),D.halfHeight.applyMatrix4(h),E++}else if(N.isPointLight){const D=r.point[x];D.position.setFromMatrixPosition(N.matrixWorld),D.position.applyMatrix4(y),x++}else if(N.isHemisphereLight){const D=r.hemi[b];D.direction.setFromMatrixPosition(N.matrixWorld),D.direction.transformDirection(y),b++}}}return{setup:d,setupView:m,state:r}}function Zx(o){const e=new S2(o),i=[],r=[];function l(_){g.camera=_,i.length=0,r.length=0}function c(_){i.push(_)}function h(_){r.push(_)}function d(){e.setup(i)}function m(_){e.setupView(i,_)}const g={lightsArray:i,shadowsArray:r,camera:null,lights:e,transmissionRenderTarget:{}};return{init:l,state:g,setupLights:d,setupLightsView:m,pushLight:c,pushShadow:h}}function M2(o){let e=new WeakMap;function i(l,c=0){const h=e.get(l);let d;return h===void 0?(d=new Zx(o),e.set(l,[d])):c>=h.length?(d=new Zx(o),h.push(d)):d=h[c],d}function r(){e=new WeakMap}return{get:i,dispose:r}}const E2=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,T2=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function b2(o,e,i){let r=new Sm;const l=new be,c=new be,h=new We,d=new W1({depthPacking:s1}),m=new j1,g={},_=i.maxTextureSize,p={[mr]:Qn,[Qn]:mr,[ba]:ba},x=new gr({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new be},radius:{value:4}},vertexShader:E2,fragmentShader:T2}),M=x.clone();M.defines.HORIZONTAL_PASS=1;const E=new Ti;E.setAttribute("position",new Bi(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const b=new Nn(E,x),y=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=My;let S=this.type;this.render=function(z,L,B){if(y.enabled===!1||y.autoUpdate===!1&&y.needsUpdate===!1||z.length===0)return;const C=o.getRenderTarget(),R=o.getActiveCubeFace(),G=o.getActiveMipmapLevel(),Z=o.state;Z.setBlending(dr),Z.buffers.depth.getReversed()===!0?Z.buffers.color.setClear(0,0,0,0):Z.buffers.color.setClear(1,1,1,1),Z.buffers.depth.setTest(!0),Z.setScissorTest(!1);const et=S!==Ta&&this.type===Ta,ct=S===Ta&&this.type!==Ta;for(let st=0,k=z.length;st<k;st++){const it=z[st],j=it.shadow;if(j===void 0){console.warn("THREE.WebGLShadowMap:",it,"has no shadow.");continue}if(j.autoUpdate===!1&&j.needsUpdate===!1)continue;l.copy(j.mapSize);const xt=j.getFrameExtents();if(l.multiply(xt),c.copy(j.mapSize),(l.x>_||l.y>_)&&(l.x>_&&(c.x=Math.floor(_/xt.x),l.x=c.x*xt.x,j.mapSize.x=c.x),l.y>_&&(c.y=Math.floor(_/xt.y),l.y=c.y*xt.y,j.mapSize.y=c.y)),j.map===null||et===!0||ct===!0){const Ht=this.type!==Ta?{minFilter:Ii,magFilter:Ii}:{};j.map!==null&&j.map.dispose(),j.map=new ts(l.x,l.y,Ht),j.map.texture.name=it.name+".shadowMap",j.camera.updateProjectionMatrix()}o.setRenderTarget(j.map),o.clear();const Mt=j.getViewportCount();for(let Ht=0;Ht<Mt;Ht++){const oe=j.getViewport(Ht);h.set(c.x*oe.x,c.y*oe.y,c.x*oe.z,c.y*oe.w),Z.viewport(h),j.updateMatrices(it,Ht),r=j.getFrustum(),D(L,B,j.camera,it,this.type)}j.isPointLightShadow!==!0&&this.type===Ta&&U(j,B),j.needsUpdate=!1}S=this.type,y.needsUpdate=!1,o.setRenderTarget(C,R,G)};function U(z,L){const B=e.update(b);x.defines.VSM_SAMPLES!==z.blurSamples&&(x.defines.VSM_SAMPLES=z.blurSamples,M.defines.VSM_SAMPLES=z.blurSamples,x.needsUpdate=!0,M.needsUpdate=!0),z.mapPass===null&&(z.mapPass=new ts(l.x,l.y)),x.uniforms.shadow_pass.value=z.map.texture,x.uniforms.resolution.value=z.mapSize,x.uniforms.radius.value=z.radius,o.setRenderTarget(z.mapPass),o.clear(),o.renderBufferDirect(L,null,B,x,b,null),M.uniforms.shadow_pass.value=z.mapPass.texture,M.uniforms.resolution.value=z.mapSize,M.uniforms.radius.value=z.radius,o.setRenderTarget(z.map),o.clear(),o.renderBufferDirect(L,null,B,M,b,null)}function N(z,L,B,C){let R=null;const G=B.isPointLight===!0?z.customDistanceMaterial:z.customDepthMaterial;if(G!==void 0)R=G;else if(R=B.isPointLight===!0?m:d,o.localClippingEnabled&&L.clipShadows===!0&&Array.isArray(L.clippingPlanes)&&L.clippingPlanes.length!==0||L.displacementMap&&L.displacementScale!==0||L.alphaMap&&L.alphaTest>0||L.map&&L.alphaTest>0||L.alphaToCoverage===!0){const Z=R.uuid,et=L.uuid;let ct=g[Z];ct===void 0&&(ct={},g[Z]=ct);let st=ct[et];st===void 0&&(st=R.clone(),ct[et]=st,L.addEventListener("dispose",I)),R=st}if(R.visible=L.visible,R.wireframe=L.wireframe,C===Ta?R.side=L.shadowSide!==null?L.shadowSide:L.side:R.side=L.shadowSide!==null?L.shadowSide:p[L.side],R.alphaMap=L.alphaMap,R.alphaTest=L.alphaToCoverage===!0?.5:L.alphaTest,R.map=L.map,R.clipShadows=L.clipShadows,R.clippingPlanes=L.clippingPlanes,R.clipIntersection=L.clipIntersection,R.displacementMap=L.displacementMap,R.displacementScale=L.displacementScale,R.displacementBias=L.displacementBias,R.wireframeLinewidth=L.wireframeLinewidth,R.linewidth=L.linewidth,B.isPointLight===!0&&R.isMeshDistanceMaterial===!0){const Z=o.properties.get(R);Z.light=B}return R}function D(z,L,B,C,R){if(z.visible===!1)return;if(z.layers.test(L.layers)&&(z.isMesh||z.isLine||z.isPoints)&&(z.castShadow||z.receiveShadow&&R===Ta)&&(!z.frustumCulled||r.intersectsObject(z))){z.modelViewMatrix.multiplyMatrices(B.matrixWorldInverse,z.matrixWorld);const et=e.update(z),ct=z.material;if(Array.isArray(ct)){const st=et.groups;for(let k=0,it=st.length;k<it;k++){const j=st[k],xt=ct[j.materialIndex];if(xt&&xt.visible){const Mt=N(z,xt,C,R);z.onBeforeShadow(o,z,L,B,et,Mt,j),o.renderBufferDirect(B,null,et,Mt,z,j),z.onAfterShadow(o,z,L,B,et,Mt,j)}}}else if(ct.visible){const st=N(z,ct,C,R);z.onBeforeShadow(o,z,L,B,et,st,null),o.renderBufferDirect(B,null,et,st,z,null),z.onAfterShadow(o,z,L,B,et,st,null)}}const Z=z.children;for(let et=0,ct=Z.length;et<ct;et++)D(Z[et],L,B,C,R)}function I(z){z.target.removeEventListener("dispose",I);for(const B in g){const C=g[B],R=z.target.uuid;R in C&&(C[R].dispose(),delete C[R])}}}const A2={[dp]:pp,[mp]:vp,[gp]:xp,[uo]:_p,[pp]:dp,[vp]:mp,[xp]:gp,[_p]:uo};function R2(o,e){function i(){let X=!1;const wt=new We;let Lt=null;const qt=new We(0,0,0,0);return{setMask:function(bt){Lt!==bt&&!X&&(o.colorMask(bt,bt,bt,bt),Lt=bt)},setLocked:function(bt){X=bt},setClear:function(bt,yt,Zt,fe,ke){ke===!0&&(bt*=fe,yt*=fe,Zt*=fe),wt.set(bt,yt,Zt,fe),qt.equals(wt)===!1&&(o.clearColor(bt,yt,Zt,fe),qt.copy(wt))},reset:function(){X=!1,Lt=null,qt.set(-1,0,0,0)}}}function r(){let X=!1,wt=!1,Lt=null,qt=null,bt=null;return{setReversed:function(yt){if(wt!==yt){const Zt=e.get("EXT_clip_control");yt?Zt.clipControlEXT(Zt.LOWER_LEFT_EXT,Zt.ZERO_TO_ONE_EXT):Zt.clipControlEXT(Zt.LOWER_LEFT_EXT,Zt.NEGATIVE_ONE_TO_ONE_EXT),wt=yt;const fe=bt;bt=null,this.setClear(fe)}},getReversed:function(){return wt},setTest:function(yt){yt?at(o.DEPTH_TEST):Et(o.DEPTH_TEST)},setMask:function(yt){Lt!==yt&&!X&&(o.depthMask(yt),Lt=yt)},setFunc:function(yt){if(wt&&(yt=A2[yt]),qt!==yt){switch(yt){case dp:o.depthFunc(o.NEVER);break;case pp:o.depthFunc(o.ALWAYS);break;case mp:o.depthFunc(o.LESS);break;case uo:o.depthFunc(o.LEQUAL);break;case gp:o.depthFunc(o.EQUAL);break;case _p:o.depthFunc(o.GEQUAL);break;case vp:o.depthFunc(o.GREATER);break;case xp:o.depthFunc(o.NOTEQUAL);break;default:o.depthFunc(o.LEQUAL)}qt=yt}},setLocked:function(yt){X=yt},setClear:function(yt){bt!==yt&&(wt&&(yt=1-yt),o.clearDepth(yt),bt=yt)},reset:function(){X=!1,Lt=null,qt=null,bt=null,wt=!1}}}function l(){let X=!1,wt=null,Lt=null,qt=null,bt=null,yt=null,Zt=null,fe=null,ke=null;return{setTest:function(Ae){X||(Ae?at(o.STENCIL_TEST):Et(o.STENCIL_TEST))},setMask:function(Ae){wt!==Ae&&!X&&(o.stencilMask(Ae),wt=Ae)},setFunc:function(Ae,tn,gn){(Lt!==Ae||qt!==tn||bt!==gn)&&(o.stencilFunc(Ae,tn,gn),Lt=Ae,qt=tn,bt=gn)},setOp:function(Ae,tn,gn){(yt!==Ae||Zt!==tn||fe!==gn)&&(o.stencilOp(Ae,tn,gn),yt=Ae,Zt=tn,fe=gn)},setLocked:function(Ae){X=Ae},setClear:function(Ae){ke!==Ae&&(o.clearStencil(Ae),ke=Ae)},reset:function(){X=!1,wt=null,Lt=null,qt=null,bt=null,yt=null,Zt=null,fe=null,ke=null}}}const c=new i,h=new r,d=new l,m=new WeakMap,g=new WeakMap;let _={},p={},x=new WeakMap,M=[],E=null,b=!1,y=null,S=null,U=null,N=null,D=null,I=null,z=null,L=new Se(0,0,0),B=0,C=!1,R=null,G=null,Z=null,et=null,ct=null;const st=o.getParameter(o.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let k=!1,it=0;const j=o.getParameter(o.VERSION);j.indexOf("WebGL")!==-1?(it=parseFloat(/^WebGL (\d)/.exec(j)[1]),k=it>=1):j.indexOf("OpenGL ES")!==-1&&(it=parseFloat(/^OpenGL ES (\d)/.exec(j)[1]),k=it>=2);let xt=null,Mt={};const Ht=o.getParameter(o.SCISSOR_BOX),oe=o.getParameter(o.VIEWPORT),xe=new We().fromArray(Ht),H=new We().fromArray(oe);function ft(X,wt,Lt,qt){const bt=new Uint8Array(4),yt=o.createTexture();o.bindTexture(X,yt),o.texParameteri(X,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(X,o.TEXTURE_MAG_FILTER,o.NEAREST);for(let Zt=0;Zt<Lt;Zt++)X===o.TEXTURE_3D||X===o.TEXTURE_2D_ARRAY?o.texImage3D(wt,0,o.RGBA,1,1,qt,0,o.RGBA,o.UNSIGNED_BYTE,bt):o.texImage2D(wt+Zt,0,o.RGBA,1,1,0,o.RGBA,o.UNSIGNED_BYTE,bt);return yt}const $={};$[o.TEXTURE_2D]=ft(o.TEXTURE_2D,o.TEXTURE_2D,1),$[o.TEXTURE_CUBE_MAP]=ft(o.TEXTURE_CUBE_MAP,o.TEXTURE_CUBE_MAP_POSITIVE_X,6),$[o.TEXTURE_2D_ARRAY]=ft(o.TEXTURE_2D_ARRAY,o.TEXTURE_2D_ARRAY,1,1),$[o.TEXTURE_3D]=ft(o.TEXTURE_3D,o.TEXTURE_3D,1,1),c.setClear(0,0,0,1),h.setClear(1),d.setClear(0),at(o.DEPTH_TEST),h.setFunc(uo),Qt(!1),Ot(Z0),at(o.CULL_FACE),Pe(dr);function at(X){_[X]!==!0&&(o.enable(X),_[X]=!0)}function Et(X){_[X]!==!1&&(o.disable(X),_[X]=!1)}function Ut(X,wt){return p[X]!==wt?(o.bindFramebuffer(X,wt),p[X]=wt,X===o.DRAW_FRAMEBUFFER&&(p[o.FRAMEBUFFER]=wt),X===o.FRAMEBUFFER&&(p[o.DRAW_FRAMEBUFFER]=wt),!0):!1}function Rt(X,wt){let Lt=M,qt=!1;if(X){Lt=x.get(wt),Lt===void 0&&(Lt=[],x.set(wt,Lt));const bt=X.textures;if(Lt.length!==bt.length||Lt[0]!==o.COLOR_ATTACHMENT0){for(let yt=0,Zt=bt.length;yt<Zt;yt++)Lt[yt]=o.COLOR_ATTACHMENT0+yt;Lt.length=bt.length,qt=!0}}else Lt[0]!==o.BACK&&(Lt[0]=o.BACK,qt=!0);qt&&o.drawBuffers(Lt)}function St(X){return E!==X?(o.useProgram(X),E=X,!0):!1}const kt={[Zr]:o.FUNC_ADD,[Lb]:o.FUNC_SUBTRACT,[Ob]:o.FUNC_REVERSE_SUBTRACT};kt[Pb]=o.MIN,kt[zb]=o.MAX;const F={[Ib]:o.ZERO,[Bb]:o.ONE,[Fb]:o.SRC_COLOR,[fp]:o.SRC_ALPHA,[qb]:o.SRC_ALPHA_SATURATE,[Xb]:o.DST_COLOR,[Gb]:o.DST_ALPHA,[Hb]:o.ONE_MINUS_SRC_COLOR,[hp]:o.ONE_MINUS_SRC_ALPHA,[kb]:o.ONE_MINUS_DST_COLOR,[Vb]:o.ONE_MINUS_DST_ALPHA,[Yb]:o.CONSTANT_COLOR,[Wb]:o.ONE_MINUS_CONSTANT_COLOR,[jb]:o.CONSTANT_ALPHA,[Zb]:o.ONE_MINUS_CONSTANT_ALPHA};function Pe(X,wt,Lt,qt,bt,yt,Zt,fe,ke,Ae){if(X===dr){b===!0&&(Et(o.BLEND),b=!1);return}if(b===!1&&(at(o.BLEND),b=!0),X!==Nb){if(X!==y||Ae!==C){if((S!==Zr||D!==Zr)&&(o.blendEquation(o.FUNC_ADD),S=Zr,D=Zr),Ae)switch(X){case ro:o.blendFuncSeparate(o.ONE,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case K0:o.blendFunc(o.ONE,o.ONE);break;case Q0:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case J0:o.blendFuncSeparate(o.DST_COLOR,o.ONE_MINUS_SRC_ALPHA,o.ZERO,o.ONE);break;default:console.error("THREE.WebGLState: Invalid blending: ",X);break}else switch(X){case ro:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case K0:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE,o.ONE,o.ONE);break;case Q0:console.error("THREE.WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case J0:console.error("THREE.WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:console.error("THREE.WebGLState: Invalid blending: ",X);break}U=null,N=null,I=null,z=null,L.set(0,0,0),B=0,y=X,C=Ae}return}bt=bt||wt,yt=yt||Lt,Zt=Zt||qt,(wt!==S||bt!==D)&&(o.blendEquationSeparate(kt[wt],kt[bt]),S=wt,D=bt),(Lt!==U||qt!==N||yt!==I||Zt!==z)&&(o.blendFuncSeparate(F[Lt],F[qt],F[yt],F[Zt]),U=Lt,N=qt,I=yt,z=Zt),(fe.equals(L)===!1||ke!==B)&&(o.blendColor(fe.r,fe.g,fe.b,ke),L.copy(fe),B=ke),y=X,C=!1}function re(X,wt){X.side===ba?Et(o.CULL_FACE):at(o.CULL_FACE);let Lt=X.side===Qn;wt&&(Lt=!Lt),Qt(Lt),X.blending===ro&&X.transparent===!1?Pe(dr):Pe(X.blending,X.blendEquation,X.blendSrc,X.blendDst,X.blendEquationAlpha,X.blendSrcAlpha,X.blendDstAlpha,X.blendColor,X.blendAlpha,X.premultipliedAlpha),h.setFunc(X.depthFunc),h.setTest(X.depthTest),h.setMask(X.depthWrite),c.setMask(X.colorWrite);const qt=X.stencilWrite;d.setTest(qt),qt&&(d.setMask(X.stencilWriteMask),d.setFunc(X.stencilFunc,X.stencilRef,X.stencilFuncMask),d.setOp(X.stencilFail,X.stencilZFail,X.stencilZPass)),vt(X.polygonOffset,X.polygonOffsetFactor,X.polygonOffsetUnits),X.alphaToCoverage===!0?at(o.SAMPLE_ALPHA_TO_COVERAGE):Et(o.SAMPLE_ALPHA_TO_COVERAGE)}function Qt(X){R!==X&&(X?o.frontFace(o.CW):o.frontFace(o.CCW),R=X)}function Ot(X){X!==Db?(at(o.CULL_FACE),X!==G&&(X===Z0?o.cullFace(o.BACK):X===Ub?o.cullFace(o.FRONT):o.cullFace(o.FRONT_AND_BACK))):Et(o.CULL_FACE),G=X}function ie(X){X!==Z&&(k&&o.lineWidth(X),Z=X)}function vt(X,wt,Lt){X?(at(o.POLYGON_OFFSET_FILL),(et!==wt||ct!==Lt)&&(o.polygonOffset(wt,Lt),et=wt,ct=Lt)):Et(o.POLYGON_OFFSET_FILL)}function Gt(X){X?at(o.SCISSOR_TEST):Et(o.SCISSOR_TEST)}function le(X){X===void 0&&(X=o.TEXTURE0+st-1),xt!==X&&(o.activeTexture(X),xt=X)}function Me(X,wt,Lt){Lt===void 0&&(xt===null?Lt=o.TEXTURE0+st-1:Lt=xt);let qt=Mt[Lt];qt===void 0&&(qt={type:void 0,texture:void 0},Mt[Lt]=qt),(qt.type!==X||qt.texture!==wt)&&(xt!==Lt&&(o.activeTexture(Lt),xt=Lt),o.bindTexture(X,wt||$[X]),qt.type=X,qt.texture=wt)}function O(){const X=Mt[xt];X!==void 0&&X.type!==void 0&&(o.bindTexture(X.type,null),X.type=void 0,X.texture=void 0)}function A(){try{o.compressedTexImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function rt(){try{o.compressedTexImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function mt(){try{o.texSubImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Tt(){try{o.texSubImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function ht(){try{o.compressedTexSubImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Yt(){try{o.compressedTexSubImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Dt(){try{o.texStorage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Kt(){try{o.texStorage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function $t(){try{o.texImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Ct(){try{o.texImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function zt(X){xe.equals(X)===!1&&(o.scissor(X.x,X.y,X.z,X.w),xe.copy(X))}function se(X){H.equals(X)===!1&&(o.viewport(X.x,X.y,X.z,X.w),H.copy(X))}function Jt(X,wt){let Lt=g.get(wt);Lt===void 0&&(Lt=new WeakMap,g.set(wt,Lt));let qt=Lt.get(X);qt===void 0&&(qt=o.getUniformBlockIndex(wt,X.name),Lt.set(X,qt))}function It(X,wt){const qt=g.get(wt).get(X);m.get(wt)!==qt&&(o.uniformBlockBinding(wt,qt,X.__bindingPointIndex),m.set(wt,qt))}function he(){o.disable(o.BLEND),o.disable(o.CULL_FACE),o.disable(o.DEPTH_TEST),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SCISSOR_TEST),o.disable(o.STENCIL_TEST),o.disable(o.SAMPLE_ALPHA_TO_COVERAGE),o.blendEquation(o.FUNC_ADD),o.blendFunc(o.ONE,o.ZERO),o.blendFuncSeparate(o.ONE,o.ZERO,o.ONE,o.ZERO),o.blendColor(0,0,0,0),o.colorMask(!0,!0,!0,!0),o.clearColor(0,0,0,0),o.depthMask(!0),o.depthFunc(o.LESS),h.setReversed(!1),o.clearDepth(1),o.stencilMask(4294967295),o.stencilFunc(o.ALWAYS,0,4294967295),o.stencilOp(o.KEEP,o.KEEP,o.KEEP),o.clearStencil(0),o.cullFace(o.BACK),o.frontFace(o.CCW),o.polygonOffset(0,0),o.activeTexture(o.TEXTURE0),o.bindFramebuffer(o.FRAMEBUFFER,null),o.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),o.bindFramebuffer(o.READ_FRAMEBUFFER,null),o.useProgram(null),o.lineWidth(1),o.scissor(0,0,o.canvas.width,o.canvas.height),o.viewport(0,0,o.canvas.width,o.canvas.height),_={},xt=null,Mt={},p={},x=new WeakMap,M=[],E=null,b=!1,y=null,S=null,U=null,N=null,D=null,I=null,z=null,L=new Se(0,0,0),B=0,C=!1,R=null,G=null,Z=null,et=null,ct=null,xe.set(0,0,o.canvas.width,o.canvas.height),H.set(0,0,o.canvas.width,o.canvas.height),c.reset(),h.reset(),d.reset()}return{buffers:{color:c,depth:h,stencil:d},enable:at,disable:Et,bindFramebuffer:Ut,drawBuffers:Rt,useProgram:St,setBlending:Pe,setMaterial:re,setFlipSided:Qt,setCullFace:Ot,setLineWidth:ie,setPolygonOffset:vt,setScissorTest:Gt,activeTexture:le,bindTexture:Me,unbindTexture:O,compressedTexImage2D:A,compressedTexImage3D:rt,texImage2D:$t,texImage3D:Ct,updateUBOMapping:Jt,uniformBlockBinding:It,texStorage2D:Dt,texStorage3D:Kt,texSubImage2D:mt,texSubImage3D:Tt,compressedTexSubImage2D:ht,compressedTexSubImage3D:Yt,scissor:zt,viewport:se,reset:he}}function C2(o,e,i,r,l,c,h){const d=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,m=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),g=new be,_=new WeakMap;let p;const x=new WeakMap;let M=!1;try{M=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function E(O,A){return M?new OffscreenCanvas(O,A):Ic("canvas")}function b(O,A,rt){let mt=1;const Tt=Me(O);if((Tt.width>rt||Tt.height>rt)&&(mt=rt/Math.max(Tt.width,Tt.height)),mt<1)if(typeof HTMLImageElement<"u"&&O instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&O instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&O instanceof ImageBitmap||typeof VideoFrame<"u"&&O instanceof VideoFrame){const ht=Math.floor(mt*Tt.width),Yt=Math.floor(mt*Tt.height);p===void 0&&(p=E(ht,Yt));const Dt=A?E(ht,Yt):p;return Dt.width=ht,Dt.height=Yt,Dt.getContext("2d").drawImage(O,0,0,ht,Yt),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+Tt.width+"x"+Tt.height+") to ("+ht+"x"+Yt+")."),Dt}else return"data"in O&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+Tt.width+"x"+Tt.height+")."),O;return O}function y(O){return O.generateMipmaps}function S(O){o.generateMipmap(O)}function U(O){return O.isWebGLCubeRenderTarget?o.TEXTURE_CUBE_MAP:O.isWebGL3DRenderTarget?o.TEXTURE_3D:O.isWebGLArrayRenderTarget||O.isCompressedArrayTexture?o.TEXTURE_2D_ARRAY:o.TEXTURE_2D}function N(O,A,rt,mt,Tt=!1){if(O!==null){if(o[O]!==void 0)return o[O];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+O+"'")}let ht=A;if(A===o.RED&&(rt===o.FLOAT&&(ht=o.R32F),rt===o.HALF_FLOAT&&(ht=o.R16F),rt===o.UNSIGNED_BYTE&&(ht=o.R8)),A===o.RED_INTEGER&&(rt===o.UNSIGNED_BYTE&&(ht=o.R8UI),rt===o.UNSIGNED_SHORT&&(ht=o.R16UI),rt===o.UNSIGNED_INT&&(ht=o.R32UI),rt===o.BYTE&&(ht=o.R8I),rt===o.SHORT&&(ht=o.R16I),rt===o.INT&&(ht=o.R32I)),A===o.RG&&(rt===o.FLOAT&&(ht=o.RG32F),rt===o.HALF_FLOAT&&(ht=o.RG16F),rt===o.UNSIGNED_BYTE&&(ht=o.RG8)),A===o.RG_INTEGER&&(rt===o.UNSIGNED_BYTE&&(ht=o.RG8UI),rt===o.UNSIGNED_SHORT&&(ht=o.RG16UI),rt===o.UNSIGNED_INT&&(ht=o.RG32UI),rt===o.BYTE&&(ht=o.RG8I),rt===o.SHORT&&(ht=o.RG16I),rt===o.INT&&(ht=o.RG32I)),A===o.RGB_INTEGER&&(rt===o.UNSIGNED_BYTE&&(ht=o.RGB8UI),rt===o.UNSIGNED_SHORT&&(ht=o.RGB16UI),rt===o.UNSIGNED_INT&&(ht=o.RGB32UI),rt===o.BYTE&&(ht=o.RGB8I),rt===o.SHORT&&(ht=o.RGB16I),rt===o.INT&&(ht=o.RGB32I)),A===o.RGBA_INTEGER&&(rt===o.UNSIGNED_BYTE&&(ht=o.RGBA8UI),rt===o.UNSIGNED_SHORT&&(ht=o.RGBA16UI),rt===o.UNSIGNED_INT&&(ht=o.RGBA32UI),rt===o.BYTE&&(ht=o.RGBA8I),rt===o.SHORT&&(ht=o.RGBA16I),rt===o.INT&&(ht=o.RGBA32I)),A===o.RGB&&(rt===o.UNSIGNED_INT_5_9_9_9_REV&&(ht=o.RGB9_E5),rt===o.UNSIGNED_INT_10F_11F_11F_REV&&(ht=o.R11F_G11F_B10F)),A===o.RGBA){const Yt=Tt?Pc:Oe.getTransfer(mt);rt===o.FLOAT&&(ht=o.RGBA32F),rt===o.HALF_FLOAT&&(ht=o.RGBA16F),rt===o.UNSIGNED_BYTE&&(ht=Yt===Ye?o.SRGB8_ALPHA8:o.RGBA8),rt===o.UNSIGNED_SHORT_4_4_4_4&&(ht=o.RGBA4),rt===o.UNSIGNED_SHORT_5_5_5_1&&(ht=o.RGB5_A1)}return(ht===o.R16F||ht===o.R32F||ht===o.RG16F||ht===o.RG32F||ht===o.RGBA16F||ht===o.RGBA32F)&&e.get("EXT_color_buffer_float"),ht}function D(O,A){let rt;return O?A===null||A===$r||A===Ml?rt=o.DEPTH24_STENCIL8:A===Aa?rt=o.DEPTH32F_STENCIL8:A===Sl&&(rt=o.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===$r||A===Ml?rt=o.DEPTH_COMPONENT24:A===Aa?rt=o.DEPTH_COMPONENT32F:A===Sl&&(rt=o.DEPTH_COMPONENT16),rt}function I(O,A){return y(O)===!0||O.isFramebufferTexture&&O.minFilter!==Ii&&O.minFilter!==Ji?Math.log2(Math.max(A.width,A.height))+1:O.mipmaps!==void 0&&O.mipmaps.length>0?O.mipmaps.length:O.isCompressedTexture&&Array.isArray(O.image)?A.mipmaps.length:1}function z(O){const A=O.target;A.removeEventListener("dispose",z),B(A),A.isVideoTexture&&_.delete(A)}function L(O){const A=O.target;A.removeEventListener("dispose",L),R(A)}function B(O){const A=r.get(O);if(A.__webglInit===void 0)return;const rt=O.source,mt=x.get(rt);if(mt){const Tt=mt[A.__cacheKey];Tt.usedTimes--,Tt.usedTimes===0&&C(O),Object.keys(mt).length===0&&x.delete(rt)}r.remove(O)}function C(O){const A=r.get(O);o.deleteTexture(A.__webglTexture);const rt=O.source,mt=x.get(rt);delete mt[A.__cacheKey],h.memory.textures--}function R(O){const A=r.get(O);if(O.depthTexture&&(O.depthTexture.dispose(),r.remove(O.depthTexture)),O.isWebGLCubeRenderTarget)for(let mt=0;mt<6;mt++){if(Array.isArray(A.__webglFramebuffer[mt]))for(let Tt=0;Tt<A.__webglFramebuffer[mt].length;Tt++)o.deleteFramebuffer(A.__webglFramebuffer[mt][Tt]);else o.deleteFramebuffer(A.__webglFramebuffer[mt]);A.__webglDepthbuffer&&o.deleteRenderbuffer(A.__webglDepthbuffer[mt])}else{if(Array.isArray(A.__webglFramebuffer))for(let mt=0;mt<A.__webglFramebuffer.length;mt++)o.deleteFramebuffer(A.__webglFramebuffer[mt]);else o.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&o.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&o.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let mt=0;mt<A.__webglColorRenderbuffer.length;mt++)A.__webglColorRenderbuffer[mt]&&o.deleteRenderbuffer(A.__webglColorRenderbuffer[mt]);A.__webglDepthRenderbuffer&&o.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const rt=O.textures;for(let mt=0,Tt=rt.length;mt<Tt;mt++){const ht=r.get(rt[mt]);ht.__webglTexture&&(o.deleteTexture(ht.__webglTexture),h.memory.textures--),r.remove(rt[mt])}r.remove(O)}let G=0;function Z(){G=0}function et(){const O=G;return O>=l.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+O+" texture units while this GPU supports only "+l.maxTextures),G+=1,O}function ct(O){const A=[];return A.push(O.wrapS),A.push(O.wrapT),A.push(O.wrapR||0),A.push(O.magFilter),A.push(O.minFilter),A.push(O.anisotropy),A.push(O.internalFormat),A.push(O.format),A.push(O.type),A.push(O.generateMipmaps),A.push(O.premultiplyAlpha),A.push(O.flipY),A.push(O.unpackAlignment),A.push(O.colorSpace),A.join()}function st(O,A){const rt=r.get(O);if(O.isVideoTexture&&Gt(O),O.isRenderTargetTexture===!1&&O.isExternalTexture!==!0&&O.version>0&&rt.__version!==O.version){const mt=O.image;if(mt===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(mt.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{$(rt,O,A);return}}else O.isExternalTexture&&(rt.__webglTexture=O.sourceTexture?O.sourceTexture:null);i.bindTexture(o.TEXTURE_2D,rt.__webglTexture,o.TEXTURE0+A)}function k(O,A){const rt=r.get(O);if(O.isRenderTargetTexture===!1&&O.version>0&&rt.__version!==O.version){$(rt,O,A);return}i.bindTexture(o.TEXTURE_2D_ARRAY,rt.__webglTexture,o.TEXTURE0+A)}function it(O,A){const rt=r.get(O);if(O.isRenderTargetTexture===!1&&O.version>0&&rt.__version!==O.version){$(rt,O,A);return}i.bindTexture(o.TEXTURE_3D,rt.__webglTexture,o.TEXTURE0+A)}function j(O,A){const rt=r.get(O);if(O.version>0&&rt.__version!==O.version){at(rt,O,A);return}i.bindTexture(o.TEXTURE_CUBE_MAP,rt.__webglTexture,o.TEXTURE0+A)}const xt={[Mp]:o.REPEAT,[Qr]:o.CLAMP_TO_EDGE,[Ep]:o.MIRRORED_REPEAT},Mt={[Ii]:o.NEAREST,[a1]:o.NEAREST_MIPMAP_NEAREST,[ac]:o.NEAREST_MIPMAP_LINEAR,[Ji]:o.LINEAR,[wd]:o.LINEAR_MIPMAP_NEAREST,[Jr]:o.LINEAR_MIPMAP_LINEAR},Ht={[l1]:o.NEVER,[p1]:o.ALWAYS,[u1]:o.LESS,[zy]:o.LEQUAL,[c1]:o.EQUAL,[d1]:o.GEQUAL,[f1]:o.GREATER,[h1]:o.NOTEQUAL};function oe(O,A){if(A.type===Aa&&e.has("OES_texture_float_linear")===!1&&(A.magFilter===Ji||A.magFilter===wd||A.magFilter===ac||A.magFilter===Jr||A.minFilter===Ji||A.minFilter===wd||A.minFilter===ac||A.minFilter===Jr)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),o.texParameteri(O,o.TEXTURE_WRAP_S,xt[A.wrapS]),o.texParameteri(O,o.TEXTURE_WRAP_T,xt[A.wrapT]),(O===o.TEXTURE_3D||O===o.TEXTURE_2D_ARRAY)&&o.texParameteri(O,o.TEXTURE_WRAP_R,xt[A.wrapR]),o.texParameteri(O,o.TEXTURE_MAG_FILTER,Mt[A.magFilter]),o.texParameteri(O,o.TEXTURE_MIN_FILTER,Mt[A.minFilter]),A.compareFunction&&(o.texParameteri(O,o.TEXTURE_COMPARE_MODE,o.COMPARE_REF_TO_TEXTURE),o.texParameteri(O,o.TEXTURE_COMPARE_FUNC,Ht[A.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===Ii||A.minFilter!==ac&&A.minFilter!==Jr||A.type===Aa&&e.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||r.get(A).__currentAnisotropy){const rt=e.get("EXT_texture_filter_anisotropic");o.texParameterf(O,rt.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,l.getMaxAnisotropy())),r.get(A).__currentAnisotropy=A.anisotropy}}}function xe(O,A){let rt=!1;O.__webglInit===void 0&&(O.__webglInit=!0,A.addEventListener("dispose",z));const mt=A.source;let Tt=x.get(mt);Tt===void 0&&(Tt={},x.set(mt,Tt));const ht=ct(A);if(ht!==O.__cacheKey){Tt[ht]===void 0&&(Tt[ht]={texture:o.createTexture(),usedTimes:0},h.memory.textures++,rt=!0),Tt[ht].usedTimes++;const Yt=Tt[O.__cacheKey];Yt!==void 0&&(Tt[O.__cacheKey].usedTimes--,Yt.usedTimes===0&&C(A)),O.__cacheKey=ht,O.__webglTexture=Tt[ht].texture}return rt}function H(O,A,rt){return Math.floor(Math.floor(O/rt)/A)}function ft(O,A,rt,mt){const ht=O.updateRanges;if(ht.length===0)i.texSubImage2D(o.TEXTURE_2D,0,0,0,A.width,A.height,rt,mt,A.data);else{ht.sort((Ct,zt)=>Ct.start-zt.start);let Yt=0;for(let Ct=1;Ct<ht.length;Ct++){const zt=ht[Yt],se=ht[Ct],Jt=zt.start+zt.count,It=H(se.start,A.width,4),he=H(zt.start,A.width,4);se.start<=Jt+1&&It===he&&H(se.start+se.count-1,A.width,4)===It?zt.count=Math.max(zt.count,se.start+se.count-zt.start):(++Yt,ht[Yt]=se)}ht.length=Yt+1;const Dt=o.getParameter(o.UNPACK_ROW_LENGTH),Kt=o.getParameter(o.UNPACK_SKIP_PIXELS),$t=o.getParameter(o.UNPACK_SKIP_ROWS);o.pixelStorei(o.UNPACK_ROW_LENGTH,A.width);for(let Ct=0,zt=ht.length;Ct<zt;Ct++){const se=ht[Ct],Jt=Math.floor(se.start/4),It=Math.ceil(se.count/4),he=Jt%A.width,X=Math.floor(Jt/A.width),wt=It,Lt=1;o.pixelStorei(o.UNPACK_SKIP_PIXELS,he),o.pixelStorei(o.UNPACK_SKIP_ROWS,X),i.texSubImage2D(o.TEXTURE_2D,0,he,X,wt,Lt,rt,mt,A.data)}O.clearUpdateRanges(),o.pixelStorei(o.UNPACK_ROW_LENGTH,Dt),o.pixelStorei(o.UNPACK_SKIP_PIXELS,Kt),o.pixelStorei(o.UNPACK_SKIP_ROWS,$t)}}function $(O,A,rt){let mt=o.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(mt=o.TEXTURE_2D_ARRAY),A.isData3DTexture&&(mt=o.TEXTURE_3D);const Tt=xe(O,A),ht=A.source;i.bindTexture(mt,O.__webglTexture,o.TEXTURE0+rt);const Yt=r.get(ht);if(ht.version!==Yt.__version||Tt===!0){i.activeTexture(o.TEXTURE0+rt);const Dt=Oe.getPrimaries(Oe.workingColorSpace),Kt=A.colorSpace===hr?null:Oe.getPrimaries(A.colorSpace),$t=A.colorSpace===hr||Dt===Kt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,A.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,A.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,$t);let Ct=b(A.image,!1,l.maxTextureSize);Ct=le(A,Ct);const zt=c.convert(A.format,A.colorSpace),se=c.convert(A.type);let Jt=N(A.internalFormat,zt,se,A.colorSpace,A.isVideoTexture);oe(mt,A);let It;const he=A.mipmaps,X=A.isVideoTexture!==!0,wt=Yt.__version===void 0||Tt===!0,Lt=ht.dataReady,qt=I(A,Ct);if(A.isDepthTexture)Jt=D(A.format===Tl,A.type),wt&&(X?i.texStorage2D(o.TEXTURE_2D,1,Jt,Ct.width,Ct.height):i.texImage2D(o.TEXTURE_2D,0,Jt,Ct.width,Ct.height,0,zt,se,null));else if(A.isDataTexture)if(he.length>0){X&&wt&&i.texStorage2D(o.TEXTURE_2D,qt,Jt,he[0].width,he[0].height);for(let bt=0,yt=he.length;bt<yt;bt++)It=he[bt],X?Lt&&i.texSubImage2D(o.TEXTURE_2D,bt,0,0,It.width,It.height,zt,se,It.data):i.texImage2D(o.TEXTURE_2D,bt,Jt,It.width,It.height,0,zt,se,It.data);A.generateMipmaps=!1}else X?(wt&&i.texStorage2D(o.TEXTURE_2D,qt,Jt,Ct.width,Ct.height),Lt&&ft(A,Ct,zt,se)):i.texImage2D(o.TEXTURE_2D,0,Jt,Ct.width,Ct.height,0,zt,se,Ct.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){X&&wt&&i.texStorage3D(o.TEXTURE_2D_ARRAY,qt,Jt,he[0].width,he[0].height,Ct.depth);for(let bt=0,yt=he.length;bt<yt;bt++)if(It=he[bt],A.format!==Pi)if(zt!==null)if(X){if(Lt)if(A.layerUpdates.size>0){const Zt=bx(It.width,It.height,A.format,A.type);for(const fe of A.layerUpdates){const ke=It.data.subarray(fe*Zt/It.data.BYTES_PER_ELEMENT,(fe+1)*Zt/It.data.BYTES_PER_ELEMENT);i.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,bt,0,0,fe,It.width,It.height,1,zt,ke)}A.clearLayerUpdates()}else i.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,bt,0,0,0,It.width,It.height,Ct.depth,zt,It.data)}else i.compressedTexImage3D(o.TEXTURE_2D_ARRAY,bt,Jt,It.width,It.height,Ct.depth,0,It.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else X?Lt&&i.texSubImage3D(o.TEXTURE_2D_ARRAY,bt,0,0,0,It.width,It.height,Ct.depth,zt,se,It.data):i.texImage3D(o.TEXTURE_2D_ARRAY,bt,Jt,It.width,It.height,Ct.depth,0,zt,se,It.data)}else{X&&wt&&i.texStorage2D(o.TEXTURE_2D,qt,Jt,he[0].width,he[0].height);for(let bt=0,yt=he.length;bt<yt;bt++)It=he[bt],A.format!==Pi?zt!==null?X?Lt&&i.compressedTexSubImage2D(o.TEXTURE_2D,bt,0,0,It.width,It.height,zt,It.data):i.compressedTexImage2D(o.TEXTURE_2D,bt,Jt,It.width,It.height,0,It.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):X?Lt&&i.texSubImage2D(o.TEXTURE_2D,bt,0,0,It.width,It.height,zt,se,It.data):i.texImage2D(o.TEXTURE_2D,bt,Jt,It.width,It.height,0,zt,se,It.data)}else if(A.isDataArrayTexture)if(X){if(wt&&i.texStorage3D(o.TEXTURE_2D_ARRAY,qt,Jt,Ct.width,Ct.height,Ct.depth),Lt)if(A.layerUpdates.size>0){const bt=bx(Ct.width,Ct.height,A.format,A.type);for(const yt of A.layerUpdates){const Zt=Ct.data.subarray(yt*bt/Ct.data.BYTES_PER_ELEMENT,(yt+1)*bt/Ct.data.BYTES_PER_ELEMENT);i.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,yt,Ct.width,Ct.height,1,zt,se,Zt)}A.clearLayerUpdates()}else i.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,0,Ct.width,Ct.height,Ct.depth,zt,se,Ct.data)}else i.texImage3D(o.TEXTURE_2D_ARRAY,0,Jt,Ct.width,Ct.height,Ct.depth,0,zt,se,Ct.data);else if(A.isData3DTexture)X?(wt&&i.texStorage3D(o.TEXTURE_3D,qt,Jt,Ct.width,Ct.height,Ct.depth),Lt&&i.texSubImage3D(o.TEXTURE_3D,0,0,0,0,Ct.width,Ct.height,Ct.depth,zt,se,Ct.data)):i.texImage3D(o.TEXTURE_3D,0,Jt,Ct.width,Ct.height,Ct.depth,0,zt,se,Ct.data);else if(A.isFramebufferTexture){if(wt)if(X)i.texStorage2D(o.TEXTURE_2D,qt,Jt,Ct.width,Ct.height);else{let bt=Ct.width,yt=Ct.height;for(let Zt=0;Zt<qt;Zt++)i.texImage2D(o.TEXTURE_2D,Zt,Jt,bt,yt,0,zt,se,null),bt>>=1,yt>>=1}}else if(he.length>0){if(X&&wt){const bt=Me(he[0]);i.texStorage2D(o.TEXTURE_2D,qt,Jt,bt.width,bt.height)}for(let bt=0,yt=he.length;bt<yt;bt++)It=he[bt],X?Lt&&i.texSubImage2D(o.TEXTURE_2D,bt,0,0,zt,se,It):i.texImage2D(o.TEXTURE_2D,bt,Jt,zt,se,It);A.generateMipmaps=!1}else if(X){if(wt){const bt=Me(Ct);i.texStorage2D(o.TEXTURE_2D,qt,Jt,bt.width,bt.height)}Lt&&i.texSubImage2D(o.TEXTURE_2D,0,0,0,zt,se,Ct)}else i.texImage2D(o.TEXTURE_2D,0,Jt,zt,se,Ct);y(A)&&S(mt),Yt.__version=ht.version,A.onUpdate&&A.onUpdate(A)}O.__version=A.version}function at(O,A,rt){if(A.image.length!==6)return;const mt=xe(O,A),Tt=A.source;i.bindTexture(o.TEXTURE_CUBE_MAP,O.__webglTexture,o.TEXTURE0+rt);const ht=r.get(Tt);if(Tt.version!==ht.__version||mt===!0){i.activeTexture(o.TEXTURE0+rt);const Yt=Oe.getPrimaries(Oe.workingColorSpace),Dt=A.colorSpace===hr?null:Oe.getPrimaries(A.colorSpace),Kt=A.colorSpace===hr||Yt===Dt?o.NONE:o.BROWSER_DEFAULT_WEBGL;o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,A.flipY),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),o.pixelStorei(o.UNPACK_ALIGNMENT,A.unpackAlignment),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Kt);const $t=A.isCompressedTexture||A.image[0].isCompressedTexture,Ct=A.image[0]&&A.image[0].isDataTexture,zt=[];for(let yt=0;yt<6;yt++)!$t&&!Ct?zt[yt]=b(A.image[yt],!0,l.maxCubemapSize):zt[yt]=Ct?A.image[yt].image:A.image[yt],zt[yt]=le(A,zt[yt]);const se=zt[0],Jt=c.convert(A.format,A.colorSpace),It=c.convert(A.type),he=N(A.internalFormat,Jt,It,A.colorSpace),X=A.isVideoTexture!==!0,wt=ht.__version===void 0||mt===!0,Lt=Tt.dataReady;let qt=I(A,se);oe(o.TEXTURE_CUBE_MAP,A);let bt;if($t){X&&wt&&i.texStorage2D(o.TEXTURE_CUBE_MAP,qt,he,se.width,se.height);for(let yt=0;yt<6;yt++){bt=zt[yt].mipmaps;for(let Zt=0;Zt<bt.length;Zt++){const fe=bt[Zt];A.format!==Pi?Jt!==null?X?Lt&&i.compressedTexSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Zt,0,0,fe.width,fe.height,Jt,fe.data):i.compressedTexImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Zt,he,fe.width,fe.height,0,fe.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):X?Lt&&i.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Zt,0,0,fe.width,fe.height,Jt,It,fe.data):i.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Zt,he,fe.width,fe.height,0,Jt,It,fe.data)}}}else{if(bt=A.mipmaps,X&&wt){bt.length>0&&qt++;const yt=Me(zt[0]);i.texStorage2D(o.TEXTURE_CUBE_MAP,qt,he,yt.width,yt.height)}for(let yt=0;yt<6;yt++)if(Ct){X?Lt&&i.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,0,0,0,zt[yt].width,zt[yt].height,Jt,It,zt[yt].data):i.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,0,he,zt[yt].width,zt[yt].height,0,Jt,It,zt[yt].data);for(let Zt=0;Zt<bt.length;Zt++){const ke=bt[Zt].image[yt].image;X?Lt&&i.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Zt+1,0,0,ke.width,ke.height,Jt,It,ke.data):i.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Zt+1,he,ke.width,ke.height,0,Jt,It,ke.data)}}else{X?Lt&&i.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,0,0,0,Jt,It,zt[yt]):i.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,0,he,Jt,It,zt[yt]);for(let Zt=0;Zt<bt.length;Zt++){const fe=bt[Zt];X?Lt&&i.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Zt+1,0,0,Jt,It,fe.image[yt]):i.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+yt,Zt+1,he,Jt,It,fe.image[yt])}}}y(A)&&S(o.TEXTURE_CUBE_MAP),ht.__version=Tt.version,A.onUpdate&&A.onUpdate(A)}O.__version=A.version}function Et(O,A,rt,mt,Tt,ht){const Yt=c.convert(rt.format,rt.colorSpace),Dt=c.convert(rt.type),Kt=N(rt.internalFormat,Yt,Dt,rt.colorSpace),$t=r.get(A),Ct=r.get(rt);if(Ct.__renderTarget=A,!$t.__hasExternalTextures){const zt=Math.max(1,A.width>>ht),se=Math.max(1,A.height>>ht);Tt===o.TEXTURE_3D||Tt===o.TEXTURE_2D_ARRAY?i.texImage3D(Tt,ht,Kt,zt,se,A.depth,0,Yt,Dt,null):i.texImage2D(Tt,ht,Kt,zt,se,0,Yt,Dt,null)}i.bindFramebuffer(o.FRAMEBUFFER,O),vt(A)?d.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,mt,Tt,Ct.__webglTexture,0,ie(A)):(Tt===o.TEXTURE_2D||Tt>=o.TEXTURE_CUBE_MAP_POSITIVE_X&&Tt<=o.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&o.framebufferTexture2D(o.FRAMEBUFFER,mt,Tt,Ct.__webglTexture,ht),i.bindFramebuffer(o.FRAMEBUFFER,null)}function Ut(O,A,rt){if(o.bindRenderbuffer(o.RENDERBUFFER,O),A.depthBuffer){const mt=A.depthTexture,Tt=mt&&mt.isDepthTexture?mt.type:null,ht=D(A.stencilBuffer,Tt),Yt=A.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,Dt=ie(A);vt(A)?d.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,Dt,ht,A.width,A.height):rt?o.renderbufferStorageMultisample(o.RENDERBUFFER,Dt,ht,A.width,A.height):o.renderbufferStorage(o.RENDERBUFFER,ht,A.width,A.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,Yt,o.RENDERBUFFER,O)}else{const mt=A.textures;for(let Tt=0;Tt<mt.length;Tt++){const ht=mt[Tt],Yt=c.convert(ht.format,ht.colorSpace),Dt=c.convert(ht.type),Kt=N(ht.internalFormat,Yt,Dt,ht.colorSpace),$t=ie(A);rt&&vt(A)===!1?o.renderbufferStorageMultisample(o.RENDERBUFFER,$t,Kt,A.width,A.height):vt(A)?d.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,$t,Kt,A.width,A.height):o.renderbufferStorage(o.RENDERBUFFER,Kt,A.width,A.height)}}o.bindRenderbuffer(o.RENDERBUFFER,null)}function Rt(O,A){if(A&&A.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(i.bindFramebuffer(o.FRAMEBUFFER,O),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const mt=r.get(A.depthTexture);mt.__renderTarget=A,(!mt.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),st(A.depthTexture,0);const Tt=mt.__webglTexture,ht=ie(A);if(A.depthTexture.format===El)vt(A)?d.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,Tt,0,ht):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_ATTACHMENT,o.TEXTURE_2D,Tt,0);else if(A.depthTexture.format===Tl)vt(A)?d.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,Tt,0,ht):o.framebufferTexture2D(o.FRAMEBUFFER,o.DEPTH_STENCIL_ATTACHMENT,o.TEXTURE_2D,Tt,0);else throw new Error("Unknown depthTexture format")}function St(O){const A=r.get(O),rt=O.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==O.depthTexture){const mt=O.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),mt){const Tt=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,mt.removeEventListener("dispose",Tt)};mt.addEventListener("dispose",Tt),A.__depthDisposeCallback=Tt}A.__boundDepthTexture=mt}if(O.depthTexture&&!A.__autoAllocateDepthBuffer){if(rt)throw new Error("target.depthTexture not supported in Cube render targets");const mt=O.texture.mipmaps;mt&&mt.length>0?Rt(A.__webglFramebuffer[0],O):Rt(A.__webglFramebuffer,O)}else if(rt){A.__webglDepthbuffer=[];for(let mt=0;mt<6;mt++)if(i.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer[mt]),A.__webglDepthbuffer[mt]===void 0)A.__webglDepthbuffer[mt]=o.createRenderbuffer(),Ut(A.__webglDepthbuffer[mt],O,!1);else{const Tt=O.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,ht=A.__webglDepthbuffer[mt];o.bindRenderbuffer(o.RENDERBUFFER,ht),o.framebufferRenderbuffer(o.FRAMEBUFFER,Tt,o.RENDERBUFFER,ht)}}else{const mt=O.texture.mipmaps;if(mt&&mt.length>0?i.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer[0]):i.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=o.createRenderbuffer(),Ut(A.__webglDepthbuffer,O,!1);else{const Tt=O.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,ht=A.__webglDepthbuffer;o.bindRenderbuffer(o.RENDERBUFFER,ht),o.framebufferRenderbuffer(o.FRAMEBUFFER,Tt,o.RENDERBUFFER,ht)}}i.bindFramebuffer(o.FRAMEBUFFER,null)}function kt(O,A,rt){const mt=r.get(O);A!==void 0&&Et(mt.__webglFramebuffer,O,O.texture,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,0),rt!==void 0&&St(O)}function F(O){const A=O.texture,rt=r.get(O),mt=r.get(A);O.addEventListener("dispose",L);const Tt=O.textures,ht=O.isWebGLCubeRenderTarget===!0,Yt=Tt.length>1;if(Yt||(mt.__webglTexture===void 0&&(mt.__webglTexture=o.createTexture()),mt.__version=A.version,h.memory.textures++),ht){rt.__webglFramebuffer=[];for(let Dt=0;Dt<6;Dt++)if(A.mipmaps&&A.mipmaps.length>0){rt.__webglFramebuffer[Dt]=[];for(let Kt=0;Kt<A.mipmaps.length;Kt++)rt.__webglFramebuffer[Dt][Kt]=o.createFramebuffer()}else rt.__webglFramebuffer[Dt]=o.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){rt.__webglFramebuffer=[];for(let Dt=0;Dt<A.mipmaps.length;Dt++)rt.__webglFramebuffer[Dt]=o.createFramebuffer()}else rt.__webglFramebuffer=o.createFramebuffer();if(Yt)for(let Dt=0,Kt=Tt.length;Dt<Kt;Dt++){const $t=r.get(Tt[Dt]);$t.__webglTexture===void 0&&($t.__webglTexture=o.createTexture(),h.memory.textures++)}if(O.samples>0&&vt(O)===!1){rt.__webglMultisampledFramebuffer=o.createFramebuffer(),rt.__webglColorRenderbuffer=[],i.bindFramebuffer(o.FRAMEBUFFER,rt.__webglMultisampledFramebuffer);for(let Dt=0;Dt<Tt.length;Dt++){const Kt=Tt[Dt];rt.__webglColorRenderbuffer[Dt]=o.createRenderbuffer(),o.bindRenderbuffer(o.RENDERBUFFER,rt.__webglColorRenderbuffer[Dt]);const $t=c.convert(Kt.format,Kt.colorSpace),Ct=c.convert(Kt.type),zt=N(Kt.internalFormat,$t,Ct,Kt.colorSpace,O.isXRRenderTarget===!0),se=ie(O);o.renderbufferStorageMultisample(o.RENDERBUFFER,se,zt,O.width,O.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Dt,o.RENDERBUFFER,rt.__webglColorRenderbuffer[Dt])}o.bindRenderbuffer(o.RENDERBUFFER,null),O.depthBuffer&&(rt.__webglDepthRenderbuffer=o.createRenderbuffer(),Ut(rt.__webglDepthRenderbuffer,O,!0)),i.bindFramebuffer(o.FRAMEBUFFER,null)}}if(ht){i.bindTexture(o.TEXTURE_CUBE_MAP,mt.__webglTexture),oe(o.TEXTURE_CUBE_MAP,A);for(let Dt=0;Dt<6;Dt++)if(A.mipmaps&&A.mipmaps.length>0)for(let Kt=0;Kt<A.mipmaps.length;Kt++)Et(rt.__webglFramebuffer[Dt][Kt],O,A,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,Kt);else Et(rt.__webglFramebuffer[Dt],O,A,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+Dt,0);y(A)&&S(o.TEXTURE_CUBE_MAP),i.unbindTexture()}else if(Yt){for(let Dt=0,Kt=Tt.length;Dt<Kt;Dt++){const $t=Tt[Dt],Ct=r.get($t);let zt=o.TEXTURE_2D;(O.isWebGL3DRenderTarget||O.isWebGLArrayRenderTarget)&&(zt=O.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),i.bindTexture(zt,Ct.__webglTexture),oe(zt,$t),Et(rt.__webglFramebuffer,O,$t,o.COLOR_ATTACHMENT0+Dt,zt,0),y($t)&&S(zt)}i.unbindTexture()}else{let Dt=o.TEXTURE_2D;if((O.isWebGL3DRenderTarget||O.isWebGLArrayRenderTarget)&&(Dt=O.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),i.bindTexture(Dt,mt.__webglTexture),oe(Dt,A),A.mipmaps&&A.mipmaps.length>0)for(let Kt=0;Kt<A.mipmaps.length;Kt++)Et(rt.__webglFramebuffer[Kt],O,A,o.COLOR_ATTACHMENT0,Dt,Kt);else Et(rt.__webglFramebuffer,O,A,o.COLOR_ATTACHMENT0,Dt,0);y(A)&&S(Dt),i.unbindTexture()}O.depthBuffer&&St(O)}function Pe(O){const A=O.textures;for(let rt=0,mt=A.length;rt<mt;rt++){const Tt=A[rt];if(y(Tt)){const ht=U(O),Yt=r.get(Tt).__webglTexture;i.bindTexture(ht,Yt),S(ht),i.unbindTexture()}}}const re=[],Qt=[];function Ot(O){if(O.samples>0){if(vt(O)===!1){const A=O.textures,rt=O.width,mt=O.height;let Tt=o.COLOR_BUFFER_BIT;const ht=O.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,Yt=r.get(O),Dt=A.length>1;if(Dt)for(let $t=0;$t<A.length;$t++)i.bindFramebuffer(o.FRAMEBUFFER,Yt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+$t,o.RENDERBUFFER,null),i.bindFramebuffer(o.FRAMEBUFFER,Yt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+$t,o.TEXTURE_2D,null,0);i.bindFramebuffer(o.READ_FRAMEBUFFER,Yt.__webglMultisampledFramebuffer);const Kt=O.texture.mipmaps;Kt&&Kt.length>0?i.bindFramebuffer(o.DRAW_FRAMEBUFFER,Yt.__webglFramebuffer[0]):i.bindFramebuffer(o.DRAW_FRAMEBUFFER,Yt.__webglFramebuffer);for(let $t=0;$t<A.length;$t++){if(O.resolveDepthBuffer&&(O.depthBuffer&&(Tt|=o.DEPTH_BUFFER_BIT),O.stencilBuffer&&O.resolveStencilBuffer&&(Tt|=o.STENCIL_BUFFER_BIT)),Dt){o.framebufferRenderbuffer(o.READ_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.RENDERBUFFER,Yt.__webglColorRenderbuffer[$t]);const Ct=r.get(A[$t]).__webglTexture;o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,Ct,0)}o.blitFramebuffer(0,0,rt,mt,0,0,rt,mt,Tt,o.NEAREST),m===!0&&(re.length=0,Qt.length=0,re.push(o.COLOR_ATTACHMENT0+$t),O.depthBuffer&&O.resolveDepthBuffer===!1&&(re.push(ht),Qt.push(ht),o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,Qt)),o.invalidateFramebuffer(o.READ_FRAMEBUFFER,re))}if(i.bindFramebuffer(o.READ_FRAMEBUFFER,null),i.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),Dt)for(let $t=0;$t<A.length;$t++){i.bindFramebuffer(o.FRAMEBUFFER,Yt.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+$t,o.RENDERBUFFER,Yt.__webglColorRenderbuffer[$t]);const Ct=r.get(A[$t]).__webglTexture;i.bindFramebuffer(o.FRAMEBUFFER,Yt.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+$t,o.TEXTURE_2D,Ct,0)}i.bindFramebuffer(o.DRAW_FRAMEBUFFER,Yt.__webglMultisampledFramebuffer)}else if(O.depthBuffer&&O.resolveDepthBuffer===!1&&m){const A=O.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,[A])}}}function ie(O){return Math.min(l.maxSamples,O.samples)}function vt(O){const A=r.get(O);return O.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function Gt(O){const A=h.render.frame;_.get(O)!==A&&(_.set(O,A),O.update())}function le(O,A){const rt=O.colorSpace,mt=O.format,Tt=O.type;return O.isCompressedTexture===!0||O.isVideoTexture===!0||rt!==ho&&rt!==hr&&(Oe.getTransfer(rt)===Ye?(mt!==Pi||Tt!==ea)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",rt)),A}function Me(O){return typeof HTMLImageElement<"u"&&O instanceof HTMLImageElement?(g.width=O.naturalWidth||O.width,g.height=O.naturalHeight||O.height):typeof VideoFrame<"u"&&O instanceof VideoFrame?(g.width=O.displayWidth,g.height=O.displayHeight):(g.width=O.width,g.height=O.height),g}this.allocateTextureUnit=et,this.resetTextureUnits=Z,this.setTexture2D=st,this.setTexture2DArray=k,this.setTexture3D=it,this.setTextureCube=j,this.rebindTextures=kt,this.setupRenderTarget=F,this.updateRenderTargetMipmap=Pe,this.updateMultisampleRenderTarget=Ot,this.setupDepthRenderbuffer=St,this.setupFrameBufferTexture=Et,this.useMultisampledRTT=vt}function w2(o,e){function i(r,l=hr){let c;const h=Oe.getTransfer(l);if(r===ea)return o.UNSIGNED_BYTE;if(r===dm)return o.UNSIGNED_SHORT_4_4_4_4;if(r===pm)return o.UNSIGNED_SHORT_5_5_5_1;if(r===wy)return o.UNSIGNED_INT_5_9_9_9_REV;if(r===Dy)return o.UNSIGNED_INT_10F_11F_11F_REV;if(r===Ry)return o.BYTE;if(r===Cy)return o.SHORT;if(r===Sl)return o.UNSIGNED_SHORT;if(r===hm)return o.INT;if(r===$r)return o.UNSIGNED_INT;if(r===Aa)return o.FLOAT;if(r===wl)return o.HALF_FLOAT;if(r===Uy)return o.ALPHA;if(r===Ny)return o.RGB;if(r===Pi)return o.RGBA;if(r===El)return o.DEPTH_COMPONENT;if(r===Tl)return o.DEPTH_STENCIL;if(r===Ly)return o.RED;if(r===mm)return o.RED_INTEGER;if(r===Oy)return o.RG;if(r===gm)return o.RG_INTEGER;if(r===_m)return o.RGBA_INTEGER;if(r===wc||r===Dc||r===Uc||r===Nc)if(h===Ye)if(c=e.get("WEBGL_compressed_texture_s3tc_srgb"),c!==null){if(r===wc)return c.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(r===Dc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(r===Uc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(r===Nc)return c.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(c=e.get("WEBGL_compressed_texture_s3tc"),c!==null){if(r===wc)return c.COMPRESSED_RGB_S3TC_DXT1_EXT;if(r===Dc)return c.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(r===Uc)return c.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(r===Nc)return c.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(r===Tp||r===bp||r===Ap||r===Rp)if(c=e.get("WEBGL_compressed_texture_pvrtc"),c!==null){if(r===Tp)return c.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(r===bp)return c.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(r===Ap)return c.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(r===Rp)return c.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(r===Cp||r===wp||r===Dp)if(c=e.get("WEBGL_compressed_texture_etc"),c!==null){if(r===Cp||r===wp)return h===Ye?c.COMPRESSED_SRGB8_ETC2:c.COMPRESSED_RGB8_ETC2;if(r===Dp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:c.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(r===Up||r===Np||r===Lp||r===Op||r===Pp||r===zp||r===Ip||r===Bp||r===Fp||r===Hp||r===Gp||r===Vp||r===Xp||r===kp)if(c=e.get("WEBGL_compressed_texture_astc"),c!==null){if(r===Up)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:c.COMPRESSED_RGBA_ASTC_4x4_KHR;if(r===Np)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:c.COMPRESSED_RGBA_ASTC_5x4_KHR;if(r===Lp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:c.COMPRESSED_RGBA_ASTC_5x5_KHR;if(r===Op)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:c.COMPRESSED_RGBA_ASTC_6x5_KHR;if(r===Pp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:c.COMPRESSED_RGBA_ASTC_6x6_KHR;if(r===zp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:c.COMPRESSED_RGBA_ASTC_8x5_KHR;if(r===Ip)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:c.COMPRESSED_RGBA_ASTC_8x6_KHR;if(r===Bp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:c.COMPRESSED_RGBA_ASTC_8x8_KHR;if(r===Fp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:c.COMPRESSED_RGBA_ASTC_10x5_KHR;if(r===Hp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:c.COMPRESSED_RGBA_ASTC_10x6_KHR;if(r===Gp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:c.COMPRESSED_RGBA_ASTC_10x8_KHR;if(r===Vp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:c.COMPRESSED_RGBA_ASTC_10x10_KHR;if(r===Xp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:c.COMPRESSED_RGBA_ASTC_12x10_KHR;if(r===kp)return h===Ye?c.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:c.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(r===qp||r===Yp||r===Wp)if(c=e.get("EXT_texture_compression_bptc"),c!==null){if(r===qp)return h===Ye?c.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:c.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(r===Yp)return c.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(r===Wp)return c.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(r===jp||r===Zp||r===Kp||r===Qp)if(c=e.get("EXT_texture_compression_rgtc"),c!==null){if(r===jp)return c.COMPRESSED_RED_RGTC1_EXT;if(r===Zp)return c.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(r===Kp)return c.COMPRESSED_RED_GREEN_RGTC2_EXT;if(r===Qp)return c.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return r===Ml?o.UNSIGNED_INT_24_8:o[r]!==void 0?o[r]:null}return{convert:i}}const D2=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,U2=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class N2{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,i){if(this.texture===null){const r=new Zy(e.texture);(e.depthNear!==i.depthNear||e.depthFar!==i.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=r}}getMesh(e){if(this.texture!==null&&this.mesh===null){const i=e.cameras[0].viewport,r=new gr({vertexShader:D2,fragmentShader:U2,uniforms:{depthColor:{value:this.texture},depthWidth:{value:i.z},depthHeight:{value:i.w}}});this.mesh=new Nn(new kc(20,20),r)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class L2 extends _o{constructor(e,i){super();const r=this;let l=null,c=1,h=null,d="local-floor",m=1,g=null,_=null,p=null,x=null,M=null,E=null;const b=typeof XRWebGLBinding<"u",y=new N2,S={},U=i.getContextAttributes();let N=null,D=null;const I=[],z=[],L=new be;let B=null;const C=new ci;C.viewport=new We;const R=new ci;R.viewport=new We;const G=[C,R],Z=new tA;let et=null,ct=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function($){let at=I[$];return at===void 0&&(at=new Jd,I[$]=at),at.getTargetRaySpace()},this.getControllerGrip=function($){let at=I[$];return at===void 0&&(at=new Jd,I[$]=at),at.getGripSpace()},this.getHand=function($){let at=I[$];return at===void 0&&(at=new Jd,I[$]=at),at.getHandSpace()};function st($){const at=z.indexOf($.inputSource);if(at===-1)return;const Et=I[at];Et!==void 0&&(Et.update($.inputSource,$.frame,g||h),Et.dispatchEvent({type:$.type,data:$.inputSource}))}function k(){l.removeEventListener("select",st),l.removeEventListener("selectstart",st),l.removeEventListener("selectend",st),l.removeEventListener("squeeze",st),l.removeEventListener("squeezestart",st),l.removeEventListener("squeezeend",st),l.removeEventListener("end",k),l.removeEventListener("inputsourceschange",it);for(let $=0;$<I.length;$++){const at=z[$];at!==null&&(z[$]=null,I[$].disconnect(at))}et=null,ct=null,y.reset();for(const $ in S)delete S[$];e.setRenderTarget(N),M=null,x=null,p=null,l=null,D=null,ft.stop(),r.isPresenting=!1,e.setPixelRatio(B),e.setSize(L.width,L.height,!1),r.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function($){c=$,r.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function($){d=$,r.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return g||h},this.setReferenceSpace=function($){g=$},this.getBaseLayer=function(){return x!==null?x:M},this.getBinding=function(){return p===null&&b&&(p=new XRWebGLBinding(l,i)),p},this.getFrame=function(){return E},this.getSession=function(){return l},this.setSession=async function($){if(l=$,l!==null){if(N=e.getRenderTarget(),l.addEventListener("select",st),l.addEventListener("selectstart",st),l.addEventListener("selectend",st),l.addEventListener("squeeze",st),l.addEventListener("squeezestart",st),l.addEventListener("squeezeend",st),l.addEventListener("end",k),l.addEventListener("inputsourceschange",it),U.xrCompatible!==!0&&await i.makeXRCompatible(),B=e.getPixelRatio(),e.getSize(L),b&&"createProjectionLayer"in XRWebGLBinding.prototype){let Et=null,Ut=null,Rt=null;U.depth&&(Rt=U.stencil?i.DEPTH24_STENCIL8:i.DEPTH_COMPONENT24,Et=U.stencil?Tl:El,Ut=U.stencil?Ml:$r);const St={colorFormat:i.RGBA8,depthFormat:Rt,scaleFactor:c};p=this.getBinding(),x=p.createProjectionLayer(St),l.updateRenderState({layers:[x]}),e.setPixelRatio(1),e.setSize(x.textureWidth,x.textureHeight,!1),D=new ts(x.textureWidth,x.textureHeight,{format:Pi,type:ea,depthTexture:new jy(x.textureWidth,x.textureHeight,Ut,void 0,void 0,void 0,void 0,void 0,void 0,Et),stencilBuffer:U.stencil,colorSpace:e.outputColorSpace,samples:U.antialias?4:0,resolveDepthBuffer:x.ignoreDepthValues===!1,resolveStencilBuffer:x.ignoreDepthValues===!1})}else{const Et={antialias:U.antialias,alpha:!0,depth:U.depth,stencil:U.stencil,framebufferScaleFactor:c};M=new XRWebGLLayer(l,i,Et),l.updateRenderState({baseLayer:M}),e.setPixelRatio(1),e.setSize(M.framebufferWidth,M.framebufferHeight,!1),D=new ts(M.framebufferWidth,M.framebufferHeight,{format:Pi,type:ea,colorSpace:e.outputColorSpace,stencilBuffer:U.stencil,resolveDepthBuffer:M.ignoreDepthValues===!1,resolveStencilBuffer:M.ignoreDepthValues===!1})}D.isXRRenderTarget=!0,this.setFoveation(m),g=null,h=await l.requestReferenceSpace(d),ft.setContext(l),ft.start(),r.isPresenting=!0,r.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(l!==null)return l.environmentBlendMode},this.getDepthTexture=function(){return y.getDepthTexture()};function it($){for(let at=0;at<$.removed.length;at++){const Et=$.removed[at],Ut=z.indexOf(Et);Ut>=0&&(z[Ut]=null,I[Ut].disconnect(Et))}for(let at=0;at<$.added.length;at++){const Et=$.added[at];let Ut=z.indexOf(Et);if(Ut===-1){for(let St=0;St<I.length;St++)if(St>=z.length){z.push(Et),Ut=St;break}else if(z[St]===null){z[St]=Et,Ut=St;break}if(Ut===-1)break}const Rt=I[Ut];Rt&&Rt.connect(Et)}}const j=new J,xt=new J;function Mt($,at,Et){j.setFromMatrixPosition(at.matrixWorld),xt.setFromMatrixPosition(Et.matrixWorld);const Ut=j.distanceTo(xt),Rt=at.projectionMatrix.elements,St=Et.projectionMatrix.elements,kt=Rt[14]/(Rt[10]-1),F=Rt[14]/(Rt[10]+1),Pe=(Rt[9]+1)/Rt[5],re=(Rt[9]-1)/Rt[5],Qt=(Rt[8]-1)/Rt[0],Ot=(St[8]+1)/St[0],ie=kt*Qt,vt=kt*Ot,Gt=Ut/(-Qt+Ot),le=Gt*-Qt;if(at.matrixWorld.decompose($.position,$.quaternion,$.scale),$.translateX(le),$.translateZ(Gt),$.matrixWorld.compose($.position,$.quaternion,$.scale),$.matrixWorldInverse.copy($.matrixWorld).invert(),Rt[10]===-1)$.projectionMatrix.copy(at.projectionMatrix),$.projectionMatrixInverse.copy(at.projectionMatrixInverse);else{const Me=kt+Gt,O=F+Gt,A=ie-le,rt=vt+(Ut-le),mt=Pe*F/O*Me,Tt=re*F/O*Me;$.projectionMatrix.makePerspective(A,rt,mt,Tt,Me,O),$.projectionMatrixInverse.copy($.projectionMatrix).invert()}}function Ht($,at){at===null?$.matrixWorld.copy($.matrix):$.matrixWorld.multiplyMatrices(at.matrixWorld,$.matrix),$.matrixWorldInverse.copy($.matrixWorld).invert()}this.updateCamera=function($){if(l===null)return;let at=$.near,Et=$.far;y.texture!==null&&(y.depthNear>0&&(at=y.depthNear),y.depthFar>0&&(Et=y.depthFar)),Z.near=R.near=C.near=at,Z.far=R.far=C.far=Et,(et!==Z.near||ct!==Z.far)&&(l.updateRenderState({depthNear:Z.near,depthFar:Z.far}),et=Z.near,ct=Z.far),Z.layers.mask=$.layers.mask|6,C.layers.mask=Z.layers.mask&3,R.layers.mask=Z.layers.mask&5;const Ut=$.parent,Rt=Z.cameras;Ht(Z,Ut);for(let St=0;St<Rt.length;St++)Ht(Rt[St],Ut);Rt.length===2?Mt(Z,C,R):Z.projectionMatrix.copy(C.projectionMatrix),oe($,Z,Ut)};function oe($,at,Et){Et===null?$.matrix.copy(at.matrixWorld):($.matrix.copy(Et.matrixWorld),$.matrix.invert(),$.matrix.multiply(at.matrixWorld)),$.matrix.decompose($.position,$.quaternion,$.scale),$.updateMatrixWorld(!0),$.projectionMatrix.copy(at.projectionMatrix),$.projectionMatrixInverse.copy(at.projectionMatrixInverse),$.isPerspectiveCamera&&($.fov=Jp*2*Math.atan(1/$.projectionMatrix.elements[5]),$.zoom=1)}this.getCamera=function(){return Z},this.getFoveation=function(){if(!(x===null&&M===null))return m},this.setFoveation=function($){m=$,x!==null&&(x.fixedFoveation=$),M!==null&&M.fixedFoveation!==void 0&&(M.fixedFoveation=$)},this.hasDepthSensing=function(){return y.texture!==null},this.getDepthSensingMesh=function(){return y.getMesh(Z)},this.getCameraTexture=function($){return S[$]};let xe=null;function H($,at){if(_=at.getViewerPose(g||h),E=at,_!==null){const Et=_.views;M!==null&&(e.setRenderTargetFramebuffer(D,M.framebuffer),e.setRenderTarget(D));let Ut=!1;Et.length!==Z.cameras.length&&(Z.cameras.length=0,Ut=!0);for(let F=0;F<Et.length;F++){const Pe=Et[F];let re=null;if(M!==null)re=M.getViewport(Pe);else{const Ot=p.getViewSubImage(x,Pe);re=Ot.viewport,F===0&&(e.setRenderTargetTextures(D,Ot.colorTexture,Ot.depthStencilTexture),e.setRenderTarget(D))}let Qt=G[F];Qt===void 0&&(Qt=new ci,Qt.layers.enable(F),Qt.viewport=new We,G[F]=Qt),Qt.matrix.fromArray(Pe.transform.matrix),Qt.matrix.decompose(Qt.position,Qt.quaternion,Qt.scale),Qt.projectionMatrix.fromArray(Pe.projectionMatrix),Qt.projectionMatrixInverse.copy(Qt.projectionMatrix).invert(),Qt.viewport.set(re.x,re.y,re.width,re.height),F===0&&(Z.matrix.copy(Qt.matrix),Z.matrix.decompose(Z.position,Z.quaternion,Z.scale)),Ut===!0&&Z.cameras.push(Qt)}const Rt=l.enabledFeatures;if(Rt&&Rt.includes("depth-sensing")&&l.depthUsage=="gpu-optimized"&&b){p=r.getBinding();const F=p.getDepthInformation(Et[0]);F&&F.isValid&&F.texture&&y.init(F,l.renderState)}if(Rt&&Rt.includes("camera-access")&&b){e.state.unbindTexture(),p=r.getBinding();for(let F=0;F<Et.length;F++){const Pe=Et[F].camera;if(Pe){let re=S[Pe];re||(re=new Zy,S[Pe]=re);const Qt=p.getCameraImage(Pe);re.sourceTexture=Qt}}}}for(let Et=0;Et<I.length;Et++){const Ut=z[Et],Rt=I[Et];Ut!==null&&Rt!==void 0&&Rt.update(Ut,at,g||h)}xe&&xe($,at),at.detectedPlanes&&r.dispatchEvent({type:"planesdetected",data:at}),E=null}const ft=new Jy;ft.setAnimationLoop(H),this.setAnimationLoop=function($){xe=$},this.dispose=function(){}}}const Yr=new na,O2=new an;function P2(o,e){function i(y,S){y.matrixAutoUpdate===!0&&y.updateMatrix(),S.value.copy(y.matrix)}function r(y,S){S.color.getRGB(y.fogColor.value,ky(o)),S.isFog?(y.fogNear.value=S.near,y.fogFar.value=S.far):S.isFogExp2&&(y.fogDensity.value=S.density)}function l(y,S,U,N,D){S.isMeshBasicMaterial||S.isMeshLambertMaterial?c(y,S):S.isMeshToonMaterial?(c(y,S),p(y,S)):S.isMeshPhongMaterial?(c(y,S),_(y,S)):S.isMeshStandardMaterial?(c(y,S),x(y,S),S.isMeshPhysicalMaterial&&M(y,S,D)):S.isMeshMatcapMaterial?(c(y,S),E(y,S)):S.isMeshDepthMaterial?c(y,S):S.isMeshDistanceMaterial?(c(y,S),b(y,S)):S.isMeshNormalMaterial?c(y,S):S.isLineBasicMaterial?(h(y,S),S.isLineDashedMaterial&&d(y,S)):S.isPointsMaterial?m(y,S,U,N):S.isSpriteMaterial?g(y,S):S.isShadowMaterial?(y.color.value.copy(S.color),y.opacity.value=S.opacity):S.isShaderMaterial&&(S.uniformsNeedUpdate=!1)}function c(y,S){y.opacity.value=S.opacity,S.color&&y.diffuse.value.copy(S.color),S.emissive&&y.emissive.value.copy(S.emissive).multiplyScalar(S.emissiveIntensity),S.map&&(y.map.value=S.map,i(S.map,y.mapTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,i(S.alphaMap,y.alphaMapTransform)),S.bumpMap&&(y.bumpMap.value=S.bumpMap,i(S.bumpMap,y.bumpMapTransform),y.bumpScale.value=S.bumpScale,S.side===Qn&&(y.bumpScale.value*=-1)),S.normalMap&&(y.normalMap.value=S.normalMap,i(S.normalMap,y.normalMapTransform),y.normalScale.value.copy(S.normalScale),S.side===Qn&&y.normalScale.value.negate()),S.displacementMap&&(y.displacementMap.value=S.displacementMap,i(S.displacementMap,y.displacementMapTransform),y.displacementScale.value=S.displacementScale,y.displacementBias.value=S.displacementBias),S.emissiveMap&&(y.emissiveMap.value=S.emissiveMap,i(S.emissiveMap,y.emissiveMapTransform)),S.specularMap&&(y.specularMap.value=S.specularMap,i(S.specularMap,y.specularMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest);const U=e.get(S),N=U.envMap,D=U.envMapRotation;N&&(y.envMap.value=N,Yr.copy(D),Yr.x*=-1,Yr.y*=-1,Yr.z*=-1,N.isCubeTexture&&N.isRenderTargetTexture===!1&&(Yr.y*=-1,Yr.z*=-1),y.envMapRotation.value.setFromMatrix4(O2.makeRotationFromEuler(Yr)),y.flipEnvMap.value=N.isCubeTexture&&N.isRenderTargetTexture===!1?-1:1,y.reflectivity.value=S.reflectivity,y.ior.value=S.ior,y.refractionRatio.value=S.refractionRatio),S.lightMap&&(y.lightMap.value=S.lightMap,y.lightMapIntensity.value=S.lightMapIntensity,i(S.lightMap,y.lightMapTransform)),S.aoMap&&(y.aoMap.value=S.aoMap,y.aoMapIntensity.value=S.aoMapIntensity,i(S.aoMap,y.aoMapTransform))}function h(y,S){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,S.map&&(y.map.value=S.map,i(S.map,y.mapTransform))}function d(y,S){y.dashSize.value=S.dashSize,y.totalSize.value=S.dashSize+S.gapSize,y.scale.value=S.scale}function m(y,S,U,N){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,y.size.value=S.size*U,y.scale.value=N*.5,S.map&&(y.map.value=S.map,i(S.map,y.uvTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,i(S.alphaMap,y.alphaMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest)}function g(y,S){y.diffuse.value.copy(S.color),y.opacity.value=S.opacity,y.rotation.value=S.rotation,S.map&&(y.map.value=S.map,i(S.map,y.mapTransform)),S.alphaMap&&(y.alphaMap.value=S.alphaMap,i(S.alphaMap,y.alphaMapTransform)),S.alphaTest>0&&(y.alphaTest.value=S.alphaTest)}function _(y,S){y.specular.value.copy(S.specular),y.shininess.value=Math.max(S.shininess,1e-4)}function p(y,S){S.gradientMap&&(y.gradientMap.value=S.gradientMap)}function x(y,S){y.metalness.value=S.metalness,S.metalnessMap&&(y.metalnessMap.value=S.metalnessMap,i(S.metalnessMap,y.metalnessMapTransform)),y.roughness.value=S.roughness,S.roughnessMap&&(y.roughnessMap.value=S.roughnessMap,i(S.roughnessMap,y.roughnessMapTransform)),S.envMap&&(y.envMapIntensity.value=S.envMapIntensity)}function M(y,S,U){y.ior.value=S.ior,S.sheen>0&&(y.sheenColor.value.copy(S.sheenColor).multiplyScalar(S.sheen),y.sheenRoughness.value=S.sheenRoughness,S.sheenColorMap&&(y.sheenColorMap.value=S.sheenColorMap,i(S.sheenColorMap,y.sheenColorMapTransform)),S.sheenRoughnessMap&&(y.sheenRoughnessMap.value=S.sheenRoughnessMap,i(S.sheenRoughnessMap,y.sheenRoughnessMapTransform))),S.clearcoat>0&&(y.clearcoat.value=S.clearcoat,y.clearcoatRoughness.value=S.clearcoatRoughness,S.clearcoatMap&&(y.clearcoatMap.value=S.clearcoatMap,i(S.clearcoatMap,y.clearcoatMapTransform)),S.clearcoatRoughnessMap&&(y.clearcoatRoughnessMap.value=S.clearcoatRoughnessMap,i(S.clearcoatRoughnessMap,y.clearcoatRoughnessMapTransform)),S.clearcoatNormalMap&&(y.clearcoatNormalMap.value=S.clearcoatNormalMap,i(S.clearcoatNormalMap,y.clearcoatNormalMapTransform),y.clearcoatNormalScale.value.copy(S.clearcoatNormalScale),S.side===Qn&&y.clearcoatNormalScale.value.negate())),S.dispersion>0&&(y.dispersion.value=S.dispersion),S.iridescence>0&&(y.iridescence.value=S.iridescence,y.iridescenceIOR.value=S.iridescenceIOR,y.iridescenceThicknessMinimum.value=S.iridescenceThicknessRange[0],y.iridescenceThicknessMaximum.value=S.iridescenceThicknessRange[1],S.iridescenceMap&&(y.iridescenceMap.value=S.iridescenceMap,i(S.iridescenceMap,y.iridescenceMapTransform)),S.iridescenceThicknessMap&&(y.iridescenceThicknessMap.value=S.iridescenceThicknessMap,i(S.iridescenceThicknessMap,y.iridescenceThicknessMapTransform))),S.transmission>0&&(y.transmission.value=S.transmission,y.transmissionSamplerMap.value=U.texture,y.transmissionSamplerSize.value.set(U.width,U.height),S.transmissionMap&&(y.transmissionMap.value=S.transmissionMap,i(S.transmissionMap,y.transmissionMapTransform)),y.thickness.value=S.thickness,S.thicknessMap&&(y.thicknessMap.value=S.thicknessMap,i(S.thicknessMap,y.thicknessMapTransform)),y.attenuationDistance.value=S.attenuationDistance,y.attenuationColor.value.copy(S.attenuationColor)),S.anisotropy>0&&(y.anisotropyVector.value.set(S.anisotropy*Math.cos(S.anisotropyRotation),S.anisotropy*Math.sin(S.anisotropyRotation)),S.anisotropyMap&&(y.anisotropyMap.value=S.anisotropyMap,i(S.anisotropyMap,y.anisotropyMapTransform))),y.specularIntensity.value=S.specularIntensity,y.specularColor.value.copy(S.specularColor),S.specularColorMap&&(y.specularColorMap.value=S.specularColorMap,i(S.specularColorMap,y.specularColorMapTransform)),S.specularIntensityMap&&(y.specularIntensityMap.value=S.specularIntensityMap,i(S.specularIntensityMap,y.specularIntensityMapTransform))}function E(y,S){S.matcap&&(y.matcap.value=S.matcap)}function b(y,S){const U=e.get(S).light;y.referencePosition.value.setFromMatrixPosition(U.matrixWorld),y.nearDistance.value=U.shadow.camera.near,y.farDistance.value=U.shadow.camera.far}return{refreshFogUniforms:r,refreshMaterialUniforms:l}}function z2(o,e,i,r){let l={},c={},h=[];const d=o.getParameter(o.MAX_UNIFORM_BUFFER_BINDINGS);function m(U,N){const D=N.program;r.uniformBlockBinding(U,D)}function g(U,N){let D=l[U.id];D===void 0&&(E(U),D=_(U),l[U.id]=D,U.addEventListener("dispose",y));const I=N.program;r.updateUBOMapping(U,I);const z=e.render.frame;c[U.id]!==z&&(x(U),c[U.id]=z)}function _(U){const N=p();U.__bindingPointIndex=N;const D=o.createBuffer(),I=U.__size,z=U.usage;return o.bindBuffer(o.UNIFORM_BUFFER,D),o.bufferData(o.UNIFORM_BUFFER,I,z),o.bindBuffer(o.UNIFORM_BUFFER,null),o.bindBufferBase(o.UNIFORM_BUFFER,N,D),D}function p(){for(let U=0;U<d;U++)if(h.indexOf(U)===-1)return h.push(U),U;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function x(U){const N=l[U.id],D=U.uniforms,I=U.__cache;o.bindBuffer(o.UNIFORM_BUFFER,N);for(let z=0,L=D.length;z<L;z++){const B=Array.isArray(D[z])?D[z]:[D[z]];for(let C=0,R=B.length;C<R;C++){const G=B[C];if(M(G,z,C,I)===!0){const Z=G.__offset,et=Array.isArray(G.value)?G.value:[G.value];let ct=0;for(let st=0;st<et.length;st++){const k=et[st],it=b(k);typeof k=="number"||typeof k=="boolean"?(G.__data[0]=k,o.bufferSubData(o.UNIFORM_BUFFER,Z+ct,G.__data)):k.isMatrix3?(G.__data[0]=k.elements[0],G.__data[1]=k.elements[1],G.__data[2]=k.elements[2],G.__data[3]=0,G.__data[4]=k.elements[3],G.__data[5]=k.elements[4],G.__data[6]=k.elements[5],G.__data[7]=0,G.__data[8]=k.elements[6],G.__data[9]=k.elements[7],G.__data[10]=k.elements[8],G.__data[11]=0):(k.toArray(G.__data,ct),ct+=it.storage/Float32Array.BYTES_PER_ELEMENT)}o.bufferSubData(o.UNIFORM_BUFFER,Z,G.__data)}}}o.bindBuffer(o.UNIFORM_BUFFER,null)}function M(U,N,D,I){const z=U.value,L=N+"_"+D;if(I[L]===void 0)return typeof z=="number"||typeof z=="boolean"?I[L]=z:I[L]=z.clone(),!0;{const B=I[L];if(typeof z=="number"||typeof z=="boolean"){if(B!==z)return I[L]=z,!0}else if(B.equals(z)===!1)return B.copy(z),!0}return!1}function E(U){const N=U.uniforms;let D=0;const I=16;for(let L=0,B=N.length;L<B;L++){const C=Array.isArray(N[L])?N[L]:[N[L]];for(let R=0,G=C.length;R<G;R++){const Z=C[R],et=Array.isArray(Z.value)?Z.value:[Z.value];for(let ct=0,st=et.length;ct<st;ct++){const k=et[ct],it=b(k),j=D%I,xt=j%it.boundary,Mt=j+xt;D+=xt,Mt!==0&&I-Mt<it.storage&&(D+=I-Mt),Z.__data=new Float32Array(it.storage/Float32Array.BYTES_PER_ELEMENT),Z.__offset=D,D+=it.storage}}}const z=D%I;return z>0&&(D+=I-z),U.__size=D,U.__cache={},this}function b(U){const N={boundary:0,storage:0};return typeof U=="number"||typeof U=="boolean"?(N.boundary=4,N.storage=4):U.isVector2?(N.boundary=8,N.storage=8):U.isVector3||U.isColor?(N.boundary=16,N.storage=12):U.isVector4?(N.boundary=16,N.storage=16):U.isMatrix3?(N.boundary=48,N.storage=48):U.isMatrix4?(N.boundary=64,N.storage=64):U.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",U),N}function y(U){const N=U.target;N.removeEventListener("dispose",y);const D=h.indexOf(N.__bindingPointIndex);h.splice(D,1),o.deleteBuffer(l[N.id]),delete l[N.id],delete c[N.id]}function S(){for(const U in l)o.deleteBuffer(l[U]);h=[],l={},c={}}return{bind:m,update:g,dispose:S}}class I2{constructor(e={}){const{canvas:i=g1(),context:r=null,depth:l=!0,stencil:c=!1,alpha:h=!1,antialias:d=!1,premultipliedAlpha:m=!0,preserveDrawingBuffer:g=!1,powerPreference:_="default",failIfMajorPerformanceCaveat:p=!1,reversedDepthBuffer:x=!1}=e;this.isWebGLRenderer=!0;let M;if(r!==null){if(typeof WebGLRenderingContext<"u"&&r instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=r.getContextAttributes().alpha}else M=h;const E=new Uint32Array(4),b=new Int32Array(4);let y=null,S=null;const U=[],N=[];this.domElement=i,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=pr,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const D=this;let I=!1;this._outputColorSpace=Mi;let z=0,L=0,B=null,C=-1,R=null;const G=new We,Z=new We;let et=null;const ct=new Se(0);let st=0,k=i.width,it=i.height,j=1,xt=null,Mt=null;const Ht=new We(0,0,k,it),oe=new We(0,0,k,it);let xe=!1;const H=new Sm;let ft=!1,$=!1;const at=new an,Et=new J,Ut=new We,Rt={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let St=!1;function kt(){return B===null?j:1}let F=r;function Pe(w,K){return i.getContext(w,K)}try{const w={alpha:!0,depth:l,stencil:c,antialias:d,premultipliedAlpha:m,preserveDrawingBuffer:g,powerPreference:_,failIfMajorPerformanceCaveat:p};if("setAttribute"in i&&i.setAttribute("data-engine",`three.js r${fm}`),i.addEventListener("webglcontextlost",Lt,!1),i.addEventListener("webglcontextrestored",qt,!1),i.addEventListener("webglcontextcreationerror",bt,!1),F===null){const K="webgl2";if(F=Pe(K,w),F===null)throw Pe(K)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(w){throw console.error("THREE.WebGLRenderer: "+w.message),w}let re,Qt,Ot,ie,vt,Gt,le,Me,O,A,rt,mt,Tt,ht,Yt,Dt,Kt,$t,Ct,zt,se,Jt,It,he;function X(){re=new WC(F),re.init(),Jt=new w2(F,re),Qt=new HC(F,re,e,Jt),Ot=new R2(F,re),Qt.reversedDepthBuffer&&x&&Ot.buffers.depth.setReversed(!0),ie=new KC(F),vt=new p2,Gt=new C2(F,re,Ot,vt,Qt,Jt,ie),le=new VC(D),Me=new YC(D),O=new nA(F),It=new BC(F,O),A=new jC(F,O,ie,It),rt=new JC(F,A,O,ie),Ct=new QC(F,Qt,Gt),Dt=new GC(vt),mt=new d2(D,le,Me,re,Qt,It,Dt),Tt=new P2(D,vt),ht=new g2,Yt=new M2(re),$t=new IC(D,le,Me,Ot,rt,M,m),Kt=new b2(D,rt,Qt),he=new z2(F,ie,Qt,Ot),zt=new FC(F,re,ie),se=new ZC(F,re,ie),ie.programs=mt.programs,D.capabilities=Qt,D.extensions=re,D.properties=vt,D.renderLists=ht,D.shadowMap=Kt,D.state=Ot,D.info=ie}X();const wt=new L2(D,F);this.xr=wt,this.getContext=function(){return F},this.getContextAttributes=function(){return F.getContextAttributes()},this.forceContextLoss=function(){const w=re.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=re.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return j},this.setPixelRatio=function(w){w!==void 0&&(j=w,this.setSize(k,it,!1))},this.getSize=function(w){return w.set(k,it)},this.setSize=function(w,K,lt=!0){if(wt.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}k=w,it=K,i.width=Math.floor(w*j),i.height=Math.floor(K*j),lt===!0&&(i.style.width=w+"px",i.style.height=K+"px"),this.setViewport(0,0,w,K)},this.getDrawingBufferSize=function(w){return w.set(k*j,it*j).floor()},this.setDrawingBufferSize=function(w,K,lt){k=w,it=K,j=lt,i.width=Math.floor(w*lt),i.height=Math.floor(K*lt),this.setViewport(0,0,w,K)},this.getCurrentViewport=function(w){return w.copy(G)},this.getViewport=function(w){return w.copy(Ht)},this.setViewport=function(w,K,lt,ut){w.isVector4?Ht.set(w.x,w.y,w.z,w.w):Ht.set(w,K,lt,ut),Ot.viewport(G.copy(Ht).multiplyScalar(j).round())},this.getScissor=function(w){return w.copy(oe)},this.setScissor=function(w,K,lt,ut){w.isVector4?oe.set(w.x,w.y,w.z,w.w):oe.set(w,K,lt,ut),Ot.scissor(Z.copy(oe).multiplyScalar(j).round())},this.getScissorTest=function(){return xe},this.setScissorTest=function(w){Ot.setScissorTest(xe=w)},this.setOpaqueSort=function(w){xt=w},this.setTransparentSort=function(w){Mt=w},this.getClearColor=function(w){return w.copy($t.getClearColor())},this.setClearColor=function(){$t.setClearColor(...arguments)},this.getClearAlpha=function(){return $t.getClearAlpha()},this.setClearAlpha=function(){$t.setClearAlpha(...arguments)},this.clear=function(w=!0,K=!0,lt=!0){let ut=0;if(w){let Q=!1;if(B!==null){const At=B.texture.format;Q=At===_m||At===gm||At===mm}if(Q){const At=B.texture.type,Bt=At===ea||At===$r||At===Sl||At===Ml||At===dm||At===pm,Vt=$t.getClearColor(),Nt=$t.getClearAlpha(),Wt=Vt.r,ae=Vt.g,ee=Vt.b;Bt?(E[0]=Wt,E[1]=ae,E[2]=ee,E[3]=Nt,F.clearBufferuiv(F.COLOR,0,E)):(b[0]=Wt,b[1]=ae,b[2]=ee,b[3]=Nt,F.clearBufferiv(F.COLOR,0,b))}else ut|=F.COLOR_BUFFER_BIT}K&&(ut|=F.DEPTH_BUFFER_BIT),lt&&(ut|=F.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),F.clear(ut)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){i.removeEventListener("webglcontextlost",Lt,!1),i.removeEventListener("webglcontextrestored",qt,!1),i.removeEventListener("webglcontextcreationerror",bt,!1),$t.dispose(),ht.dispose(),Yt.dispose(),vt.dispose(),le.dispose(),Me.dispose(),rt.dispose(),It.dispose(),he.dispose(),mt.dispose(),wt.dispose(),wt.removeEventListener("sessionstart",gn),wt.removeEventListener("sessionend",Ln),ia.stop()};function Lt(w){w.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),I=!0}function qt(){console.log("THREE.WebGLRenderer: Context Restored."),I=!1;const w=ie.autoReset,K=Kt.enabled,lt=Kt.autoUpdate,ut=Kt.needsUpdate,Q=Kt.type;X(),ie.autoReset=w,Kt.enabled=K,Kt.autoUpdate=lt,Kt.needsUpdate=ut,Kt.type=Q}function bt(w){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function yt(w){const K=w.target;K.removeEventListener("dispose",yt),Zt(K)}function Zt(w){fe(w),vt.remove(w)}function fe(w){const K=vt.get(w).programs;K!==void 0&&(K.forEach(function(lt){mt.releaseProgram(lt)}),w.isShaderMaterial&&mt.releaseShaderCache(w))}this.renderBufferDirect=function(w,K,lt,ut,Q,At){K===null&&(K=Rt);const Bt=Q.isMesh&&Q.matrixWorld.determinant()<0,Vt=Pl(w,K,lt,ut,Q);Ot.setMaterial(ut,Bt);let Nt=lt.index,Wt=1;if(ut.wireframe===!0){if(Nt=A.getWireframeAttribute(lt),Nt===void 0)return;Wt=2}const ae=lt.drawRange,ee=lt.attributes.position;let ye=ae.start*Wt,Fe=(ae.start+ae.count)*Wt;At!==null&&(ye=Math.max(ye,At.start*Wt),Fe=Math.min(Fe,(At.start+At.count)*Wt)),Nt!==null?(ye=Math.max(ye,0),Fe=Math.min(Fe,Nt.count)):ee!=null&&(ye=Math.max(ye,0),Fe=Math.min(Fe,ee.count));const Je=Fe-ye;if(Je<0||Je===1/0)return;It.setup(Q,ut,Vt,lt,Nt);let ze,Ue=zt;if(Nt!==null&&(ze=O.get(Nt),Ue=se,Ue.setIndex(ze)),Q.isMesh)ut.wireframe===!0?(Ot.setLineWidth(ut.wireframeLinewidth*kt()),Ue.setMode(F.LINES)):Ue.setMode(F.TRIANGLES);else if(Q.isLine){let ne=ut.linewidth;ne===void 0&&(ne=1),Ot.setLineWidth(ne*kt()),Q.isLineSegments?Ue.setMode(F.LINES):Q.isLineLoop?Ue.setMode(F.LINE_LOOP):Ue.setMode(F.LINE_STRIP)}else Q.isPoints?Ue.setMode(F.POINTS):Q.isSprite&&Ue.setMode(F.TRIANGLES);if(Q.isBatchedMesh)if(Q._multiDrawInstances!==null)bl("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),Ue.renderMultiDrawInstances(Q._multiDrawStarts,Q._multiDrawCounts,Q._multiDrawCount,Q._multiDrawInstances);else if(re.get("WEBGL_multi_draw"))Ue.renderMultiDraw(Q._multiDrawStarts,Q._multiDrawCounts,Q._multiDrawCount);else{const ne=Q._multiDrawStarts,Ie=Q._multiDrawCounts,_e=Q._multiDrawCount,_n=Nt?O.get(Nt).bytesPerElement:1,$n=vt.get(ut).currentProgram.getUniforms();for(let Ne=0;Ne<_e;Ne++)$n.setValue(F,"_gl_DrawID",Ne),Ue.render(ne[Ne]/_n,Ie[Ne])}else if(Q.isInstancedMesh)Ue.renderInstances(ye,Je,Q.count);else if(lt.isInstancedBufferGeometry){const ne=lt._maxInstanceCount!==void 0?lt._maxInstanceCount:1/0,Ie=Math.min(lt.instanceCount,ne);Ue.renderInstances(ye,Je,Ie)}else Ue.render(ye,Je)};function ke(w,K,lt){w.transparent===!0&&w.side===ba&&w.forceSinglePass===!1?(w.side=Qn,w.needsUpdate=!0,fi(w,K,lt),w.side=mr,w.needsUpdate=!0,fi(w,K,lt),w.side=ba):fi(w,K,lt)}this.compile=function(w,K,lt=null){lt===null&&(lt=w),S=Yt.get(lt),S.init(K),N.push(S),lt.traverseVisible(function(Q){Q.isLight&&Q.layers.test(K.layers)&&(S.pushLight(Q),Q.castShadow&&S.pushShadow(Q))}),w!==lt&&w.traverseVisible(function(Q){Q.isLight&&Q.layers.test(K.layers)&&(S.pushLight(Q),Q.castShadow&&S.pushShadow(Q))}),S.setupLights();const ut=new Set;return w.traverse(function(Q){if(!(Q.isMesh||Q.isPoints||Q.isLine||Q.isSprite))return;const At=Q.material;if(At)if(Array.isArray(At))for(let Bt=0;Bt<At.length;Bt++){const Vt=At[Bt];ke(Vt,lt,Q),ut.add(Vt)}else ke(At,lt,Q),ut.add(At)}),S=N.pop(),ut},this.compileAsync=function(w,K,lt=null){const ut=this.compile(w,K,lt);return new Promise(Q=>{function At(){if(ut.forEach(function(Bt){vt.get(Bt).currentProgram.isReady()&&ut.delete(Bt)}),ut.size===0){Q(w);return}setTimeout(At,10)}re.get("KHR_parallel_shader_compile")!==null?At():setTimeout(At,10)})};let Ae=null;function tn(w){Ae&&Ae(w)}function gn(){ia.stop()}function Ln(){ia.start()}const ia=new Jy;ia.setAnimationLoop(tn),typeof self<"u"&&ia.setContext(self),this.setAnimationLoop=function(w){Ae=w,wt.setAnimationLoop(w),w===null?ia.stop():ia.start()},wt.addEventListener("sessionstart",gn),wt.addEventListener("sessionend",Ln),this.render=function(w,K){if(K!==void 0&&K.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(I===!0)return;if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),K.parent===null&&K.matrixWorldAutoUpdate===!0&&K.updateMatrixWorld(),wt.enabled===!0&&wt.isPresenting===!0&&(wt.cameraAutoUpdate===!0&&wt.updateCamera(K),K=wt.getCamera()),w.isScene===!0&&w.onBeforeRender(D,w,K,B),S=Yt.get(w,N.length),S.init(K),N.push(S),at.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),H.setFromProjectionMatrix(at,$i,K.reversedDepth),$=this.localClippingEnabled,ft=Dt.init(this.clippingPlanes,$),y=ht.get(w,U.length),y.init(),U.push(y),wt.enabled===!0&&wt.isPresenting===!0){const At=D.xr.getDepthSensingMesh();At!==null&&yo(At,K,-1/0,D.sortObjects)}yo(w,K,0,D.sortObjects),y.finish(),D.sortObjects===!0&&y.sort(xt,Mt),St=wt.enabled===!1||wt.isPresenting===!1||wt.hasDepthSensing()===!1,St&&$t.addToRenderList(y,w),this.info.render.frame++,ft===!0&&Dt.beginShadows();const lt=S.state.shadowsArray;Kt.render(lt,w,K),ft===!0&&Dt.endShadows(),this.info.autoReset===!0&&this.info.reset();const ut=y.opaque,Q=y.transmissive;if(S.setupLights(),K.isArrayCamera){const At=K.cameras;if(Q.length>0)for(let Bt=0,Vt=At.length;Bt<Vt;Bt++){const Nt=At[Bt];_r(ut,Q,w,Nt)}St&&$t.render(w);for(let Bt=0,Vt=At.length;Bt<Vt;Bt++){const Nt=At[Bt];Ol(y,w,Nt,Nt.viewport)}}else Q.length>0&&_r(ut,Q,w,K),St&&$t.render(w),Ol(y,w,K);B!==null&&L===0&&(Gt.updateMultisampleRenderTarget(B),Gt.updateRenderTargetMipmap(B)),w.isScene===!0&&w.onAfterRender(D,w,K),It.resetDefaultState(),C=-1,R=null,N.pop(),N.length>0?(S=N[N.length-1],ft===!0&&Dt.setGlobalState(D.clippingPlanes,S.state.camera)):S=null,U.pop(),U.length>0?y=U[U.length-1]:y=null};function yo(w,K,lt,ut){if(w.visible===!1)return;if(w.layers.test(K.layers)){if(w.isGroup)lt=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(K);else if(w.isLight)S.pushLight(w),w.castShadow&&S.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||H.intersectsSprite(w)){ut&&Ut.setFromMatrixPosition(w.matrixWorld).applyMatrix4(at);const Bt=rt.update(w),Vt=w.material;Vt.visible&&y.push(w,Bt,Vt,lt,Ut.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||H.intersectsObject(w))){const Bt=rt.update(w),Vt=w.material;if(ut&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),Ut.copy(w.boundingSphere.center)):(Bt.boundingSphere===null&&Bt.computeBoundingSphere(),Ut.copy(Bt.boundingSphere.center)),Ut.applyMatrix4(w.matrixWorld).applyMatrix4(at)),Array.isArray(Vt)){const Nt=Bt.groups;for(let Wt=0,ae=Nt.length;Wt<ae;Wt++){const ee=Nt[Wt],ye=Vt[ee.materialIndex];ye&&ye.visible&&y.push(w,Bt,ye,lt,Ut.z,ee)}}else Vt.visible&&y.push(w,Bt,Vt,lt,Ut.z,null)}}const At=w.children;for(let Bt=0,Vt=At.length;Bt<Vt;Bt++)yo(At[Bt],K,lt,ut)}function Ol(w,K,lt,ut){const Q=w.opaque,At=w.transmissive,Bt=w.transparent;S.setupLightsView(lt),ft===!0&&Dt.setGlobalState(D.clippingPlanes,lt),ut&&Ot.viewport(G.copy(ut)),Q.length>0&&aa(Q,K,lt),At.length>0&&aa(At,K,lt),Bt.length>0&&aa(Bt,K,lt),Ot.buffers.depth.setTest(!0),Ot.buffers.depth.setMask(!0),Ot.buffers.color.setMask(!0),Ot.setPolygonOffset(!1)}function _r(w,K,lt,ut){if((lt.isScene===!0?lt.overrideMaterial:null)!==null)return;S.state.transmissionRenderTarget[ut.id]===void 0&&(S.state.transmissionRenderTarget[ut.id]=new ts(1,1,{generateMipmaps:!0,type:re.has("EXT_color_buffer_half_float")||re.has("EXT_color_buffer_float")?wl:ea,minFilter:Jr,samples:4,stencilBuffer:c,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Oe.workingColorSpace}));const At=S.state.transmissionRenderTarget[ut.id],Bt=ut.viewport||G;At.setSize(Bt.z*D.transmissionResolutionScale,Bt.w*D.transmissionResolutionScale);const Vt=D.getRenderTarget(),Nt=D.getActiveCubeFace(),Wt=D.getActiveMipmapLevel();D.setRenderTarget(At),D.getClearColor(ct),st=D.getClearAlpha(),st<1&&D.setClearColor(16777215,.5),D.clear(),St&&$t.render(lt);const ae=D.toneMapping;D.toneMapping=pr;const ee=ut.viewport;if(ut.viewport!==void 0&&(ut.viewport=void 0),S.setupLightsView(ut),ft===!0&&Dt.setGlobalState(D.clippingPlanes,ut),aa(w,lt,ut),Gt.updateMultisampleRenderTarget(At),Gt.updateRenderTargetMipmap(At),re.has("WEBGL_multisampled_render_to_texture")===!1){let ye=!1;for(let Fe=0,Je=K.length;Fe<Je;Fe++){const ze=K[Fe],Ue=ze.object,ne=ze.geometry,Ie=ze.material,_e=ze.group;if(Ie.side===ba&&Ue.layers.test(ut.layers)){const _n=Ie.side;Ie.side=Qn,Ie.needsUpdate=!0,vr(Ue,lt,ut,ne,Ie,_e),Ie.side=_n,Ie.needsUpdate=!0,ye=!0}}ye===!0&&(Gt.updateMultisampleRenderTarget(At),Gt.updateRenderTargetMipmap(At))}D.setRenderTarget(Vt,Nt,Wt),D.setClearColor(ct,st),ee!==void 0&&(ut.viewport=ee),D.toneMapping=ae}function aa(w,K,lt){const ut=K.isScene===!0?K.overrideMaterial:null;for(let Q=0,At=w.length;Q<At;Q++){const Bt=w[Q],Vt=Bt.object,Nt=Bt.geometry,Wt=Bt.group;let ae=Bt.material;ae.allowOverride===!0&&ut!==null&&(ae=ut),Vt.layers.test(lt.layers)&&vr(Vt,K,lt,Nt,ae,Wt)}}function vr(w,K,lt,ut,Q,At){w.onBeforeRender(D,K,lt,ut,Q,At),w.modelViewMatrix.multiplyMatrices(lt.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),Q.onBeforeRender(D,K,lt,ut,w,At),Q.transparent===!0&&Q.side===ba&&Q.forceSinglePass===!1?(Q.side=Qn,Q.needsUpdate=!0,D.renderBufferDirect(lt,K,ut,Q,w,At),Q.side=mr,Q.needsUpdate=!0,D.renderBufferDirect(lt,K,ut,Q,w,At),Q.side=ba):D.renderBufferDirect(lt,K,ut,Q,w,At),w.onAfterRender(D,K,lt,ut,Q,At)}function fi(w,K,lt){K.isScene!==!0&&(K=Rt);const ut=vt.get(w),Q=S.state.lights,At=S.state.shadowsArray,Bt=Q.state.version,Vt=mt.getParameters(w,Q.state,At,K,lt),Nt=mt.getProgramCacheKey(Vt);let Wt=ut.programs;ut.environment=w.isMeshStandardMaterial?K.environment:null,ut.fog=K.fog,ut.envMap=(w.isMeshStandardMaterial?Me:le).get(w.envMap||ut.environment),ut.envMapRotation=ut.environment!==null&&w.envMap===null?K.environmentRotation:w.envMapRotation,Wt===void 0&&(w.addEventListener("dispose",yt),Wt=new Map,ut.programs=Wt);let ae=Wt.get(Nt);if(ae!==void 0){if(ut.currentProgram===ae&&ut.lightsStateVersion===Bt)return Ua(w,Vt),ae}else Vt.uniforms=mt.getUniforms(w),w.onBeforeCompile(Vt,D),ae=mt.acquireProgram(Vt,Nt),Wt.set(Nt,ae),ut.uniforms=Vt.uniforms;const ee=ut.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(ee.clippingPlanes=Dt.uniform),Ua(w,Vt),ut.needsLights=zl(w),ut.lightsStateVersion=Bt,ut.needsLights&&(ee.ambientLightColor.value=Q.state.ambient,ee.lightProbe.value=Q.state.probe,ee.directionalLights.value=Q.state.directional,ee.directionalLightShadows.value=Q.state.directionalShadow,ee.spotLights.value=Q.state.spot,ee.spotLightShadows.value=Q.state.spotShadow,ee.rectAreaLights.value=Q.state.rectArea,ee.ltc_1.value=Q.state.rectAreaLTC1,ee.ltc_2.value=Q.state.rectAreaLTC2,ee.pointLights.value=Q.state.point,ee.pointLightShadows.value=Q.state.pointShadow,ee.hemisphereLights.value=Q.state.hemi,ee.directionalShadowMap.value=Q.state.directionalShadowMap,ee.directionalShadowMatrix.value=Q.state.directionalShadowMatrix,ee.spotShadowMap.value=Q.state.spotShadowMap,ee.spotLightMatrix.value=Q.state.spotLightMatrix,ee.spotLightMap.value=Q.state.spotLightMap,ee.pointShadowMap.value=Q.state.pointShadowMap,ee.pointShadowMatrix.value=Q.state.pointShadowMatrix),ut.currentProgram=ae,ut.uniformsList=null,ae}function xr(w){if(w.uniformsList===null){const K=w.currentProgram.getUniforms();w.uniformsList=Lc.seqWithValue(K.seq,w.uniforms)}return w.uniformsList}function Ua(w,K){const lt=vt.get(w);lt.outputColorSpace=K.outputColorSpace,lt.batching=K.batching,lt.batchingColor=K.batchingColor,lt.instancing=K.instancing,lt.instancingColor=K.instancingColor,lt.instancingMorph=K.instancingMorph,lt.skinning=K.skinning,lt.morphTargets=K.morphTargets,lt.morphNormals=K.morphNormals,lt.morphColors=K.morphColors,lt.morphTargetsCount=K.morphTargetsCount,lt.numClippingPlanes=K.numClippingPlanes,lt.numIntersection=K.numClipIntersection,lt.vertexAlphas=K.vertexAlphas,lt.vertexTangents=K.vertexTangents,lt.toneMapping=K.toneMapping}function Pl(w,K,lt,ut,Q){K.isScene!==!0&&(K=Rt),Gt.resetTextureUnits();const At=K.fog,Bt=ut.isMeshStandardMaterial?K.environment:null,Vt=B===null?D.outputColorSpace:B.isXRRenderTarget===!0?B.texture.colorSpace:ho,Nt=(ut.isMeshStandardMaterial?Me:le).get(ut.envMap||Bt),Wt=ut.vertexColors===!0&&!!lt.attributes.color&&lt.attributes.color.itemSize===4,ae=!!lt.attributes.tangent&&(!!ut.normalMap||ut.anisotropy>0),ee=!!lt.morphAttributes.position,ye=!!lt.morphAttributes.normal,Fe=!!lt.morphAttributes.color;let Je=pr;ut.toneMapped&&(B===null||B.isXRRenderTarget===!0)&&(Je=D.toneMapping);const ze=lt.morphAttributes.position||lt.morphAttributes.normal||lt.morphAttributes.color,Ue=ze!==void 0?ze.length:0,ne=vt.get(ut),Ie=S.state.lights;if(ft===!0&&($===!0||w!==R)){const rn=w===R&&ut.id===C;Dt.setState(ut,w,rn)}let _e=!1;ut.version===ne.__version?(ne.needsLights&&ne.lightsStateVersion!==Ie.state.version||ne.outputColorSpace!==Vt||Q.isBatchedMesh&&ne.batching===!1||!Q.isBatchedMesh&&ne.batching===!0||Q.isBatchedMesh&&ne.batchingColor===!0&&Q.colorTexture===null||Q.isBatchedMesh&&ne.batchingColor===!1&&Q.colorTexture!==null||Q.isInstancedMesh&&ne.instancing===!1||!Q.isInstancedMesh&&ne.instancing===!0||Q.isSkinnedMesh&&ne.skinning===!1||!Q.isSkinnedMesh&&ne.skinning===!0||Q.isInstancedMesh&&ne.instancingColor===!0&&Q.instanceColor===null||Q.isInstancedMesh&&ne.instancingColor===!1&&Q.instanceColor!==null||Q.isInstancedMesh&&ne.instancingMorph===!0&&Q.morphTexture===null||Q.isInstancedMesh&&ne.instancingMorph===!1&&Q.morphTexture!==null||ne.envMap!==Nt||ut.fog===!0&&ne.fog!==At||ne.numClippingPlanes!==void 0&&(ne.numClippingPlanes!==Dt.numPlanes||ne.numIntersection!==Dt.numIntersection)||ne.vertexAlphas!==Wt||ne.vertexTangents!==ae||ne.morphTargets!==ee||ne.morphNormals!==ye||ne.morphColors!==Fe||ne.toneMapping!==Je||ne.morphTargetsCount!==Ue)&&(_e=!0):(_e=!0,ne.__version=ut.version);let _n=ne.currentProgram;_e===!0&&(_n=fi(ut,K,Q));let $n=!1,Ne=!1,Na=!1;const Ze=_n.getUniforms(),Fn=ne.uniforms;if(Ot.useProgram(_n.program)&&($n=!0,Ne=!0,Na=!0),ut.id!==C&&(C=ut.id,Ne=!0),$n||R!==w){Ot.buffers.depth.getReversed()&&w.reversedDepth!==!0&&(w._reversedDepth=!0,w.updateProjectionMatrix()),Ze.setValue(F,"projectionMatrix",w.projectionMatrix),Ze.setValue(F,"viewMatrix",w.matrixWorldInverse);const On=Ze.map.cameraPosition;On!==void 0&&On.setValue(F,Et.setFromMatrixPosition(w.matrixWorld)),Qt.logarithmicDepthBuffer&&Ze.setValue(F,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(ut.isMeshPhongMaterial||ut.isMeshToonMaterial||ut.isMeshLambertMaterial||ut.isMeshBasicMaterial||ut.isMeshStandardMaterial||ut.isShaderMaterial)&&Ze.setValue(F,"isOrthographic",w.isOrthographicCamera===!0),R!==w&&(R=w,Ne=!0,Na=!0)}if(Q.isSkinnedMesh){Ze.setOptional(F,Q,"bindMatrix"),Ze.setOptional(F,Q,"bindMatrixInverse");const rn=Q.skeleton;rn&&(rn.boneTexture===null&&rn.computeBoneTexture(),Ze.setValue(F,"boneTexture",rn.boneTexture,Gt))}Q.isBatchedMesh&&(Ze.setOptional(F,Q,"batchingTexture"),Ze.setValue(F,"batchingTexture",Q._matricesTexture,Gt),Ze.setOptional(F,Q,"batchingIdTexture"),Ze.setValue(F,"batchingIdTexture",Q._indirectTexture,Gt),Ze.setOptional(F,Q,"batchingColorTexture"),Q._colorsTexture!==null&&Ze.setValue(F,"batchingColorTexture",Q._colorsTexture,Gt));const un=lt.morphAttributes;if((un.position!==void 0||un.normal!==void 0||un.color!==void 0)&&Ct.update(Q,lt,_n),(Ne||ne.receiveShadow!==Q.receiveShadow)&&(ne.receiveShadow=Q.receiveShadow,Ze.setValue(F,"receiveShadow",Q.receiveShadow)),ut.isMeshGouraudMaterial&&ut.envMap!==null&&(Fn.envMap.value=Nt,Fn.flipEnvMap.value=Nt.isCubeTexture&&Nt.isRenderTargetTexture===!1?-1:1),ut.isMeshStandardMaterial&&ut.envMap===null&&K.environment!==null&&(Fn.envMapIntensity.value=K.environmentIntensity),Ne&&(Ze.setValue(F,"toneMappingExposure",D.toneMappingExposure),ne.needsLights&&Yc(Fn,Na),At&&ut.fog===!0&&Tt.refreshFogUniforms(Fn,At),Tt.refreshMaterialUniforms(Fn,ut,j,it,S.state.transmissionRenderTarget[w.id]),Lc.upload(F,xr(ne),Fn,Gt)),ut.isShaderMaterial&&ut.uniformsNeedUpdate===!0&&(Lc.upload(F,xr(ne),Fn,Gt),ut.uniformsNeedUpdate=!1),ut.isSpriteMaterial&&Ze.setValue(F,"center",Q.center),Ze.setValue(F,"modelViewMatrix",Q.modelViewMatrix),Ze.setValue(F,"normalMatrix",Q.normalMatrix),Ze.setValue(F,"modelMatrix",Q.matrixWorld),ut.isShaderMaterial||ut.isRawShaderMaterial){const rn=ut.uniformsGroups;for(let On=0,es=rn.length;On<es;On++){const Fi=rn[On];he.update(Fi,_n),he.bind(Fi,_n)}}return _n}function Yc(w,K){w.ambientLightColor.needsUpdate=K,w.lightProbe.needsUpdate=K,w.directionalLights.needsUpdate=K,w.directionalLightShadows.needsUpdate=K,w.pointLights.needsUpdate=K,w.pointLightShadows.needsUpdate=K,w.spotLights.needsUpdate=K,w.spotLightShadows.needsUpdate=K,w.rectAreaLights.needsUpdate=K,w.hemisphereLights.needsUpdate=K}function zl(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return z},this.getActiveMipmapLevel=function(){return L},this.getRenderTarget=function(){return B},this.setRenderTargetTextures=function(w,K,lt){const ut=vt.get(w);ut.__autoAllocateDepthBuffer=w.resolveDepthBuffer===!1,ut.__autoAllocateDepthBuffer===!1&&(ut.__useRenderToTexture=!1),vt.get(w.texture).__webglTexture=K,vt.get(w.depthTexture).__webglTexture=ut.__autoAllocateDepthBuffer?void 0:lt,ut.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(w,K){const lt=vt.get(w);lt.__webglFramebuffer=K,lt.__useDefaultFramebuffer=K===void 0};const So=F.createFramebuffer();this.setRenderTarget=function(w,K=0,lt=0){B=w,z=K,L=lt;let ut=!0,Q=null,At=!1,Bt=!1;if(w){const Nt=vt.get(w);if(Nt.__useDefaultFramebuffer!==void 0)Ot.bindFramebuffer(F.FRAMEBUFFER,null),ut=!1;else if(Nt.__webglFramebuffer===void 0)Gt.setupRenderTarget(w);else if(Nt.__hasExternalTextures)Gt.rebindTextures(w,vt.get(w.texture).__webglTexture,vt.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const ee=w.depthTexture;if(Nt.__boundDepthTexture!==ee){if(ee!==null&&vt.has(ee)&&(w.width!==ee.image.width||w.height!==ee.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");Gt.setupDepthRenderbuffer(w)}}const Wt=w.texture;(Wt.isData3DTexture||Wt.isDataArrayTexture||Wt.isCompressedArrayTexture)&&(Bt=!0);const ae=vt.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(ae[K])?Q=ae[K][lt]:Q=ae[K],At=!0):w.samples>0&&Gt.useMultisampledRTT(w)===!1?Q=vt.get(w).__webglMultisampledFramebuffer:Array.isArray(ae)?Q=ae[lt]:Q=ae,G.copy(w.viewport),Z.copy(w.scissor),et=w.scissorTest}else G.copy(Ht).multiplyScalar(j).floor(),Z.copy(oe).multiplyScalar(j).floor(),et=xe;if(lt!==0&&(Q=So),Ot.bindFramebuffer(F.FRAMEBUFFER,Q)&&ut&&Ot.drawBuffers(w,Q),Ot.viewport(G),Ot.scissor(Z),Ot.setScissorTest(et),At){const Nt=vt.get(w.texture);F.framebufferTexture2D(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_CUBE_MAP_POSITIVE_X+K,Nt.__webglTexture,lt)}else if(Bt){const Nt=K;for(let Wt=0;Wt<w.textures.length;Wt++){const ae=vt.get(w.textures[Wt]);F.framebufferTextureLayer(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0+Wt,ae.__webglTexture,lt,Nt)}}else if(w!==null&&lt!==0){const Nt=vt.get(w.texture);F.framebufferTexture2D(F.FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_2D,Nt.__webglTexture,lt)}C=-1},this.readRenderTargetPixels=function(w,K,lt,ut,Q,At,Bt,Vt=0){if(!(w&&w.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Nt=vt.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&Bt!==void 0&&(Nt=Nt[Bt]),Nt){Ot.bindFramebuffer(F.FRAMEBUFFER,Nt);try{const Wt=w.textures[Vt],ae=Wt.format,ee=Wt.type;if(!Qt.textureFormatReadable(ae)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Qt.textureTypeReadable(ee)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}K>=0&&K<=w.width-ut&&lt>=0&&lt<=w.height-Q&&(w.textures.length>1&&F.readBuffer(F.COLOR_ATTACHMENT0+Vt),F.readPixels(K,lt,ut,Q,Jt.convert(ae),Jt.convert(ee),At))}finally{const Wt=B!==null?vt.get(B).__webglFramebuffer:null;Ot.bindFramebuffer(F.FRAMEBUFFER,Wt)}}},this.readRenderTargetPixelsAsync=async function(w,K,lt,ut,Q,At,Bt,Vt=0){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Nt=vt.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&Bt!==void 0&&(Nt=Nt[Bt]),Nt)if(K>=0&&K<=w.width-ut&&lt>=0&&lt<=w.height-Q){Ot.bindFramebuffer(F.FRAMEBUFFER,Nt);const Wt=w.textures[Vt],ae=Wt.format,ee=Wt.type;if(!Qt.textureFormatReadable(ae))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Qt.textureTypeReadable(ee))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const ye=F.createBuffer();F.bindBuffer(F.PIXEL_PACK_BUFFER,ye),F.bufferData(F.PIXEL_PACK_BUFFER,At.byteLength,F.STREAM_READ),w.textures.length>1&&F.readBuffer(F.COLOR_ATTACHMENT0+Vt),F.readPixels(K,lt,ut,Q,Jt.convert(ae),Jt.convert(ee),0);const Fe=B!==null?vt.get(B).__webglFramebuffer:null;Ot.bindFramebuffer(F.FRAMEBUFFER,Fe);const Je=F.fenceSync(F.SYNC_GPU_COMMANDS_COMPLETE,0);return F.flush(),await _1(F,Je,4),F.bindBuffer(F.PIXEL_PACK_BUFFER,ye),F.getBufferSubData(F.PIXEL_PACK_BUFFER,0,At),F.deleteBuffer(ye),F.deleteSync(Je),At}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(w,K=null,lt=0){const ut=Math.pow(2,-lt),Q=Math.floor(w.image.width*ut),At=Math.floor(w.image.height*ut),Bt=K!==null?K.x:0,Vt=K!==null?K.y:0;Gt.setTexture2D(w,0),F.copyTexSubImage2D(F.TEXTURE_2D,lt,0,0,Bt,Vt,Q,At),Ot.unbindTexture()};const yr=F.createFramebuffer(),Wc=F.createFramebuffer();this.copyTextureToTexture=function(w,K,lt=null,ut=null,Q=0,At=null){At===null&&(Q!==0?(bl("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),At=Q,Q=0):At=0);let Bt,Vt,Nt,Wt,ae,ee,ye,Fe,Je;const ze=w.isCompressedTexture?w.mipmaps[At]:w.image;if(lt!==null)Bt=lt.max.x-lt.min.x,Vt=lt.max.y-lt.min.y,Nt=lt.isBox3?lt.max.z-lt.min.z:1,Wt=lt.min.x,ae=lt.min.y,ee=lt.isBox3?lt.min.z:0;else{const un=Math.pow(2,-Q);Bt=Math.floor(ze.width*un),Vt=Math.floor(ze.height*un),w.isDataArrayTexture?Nt=ze.depth:w.isData3DTexture?Nt=Math.floor(ze.depth*un):Nt=1,Wt=0,ae=0,ee=0}ut!==null?(ye=ut.x,Fe=ut.y,Je=ut.z):(ye=0,Fe=0,Je=0);const Ue=Jt.convert(K.format),ne=Jt.convert(K.type);let Ie;K.isData3DTexture?(Gt.setTexture3D(K,0),Ie=F.TEXTURE_3D):K.isDataArrayTexture||K.isCompressedArrayTexture?(Gt.setTexture2DArray(K,0),Ie=F.TEXTURE_2D_ARRAY):(Gt.setTexture2D(K,0),Ie=F.TEXTURE_2D),F.pixelStorei(F.UNPACK_FLIP_Y_WEBGL,K.flipY),F.pixelStorei(F.UNPACK_PREMULTIPLY_ALPHA_WEBGL,K.premultiplyAlpha),F.pixelStorei(F.UNPACK_ALIGNMENT,K.unpackAlignment);const _e=F.getParameter(F.UNPACK_ROW_LENGTH),_n=F.getParameter(F.UNPACK_IMAGE_HEIGHT),$n=F.getParameter(F.UNPACK_SKIP_PIXELS),Ne=F.getParameter(F.UNPACK_SKIP_ROWS),Na=F.getParameter(F.UNPACK_SKIP_IMAGES);F.pixelStorei(F.UNPACK_ROW_LENGTH,ze.width),F.pixelStorei(F.UNPACK_IMAGE_HEIGHT,ze.height),F.pixelStorei(F.UNPACK_SKIP_PIXELS,Wt),F.pixelStorei(F.UNPACK_SKIP_ROWS,ae),F.pixelStorei(F.UNPACK_SKIP_IMAGES,ee);const Ze=w.isDataArrayTexture||w.isData3DTexture,Fn=K.isDataArrayTexture||K.isData3DTexture;if(w.isDepthTexture){const un=vt.get(w),rn=vt.get(K),On=vt.get(un.__renderTarget),es=vt.get(rn.__renderTarget);Ot.bindFramebuffer(F.READ_FRAMEBUFFER,On.__webglFramebuffer),Ot.bindFramebuffer(F.DRAW_FRAMEBUFFER,es.__webglFramebuffer);for(let Fi=0;Fi<Nt;Fi++)Ze&&(F.framebufferTextureLayer(F.READ_FRAMEBUFFER,F.COLOR_ATTACHMENT0,vt.get(w).__webglTexture,Q,ee+Fi),F.framebufferTextureLayer(F.DRAW_FRAMEBUFFER,F.COLOR_ATTACHMENT0,vt.get(K).__webglTexture,At,Je+Fi)),F.blitFramebuffer(Wt,ae,Bt,Vt,ye,Fe,Bt,Vt,F.DEPTH_BUFFER_BIT,F.NEAREST);Ot.bindFramebuffer(F.READ_FRAMEBUFFER,null),Ot.bindFramebuffer(F.DRAW_FRAMEBUFFER,null)}else if(Q!==0||w.isRenderTargetTexture||vt.has(w)){const un=vt.get(w),rn=vt.get(K);Ot.bindFramebuffer(F.READ_FRAMEBUFFER,yr),Ot.bindFramebuffer(F.DRAW_FRAMEBUFFER,Wc);for(let On=0;On<Nt;On++)Ze?F.framebufferTextureLayer(F.READ_FRAMEBUFFER,F.COLOR_ATTACHMENT0,un.__webglTexture,Q,ee+On):F.framebufferTexture2D(F.READ_FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_2D,un.__webglTexture,Q),Fn?F.framebufferTextureLayer(F.DRAW_FRAMEBUFFER,F.COLOR_ATTACHMENT0,rn.__webglTexture,At,Je+On):F.framebufferTexture2D(F.DRAW_FRAMEBUFFER,F.COLOR_ATTACHMENT0,F.TEXTURE_2D,rn.__webglTexture,At),Q!==0?F.blitFramebuffer(Wt,ae,Bt,Vt,ye,Fe,Bt,Vt,F.COLOR_BUFFER_BIT,F.NEAREST):Fn?F.copyTexSubImage3D(Ie,At,ye,Fe,Je+On,Wt,ae,Bt,Vt):F.copyTexSubImage2D(Ie,At,ye,Fe,Wt,ae,Bt,Vt);Ot.bindFramebuffer(F.READ_FRAMEBUFFER,null),Ot.bindFramebuffer(F.DRAW_FRAMEBUFFER,null)}else Fn?w.isDataTexture||w.isData3DTexture?F.texSubImage3D(Ie,At,ye,Fe,Je,Bt,Vt,Nt,Ue,ne,ze.data):K.isCompressedArrayTexture?F.compressedTexSubImage3D(Ie,At,ye,Fe,Je,Bt,Vt,Nt,Ue,ze.data):F.texSubImage3D(Ie,At,ye,Fe,Je,Bt,Vt,Nt,Ue,ne,ze):w.isDataTexture?F.texSubImage2D(F.TEXTURE_2D,At,ye,Fe,Bt,Vt,Ue,ne,ze.data):w.isCompressedTexture?F.compressedTexSubImage2D(F.TEXTURE_2D,At,ye,Fe,ze.width,ze.height,Ue,ze.data):F.texSubImage2D(F.TEXTURE_2D,At,ye,Fe,Bt,Vt,Ue,ne,ze);F.pixelStorei(F.UNPACK_ROW_LENGTH,_e),F.pixelStorei(F.UNPACK_IMAGE_HEIGHT,_n),F.pixelStorei(F.UNPACK_SKIP_PIXELS,$n),F.pixelStorei(F.UNPACK_SKIP_ROWS,Ne),F.pixelStorei(F.UNPACK_SKIP_IMAGES,Na),At===0&&K.generateMipmaps&&F.generateMipmap(Ie),Ot.unbindTexture()},this.initRenderTarget=function(w){vt.get(w).__webglFramebuffer===void 0&&Gt.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?Gt.setTextureCube(w,0):w.isData3DTexture?Gt.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?Gt.setTexture2DArray(w,0):Gt.setTexture2D(w,0),Ot.unbindTexture()},this.resetState=function(){z=0,L=0,B=null,Ot.reset(),It.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return $i}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const i=this.getContext();i.drawingBufferColorSpace=Oe._getDrawingBufferColorSpace(e),i.unpackColorSpace=Oe._getUnpackColorSpace()}}const iS="game.muted";function B2(){try{return localStorage.getItem(iS)==="1"}catch{return!1}}function F2(o){try{localStorage.setItem(iS,o?"1":"0")}catch{}}class H2{ctx=null;master=null;musicOsc=null;disposed=!1;muted=!1;unlock=()=>{this.ensureCtx(),this.detachUnlock()};constructor(){this.muted=B2(),window.addEventListener("pointerdown",this.unlock),window.addEventListener("keydown",this.unlock)}detachUnlock(){window.removeEventListener("pointerdown",this.unlock),window.removeEventListener("keydown",this.unlock)}dispose(){if(this.disposed)return;this.disposed=!0,this.detachUnlock(),this.stopMusic(),this.master?.disconnect(),this.master=null;const e=this.ctx;this.ctx=null,e&&e.state!=="closed"&&e.close()}ensureCtx(){return this.ctx||(this.ctx=new AudioContext,this.master=this.ctx.createGain(),this.master.gain.value=this.muted?0:.5,this.master.connect(this.ctx.destination)),this.ctx.state==="suspended"&&this.ctx.resume(),this.ctx}toggleMute(){return this.muted=!this.muted,F2(this.muted),this.master&&(this.master.gain.value=this.muted?0:.5),this.muted}sfx(e){if(this.disposed||this.muted)return;const i=this.ensureCtx();if(!this.master)return;const r=i.currentTime,l={move:["triangle",220,180,.08,.15],hit:["square",160,60,.12,.3],pickup:["sine",660,990,.12,.25],ui:["sine",440,520,.05,.15],explosion:["sawtooth",120,30,.4,.4],win:["sine",523,1046,.5,.3],lose:["sawtooth",220,55,.6,.3]},[c,h,d,m,g]=l[e],_=i.createOscillator(),p=i.createGain();_.type=c,_.frequency.setValueAtTime(h,r),_.frequency.exponentialRampToValueAtTime(Math.max(1,d),r+m),p.gain.setValueAtTime(g,r),p.gain.exponentialRampToValueAtTime(.001,r+m),_.connect(p).connect(this.master),_.start(r),_.stop(r+m)}startMusic(){if(this.disposed)return;const e=this.ensureCtx();if(this.musicOsc)return;const i=e.createOscillator(),r=e.createGain();i.type="sine",i.frequency.value=55,r.gain.value=.06,i.connect(r).connect(this.master),i.start(),this.musicOsc=i}stopMusic(){this.musicOsc?.stop(),this.musicOsc=null}}const lp="game.",fr={get(o,e){try{const i=localStorage.getItem(lp+o);return i===null?e:JSON.parse(i)}catch{return e}},set(o,e){try{localStorage.setItem(lp+o,JSON.stringify(e))}catch{}},remove(o){try{localStorage.removeItem(lp+o)}catch{}}};let em=null;const Kx=["莫湾基黑乌砂","木那杨梅皮","会卡青蛙皮","大马坎黄砂皮","后江灰砂皮","南奇蜡壳皮"],G2=["皮壳紧实，隐约透出凉意","砂粒均匀，松花若有若无","雾层细腻，打灯见柔光","蟒带环绕，色根似有延伸","皮壳松散，裂隙难以判断"];function V2(o){aS();const e=new I2({canvas:o,antialias:!0,preserveDrawingBuffer:!0});e.setPixelRatio(Math.min(devicePixelRatio,1.8)),e.setSize(innerWidth,innerHeight,!1),e.shadowMap.enabled=!0,e.shadowMap.type=Ey,e.toneMapping=by,e.toneMappingExposure=1.1;const i=new V1;i.background=new Se(463119),i.fog=new ym(463119,9,20);const r=new ci(42,innerWidth/innerHeight,.1,60);r.position.set(5.8,4.2,7.5),r.lookAt(0,1.05,0),i.add(new Z1(12445912,1384987,1.3));const l=new $1(16773840,3.4);l.position.set(3,7,4),l.castShadow=!0,l.shadow.mapSize.set(1024,1024),i.add(l);const c=new Q1(4390832,18,12);c.position.set(-4,2,-3),i.add(c);const h=new Nn(new io(7,7.3,.35,64),new no({color:1055769,roughness:.82,metalness:.25}));h.position.y=-.25,h.receiveShadow=!0,i.add(h);const d=new Nn(new io(2.65,2.85,.35,48),new no({color:2503470,roughness:.45,metalness:.55}));d.position.y=.12,d.receiveShadow=!0,i.add(d);const m=new Nn(new Em(2.15,.025,8,80),new xm({color:5165981}));m.rotation.x=Math.PI/2,m.position.y=.32,i.add(m);const g=new xl;i.add(g);const _=new Bc(1.38,3),p=_.attributes.position;for(let vt=0;vt<p.count;vt++){const Gt=p.getX(vt),le=p.getY(vt),Me=p.getZ(vt),O=1+.065*Math.sin(Gt*9+Me*5)*Math.cos(le*8-Gt*3);p.setXYZ(vt,Gt*O*1.15,le*O*.82,Me*O)}_.computeVertexNormals();const x=new no({color:5326906,roughness:.94,metalness:.02}),M=new Nn(_,x);M.castShadow=!0,M.receiveShadow=!0,M.position.y=1.32,g.add(M);const E=new Y1({color:3524993,roughness:.18,metalness:.05,transmission:.12,thickness:1.2,clearcoat:1,emissive:473893,emissiveIntensity:.6}),b=new Nn(new Bc(1.13,3),E);b.scale.set(1.16,.8,1),b.position.y=1.32,b.visible=!1,g.add(b);const y=new Nn(new io(1.05,1.05,.055,64),new no({color:12175300,metalness:.9,roughness:.25}));y.rotation.z=Math.PI/2,y.position.set(0,2.8,0),y.castShadow=!0,i.add(y);const S=new Nn(new io(.18,.18,.1,24),new no({color:14264920,metalness:.8}));S.rotation.z=Math.PI/2,y.add(S);const U=100,N=new Float32Array(U*3),D=new Ti;D.setAttribute("position",new Bi(N,3));const I=new yx(D,new Wy({color:14862476,size:.035,transparent:!0,opacity:.7}));i.add(I);const z=new H2;let L=Math.max(0,fr.get("jade.coins",8e3)),B=fr.get("jade.collection",[]);Array.isArray(B)||(B=[]);let C=fr.get("jade.best",0),R="title",G="market",Z=[],et=null,ct=0,st=0,k=0,it=!1,j=0,xt=0,Mt="—",Ht="擦石见绿，一刀穷富。理性游戏，拒绝现实赌石。",oe=performance.now(),xe=0,H=7823,ft=0,$=0,at=0;const Et=()=>(H=H*1664525+1013904223>>>0,H/4294967296),Ut=()=>{const vt={phase:R,previousPhase:G,coins:L,stones:Z,selected:et,progress:ct,heat:st,polish:k,holding:it,value:xt,profit:et?xt-et.price:0,grade:Mt,collection:B,rounds:j,best:C,muted:z.muted,message:Ht};window.dispatchEvent(new CustomEvent("jade-state",{detail:vt}))},Rt=()=>{Z=Array.from({length:3},(vt,Gt)=>{const le=.12+Et()*.86,Me=Math.round((650+j*45+Gt*500+Et()*700)/50)*50;return{id:Date.now()+Gt,name:Kx[Math.floor(Et()*Kx.length)],price:Me,hint:G2[Math.min(4,Math.floor((1-le)*3+Et()*2))],skin:["黑乌砂","黄砂皮","灰砂皮"][Gt],quality:le,color:Et(),cracks:Et()*.65,seed:Et()*1e3}})},St=vt=>{R=vt,it=!1,Ht=vt==="cutting"?"按住切割，松开降温。过热会增加裂纹！":vt==="polishing"?"按住抛光，让翡翠呈现最佳光泽。":Ht,Ut()},kt=()=>{et=null,ct=0,st=0,k=0,xt=0,Mt="—",M.visible=!0,b.visible=!1,M.scale.set(1,1,1),M.position.x=0,b.position.x=0,x.color.setHex(5326906),y.position.y=2.8},F=(vt,Gt)=>{if(z.sfx("ui"),vt==="start"||vt==="market")kt(),Rt(),St("market");else if(vt==="buy"&&R==="market"){const le=Z.find(Me=>Me.id===Gt);if(!le||L<le.price){Ht="金币不足，换一块试试。",z.sfx("lose"),Ut();return}et=le,L-=le.price,fr.set("jade.coins",L),St("cutting")}else if(vt==="hold")it=!0;else if(vt==="release")it=!1;else if(vt==="polish"&&R==="cutting"&&ct>=1)St("polishing");else if(vt==="appraise"&&R==="polishing"){if(!et)return;xt=Math.round(et.price*(.18+et.quality*3.4+et.color*.9)*(1-Math.min(.65,et.cracks))*(.8+k*.35)),Mt=xt>et.price*3?"帝王绿":xt>et.price*1.8?"冰种阳绿":xt>et.price?"糯种飘花":"豆种翡翠",St("result"),z.sfx(xt>et.price?"win":"lose")}else vt==="sell"&&R==="result"&&et?(L+=xt,C=Math.max(C,xt),j++,B.unshift({name:et.name,grade:Mt,value:xt,color:`#${E.color.getHexString()}`,date:new Date().toLocaleDateString("zh-CN")}),B=B.slice(0,30),fr.set("jade.coins",L),fr.set("jade.best",C),fr.set("jade.collection",B),kt(),L<650?St("bankrupt"):(Rt(),St("market"))):vt==="collection"?(G=R,St("collection")):vt==="closeCollection"?St(G==="collection"?"market":G):vt==="pause"&&R!=="title"&&R!=="paused"?(G=R,St("paused")):vt==="resume"?St(G):vt==="mute"?(z.toggleMute(),Ut()):vt==="restart"&&(L=8e3,j=0,fr.set("jade.coins",L),kt(),Rt(),St("market"))},Pe=vt=>{const Gt=vt.detail;F(Gt.action,Gt.payload)},re=vt=>{vt.code==="Space"&&(vt.preventDefault(),R==="title"?F("start"):(R==="cutting"||R==="polishing")&&(it=!0)),vt.code==="Escape"&&F(R==="paused"?"resume":"pause")},Qt=vt=>{vt.code==="Space"&&(it=!1)};window.addEventListener("jade-action",Pe),window.addEventListener("keydown",re),window.addEventListener("keyup",Qt);const Ot=()=>{r.aspect=innerWidth/innerHeight,r.updateProjectionMatrix(),e.setSize(innerWidth,innerHeight,!1)};window.addEventListener("resize",Ot),window.__jadeDebug=()=>({phase:R,previousPhase:G,coins:L,stones:Z,selected:et,progress:ct,heat:st,polish:k,holding:it,value:xt,profit:et?xt-et.price:0,grade:Mt,collection:B,rounds:j,best:C,muted:z.muted,message:Ht});const ie=vt=>{const Gt=Math.min(.1,(vt-oe)/1e3);oe=vt,ft+=Gt,at+=Gt,R!=="paused"&&(g.rotation.y+=Gt*(R==="title"||R==="market"?.16:.035),m.rotation.z+=Gt*.08,R==="cutting"&&it&&ct<1?(ct=Math.min(1,ct+Gt*.19),st=Math.min(1,st+Gt*.28),y.position.y=2.8-ct*1.75,y.rotation.x+=Gt*26,st>.94&&et&&(et.cracks=Math.min(.95,et.cracks+Gt*.12)),$-=Gt,$<=0&&(z.sfx("hit"),$=.16),ct>=1&&(it=!1,M.visible=!1,b.visible=!0,E.color.setHSL(.34+(et?.color??0)*.08,.65,.32+(et?.quality??0)*.2),z.sfx("explosion"),Ht="切面已露出！进入抛光，提升成品价值。"),(at>.1||ct>=1)&&(at=0,Ut())):st=Math.max(0,st-Gt*.22),R==="polishing"&&it&&k<1&&(k=Math.min(1,k+Gt*.28),b.rotation.y+=Gt*3,E.roughness=.35-k*.28,E.clearcoat=k,k>=1&&(it=!1,z.sfx("pickup"),Ht="抛光完成，可以鉴定估价了。"),(at>.1||k>=1)&&(at=0,Ut())),y.visible=R==="cutting"||R==="title",R!=="cutting"&&(y.rotation.x+=Gt*.6));for(let le=0;le<U;le++){const Me=it&&R==="cutting";N[le*3]=Me?Math.sin(le*12.31+ft*5)*(.4+le%9*.08):0,N[le*3+1]=Me?1.2+(ft*1.7+le*.037)%1*1.2:-5,N[le*3+2]=Me?Math.cos(le*7.7+ft*3)*.65:0}D.attributes.position.needsUpdate=!0,r.position.x=5.8+Math.sin(ft*.18)*.22,r.lookAt(0,1.05,0),e.render(i,r),window.__GAME_READY__=!0,xe=requestAnimationFrame(ie)};Rt(),Ut(),xe=requestAnimationFrame(ie),em={dispose:()=>{cancelAnimationFrame(xe),z.dispose(),window.removeEventListener("jade-action",Pe),window.removeEventListener("keydown",re),window.removeEventListener("keyup",Qt),window.removeEventListener("resize",Ot),i.traverse(vt=>{(vt instanceof Nn||vt instanceof yx)&&(vt.geometry.dispose(),(Array.isArray(vt.material)?vt.material:[vt.material]).forEach(le=>le.dispose()))}),e.dispose(),delete window.__jadeDebug,window.__GAME_READY__=!1}}}function aS(){em?.dispose(),em=null}const mn=(o,e)=>window.dispatchEvent(new CustomEvent("jade-action",{detail:{action:o,payload:e}})),eo=o=>o.toLocaleString("zh-CN");function X2(){const o=dt.useRef(null),[e,i]=dt.useState(null);if(dt.useEffect(()=>{const l=o.current;if(!l)return;const c=h=>i(h.detail);return window.addEventListener("jade-state",c),V2(l),()=>{window.removeEventListener("jade-state",c),aS()}},[]),!e)return _t.jsx("div",{id:"game-root",children:_t.jsx("canvas",{id:"game-canvas",ref:o})});const r=e.phase==="cutting"||e.phase==="polishing";return _t.jsxs("div",{id:"game-root",children:[_t.jsx("canvas",{id:"game-canvas",ref:o}),_t.jsx("div",{className:"grain"}),_t.jsxs("header",{className:"topbar",children:[_t.jsxs("div",{className:"brand",children:[_t.jsx("span",{className:"seal",children:"翠"}),_t.jsxs("div",{children:[_t.jsx("b",{children:"璞玉"}),_t.jsx("small",{children:"JADE ATELIER"})]})]}),e.phase!=="title"&&_t.jsxs("div",{className:"wallet",children:[_t.jsx("small",{children:"工坊资金"}),_t.jsxs("strong",{children:["◈ ",eo(e.coins)]})]}),_t.jsxs("div",{className:"top-actions",children:[e.phase!=="title"&&_t.jsxs("button",{className:"icon-btn",onClick:()=>mn("collection"),"aria-label":"图鉴",children:["图鉴 ",_t.jsx("span",{children:e.collection.length})]}),_t.jsx("button",{className:"icon-btn",onClick:()=>mn("mute"),children:e.muted?"静音":"声音"}),!["title","paused","bankrupt"].includes(e.phase)&&_t.jsx("button",{className:"icon-btn",onClick:()=>mn("pause"),children:"暂停"})]})]}),e.phase==="title"&&_t.jsxs("main",{className:"title-screen",children:[_t.jsx("div",{className:"eyebrow",children:"一方原石 · 一场未知"}),_t.jsxs("h1",{children:["璞玉",_t.jsx("span",{children:"开石模拟器"})]}),_t.jsxs("p",{children:["观皮壳，辨松花。掌锯切割，细琢成玉。",_t.jsx("br",{}),"每一块原石，都藏着独一无二的绿意。"]}),_t.jsxs("button",{className:"primary jumbo",onClick:()=>mn("start"),children:["进入玉石工坊 ",_t.jsx("i",{children:"→"})]}),_t.jsxs("div",{className:"title-foot",children:[_t.jsx("span",{children:"3D  procedural"}),_t.jsx("span",{children:"纯虚拟体验 · 无真实交易"})]})]}),e.phase==="market"&&_t.jsxs("main",{className:"market-panel",children:[_t.jsxs("div",{className:"section-head",children:[_t.jsxs("div",{children:[_t.jsxs("span",{className:"step",children:["第 ",e.rounds+1," 场"]}),_t.jsx("h2",{children:"今日原石"})]}),_t.jsx("p",{children:"观察皮壳与商家描述，选择你的下一块璞玉。"})]}),_t.jsx("div",{className:"stone-grid",children:e.stones.map((l,c)=>_t.jsxs("article",{className:"stone-card",children:[_t.jsx("div",{className:`stone-orb orb-${c}`,children:_t.jsx("span",{children:l.skin})}),_t.jsxs("div",{className:"stone-info",children:[_t.jsxs("small",{children:["NO. ",String(c+1).padStart(2,"0")," · ",l.skin]}),_t.jsx("h3",{children:l.name}),_t.jsxs("p",{children:["“",l.hint,"”"]})]}),_t.jsxs("button",{className:"buy-btn",disabled:e.coins<l.price,onClick:()=>mn("buy",l.id),children:[_t.jsx("span",{children:"购入原石"}),_t.jsxs("b",{children:["◈ ",eo(l.price)]})]})]},l.id))}),_t.jsx("p",{className:"market-note",children:"提示：描述并非绝对可靠，价格也不代表品质。"})]}),r&&_t.jsxs("main",{className:"work-panel",children:[_t.jsxs("div",{className:"work-title",children:[_t.jsx("span",{className:"step",children:e.phase==="cutting"?"01 / 切割":"02 / 抛光"}),_t.jsx("h2",{children:e.selected?.name}),_t.jsx("p",{children:e.message})]}),_t.jsxs("div",{className:"meter-block",children:[_t.jsxs("div",{className:"meter-label",children:[_t.jsx("span",{children:e.phase==="cutting"?"切割进度":"抛光程度"}),_t.jsxs("b",{children:[Math.floor((e.phase==="cutting"?e.progress:e.polish)*100),"%"]})]}),_t.jsx("div",{className:"meter",children:_t.jsx("i",{style:{width:`${(e.phase==="cutting"?e.progress:e.polish)*100}%`}})}),e.phase==="cutting"&&_t.jsxs(_t.Fragment,{children:[_t.jsxs("div",{className:"meter-label heat-label",children:[_t.jsx("span",{children:"锯片温度"}),_t.jsx("b",{className:e.heat>.85?"danger":"",children:e.heat>.85?"过热！立即松手":e.heat>.6?"温度偏高":"运行稳定"})]}),_t.jsx("div",{className:"meter heat",children:_t.jsx("i",{style:{width:`${e.heat*100}%`}})})]})]}),e.phase==="cutting"&&e.progress<1&&_t.jsxs("button",{className:`hold-btn ${e.holding?"active":""}`,onPointerDown:l=>{l.currentTarget.setPointerCapture(l.pointerId),mn("hold")},onPointerUp:()=>mn("release"),onPointerCancel:()=>mn("release"),onPointerLeave:()=>mn("release"),children:[_t.jsx("span",{className:"hold-ring"}),"按住切割",_t.jsx("small",{children:"松开可降温"})]}),e.phase==="polishing"&&e.polish<1&&_t.jsxs("button",{className:`hold-btn ${e.holding?"active":""}`,onPointerDown:l=>{l.currentTarget.setPointerCapture(l.pointerId),mn("hold")},onPointerUp:()=>mn("release"),onPointerCancel:()=>mn("release"),onPointerLeave:()=>mn("release"),children:[_t.jsx("span",{className:"hold-ring"}),"按住抛光",_t.jsx("small",{children:"越细腻，价值越高"})]}),e.phase==="cutting"&&e.progress>=1&&_t.jsx("button",{className:"primary",onClick:()=>mn("polish"),children:"下一步 · 精细抛光 →"}),e.phase==="polishing"&&_t.jsx("button",{className:"primary",disabled:e.polish<.35,onClick:()=>mn("appraise"),children:e.polish<.35?"至少抛光至 35%":"完成 · 鉴定估价 →"})]}),e.phase==="result"&&_t.jsxs("main",{className:"result-panel",children:[_t.jsx("span",{className:"eyebrow",children:"鉴定证书 · CERTIFICATE"}),_t.jsx("h2",{children:e.grade}),_t.jsxs("div",{className:"value",children:[_t.jsx("small",{children:"成品估价"}),_t.jsxs("strong",{children:["◈ ",eo(e.value)]})]}),_t.jsxs("div",{className:`verdict ${e.profit>=0?"up":"down"}`,children:[e.profit>=0?"大涨":"切垮"," ",_t.jsxs("b",{children:[e.profit>=0?"+":"",eo(e.profit)]})]}),_t.jsx("p",{children:e.profit>=0?"种水与颜色相得益彰，这一刀切出了惊喜。":"玉肉未达预期。赌石有风险，下一块再仔细看看。"}),_t.jsx("button",{className:"primary jumbo",onClick:()=>mn("sell"),children:"售出并收入图鉴 →"})]}),e.phase==="collection"&&_t.jsxs("main",{className:"modal collection-panel",children:[_t.jsxs("div",{className:"modal-head",children:[_t.jsxs("div",{children:[_t.jsx("span",{className:"eyebrow",children:"PRIVATE COLLECTION"}),_t.jsx("h2",{children:"璞玉图鉴"})]}),_t.jsx("button",{className:"close",onClick:()=>mn("closeCollection"),children:"×"})]}),e.collection.length===0?_t.jsxs("div",{className:"empty",children:["尚无藏品",_t.jsx("br",{}),_t.jsx("small",{children:"完成一次开石后，翡翠会收藏在这里。"})]}):_t.jsx("div",{className:"gem-list",children:e.collection.map((l,c)=>_t.jsxs("div",{className:"gem-row",children:[_t.jsx("span",{className:"gem-dot",style:{background:l.color}}),_t.jsxs("div",{children:[_t.jsx("b",{children:l.grade}),_t.jsxs("small",{children:[l.name," · ",l.date]})]}),_t.jsxs("strong",{children:["◈ ",eo(l.value)]})]},c))}),_t.jsxs("div",{className:"collection-total",children:["历史最高估价 ",_t.jsxs("b",{children:["◈ ",eo(e.best)]})]})]}),e.phase==="paused"&&_t.jsxs("main",{className:"modal pause-panel",children:[_t.jsx("span",{className:"eyebrow",children:"TAKE A BREATH"}),_t.jsx("h2",{children:"工坊已暂停"}),_t.jsx("p",{children:"刀止，心静。你的进度已保留。"}),_t.jsx("button",{className:"primary",onClick:()=>mn("resume"),children:"继续开石"}),_t.jsx("button",{className:"text-btn",onClick:()=>mn("market"),children:"放弃本次，返回市场"})]}),e.phase==="bankrupt"&&_t.jsxs("main",{className:"modal pause-panel",children:[_t.jsx("span",{className:"eyebrow",children:"WORKSHOP CLOSED"}),_t.jsx("h2",{children:"资金不足"}),_t.jsx("p",{children:"这段开石旅程暂告一段落。重新开始，再试一次眼光。"}),_t.jsx("button",{className:"primary",onClick:()=>mn("restart"),children:"重新开张"})]}),e.phase!=="title"&&_t.jsxs("footer",{children:["虚拟游戏 · 请勿参与现实赌石 ",_t.jsx("span",{children:"进度仅保存在本机浏览器"})]})]})}function k2(){return _t.jsx(KT,{children:_t.jsx(vy,{path:"/",element:_t.jsx(X2,{})})})}ZE.createRoot(document.getElementById("root")).render(_t.jsx(dt.StrictMode,{children:_t.jsx(yb,{children:_t.jsx(k2,{})})}));
