import { useEffect, useRef, useState } from 'react'
import { startGame, stopGame } from '@/game/boot'
import type { GameSnapshot } from '@/game/types'

const send = (action: string, payload?: number) => window.dispatchEvent(new CustomEvent('jade-action', { detail: { action, payload } }))
const money = (n: number) => n.toLocaleString('zh-CN')

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [s, setS] = useState<GameSnapshot | null>(null)
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const update = (e: Event) => setS((e as CustomEvent<GameSnapshot>).detail)
    window.addEventListener('jade-state', update)
    startGame(canvas)
    return () => { window.removeEventListener('jade-state', update); stopGame() }
  }, [])
  if (!s) return <div id="game-root"><canvas id="game-canvas" ref={canvasRef} /></div>
  const work = s.phase === 'cutting' || s.phase === 'polishing'
  return (
    <div id="game-root">
      <canvas id="game-canvas" ref={canvasRef} />
      <div className="grain" />
      <header className="topbar">
        <div className="brand"><span className="seal">翠</span><div><b>璞玉</b><small>JADE ATELIER</small></div></div>
        {s.phase !== 'title' && <div className="wallet"><small>工坊资金</small><strong>◈ {money(s.coins)}</strong></div>}
        <div className="top-actions">
          {s.phase !== 'title' && <button className="icon-btn" onClick={() => send('collection')} aria-label="图鉴">图鉴 <span>{s.collection.length}</span></button>}
          <button className="icon-btn" onClick={() => send('mute')}>{s.muted ? '静音' : '声音'}</button>
          {!['title', 'paused', 'bankrupt'].includes(s.phase) && <button className="icon-btn" onClick={() => send('pause')}>暂停</button>}
        </div>
      </header>

      {s.phase === 'title' && <main className="title-screen">
        <div className="eyebrow">一方原石 · 一场未知</div>
        <h1>璞玉<span>开石模拟器</span></h1>
        <p>观皮壳，辨松花。掌锯切割，细琢成玉。<br />每一块原石，都藏着独一无二的绿意。</p>
        <button className="primary jumbo" onClick={() => send('start')}>进入玉石工坊 <i>→</i></button>
        <div className="title-foot"><span>3D  procedural</span><span>纯虚拟体验 · 无真实交易</span></div>
      </main>}

      {s.phase === 'market' && <main className="market-panel">
        <div className="section-head"><div><span className="step">第 {s.rounds + 1} 场</span><h2>今日原石</h2></div><p>观察皮壳与商家描述，选择你的下一块璞玉。</p></div>
        <div className="stone-grid">
          {s.stones.map((stone, i) => <article className="stone-card" key={stone.id}>
            <div className={`stone-orb orb-${i}`}><span>{stone.skin}</span></div>
            <div className="stone-info"><small>NO. {String(i + 1).padStart(2, '0')} · {stone.skin}</small><h3>{stone.name}</h3><p>“{stone.hint}”</p></div>
            <button className="buy-btn" disabled={s.coins < stone.price} onClick={() => send('buy', stone.id)}><span>购入原石</span><b>◈ {money(stone.price)}</b></button>
          </article>)}
        </div>
        <p className="market-note">提示：描述并非绝对可靠，价格也不代表品质。</p>
      </main>}

      {work && <main className="work-panel">
        <div className="work-title"><span className="step">{s.phase === 'cutting' ? '01 / 切割' : '02 / 抛光'}</span><h2>{s.selected?.name}</h2><p>{s.message}</p></div>
        <div className="meter-block">
          <div className="meter-label"><span>{s.phase === 'cutting' ? '切割进度' : '抛光程度'}</span><b>{Math.floor((s.phase === 'cutting' ? s.progress : s.polish) * 100)}%</b></div>
          <div className="meter"><i style={{ width: `${(s.phase === 'cutting' ? s.progress : s.polish) * 100}%` }} /></div>
          {s.phase === 'cutting' && <><div className="meter-label heat-label"><span>锯片温度</span><b className={s.heat > .85 ? 'danger' : ''}>{s.heat > .85 ? '过热！立即松手' : s.heat > .6 ? '温度偏高' : '运行稳定'}</b></div><div className="meter heat"><i style={{ width: `${s.heat * 100}%` }} /></div></>}
        </div>
        {s.phase === 'cutting' && s.progress < 1 && <button className={`hold-btn ${s.holding ? 'active' : ''}`} onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); send('hold') }} onPointerUp={() => send('release')} onPointerCancel={() => send('release')} onPointerLeave={() => send('release')}><span className="hold-ring" />按住切割<small>松开可降温</small></button>}
        {s.phase === 'polishing' && s.polish < 1 && <button className={`hold-btn ${s.holding ? 'active' : ''}`} onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); send('hold') }} onPointerUp={() => send('release')} onPointerCancel={() => send('release')} onPointerLeave={() => send('release')}><span className="hold-ring" />按住抛光<small>越细腻，价值越高</small></button>}
        {s.phase === 'cutting' && s.progress >= 1 && <button className="primary" onClick={() => send('polish')}>下一步 · 精细抛光 →</button>}
        {s.phase === 'polishing' && <button className="primary" disabled={s.polish < .35} onClick={() => send('appraise')}>{s.polish < .35 ? '至少抛光至 35%' : '完成 · 鉴定估价 →'}</button>}
      </main>}

      {s.phase === 'result' && <main className="result-panel">
        <span className="eyebrow">鉴定证书 · CERTIFICATE</span><h2>{s.grade}</h2>
        <div className="value"><small>成品估价</small><strong>◈ {money(s.value)}</strong></div>
        <div className={`verdict ${s.profit >= 0 ? 'up' : 'down'}`}>{s.profit >= 0 ? '大涨' : '切垮'} <b>{s.profit >= 0 ? '+' : ''}{money(s.profit)}</b></div>
        <p>{s.profit >= 0 ? '种水与颜色相得益彰，这一刀切出了惊喜。' : '玉肉未达预期。赌石有风险，下一块再仔细看看。'}</p>
        <button className="primary jumbo" onClick={() => send('sell')}>售出并收入图鉴 →</button>
      </main>}

      {s.phase === 'collection' && <main className="modal collection-panel">
        <div className="modal-head"><div><span className="eyebrow">PRIVATE COLLECTION</span><h2>璞玉图鉴</h2></div><button className="close" onClick={() => send('closeCollection')}>×</button></div>
        {s.collection.length === 0 ? <div className="empty">尚无藏品<br /><small>完成一次开石后，翡翠会收藏在这里。</small></div> : <div className="gem-list">{s.collection.map((g, i) => <div className="gem-row" key={i}><span className="gem-dot" style={{ background: g.color }} /><div><b>{g.grade}</b><small>{g.name} · {g.date}</small></div><strong>◈ {money(g.value)}</strong></div>)}</div>}
        <div className="collection-total">历史最高估价 <b>◈ {money(s.best)}</b></div>
      </main>}

      {s.phase === 'paused' && <main className="modal pause-panel"><span className="eyebrow">TAKE A BREATH</span><h2>工坊已暂停</h2><p>刀止，心静。你的进度已保留。</p><button className="primary" onClick={() => send('resume')}>继续开石</button><button className="text-btn" onClick={() => send('market')}>放弃本次，返回市场</button></main>}
      {s.phase === 'bankrupt' && <main className="modal pause-panel"><span className="eyebrow">WORKSHOP CLOSED</span><h2>资金不足</h2><p>这段开石旅程暂告一段落。重新开始，再试一次眼光。</p><button className="primary" onClick={() => send('restart')}>重新开张</button></main>}
      {s.phase !== 'title' && <footer>虚拟游戏 · 请勿参与现实赌石 <span>进度仅保存在本机浏览器</span></footer>}
    </div>
  )
}
