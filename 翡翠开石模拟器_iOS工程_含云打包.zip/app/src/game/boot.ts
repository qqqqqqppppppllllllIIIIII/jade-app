import * as THREE from "three";
import { AudioSystem } from "./audio";
import { storage } from "./storage";
import type { GameSnapshot, GemRecord, Phase, Stone } from "./types";

declare global {
  interface Window {
    __GAME_READY__?: boolean;
    __jadeDebug?: () => GameSnapshot;
  }
}

let session: { dispose: () => void } | null = null;
const NAMES = ["莫湾基黑乌砂", "木那杨梅皮", "会卡青蛙皮", "大马坎黄砂皮", "后江灰砂皮", "南奇蜡壳皮"];
const HINTS = ["皮壳紧实，隐约透出凉意", "砂粒均匀，松花若有若无", "雾层细腻，打灯见柔光", "蟒带环绕，色根似有延伸", "皮壳松散，裂隙难以判断"];

export function startGame(canvas: HTMLCanvasElement): void {
  stopGame();
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 1.8));
  renderer.setSize(innerWidth, innerHeight, false);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x07110f);
  scene.fog = new THREE.Fog(0x07110f, 9, 20);
  const camera = new THREE.PerspectiveCamera(42, innerWidth / innerHeight, 0.1, 60);
  camera.position.set(5.8, 4.2, 7.5);
  camera.lookAt(0, 1.05, 0);

  scene.add(new THREE.HemisphereLight(0xbde8d8, 0x15221b, 1.3));
  const key = new THREE.DirectionalLight(0xfff2d0, 3.4);
  key.position.set(3, 7, 4); key.castShadow = true;
  key.shadow.mapSize.set(1024, 1024); scene.add(key);
  const rim = new THREE.PointLight(0x42ffb0, 18, 12); rim.position.set(-4, 2, -3); scene.add(rim);

  const floor = new THREE.Mesh(new THREE.CylinderGeometry(7, 7.3, 0.35, 64), new THREE.MeshStandardMaterial({ color: 0x101c19, roughness: 0.82, metalness: 0.25 }));
  floor.position.y = -0.25; floor.receiveShadow = true; scene.add(floor);
  const table = new THREE.Mesh(new THREE.CylinderGeometry(2.65, 2.85, 0.35, 48), new THREE.MeshStandardMaterial({ color: 0x26332e, roughness: 0.45, metalness: 0.55 }));
  table.position.y = 0.12; table.receiveShadow = true; scene.add(table);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(2.15, 0.025, 8, 80), new THREE.MeshBasicMaterial({ color: 0x4ed39d }));
  ring.rotation.x = Math.PI / 2; ring.position.y = 0.32; scene.add(ring);

  const stoneGroup = new THREE.Group(); scene.add(stoneGroup);
  const geo = new THREE.IcosahedronGeometry(1.38, 3);
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const n = 1 + 0.065 * Math.sin(x * 9 + z * 5) * Math.cos(y * 8 - x * 3);
    pos.setXYZ(i, x * n * 1.15, y * n * 0.82, z * n);
  }
  geo.computeVertexNormals();
  const stoneMat = new THREE.MeshStandardMaterial({ color: 0x51483a, roughness: 0.94, metalness: 0.02 });
  const stone = new THREE.Mesh(geo, stoneMat); stone.castShadow = true; stone.receiveShadow = true;
  stone.position.y = 1.32; stoneGroup.add(stone);

  const coreMat = new THREE.MeshPhysicalMaterial({ color: 0x35c981, roughness: 0.18, metalness: 0.05, transmission: 0.12, thickness: 1.2, clearcoat: 1, emissive: 0x073b25, emissiveIntensity: 0.6 });
  const core = new THREE.Mesh(new THREE.IcosahedronGeometry(1.13, 3), coreMat);
  core.scale.set(1.16, 0.8, 1); core.position.y = 1.32; core.visible = false; stoneGroup.add(core);

  const blade = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 1.05, 0.055, 64), new THREE.MeshStandardMaterial({ color: 0xb9c7c4, metalness: 0.9, roughness: 0.25 }));
  blade.rotation.z = Math.PI / 2; blade.position.set(0, 2.8, 0); blade.castShadow = true; scene.add(blade);
  const hub = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.1, 24), new THREE.MeshStandardMaterial({ color: 0xd9aa58, metalness: 0.8 }));
  hub.rotation.z = Math.PI / 2; blade.add(hub);

  const dustCount = 100;
  const dustArray = new Float32Array(dustCount * 3);
  const dustGeo = new THREE.BufferGeometry(); dustGeo.setAttribute("position", new THREE.BufferAttribute(dustArray, 3));
  const dust = new THREE.Points(dustGeo, new THREE.PointsMaterial({ color: 0xe2c88c, size: 0.035, transparent: true, opacity: 0.7 }));
  scene.add(dust);

  const audio = new AudioSystem();
  let coins = Math.max(0, storage.get("jade.coins", 8000));
  let collection = storage.get<GemRecord[]>("jade.collection", []);
  if (!Array.isArray(collection)) collection = [];
  let best = storage.get("jade.best", 0);
  let phase: Phase = "title", previousPhase: Phase = "market";
  let stones: Stone[] = [], selected: Stone | null = null;
  let progress = 0, heat = 0, polish = 0, holding = false, rounds = 0, value = 0, grade = "—", message = "擦石见绿，一刀穷富。理性游戏，拒绝现实赌石。";
  let last = performance.now(), raf = 0, seed = 7823, elapsed = 0, soundTick = 0, uiTick = 0;
  const rand = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

  const emit = () => {
    const snap: GameSnapshot = { phase, previousPhase, coins, stones, selected, progress, heat, polish, holding, value, profit: selected ? value - selected.price : 0, grade, collection, rounds, best, muted: audio.muted, message };
    window.dispatchEvent(new CustomEvent<GameSnapshot>("jade-state", { detail: snap }));
  };
  const makeMarket = () => {
    stones = Array.from({ length: 3 }, (_, i) => {
      const q = 0.12 + rand() * 0.86;
      const price = Math.round((650 + rounds * 45 + i * 500 + rand() * 700) / 50) * 50;
      return { id: Date.now() + i, name: NAMES[Math.floor(rand() * NAMES.length)], price, hint: HINTS[Math.min(4, Math.floor((1 - q) * 3 + rand() * 2))], skin: ["黑乌砂", "黄砂皮", "灰砂皮"][i], quality: q, color: rand(), cracks: rand() * 0.65, seed: rand() * 1000 };
    });
  };
  const setPhase = (p: Phase) => { phase = p; holding = false; message = p === "cutting" ? "按住切割，松开降温。过热会增加裂纹！" : p === "polishing" ? "按住抛光，让翡翠呈现最佳光泽。" : message; emit(); };
  const resetStone = () => {
    selected = null; progress = 0; heat = 0; polish = 0; value = 0; grade = "—";
    stone.visible = true; core.visible = false; stone.scale.set(1, 1, 1); stone.position.x = 0; core.position.x = 0;
    stoneMat.color.setHex(0x51483a); blade.position.y = 2.8;
  };
  const act = (action: string, payload?: number) => {
    audio.sfx("ui");
    if (action === "start" || action === "market") { resetStone(); makeMarket(); setPhase("market"); }
    else if (action === "buy" && phase === "market") {
      const pick = stones.find(s => s.id === payload);
      if (!pick || coins < pick.price) { message = "金币不足，换一块试试。"; audio.sfx("lose"); emit(); return; }
      selected = pick; coins -= pick.price; storage.set("jade.coins", coins); setPhase("cutting");
    } else if (action === "hold") holding = true;
    else if (action === "release") holding = false;
    else if (action === "polish" && phase === "cutting" && progress >= 1) setPhase("polishing");
    else if (action === "appraise" && phase === "polishing") {
      if (!selected) return;
      value = Math.round(selected.price * (0.18 + selected.quality * 3.4 + selected.color * 0.9) * (1 - Math.min(0.65, selected.cracks)) * (0.8 + polish * 0.35));
      grade = value > selected.price * 3 ? "帝王绿" : value > selected.price * 1.8 ? "冰种阳绿" : value > selected.price ? "糯种飘花" : "豆种翡翠";
      setPhase("result"); audio.sfx(value > selected.price ? "win" : "lose");
    } else if (action === "sell" && phase === "result" && selected) {
      coins += value; best = Math.max(best, value); rounds++;
      collection.unshift({ name: selected.name, grade, value, color: `#${coreMat.color.getHexString()}`, date: new Date().toLocaleDateString("zh-CN") });
      collection = collection.slice(0, 30); storage.set("jade.coins", coins); storage.set("jade.best", best); storage.set("jade.collection", collection);
      resetStone();
      if (coins < 650) setPhase("bankrupt"); else { makeMarket(); setPhase("market"); }
    } else if (action === "collection") { previousPhase = phase; setPhase("collection"); }
    else if (action === "closeCollection") setPhase(previousPhase === "collection" ? "market" : previousPhase);
    else if (action === "pause" && phase !== "title" && phase !== "paused") { previousPhase = phase; setPhase("paused"); }
    else if (action === "resume") setPhase(previousPhase);
    else if (action === "mute") { audio.toggleMute(); emit(); }
    else if (action === "restart") { coins = 8000; rounds = 0; storage.set("jade.coins", coins); resetStone(); makeMarket(); setPhase("market"); }
  };
  const onAction = (e: Event) => { const d = (e as CustomEvent<{ action: string; payload?: number }>).detail; act(d.action, d.payload); };
  const onKey = (e: KeyboardEvent) => {
    if (e.code === "Space") { e.preventDefault(); if (phase === "title") act("start"); else if (phase === "cutting" || phase === "polishing") holding = true; }
    if (e.code === "Escape") act(phase === "paused" ? "resume" : "pause");
  };
  const onKeyUp = (e: KeyboardEvent) => { if (e.code === "Space") holding = false; };
  window.addEventListener("jade-action", onAction); window.addEventListener("keydown", onKey); window.addEventListener("keyup", onKeyUp);

  const resize = () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight, false); };
  window.addEventListener("resize", resize);
  window.__jadeDebug = () => ({ phase, previousPhase, coins, stones, selected, progress, heat, polish, holding, value, profit: selected ? value - selected.price : 0, grade, collection, rounds, best, muted: audio.muted, message });

  const frame = (now: number) => {
    const dt = Math.min(0.1, (now - last) / 1000); last = now; elapsed += dt; uiTick += dt;
    if (phase !== "paused") {
      stoneGroup.rotation.y += dt * (phase === "title" || phase === "market" ? 0.16 : 0.035);
      ring.rotation.z += dt * 0.08;
      if (phase === "cutting" && holding && progress < 1) {
        progress = Math.min(1, progress + dt * 0.19); heat = Math.min(1, heat + dt * 0.28);
        blade.position.y = 2.8 - progress * 1.75; blade.rotation.x += dt * 26;
        if (heat > 0.94 && selected) selected.cracks = Math.min(0.95, selected.cracks + dt * 0.12);
        soundTick -= dt; if (soundTick <= 0) { audio.sfx("hit"); soundTick = 0.16; }
        if (progress >= 1) { holding = false; stone.visible = false; core.visible = true; coreMat.color.setHSL(0.34 + (selected?.color ?? 0) * 0.08, 0.65, 0.32 + (selected?.quality ?? 0) * 0.2); audio.sfx("explosion"); message = "切面已露出！进入抛光，提升成品价值。"; }
        if (uiTick > 0.1 || progress >= 1) { uiTick = 0; emit(); }
      } else heat = Math.max(0, heat - dt * 0.22);
      if (phase === "polishing" && holding && polish < 1) {
        polish = Math.min(1, polish + dt * 0.28); core.rotation.y += dt * 3;
        coreMat.roughness = 0.35 - polish * 0.28; coreMat.clearcoat = polish;
        if (polish >= 1) { holding = false; audio.sfx("pickup"); message = "抛光完成，可以鉴定估价了。"; }
        if (uiTick > 0.1 || polish >= 1) { uiTick = 0; emit(); }
      }
      blade.visible = phase === "cutting" || phase === "title";
      if (phase !== "cutting") blade.rotation.x += dt * 0.6;
    }
    for (let i = 0; i < dustCount; i++) {
      const active = holding && phase === "cutting";
      dustArray[i * 3] = active ? Math.sin(i * 12.31 + elapsed * 5) * (0.4 + (i % 9) * 0.08) : 0;
      dustArray[i * 3 + 1] = active ? 1.2 + ((elapsed * 1.7 + i * 0.037) % 1) * 1.2 : -5;
      dustArray[i * 3 + 2] = active ? Math.cos(i * 7.7 + elapsed * 3) * 0.65 : 0;
    }
    dustGeo.attributes.position.needsUpdate = true;
    camera.position.x = 5.8 + Math.sin(elapsed * 0.18) * 0.22; camera.lookAt(0, 1.05, 0);
    renderer.render(scene, camera); window.__GAME_READY__ = true;
    raf = requestAnimationFrame(frame);
  };
  makeMarket(); emit(); raf = requestAnimationFrame(frame);

  session = { dispose: () => {
    cancelAnimationFrame(raf); audio.dispose();
    window.removeEventListener("jade-action", onAction); window.removeEventListener("keydown", onKey); window.removeEventListener("keyup", onKeyUp); window.removeEventListener("resize", resize);
    scene.traverse(obj => { if (obj instanceof THREE.Mesh || obj instanceof THREE.Points) { obj.geometry.dispose(); const mats = Array.isArray(obj.material) ? obj.material : [obj.material]; mats.forEach(m => m.dispose()); } });
    renderer.dispose(); delete window.__jadeDebug; window.__GAME_READY__ = false;
  } };
}
export function stopGame(): void { session?.dispose(); session = null; }
