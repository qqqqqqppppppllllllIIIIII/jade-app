export type Phase = "title" | "market" | "cutting" | "polishing" | "result" | "collection" | "paused" | "bankrupt";

export interface Stone {
  id: number;
  name: string;
  price: number;
  hint: string;
  skin: string;
  quality: number;
  color: number;
  cracks: number;
  seed: number;
}

export interface GemRecord {
  name: string;
  grade: string;
  value: number;
  color: string;
  date: string;
}

export interface GameSnapshot {
  phase: Phase;
  previousPhase: Phase;
  coins: number;
  stones: Stone[];
  selected: Stone | null;
  progress: number;
  heat: number;
  polish: number;
  holding: boolean;
  value: number;
  profit: number;
  grade: string;
  collection: GemRecord[];
  rounds: number;
  best: number;
  muted: boolean;
  message: string;
}
