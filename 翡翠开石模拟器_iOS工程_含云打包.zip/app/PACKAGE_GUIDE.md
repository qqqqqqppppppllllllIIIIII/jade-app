# 打包未签名 IPA 使用说明

## 这是什么
`翡翠开石模拟器_iOS工程_含云打包.zip` 是整理好的 Capacitor iOS 工程，
已附带 GitHub Actions 工作流，可在云端 macOS 上自动编译并产出**未签名 ipa**。

## 为什么需要云端
.ipa 中的二进制必须用 Apple Xcode 工具链（swiftc / ibtool / actool）编译，
这些工具只能在 macOS 上运行，Linux 环境无法产出可安装的 ipa。

## 使用步骤（约 5 分钟）
1. 在 GitHub 新建一个仓库（可以私有）。
2. 把压缩包里的 `app/` 目录内容全部推上去：
   ```bash
   unzip 翡翠开石模拟器_iOS工程_含云打包.zip
   cd app
   git init && git add . && git commit -m "init"
   git remote add origin https://github.com/<你的用户名>/<仓库名>.git
   git push -u origin main
   ```
3. 打开仓库 → **Actions** 页签 → 选择 "Build Unsigned IPA" → **Run workflow**。
4. 等待约 10–15 分钟构建完成，在本次运行页面底部的 **Artifacts** 下载 `unsigned-ipa`，里面就是 `翡翠开石模拟器-unsigned.ipa`。

## 得到 ipa 之后
未签名 ipa **不能直接安装**到 iPhone，需要再签名，常见方式：
- 有 Apple 开发者账号：用 [AltStore / Sideloadly / Apple Configurator] 配合免费或付费证书签名后侧载安装。
- 无证书：可上传到蒲公英等分发平台走超级签名/企业签名（第三方服务）。
- 越狱设备可用 AppSync 之类的工具直接装。

## 工作流做了什么
1. `npm ci` 安装前端依赖
2. `npx cap sync ios` 把 web 资源同步进 iOS 工程
3. `pod install` 安装 Capacitor 原生依赖
4. `xcodebuild archive` 关闭签名（CODE_SIGNING_ALLOWED=NO）
5. 从 .xcarchive 提取 .app 打包为 Payload/*.ipa 并上传为构建产物
