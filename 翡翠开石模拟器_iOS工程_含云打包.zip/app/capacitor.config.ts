import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.puyu.jadesimulator',
  appName: '璞玉开石模拟器',
  webDir: 'dist'
};

export default config;
